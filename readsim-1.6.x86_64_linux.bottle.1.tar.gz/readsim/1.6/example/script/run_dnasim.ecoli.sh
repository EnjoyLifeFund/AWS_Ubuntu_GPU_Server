#!/bin/bash

cd ../ecoli

../../src/dnasim.py --ploidy 10 --het 0.05 --pre NC_000913 NC_000913.fna

