/* ##############################################################################################
**
** Copyright 2012 CNRS, INPT
**  
** This file is part of qr_mumps.
**  
** qr_mumps is free software: you can redistribute it and/or modify
** it under the terms of the GNU Lesser General Public License as 
** published by the Free Software Foundation, either version 3 of 
** the License, or (at your option) any later version.
**  
** qr_mumps is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU Lesser General Public License for more details.
**  
** You can find a copy of the GNU Lesser General Public License
** in the qr_mumps/doc directory.
**
** ##############################################################################################*/


/*##############################################################################################*/
/** @file qrm_mumps.h
 * Header file for the C interface
 *
 * $Date: 2016-01-29 22:22:30 +0100 (Fri, 29 Jan 2016) $
 * $Author: abuttari $
 * $Version: 1.1$
 * $Revision: 2075 $
 *
 */
/*##############################################################################################*/

#if defined(zprec) || defined(cprec)
#include <complex.h>
#endif

#include <string.h>

struct cqrm_spmat_type_c{
  int          *irn, *jcn;
  float _Complex  *val;
  int          m, n, nz;
  int          *cperm_in, *rperm, *cperm;
  int          icntl[20];
  double       rcntl[10];
  long int     gstats[10];
  int          h; 
  void         *mat_ptr;
};


double qrm_swtime();
void cqrm_get_r_c(struct cqrm_spmat_type_c *qrm_spmat_c, struct cqrm_spmat_type_c *r);
void cqrm_spmat_init_c(struct cqrm_spmat_type_c *qrm_spmat_c);
void cqrm_spmat_destroy_c(struct cqrm_spmat_type_c *qrm_spmat_c);
void cqrm_readmat_c(char *matfile, struct cqrm_spmat_type_c *qrm_spmat_c);
void cqrm_analyse_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char transp);
void cqrm_factorize_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char transp);
void cqrm_solve_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char transp,
                  float _Complex *b, float _Complex *x, const int nrhs);
void cqrm_apply_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char transp,
                  float _Complex *b, const int nrhs);
void cqrm_matmul_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char transp,
                   const float _Complex alpha, float _Complex *x, 
                   const float _Complex beta, float _Complex *y, 
                   const int nrhs);
void cqrm_matnrm_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char ntype, 
                   float *nrm);
void cqrm_vecnrm_c(const float _Complex *x, const int n, const int nrhs, 
                   const char ntype, float *nrm);
void cqrm_least_squares_c(struct cqrm_spmat_type_c *qrm_spmat_c, float _Complex *b, 
                          float _Complex *x, const int nrhs);
void cqrm_min_norm_c(struct cqrm_spmat_type_c *qrm_spmat_c, float _Complex *b, 
                          float _Complex *x, const int nrhs);
void cqrm_residual_norm_c(struct cqrm_spmat_type_c *qrm_spmat_c, float _Complex *b, 
                          float _Complex *x, const int nrhs, float *nrm);
void cqrm_residual_orth_c(struct cqrm_spmat_type_c *qrm_spmat_c, float _Complex *r, 
                          const int nrhs, float *nrm);

void qrm_gseti_c(const char *string, int val);
void qrm_ggeti_c(const char *string, int *val);
void qrm_ggetii_c(const char *string, long long *val);

void cqrm_pseti_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char *string, int val);
void cqrm_pgeti_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char *string, int *val);
void cqrm_pgetii_c(struct cqrm_spmat_type_c *qrm_spmat_c, const char *string, long long *val);
void qrm_err_check_c();

enum icntl{ 
  qrm_ordering_,
  qrm_sing_,
  qrm_minamalg_,
  qrm_nb_,
  qrm_keeph_,
  qrm_ib_,
  qrm_rhsnb_,
  qrm_rhsnthreads_};

enum rcntl{ 
  qrm_amalgthr_};

enum ords{
  qrm_auto=0,
  qrm_natural_,
  qrm_given_,
  qrm_colamd_,
  qrm_metis_,
  qrm_scotch_};

enum gstats{
  qrm_e_facto_flops_=0,
  qrm_e_nnz_r_,
  qrm_e_nnz_h_,
  qrm_facto_flops_,
  qrm_nnz_r_,
  qrm_nnz_h_,



};

enum yn{
  qrm_no_=0,
  qrm_yes_};
