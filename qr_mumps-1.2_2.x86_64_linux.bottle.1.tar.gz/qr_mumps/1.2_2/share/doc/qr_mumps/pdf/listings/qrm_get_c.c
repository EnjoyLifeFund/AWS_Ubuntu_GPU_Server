void qrm_get_c(string, val);
const char *string;
int *val;


void sqrm_geti_c(qrm_mat_c, string, 
                 val);
struct sqrm_spmat_type_c *qrm_mat_c,;
const char *string;
int *val;
