void sqrm_least_squares_c(qrm_mat_c, b, 
                          x, nrhs);
struct sqrm_spmat_type_c *qrm_mat_c;
float *b;
float *x;
const int nrhs;
