void sqrm_apply_c(qrm_mat_c, transp,
                  b, nrhs);
struct sqrm_spmat_type_c *qrm_mat_c;
const char transp;
float *b;
const int nrhs;
