void sqrm_residual_orth_c(qrm_mat_c, r, 
                          nrhs, nrm);
struct sqrm_spmat_type_c *qrm_mat_c;
float *r;
const int nrhs;
float *nrm;
