void qrm_err_check( );
