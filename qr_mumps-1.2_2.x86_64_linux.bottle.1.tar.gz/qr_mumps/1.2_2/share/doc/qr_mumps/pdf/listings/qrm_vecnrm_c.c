void sqrm_vecnrm_c(x, n, nrhs, 
                   ntype, nrm);
const float *x;
const int n;
const int nrhs; 
const char ntype;
float *nrm;
