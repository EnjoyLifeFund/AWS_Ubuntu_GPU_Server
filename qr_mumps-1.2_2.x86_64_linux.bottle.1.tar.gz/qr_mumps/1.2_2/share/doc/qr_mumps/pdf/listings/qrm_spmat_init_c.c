void sqrm_spmat_init_c(qrm_mat_c);
struct sqrm_spmat_type_c *qrm_mat_c;
