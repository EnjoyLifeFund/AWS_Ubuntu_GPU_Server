void sqrm_factorize_c(qrm_mat_c, 
                      transp)
struct sqrm_spmat_type_c *qrm_mat_c;
const char transp;

