void sqrm_matnrm_c(qrm_mat_c, ntype, 
                   nrm);
struct sqrm_spmat_type_c *qrm_mat_c;
const char ntype;
float *nrm;
