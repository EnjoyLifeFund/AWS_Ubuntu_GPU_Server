## Overview

This is an example of how you can embed Apollo inside your Java application.

## Prereqs

- Install a Java SDK
- Install [Maven](http://maven.apache.org/download.html) 

## Building

Run:

    mvn install

## Running the Example

In a terminal window run:

    java -cp '../../lib/*':target/classes example.EmbeddedBroker

