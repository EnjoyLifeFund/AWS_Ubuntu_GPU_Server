class OSwitch
  PREFIX = File.expand_path('../..', File.dirname(__FILE__))
end
