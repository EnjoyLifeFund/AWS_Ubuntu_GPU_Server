class Oswitch < Formula
  desc "Docker environments to work with Bioinformatics tools"
  homepage "https://github.com/yeban/oswitch"
  url "https://github.com/yeban/oswitch/archive/v0.2.7.tar.gz"
  sha256 "69090f628213fb93dccedbd8772d462fb7100c20c4495d4079d5f4d9bb84524c"

  depends_on :ruby => "2.0" if OS.linux?

  def install
    # Build gem and install to prefix.
    system "gem", "build", "oswitch.gemspec"
    system "gem", "install", "-i", prefix, "oswitch-#{version}.gem"

    # Re-write RubyGem generated bin stub to load oswitch from prefix.
    inreplace "#{bin}/oswitch" do |s|
      s.gsub!(/require 'rubygems'/,
        "ENV['GEM_HOME']='#{prefix}'\nrequire 'rubygems'")
    end
  end
end
