/*	Public domain	*/

#ifndef _AGAR_AU_PUBLIC_H_
#define _AGAR_AU_PUBLIC_H_
#define _AGAR_AU_PUBLIC
#include <agar/core/core_begin.h>
#include <agar/au/au_init.h>
#include <agar/au/au_dev_out.h>
#include <agar/au/au_wave.h>
#include <agar/core/core_close.h>
#endif
