#ifndef _AGAR_AU_INIT_H_
#define _AGAR_AU_INIT_H_
#include <agar/au/begin.h>

/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC int AU_InitSubsystem(void);
extern DECLSPEC void AU_DestroySubsystem(void);
__END_DECLS
/* Close generated block */

#include <agar/au/close.h>
#endif	/* _AGAR_AU_INIT_H_ */
