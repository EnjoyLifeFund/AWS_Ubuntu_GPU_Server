/*	Public domain	*/

#ifndef _USE_AGAR_TYPES
# ifdef _AGAR_CORE_DEFINED_UINT
#  undef Uint
# endif
# ifdef _AGAR_CORE_DEFINED_UCHAR
#  undef Uchar
# endif
# ifdef _AGAR_CORE_DEFINED_ULONG
#  undef Ulong
# endif
# ifdef _AGAR_CORE_DEFINED_UINT8
#  undef Uint8
# endif
# ifdef _AGAR_CORE_DEFINED_SINT8
#  undef Sint8
# endif
# ifdef _AGAR_CORE_DEFINED_UINT16
#  undef Uint16
# endif
# ifdef _AGAR_CORE_DEFINED_SINT16
#  undef Sint16
# endif
# ifdef _AGAR_CORE_DEFINED_UINT32
#  undef Uint32
# endif
# ifdef _AGAR_CORE_DEFINED_SINT32
#  undef Sint32
# endif
# ifdef _AGAR_CORE_DEFINED_UINT64
#  undef Uint64
# endif
# ifdef _AGAR_CORE_DEFINED_SINT64
#  undef Sint64
# endif
#endif /* _USE_AGAR_TYPES */
