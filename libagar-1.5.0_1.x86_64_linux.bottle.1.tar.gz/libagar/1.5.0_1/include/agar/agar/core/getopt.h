/*	Public domain	*/

#include <agar/core/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC int AG_Getopt(int, char * const [], const char *, char **, int *);
__END_DECLS
/* Close generated block */
#include <agar/core/close.h>
