#ifndef PNG_LIBS
#define PNG_LIBS "-L@@HOMEBREW_PREFIX@@/Cellar/libpng/1.6.34/lib -lpng16"
#endif
