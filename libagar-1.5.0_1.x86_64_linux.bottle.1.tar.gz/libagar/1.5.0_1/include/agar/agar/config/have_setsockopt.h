#ifndef HAVE_SETSOCKOPT
#define HAVE_SETSOCKOPT "yes"
#endif
