#ifndef MODULEDIR
#define MODULEDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/lib"
#endif
