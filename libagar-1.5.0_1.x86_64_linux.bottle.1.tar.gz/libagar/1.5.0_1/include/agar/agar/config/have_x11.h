#ifndef HAVE_X11
#define HAVE_X11 "yes"
#endif
