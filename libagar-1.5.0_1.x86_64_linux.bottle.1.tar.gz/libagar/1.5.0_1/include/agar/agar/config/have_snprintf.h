#ifndef HAVE_SNPRINTF
#define HAVE_SNPRINTF "yes"
#endif
