#ifndef HAVE_PURE_ATTRIBUTE
#define HAVE_PURE_ATTRIBUTE "yes"
#endif
