#ifndef CLOCK_LIBS
#define CLOCK_LIBS ""
#endif
