#ifndef HAVE_SSE2
#define HAVE_SSE2 "yes"
#endif
