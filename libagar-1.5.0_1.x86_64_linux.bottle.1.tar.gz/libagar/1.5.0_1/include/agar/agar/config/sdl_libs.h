#ifndef SDL_LIBS
#define SDL_LIBS "-L@@HOMEBREW_PREFIX@@/lib -Wl,-rpath,@@HOMEBREW_PREFIX@@/lib -lSDL -lpthread"
#endif
