#ifndef INCLDIR
#define INCLDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/include/agar"
#endif
