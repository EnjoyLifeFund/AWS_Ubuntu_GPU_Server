#ifndef HAVE_GETPWUID
#define HAVE_GETPWUID "yes"
#endif
