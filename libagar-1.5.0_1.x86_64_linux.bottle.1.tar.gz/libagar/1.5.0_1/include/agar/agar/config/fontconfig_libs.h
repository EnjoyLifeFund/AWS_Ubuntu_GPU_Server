#ifndef FONTCONFIG_LIBS
#define FONTCONFIG_LIBS "-L@@HOMEBREW_PREFIX@@/opt/freetype/lib -lfontconfig -lfreetype"
#endif
