#ifndef AG_THREADS
#define AG_THREADS "yes"
#endif
