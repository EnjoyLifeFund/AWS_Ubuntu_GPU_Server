#ifndef HAVE_PNG
#define HAVE_PNG "yes"
#endif
