#ifndef HAVE_CLOCK_GETTIME
#define HAVE_CLOCK_GETTIME "yes"
#endif
