#ifndef HAVE_GETUID
#define HAVE_GETUID "yes"
#endif
