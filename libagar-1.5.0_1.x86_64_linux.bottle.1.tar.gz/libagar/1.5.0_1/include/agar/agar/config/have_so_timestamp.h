#ifndef HAVE_SO_TIMESTAMP
#define HAVE_SO_TIMESTAMP "yes"
#endif
