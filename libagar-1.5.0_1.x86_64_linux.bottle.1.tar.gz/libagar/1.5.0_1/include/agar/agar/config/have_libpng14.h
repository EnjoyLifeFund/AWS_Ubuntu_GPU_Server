#ifndef HAVE_LIBPNG14
#define HAVE_LIBPNG14 "yes"
#endif
