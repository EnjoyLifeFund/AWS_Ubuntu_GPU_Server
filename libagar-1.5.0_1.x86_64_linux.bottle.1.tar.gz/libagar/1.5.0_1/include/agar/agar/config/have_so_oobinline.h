#ifndef HAVE_SO_OOBINLINE
#define HAVE_SO_OOBINLINE "yes"
#endif
