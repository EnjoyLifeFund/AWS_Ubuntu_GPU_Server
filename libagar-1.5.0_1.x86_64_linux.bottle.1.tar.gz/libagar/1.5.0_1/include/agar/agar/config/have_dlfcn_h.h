#ifndef HAVE_DLFCN_H
#define HAVE_DLFCN_H "yes"
#endif
