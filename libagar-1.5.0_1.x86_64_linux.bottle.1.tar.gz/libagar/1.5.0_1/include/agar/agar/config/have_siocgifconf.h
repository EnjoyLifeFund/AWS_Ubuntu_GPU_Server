#ifndef HAVE_SIOCGIFCONF
#define HAVE_SIOCGIFCONF "yes"
#endif
