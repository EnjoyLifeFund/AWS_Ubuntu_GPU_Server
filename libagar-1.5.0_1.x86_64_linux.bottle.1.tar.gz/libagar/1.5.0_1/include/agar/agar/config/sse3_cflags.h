#ifndef SSE3_CFLAGS
#define SSE3_CFLAGS "-msse3"
#endif
