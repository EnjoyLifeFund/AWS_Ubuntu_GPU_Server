#ifndef HAVE_ASPRINTF
#define HAVE_ASPRINTF "yes"
#endif
