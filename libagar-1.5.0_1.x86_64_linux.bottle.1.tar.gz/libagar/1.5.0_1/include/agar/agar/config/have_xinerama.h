#ifndef HAVE_XINERAMA
#define HAVE_XINERAMA "yes"
#endif
