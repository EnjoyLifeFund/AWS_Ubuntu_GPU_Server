#ifndef DOUBLE_PRECISION
#define DOUBLE_PRECISION "yes"
#endif
