#ifndef FREETYPE_CFLAGS
#define FREETYPE_CFLAGS "-I@@HOMEBREW_PREFIX@@/opt/freetype/include/freetype2"
#endif
