#ifndef STATEDIR
#define STATEDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/var"
#endif
