#ifndef CLOCK_CFLAGS
#define CLOCK_CFLAGS ""
#endif
