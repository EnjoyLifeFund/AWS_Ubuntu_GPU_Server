#ifndef X11_LIBS
#define X11_LIBS "-lX11"
#endif
