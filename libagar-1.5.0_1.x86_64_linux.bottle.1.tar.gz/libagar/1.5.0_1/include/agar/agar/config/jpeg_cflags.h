#ifndef JPEG_CFLAGS
#define JPEG_CFLAGS "-I/usr/include"
#endif
