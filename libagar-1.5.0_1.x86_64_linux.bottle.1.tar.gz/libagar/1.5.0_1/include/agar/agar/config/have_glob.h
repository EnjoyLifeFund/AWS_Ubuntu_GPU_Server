#ifndef HAVE_GLOB
#define HAVE_GLOB "yes"
#endif
