#ifndef HAVE_SSE3
#define HAVE_SSE3 "yes"
#endif
