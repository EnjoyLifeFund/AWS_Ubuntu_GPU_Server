#ifndef HAVE_TIMERFD
#define HAVE_TIMERFD "yes"
#endif
