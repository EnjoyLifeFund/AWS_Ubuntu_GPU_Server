#ifndef HAVE_SO_REUSEPORT
#define HAVE_SO_REUSEPORT "yes"
#endif
