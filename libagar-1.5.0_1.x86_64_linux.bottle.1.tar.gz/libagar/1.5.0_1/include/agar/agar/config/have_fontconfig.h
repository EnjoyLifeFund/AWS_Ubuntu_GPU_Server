#ifndef HAVE_FONTCONFIG
#define HAVE_FONTCONFIG "yes"
#endif
