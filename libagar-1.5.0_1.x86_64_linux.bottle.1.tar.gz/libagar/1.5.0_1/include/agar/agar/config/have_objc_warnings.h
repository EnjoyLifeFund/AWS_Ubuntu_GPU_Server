#ifndef HAVE_OBJC_WARNINGS
#define HAVE_OBJC_WARNINGS "yes"
#endif
