#ifndef HAVE_JPEG
#define HAVE_JPEG "yes"
#endif
