#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "-L@@HOMEBREW_PREFIX@@/opt/freetype/lib -lfreetype"
#endif
