#ifndef JPEG_LIBS
#define JPEG_LIBS "-L/usr/lib -ljpeg"
#endif
