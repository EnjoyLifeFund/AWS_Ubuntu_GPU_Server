#ifndef FONTCONFIG_CFLAGS
#define FONTCONFIG_CFLAGS "-I@@HOMEBREW_PREFIX@@/opt/freetype/include/freetype2 -I/usr/include/freetype2"
#endif
