#ifndef HAVE_INT64_T
#define HAVE_INT64_T "yes"
#endif
