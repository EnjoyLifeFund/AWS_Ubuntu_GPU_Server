#ifndef OPENGL_LIBS
#define OPENGL_LIBS " -L/usr/local/lib -lGL"
#endif
