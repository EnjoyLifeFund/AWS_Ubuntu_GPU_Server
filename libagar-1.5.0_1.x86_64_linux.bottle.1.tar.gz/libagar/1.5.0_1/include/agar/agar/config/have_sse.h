#ifndef HAVE_SSE
#define HAVE_SSE "yes"
#endif
