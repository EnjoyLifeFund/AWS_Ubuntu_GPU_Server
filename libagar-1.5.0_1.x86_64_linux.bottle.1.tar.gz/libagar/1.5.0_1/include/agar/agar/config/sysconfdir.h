#ifndef SYSCONFDIR
#define SYSCONFDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/etc"
#endif
