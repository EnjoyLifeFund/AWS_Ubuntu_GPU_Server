#ifndef HAVE_SO_LINGER
#define HAVE_SO_LINGER "yes"
#endif
