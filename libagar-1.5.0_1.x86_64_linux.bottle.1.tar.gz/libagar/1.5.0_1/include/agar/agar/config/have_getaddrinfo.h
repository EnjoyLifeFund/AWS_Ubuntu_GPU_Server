#ifndef HAVE_GETADDRINFO
#define HAVE_GETADDRINFO "yes"
#endif
