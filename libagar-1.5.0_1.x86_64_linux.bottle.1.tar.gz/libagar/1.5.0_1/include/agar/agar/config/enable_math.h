#ifndef ENABLE_MATH
#define ENABLE_MATH "yes"
#endif
