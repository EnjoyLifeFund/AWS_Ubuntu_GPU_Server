#ifndef GLX_LIBS
#define GLX_LIBS " -L/usr/local/lib -lGL -lX11"
#endif
