#ifndef HAVE_FREETYPE
#define HAVE_FREETYPE "yes"
#endif
