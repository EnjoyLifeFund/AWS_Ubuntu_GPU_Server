#undef COCOA_LIBS
