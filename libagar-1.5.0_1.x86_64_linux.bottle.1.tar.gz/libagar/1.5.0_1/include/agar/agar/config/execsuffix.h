#ifndef EXECSUFFIX
#define EXECSUFFIX ""
#endif
