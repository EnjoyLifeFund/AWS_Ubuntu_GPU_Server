#ifndef RELEASE
#define RELEASE "A Mild Breeze upon the Brow of the Dead"
#endif
