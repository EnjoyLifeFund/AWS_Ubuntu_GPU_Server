#undef HAVE_MYSQL
