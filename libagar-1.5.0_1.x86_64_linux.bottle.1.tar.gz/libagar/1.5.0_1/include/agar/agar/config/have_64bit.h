#ifndef HAVE_64BIT
#define HAVE_64BIT "yes"
#endif
