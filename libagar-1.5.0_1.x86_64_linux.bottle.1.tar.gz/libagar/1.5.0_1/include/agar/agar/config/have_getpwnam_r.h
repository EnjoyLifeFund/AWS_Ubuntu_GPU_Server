#ifndef HAVE_GETPWNAM_R
#define HAVE_GETPWNAM_R "yes"
#endif
