#ifndef DATADIR
#define DATADIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/share/agar"
#endif
