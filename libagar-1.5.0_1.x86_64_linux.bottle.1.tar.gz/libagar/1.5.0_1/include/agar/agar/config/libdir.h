#ifndef LIBDIR
#define LIBDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/lib"
#endif
