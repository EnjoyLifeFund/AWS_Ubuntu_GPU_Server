#ifndef SSE_CFLAGS
#define SSE_CFLAGS "-msse"
#endif
