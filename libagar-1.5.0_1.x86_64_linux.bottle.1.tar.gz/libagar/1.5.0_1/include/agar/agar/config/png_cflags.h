#ifndef PNG_CFLAGS
#define PNG_CFLAGS "-I@@HOMEBREW_PREFIX@@/Cellar/libpng/1.6.34/include/libpng16"
#endif
