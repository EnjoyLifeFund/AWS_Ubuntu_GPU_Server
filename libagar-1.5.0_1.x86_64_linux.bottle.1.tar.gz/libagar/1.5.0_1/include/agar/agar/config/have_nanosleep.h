#ifndef HAVE_NANOSLEEP
#define HAVE_NANOSLEEP "yes"
#endif
