#ifndef XINERAMA_LIBS
#define XINERAMA_LIBS "-lXinerama"
#endif
