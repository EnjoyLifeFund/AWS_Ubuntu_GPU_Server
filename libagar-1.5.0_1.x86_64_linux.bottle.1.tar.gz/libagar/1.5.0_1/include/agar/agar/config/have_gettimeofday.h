#ifndef HAVE_GETTIMEOFDAY
#define HAVE_GETTIMEOFDAY "yes"
#endif
