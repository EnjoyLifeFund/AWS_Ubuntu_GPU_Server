#ifndef HAVE_XKB
#define HAVE_XKB "yes"
#endif
