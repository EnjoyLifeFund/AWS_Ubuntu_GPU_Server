#ifndef TTFDIR
#define TTFDIR "@@HOMEBREW_PREFIX@@/Cellar/libagar/1.5.0_1/share/agar/fonts"
#endif
