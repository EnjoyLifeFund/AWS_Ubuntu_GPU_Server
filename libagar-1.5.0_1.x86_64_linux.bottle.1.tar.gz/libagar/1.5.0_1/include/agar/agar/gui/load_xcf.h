/*	Public domain	*/

#include <agar/gui/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC int AG_XCFLoad(AG_DataSource *, off_t, void (*)(AG_Surface *, const char *, void *), void *);
__END_DECLS
/* Close generated block */
#include <agar/gui/close.h>
