/*	Public domain	*/

#include <agar/gui/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC AG_Surface *AG_ReadSurface(AG_DataSource *);
extern DECLSPEC void AG_WriteSurface(AG_DataSource *, AG_Surface *);
__END_DECLS
/* Close generated block */
#include <agar/gui/close.h>
