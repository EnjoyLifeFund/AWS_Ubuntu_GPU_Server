/*	Public domain	*/

/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC M_Rectangular M_RectangularFromSpherical(M_Spherical);
extern DECLSPEC M_Rectangular M_RectangularFromCylindrical(M_Cylindrical);
extern DECLSPEC M_Spherical M_SphericalFromRectangular(M_Rectangular);
extern DECLSPEC M_Spherical M_SphericalFromCylindrical(M_Cylindrical);
extern DECLSPEC M_Cylindrical M_CylindricalFromRectangular(M_Rectangular);
extern DECLSPEC M_Cylindrical M_CylindricalFromSpherical(M_Spherical);
__END_DECLS
/* Close generated block */
