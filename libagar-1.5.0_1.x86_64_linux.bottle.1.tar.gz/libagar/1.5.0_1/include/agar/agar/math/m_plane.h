/*	Public domain	*/

/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC M_Plane M_PlaneFromPts(M_Vector3, M_Vector3, M_Vector3);
extern DECLSPEC M_Plane M_PlaneRead(AG_DataSource *);
extern DECLSPEC void M_PlaneWrite(AG_DataSource *, M_Plane *);
extern DECLSPEC M_Real M_PlaneVectorAngle(M_Plane, M_Vector3);
__END_DECLS
/* Close generated block */
