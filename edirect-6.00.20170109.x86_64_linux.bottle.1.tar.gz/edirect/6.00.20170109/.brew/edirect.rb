class Edirect < Formula
  desc "Access NCBI's databases from the shell"
  homepage "https://www.ncbi.nlm.nih.gov/books/NBK179288/"
  url "https://ftp.ncbi.nlm.nih.gov/entrez/entrezdirect/versions/6.00.20170109/edirect.tar.gz"
  sha256 "b0709d89394ceee1c97bfc44c993ce074181837f79def2c6958edc3e5ffa7d29"
  head "https://ftp.ncbi.nlm.nih.gov/entrez/entrezdirect/versions/current/edirect.tar.gz"
  # tag "bioinformatics"

  depends_on "HTML::Entities" => :perl
  depends_on "LWP::Simple" => :perl
  depends_on "LWP::Protocol::https" => :perl

  def install
    doc.install "README"
    libexec.install "setup.sh", "setup-deps.pl"
    rm ["Mozilla-CA.tar.gz", "xtract.go"]
    bin.install Dir["*"]
  end

  test do
    system bin/"esearch", "-version"
  end
end
