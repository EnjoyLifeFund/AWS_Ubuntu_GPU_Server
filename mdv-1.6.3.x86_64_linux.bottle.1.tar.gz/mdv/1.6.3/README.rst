Terminal Markdown Viewer
========================

This is a markdown renderer for the Terminal.

More information is at the `Github page <https://github.com/axiros/terminal_markdown_viewer>`__.

(pypi still has trouble rendering .md or pandoc conversions to rst of it)
