class Fsa < Formula
  homepage "http://fsa.sourceforge.net/"
  # doi "10.1371/journal.pcbi.1000392"
  # tag "bioinformatics"

  url "https://downloads.sourceforge.net/project/fsa/fsa-1.15.9.tar.gz"
  sha256 "6ee6e238e168ccba0d51648ba64d518cdf68fa875061e0d954edfb2500b50b30"

  depends_on "mummer" => :recommended

  def install
    system "./configure",
      "--disable-debug",
      "--disable-dependency-tracking",
      "--disable-silent-rules",
      "--prefix=#{prefix}"
    system "make", "install"
  end

  test do
    system "#{bin}/fsa", "--version"
  end
end
