LICENSE
-------

The squish library is distributed under the terms and conditions of the MIT
license. This license is specified at the top of each source file and must be
preserved in its entirety.

BUILDING AND INSTALLING THE LIBRARY
-----------------------------------

The preferred way to install the library on Unix/Mac (and Windows) is via cmake:
 cmake . && make && sudo make install

REPORTING BUGS OR FEATURE REQUESTS
----------------------------------

Feedback can be sent to Simon Brown (the developer) at si@sjbrown.co.uk
Feedback can also be sent to Stefan Roettger (the maintainer) at snroettg@gmail.com
