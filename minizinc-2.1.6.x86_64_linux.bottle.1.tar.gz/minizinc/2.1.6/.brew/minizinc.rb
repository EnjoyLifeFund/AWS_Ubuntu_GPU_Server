class Minizinc < Formula
  desc "Medium-level constraint modeling language"
  homepage "http://www.minizinc.org"
  url "https://github.com/MiniZinc/libminizinc/archive/2.1.6.tar.gz"
  sha256 "4733d5c99d8a0962859d85d4bf06483fbd39039bd18c9b5aba7e9acece31dc0d"
  head "https://github.com/MiniZinc/libminizinc.git", :branch => "develop"

  depends_on :arch => :x86_64
  depends_on "cmake" => :build

  def install
    mkdir "build" do
      system "cmake", "..", *std_cmake_args
      system "cmake", "--build", ".", "--target", "install"
    end
  end

  test do
    system bin/"mzn2doc", share/"examples/functions/warehouses.mzn"
  end
end
