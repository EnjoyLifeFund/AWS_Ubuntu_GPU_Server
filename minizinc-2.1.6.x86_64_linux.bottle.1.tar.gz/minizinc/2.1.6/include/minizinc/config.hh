#define MZN_VERSION_MAJOR "2"

#define MZN_VERSION_MINOR "1"

#define MZN_VERSION_PATCH "6"

/* #undef HAS_DECLSPEC_THREAD */

#define HAS_ATTR_THREAD

/* #undef MZN_NEED_TR1 */

/* #undef HAS_PIDPATH */

/* #undef HAS_GETMODULEFILENAME */

/* #undef HAS_GETFILEATTRIBUTES */

/* #undef HAS_MEMCPY_S */

/* #undef HAS_DLFCN_H */

/* #undef HAS_WINDOWS_H */

/* #undef HAS_GUROBI_PLUGIN */
