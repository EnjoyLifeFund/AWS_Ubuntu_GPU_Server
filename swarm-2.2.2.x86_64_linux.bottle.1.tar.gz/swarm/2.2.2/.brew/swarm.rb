class Swarm < Formula
  desc "Robust and fast clustering method for amplicons"
  homepage "https://github.com/torognes/swarm"
  url "https://github.com/torognes/swarm/archive/v2.2.2.tar.gz"
  sha256 "960f9b7db1142f0b5761e5ba02bedde09f9d9816c0f8275746fd856af3dfac12"
  head "https://github.com/torognes/swarm.git"
  # doi "10.7717/peerj.1420", "10.7717/peerj.593"
  # tag "bioinformatics"

  def install
    system "make", "-C", "src"
    bin.install "bin/swarm"
    man1.install "man/swarm.1"
    doc.install "man/swarm_manual.pdf", "CITATION", "LICENSE", "README.md"
  end

  test do
    assert_match "Quince", shell_output("#{bin}/swarm --version 2>&1", 0)
  end
end
