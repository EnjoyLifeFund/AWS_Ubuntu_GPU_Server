//! [snippet1]
// We include what we need for the test
#include <gatb/gatb_core.hpp>

/********************************************************************************/
/********************************************************************************/
int main (int argc, char* argv[])
{
}
//! [snippet1]
