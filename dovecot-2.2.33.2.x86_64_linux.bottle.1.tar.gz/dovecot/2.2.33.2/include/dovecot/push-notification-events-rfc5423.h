/* Copyright (c) 2015-2017 Dovecot authors, see the included COPYING file */

#ifndef PUSH_NOTIFICATION_EVENTS_RFC5423_H
#define PUSH_NOTIFICATION_EVENTS_RFC5423_H


void push_notification_event_register_rfc5423_events(void);
void push_notification_event_unregister_rfc5423_events(void);


#endif	/* PUSH_NOTIFICATION_EVENTS_H */

