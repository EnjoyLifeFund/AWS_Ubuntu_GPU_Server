#ifndef DICT_SQL_H
#define DICT_SQL_H

void dict_sql_register(void);
void dict_sql_unregister(void);

#endif
