class Kmerstream < Formula
  desc "Streaming algorithms for k-mer abundance estimation"
  homepage "https://github.com/pmelsted/KmerStream"
  url "https://github.com/pmelsted/KmerStream/archive/v1.1.tar.gz"
  sha256 "cf5de6224a0dd40e30af4ccc464bb749d20d393a7d4d3fceafab5f3d75589617"
  revision 1
  head "https://github.com/pmelsted/KmerStream.git"
  # doi "10.1093/bioinformatics/btu713"
  # tag "bioinformatics"

  needs :openmp
  depends_on "scipy"

  def install
    system "make"
    bin.install "KmerStream", "KmerStreamJoin", "KmerStreamEstimate.py"
    doc.install "README.md"
  end

  test do
    assert_match "Usage", shell_output("#{bin}/KmerStream 2>&1", 1)
    assert_match "Usage", shell_output("#{bin}/KmerStreamJoin 2>&1", 1)
    assert_match "Usage", shell_output("#{bin}/KmerStreamEstimate.py 2>&1", 1)
  end
end
