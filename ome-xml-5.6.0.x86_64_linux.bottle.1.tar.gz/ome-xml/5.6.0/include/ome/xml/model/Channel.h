/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_CHANNEL_H
#define OME_XML_MODEL_CHANNEL_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/DetectorSettings.h>
#include <ome/xml/model/FilterSet.h>
#include <ome/xml/model/LightPath.h>
#include <ome/xml/model/LightSourceSettings.h>
#include <ome/xml/model/Pixels.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/AcquisitionMode.h>
#include <ome/xml/model/enums/ContrastMethod.h>
#include <ome/xml/model/enums/IlluminationType.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/primitives/Color.h>
#include <ome/xml/model/primitives/PositiveFloat.h>
#include <ome/xml/model/primitives/PositiveInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;

      /**
       * Channel model object.
       */
      class Channel : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Channel();

        /**
         * Copy constructor.
         *
         * @param copy the Channel to copy.
         */
        Channel (const Channel& copy);

        /// Destructor.
        virtual
        ~Channel ();

        /**
         * Create a Channel model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Channel>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Channel&
        operator= (const Channel&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Channel API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the PinholeSize property.
         *
         * @returns the PinholeSize property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPinholeSize ();

        /**
         * Get the PinholeSize property.
         *
         * @returns the PinholeSize property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPinholeSize () const;

        /**
         * Set the PinholeSize property.
         *
         * @param pinholeSize the value to set.
         */
        void
        setPinholeSize (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& pinholeSize);

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        std::shared_ptr<std::string>
        getName ();

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        const std::shared_ptr<std::string>
        getName () const;

        /**
         * Set the Name property.
         *
         * @param name the value to set.
         */
        void
        setName (std::shared_ptr<std::string>& name);

        /**
         * Get the AcquisitionMode property.
         *
         * @returns the AcquisitionMode property.
         */
        std::shared_ptr<ome::xml::model::enums::AcquisitionMode>
        getAcquisitionMode ();

        /**
         * Get the AcquisitionMode property.
         *
         * @returns the AcquisitionMode property.
         */
        const std::shared_ptr<ome::xml::model::enums::AcquisitionMode>
        getAcquisitionMode () const;

        /**
         * Set the AcquisitionMode property.
         *
         * @param acquisitionMode the value to set.
         */
        void
        setAcquisitionMode (std::shared_ptr<ome::xml::model::enums::AcquisitionMode>& acquisitionMode);

        /**
         * Get the Color property.
         *
         * @returns the Color property.
         */
        std::shared_ptr<ome::xml::model::primitives::Color>
        getColor ();

        /**
         * Get the Color property.
         *
         * @returns the Color property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Color>
        getColor () const;

        /**
         * Set the Color property.
         *
         * @param color the value to set.
         */
        void
        setColor (std::shared_ptr<ome::xml::model::primitives::Color>& color);

        /**
         * Get the ContrastMethod property.
         *
         * @returns the ContrastMethod property.
         */
        std::shared_ptr<ome::xml::model::enums::ContrastMethod>
        getContrastMethod ();

        /**
         * Get the ContrastMethod property.
         *
         * @returns the ContrastMethod property.
         */
        const std::shared_ptr<ome::xml::model::enums::ContrastMethod>
        getContrastMethod () const;

        /**
         * Set the ContrastMethod property.
         *
         * @param contrastMethod the value to set.
         */
        void
        setContrastMethod (std::shared_ptr<ome::xml::model::enums::ContrastMethod>& contrastMethod);

        /**
         * Get the ExcitationWavelength property.
         *
         * @returns the ExcitationWavelength property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getExcitationWavelength ();

        /**
         * Get the ExcitationWavelength property.
         *
         * @returns the ExcitationWavelength property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getExcitationWavelength () const;

        /**
         * Set the ExcitationWavelength property.
         *
         * @param excitationWavelength the value to set.
         */
        void
        setExcitationWavelength (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& excitationWavelength);

        /**
         * Get the IlluminationType property.
         *
         * @returns the IlluminationType property.
         */
        std::shared_ptr<ome::xml::model::enums::IlluminationType>
        getIlluminationType ();

        /**
         * Get the IlluminationType property.
         *
         * @returns the IlluminationType property.
         */
        const std::shared_ptr<ome::xml::model::enums::IlluminationType>
        getIlluminationType () const;

        /**
         * Set the IlluminationType property.
         *
         * @param illuminationType the value to set.
         */
        void
        setIlluminationType (std::shared_ptr<ome::xml::model::enums::IlluminationType>& illuminationType);

        /**
         * Get the Fluor property.
         *
         * @returns the Fluor property.
         */
        std::shared_ptr<std::string>
        getFluor ();

        /**
         * Get the Fluor property.
         *
         * @returns the Fluor property.
         */
        const std::shared_ptr<std::string>
        getFluor () const;

        /**
         * Set the Fluor property.
         *
         * @param fluor the value to set.
         */
        void
        setFluor (std::shared_ptr<std::string>& fluor);

        /**
         * Get the PockelCellSetting property.
         *
         * @returns the PockelCellSetting property.
         */
        std::shared_ptr<int32_t>
        getPockelCellSetting ();

        /**
         * Get the PockelCellSetting property.
         *
         * @returns the PockelCellSetting property.
         */
        const std::shared_ptr<int32_t>
        getPockelCellSetting () const;

        /**
         * Set the PockelCellSetting property.
         *
         * @param pockelCellSetting the value to set.
         */
        void
        setPockelCellSetting (std::shared_ptr<int32_t>& pockelCellSetting);

        /**
         * Get the NDFilter property.
         *
         * @returns the NDFilter property.
         */
        std::shared_ptr<double>
        getNDFilter ();

        /**
         * Get the NDFilter property.
         *
         * @returns the NDFilter property.
         */
        const std::shared_ptr<double>
        getNDFilter () const;

        /**
         * Set the NDFilter property.
         *
         * @param ndFilter the value to set.
         */
        void
        setNDFilter (std::shared_ptr<double>& ndFilter);

        /**
         * Get the EmissionWavelength property.
         *
         * @returns the EmissionWavelength property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getEmissionWavelength ();

        /**
         * Get the EmissionWavelength property.
         *
         * @returns the EmissionWavelength property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getEmissionWavelength () const;

        /**
         * Set the EmissionWavelength property.
         *
         * @param emissionWavelength the value to set.
         */
        void
        setEmissionWavelength (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& emissionWavelength);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the SamplesPerPixel property.
         *
         * @returns the SamplesPerPixel property.
         */
        std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getSamplesPerPixel ();

        /**
         * Get the SamplesPerPixel property.
         *
         * @returns the SamplesPerPixel property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getSamplesPerPixel () const;

        /**
         * Set the SamplesPerPixel property.
         *
         * @param samplesPerPixel the value to set.
         */
        void
        setSamplesPerPixel (std::shared_ptr<ome::xml::model::primitives::PositiveInteger>& samplesPerPixel);

        /**
         * Get the LightSourceSettings property.
         *
         * @returns the LightSourceSettings property.
         */
        std::shared_ptr<ome::xml::model::LightSourceSettings>
        getLightSourceSettings ();

        /**
         * Get the LightSourceSettings property.
         *
         * @returns the LightSourceSettings property.
         */
        const std::shared_ptr<ome::xml::model::LightSourceSettings>
        getLightSourceSettings () const;

        /**
         * Set the LightSourceSettings property.
         *
         * @param lightSourceSettings the value to set.
         */
        void
        setLightSourceSettings (std::shared_ptr<ome::xml::model::LightSourceSettings>& lightSourceSettings);

        /**
         * Get the DetectorSettings property.
         *
         * @returns the DetectorSettings property.
         */
        std::shared_ptr<ome::xml::model::DetectorSettings>
        getDetectorSettings ();

        /**
         * Get the DetectorSettings property.
         *
         * @returns the DetectorSettings property.
         */
        const std::shared_ptr<ome::xml::model::DetectorSettings>
        getDetectorSettings () const;

        /**
         * Set the DetectorSettings property.
         *
         * @param detectorSettings the value to set.
         */
        void
        setDetectorSettings (std::shared_ptr<ome::xml::model::DetectorSettings>& detectorSettings);

        /**
         * Get linked FilterSet.
         *
         * @returns the linked FilterSet.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::FilterSet>
        getLinkedFilterSet ();

        /**
         * Get linked FilterSet.
         *
         * @returns the linked FilterSet.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::FilterSet>
        getLinkedFilterSet () const;

        /**
         * Link FilterSet.
         *
         * @param filterSet the FilterSet to link.
         */
        void
        linkFilterSet (std::shared_ptr<ome::xml::model::FilterSet>& filterSet);

        /**
         * Unlink FilterSet.
         *
         * @param filterSet the FilterSet to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkFilterSet (std::shared_ptr<ome::xml::model::FilterSet>& filterSet);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the LightPath property.
         *
         * @returns the LightPath property.
         */
        std::shared_ptr<ome::xml::model::LightPath>
        getLightPath ();

        /**
         * Get the LightPath property.
         *
         * @returns the LightPath property.
         */
        const std::shared_ptr<ome::xml::model::LightPath>
        getLightPath () const;

        /**
         * Set the LightPath property.
         *
         * @param lightPath the value to set.
         */
        void
        setLightPath (std::shared_ptr<ome::xml::model::LightPath>& lightPath);

        /**
         * Get the Pixels property.
         *
         * @returns the Pixels property.
         */
        std::weak_ptr<ome::xml::model::Pixels>
        getPixels ();

        /**
         * Get the Pixels property.
         *
         * @returns the Pixels property.
         */
        const std::weak_ptr<ome::xml::model::Pixels>
        getPixels () const;

        /**
         * Set the Pixels property.
         *
         * @param pixels_BackReference the value to set.
         */
        void
        setPixels (std::weak_ptr<ome::xml::model::Pixels>& pixels_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_CHANNEL_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
