/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_EXPERIMENT_H
#define OME_XML_MODEL_EXPERIMENT_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Experimenter.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/ExperimentType.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Image;
      class MicrobeamManipulation;
      class OMEModel;

      /**
       * Experiment model object.
       */
      class Experiment : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Experiment();

        /**
         * Copy constructor.
         *
         * @param copy the Experiment to copy.
         */
        Experiment (const Experiment& copy);

        /// Destructor.
        virtual
        ~Experiment ();

        /**
         * Create a Experiment model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Experiment>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Experiment&
        operator= (const Experiment&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Experiment API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        std::shared_ptr<ome::xml::model::enums::ExperimentType>
        getType ();

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        const std::shared_ptr<ome::xml::model::enums::ExperimentType>
        getType () const;

        /**
         * Set the Type property.
         *
         * @param type the value to set.
         */
        void
        setType (std::shared_ptr<ome::xml::model::enums::ExperimentType>& type);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get linked Experimenter.
         *
         * @returns the linked Experimenter.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::Experimenter>
        getLinkedExperimenter ();

        /**
         * Get linked Experimenter.
         *
         * @returns the linked Experimenter.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::Experimenter>
        getLinkedExperimenter () const;

        /**
         * Link Experimenter.
         *
         * @param experimenter the Experimenter to link.
         */
        void
        linkExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Unlink Experimenter.
         *
         * @param experimenter the Experimenter to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Get size of linked MicrobeamManipulation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>::size_type
        sizeOfMicrobeamManipulationList () const;

        /**
         * Get the MicrobeamManipulation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>&
        getMicrobeamManipulationList ();

        /**
         * Get the MicrobeamManipulation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>&
        getMicrobeamManipulationList () const;

        /**
         * Get MicrobeamManipulation.
         *
         * @param index the index number of the MicrobeamManipulation.
         * @returns the MicrobeamManipulation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::MicrobeamManipulation>&
        getMicrobeamManipulation (std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>::size_type index);

        /**
         * Get MicrobeamManipulation.
         *
         * @param index the index number of the MicrobeamManipulation.
         * @returns the MicrobeamManipulation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::MicrobeamManipulation>&
        getMicrobeamManipulation (std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>::size_type index) const;

        /**
         * Set MicrobeamManipulation.
         *
         * @param index the index number of the MicrobeamManipulation.
         * @param microbeamManipulation the MicrobeamManipulation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setMicrobeamManipulation (std::vector<std::shared_ptr<ome::xml::model::MicrobeamManipulation>>::size_type index,
                               std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation);

        /**
         * Add MicrobeamManipulation.
         *
         * @param microbeamManipulation the MicrobeamManipulation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addMicrobeamManipulation (std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation);

        /**
         * Remove MicrobeamManipulation.
         *
         * @param microbeamManipulation the MicrobeamManipulation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeMicrobeamManipulation (std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type
        sizeOfLinkedImageList () const;

        /**
         * Get the linked Image list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type
        getLinkedImageList () const;

        /**
         * Get linked Image.
         *
         * @param index the index number of the Image.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        getLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Image.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Image.
         * @param image_BackReference the Image to set.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        setLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Link Image.
         *
         * @param image_BackReference the Image to link.
         * @returns @c true if the object was added to the internal
         * images list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Unlink Image.
         *
         * @param image_BackReference the Image to unlink.
         *
         * @returns @c true if the Image was unlinked, otherwise
         * @c false if the Image was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_EXPERIMENT_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
