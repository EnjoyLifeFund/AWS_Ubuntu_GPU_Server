/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_PLANE_H
#define OME_XML_MODEL_PLANE_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Pixels.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/enums/UnitsTime.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;

      /**
       * Plane model object.
       */
      class Plane : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Plane();

        /**
         * Copy constructor.
         *
         * @param copy the Plane to copy.
         */
        Plane (const Plane& copy);

        /// Destructor.
        virtual
        ~Plane ();

        /**
         * Create a Plane model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Plane>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Plane&
        operator= (const Plane&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Plane API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ExposureTime property.
         *
         * @returns the ExposureTime property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getExposureTime ();

        /**
         * Get the ExposureTime property.
         *
         * @returns the ExposureTime property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getExposureTime () const;

        /**
         * Set the ExposureTime property.
         *
         * @param exposureTime the value to set.
         */
        void
        setExposureTime (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >& exposureTime);

        /**
         * Get the PositionZ property.
         *
         * @returns the PositionZ property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionZ ();

        /**
         * Get the PositionZ property.
         *
         * @returns the PositionZ property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionZ () const;

        /**
         * Set the PositionZ property.
         *
         * @param positionZ the value to set.
         */
        void
        setPositionZ (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& positionZ);

        /**
         * Get the PositionX property.
         *
         * @returns the PositionX property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionX ();

        /**
         * Get the PositionX property.
         *
         * @returns the PositionX property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionX () const;

        /**
         * Set the PositionX property.
         *
         * @param positionX the value to set.
         */
        void
        setPositionX (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& positionX);

        /**
         * Get the PositionY property.
         *
         * @returns the PositionY property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionY ();

        /**
         * Get the PositionY property.
         *
         * @returns the PositionY property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getPositionY () const;

        /**
         * Set the PositionY property.
         *
         * @param positionY the value to set.
         */
        void
        setPositionY (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& positionY);

        /**
         * Get the DeltaT property.
         *
         * @returns the DeltaT property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getDeltaT ();

        /**
         * Get the DeltaT property.
         *
         * @returns the DeltaT property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getDeltaT () const;

        /**
         * Set the DeltaT property.
         *
         * @param deltaT the value to set.
         */
        void
        setDeltaT (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >& deltaT);

        /**
         * Get the TheC property.
         *
         * @returns the TheC property.
         */
        const ome::xml::model::primitives::NonNegativeInteger&
        getTheC () const;

        /**
         * Set the TheC property.
         *
         * @param theC the value to set.
         */
        void
        setTheC (const ome::xml::model::primitives::NonNegativeInteger& theC);

        /**
         * Get the TheZ property.
         *
         * @returns the TheZ property.
         */
        const ome::xml::model::primitives::NonNegativeInteger&
        getTheZ () const;

        /**
         * Set the TheZ property.
         *
         * @param theZ the value to set.
         */
        void
        setTheZ (const ome::xml::model::primitives::NonNegativeInteger& theZ);

        /**
         * Get the TheT property.
         *
         * @returns the TheT property.
         */
        const ome::xml::model::primitives::NonNegativeInteger&
        getTheT () const;

        /**
         * Set the TheT property.
         *
         * @param theT the value to set.
         */
        void
        setTheT (const ome::xml::model::primitives::NonNegativeInteger& theT);

        /**
         * Get the HashSHA1 property.
         *
         * @returns the HashSHA1 property.
         */
        std::shared_ptr<std::string>
        getHashSHA1 ();

        /**
         * Get the HashSHA1 property.
         *
         * @returns the HashSHA1 property.
         */
        const std::shared_ptr<std::string>
        getHashSHA1 () const;

        /**
         * Set the HashSHA1 property.
         *
         * @param hashSHA1 the value to set.
         */
        void
        setHashSHA1 (std::shared_ptr<std::string>& hashSHA1);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Pixels property.
         *
         * @returns the Pixels property.
         */
        std::weak_ptr<ome::xml::model::Pixels>
        getPixels ();

        /**
         * Get the Pixels property.
         *
         * @returns the Pixels property.
         */
        const std::weak_ptr<ome::xml::model::Pixels>
        getPixels () const;

        /**
         * Set the Pixels property.
         *
         * @param pixels_BackReference the value to set.
         */
        void
        setPixels (std::weak_ptr<ome::xml::model::Pixels>& pixels_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_PLANE_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
