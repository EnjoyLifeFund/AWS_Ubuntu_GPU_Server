/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_DATASET_H
#define OME_XML_MODEL_DATASET_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Experimenter.h>
#include <ome/xml/model/ExperimenterGroup.h>
#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class Image;
      class OMEModel;
      class Project;

      /**
       * Dataset model object.
       */
      class Dataset : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Dataset();

        /**
         * Copy constructor.
         *
         * @param copy the Dataset to copy.
         */
        Dataset (const Dataset& copy);

        /// Destructor.
        virtual
        ~Dataset ();

        /**
         * Create a Dataset model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Dataset>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Dataset&
        operator= (const Dataset&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Dataset API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        std::shared_ptr<std::string>
        getName ();

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        const std::shared_ptr<std::string>
        getName () const;

        /**
         * Set the Name property.
         *
         * @param name the value to set.
         */
        void
        setName (std::shared_ptr<std::string>& name);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get linked Experimenter.
         *
         * @returns the linked Experimenter.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::Experimenter>
        getLinkedExperimenter ();

        /**
         * Get linked Experimenter.
         *
         * @returns the linked Experimenter.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::Experimenter>
        getLinkedExperimenter () const;

        /**
         * Link Experimenter.
         *
         * @param experimenter the Experimenter to link.
         */
        void
        linkExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Unlink Experimenter.
         *
         * @param experimenter the Experimenter to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Get linked ExperimenterGroup.
         *
         * @returns the linked ExperimenterGroup.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::ExperimenterGroup>
        getLinkedExperimenterGroup ();

        /**
         * Get linked ExperimenterGroup.
         *
         * @returns the linked ExperimenterGroup.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::ExperimenterGroup>
        getLinkedExperimenterGroup () const;

        /**
         * Link ExperimenterGroup.
         *
         * @param experimenterGroup the ExperimenterGroup to link.
         */
        void
        linkExperimenterGroup (std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup);

        /**
         * Unlink ExperimenterGroup.
         *
         * @param experimenterGroup the ExperimenterGroup to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkExperimenterGroup (std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type
        sizeOfLinkedImageList () const;

        /**
         * Get the linked Image list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type
        getLinkedImageList () const;

        /**
         * Get linked Image.
         *
         * @param index the index number of the Image.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        getLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Image.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Image.
         * @param image the Image to set.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        setLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Link Image.
         *
         * @param image the Image to link.
         * @returns @c true if the object was added to the internal
         * imageLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkImage (const std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Unlink Image.
         *
         * @param image the Image to unlink.
         *
         * @returns @c true if the Image was unlinked, otherwise
         * @c false if the Image was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkImage (const std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get size of linked Project list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type
        sizeOfLinkedProjectList () const;

        /**
         * Get the linked Project list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type
        getLinkedProjectList () const;

        /**
         * Get linked Project.
         *
         * @param index the index number of the Project.
         * @returns a weak pointer to the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Project>&
        getLinkedProject (OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Project.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Project.
         * @param project_BackReference the Project to set.
         * @returns a weak pointer to the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Project>&
        setLinkedProject (OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

        /**
         * Link Project.
         *
         * @param project_BackReference the Project to link.
         * @returns @c true if the object was added to the internal
         * projectLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkProject (const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

        /**
         * Unlink Project.
         *
         * @param project_BackReference the Project to unlink.
         *
         * @returns @c true if the Project was unlinked, otherwise
         * @c false if the Project was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkProject (const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_DATASET_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
