/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_ANNOTATION_H
#define OME_XML_MODEL_ANNOTATION_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Channel;
      class Dataset;
      class Detector;
      class Dichroic;
      class Experimenter;
      class ExperimenterGroup;
      class Filter;
      class Folder;
      class Image;
      class Instrument;
      class LightPath;
      class LightSource;
      class OMEModel;
      class Objective;
      class Plane;
      class Plate;
      class PlateAcquisition;
      class Project;
      class ROI;
      class Reagent;
      class Screen;
      class Shape;
      class Well;

      /**
       * Annotation model object.
       */
      class Annotation : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Annotation();

        /**
         * Copy constructor.
         *
         * @param copy the Annotation to copy.
         */
        Annotation (const Annotation& copy);

        /// Destructor.
        virtual
        ~Annotation ();

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Annotation&
        operator= (const Annotation&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Annotation API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the Namespace property.
         *
         * @returns the Namespace property.
         */
        std::shared_ptr<std::string>
        getNamespace ();

        /**
         * Get the Namespace property.
         *
         * @returns the Namespace property.
         */
        const std::shared_ptr<std::string>
        getNamespace () const;

        /**
         * Set the Namespace property.
         *
         * @param namespace_ the value to set.
         */
        void
        setNamespace (std::shared_ptr<std::string>& namespace_);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Annotator property.
         *
         * @returns the Annotator property.
         */
        std::shared_ptr<std::string>
        getAnnotator ();

        /**
         * Get the Annotator property.
         *
         * @returns the Annotator property.
         */
        const std::shared_ptr<std::string>
        getAnnotator () const;

        /**
         * Set the Annotator property.
         *
         * @param annotator the value to set.
         */
        void
        setAnnotator (std::shared_ptr<std::string>& annotator);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type
        sizeOfLinkedImageList () const;

        /**
         * Get the linked Image list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type
        getLinkedImageList () const;

        /**
         * Get linked Image.
         *
         * @param index the index number of the Image.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        getLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Image.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Image.
         * @param image_BackReference the Image to set.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        setLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Link Image.
         *
         * @param image_BackReference the Image to link.
         * @returns @c true if the object was added to the internal
         * imageLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Unlink Image.
         *
         * @param image_BackReference the Image to unlink.
         *
         * @returns @c true if the Image was unlinked, otherwise
         * @c false if the Image was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Get size of linked Plane list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Plane, std::weak_ptr>::type::size_type
        sizeOfLinkedPlaneList () const;

        /**
         * Get the linked Plane list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Plane, std::weak_ptr>::type
        getLinkedPlaneList () const;

        /**
         * Get linked Plane.
         *
         * @param index the index number of the Plane.
         * @returns a weak pointer to the Plane.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Plane>&
        getLinkedPlane (OMEModelObject::indexed_container<ome::xml::model::Plane, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Plane.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Plane.
         * @param plane_BackReference the Plane to set.
         * @returns a weak pointer to the Plane.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Plane>&
        setLinkedPlane (OMEModelObject::indexed_container<ome::xml::model::Plane, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Plane>& plane_BackReference);

        /**
         * Link Plane.
         *
         * @param plane_BackReference the Plane to link.
         * @returns @c true if the object was added to the internal
         * planeLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkPlane (const std::shared_ptr<ome::xml::model::Plane>& plane_BackReference);

        /**
         * Unlink Plane.
         *
         * @param plane_BackReference the Plane to unlink.
         *
         * @returns @c true if the Plane was unlinked, otherwise
         * @c false if the Plane was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkPlane (const std::shared_ptr<ome::xml::model::Plane>& plane_BackReference);

        /**
         * Get size of linked Channel list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type
        sizeOfLinkedChannelList () const;

        /**
         * Get the linked Channel list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type
        getLinkedChannelList () const;

        /**
         * Get linked Channel.
         *
         * @param index the index number of the Channel.
         * @returns a weak pointer to the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Channel>&
        getLinkedChannel (OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Channel.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Channel.
         * @param channel_BackReference the Channel to set.
         * @returns a weak pointer to the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Channel>&
        setLinkedChannel (OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Link Channel.
         *
         * @param channel_BackReference the Channel to link.
         * @returns @c true if the object was added to the internal
         * channelLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkChannel (const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Unlink Channel.
         *
         * @param channel_BackReference the Channel to unlink.
         *
         * @returns @c true if the Channel was unlinked, otherwise
         * @c false if the Channel was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkChannel (const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Get size of linked Instrument list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Instrument, std::weak_ptr>::type::size_type
        sizeOfLinkedInstrumentList () const;

        /**
         * Get the linked Instrument list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Instrument, std::weak_ptr>::type
        getLinkedInstrumentList () const;

        /**
         * Get linked Instrument.
         *
         * @param index the index number of the Instrument.
         * @returns a weak pointer to the Instrument.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Instrument>&
        getLinkedInstrument (OMEModelObject::indexed_container<ome::xml::model::Instrument, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Instrument.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Instrument.
         * @param instrument_BackReference the Instrument to set.
         * @returns a weak pointer to the Instrument.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Instrument>&
        setLinkedInstrument (OMEModelObject::indexed_container<ome::xml::model::Instrument, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Instrument>& instrument_BackReference);

        /**
         * Link Instrument.
         *
         * @param instrument_BackReference the Instrument to link.
         * @returns @c true if the object was added to the internal
         * instrumentLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkInstrument (const std::shared_ptr<ome::xml::model::Instrument>& instrument_BackReference);

        /**
         * Unlink Instrument.
         *
         * @param instrument_BackReference the Instrument to unlink.
         *
         * @returns @c true if the Instrument was unlinked, otherwise
         * @c false if the Instrument was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkInstrument (const std::shared_ptr<ome::xml::model::Instrument>& instrument_BackReference);

        /**
         * Get size of linked LightSource list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightSource, std::weak_ptr>::type::size_type
        sizeOfLinkedLightSourceList () const;

        /**
         * Get the linked LightSource list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightSource, std::weak_ptr>::type
        getLinkedLightSourceList () const;

        /**
         * Get linked LightSource.
         *
         * @param index the index number of the LightSource.
         * @returns a weak pointer to the LightSource.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightSource>&
        getLinkedLightSource (OMEModelObject::indexed_container<ome::xml::model::LightSource, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked LightSource.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the LightSource.
         * @param lightSource_BackReference the LightSource to set.
         * @returns a weak pointer to the LightSource.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightSource>&
        setLinkedLightSource (OMEModelObject::indexed_container<ome::xml::model::LightSource, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::LightSource>& lightSource_BackReference);

        /**
         * Link LightSource.
         *
         * @param lightSource_BackReference the LightSource to link.
         * @returns @c true if the object was added to the internal
         * lightSourceLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkLightSource (const std::shared_ptr<ome::xml::model::LightSource>& lightSource_BackReference);

        /**
         * Unlink LightSource.
         *
         * @param lightSource_BackReference the LightSource to unlink.
         *
         * @returns @c true if the LightSource was unlinked, otherwise
         * @c false if the LightSource was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkLightSource (const std::shared_ptr<ome::xml::model::LightSource>& lightSource_BackReference);

        /**
         * Get size of linked Project list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type
        sizeOfLinkedProjectList () const;

        /**
         * Get the linked Project list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type
        getLinkedProjectList () const;

        /**
         * Get linked Project.
         *
         * @param index the index number of the Project.
         * @returns a weak pointer to the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Project>&
        getLinkedProject (OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Project.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Project.
         * @param project_BackReference the Project to set.
         * @returns a weak pointer to the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Project>&
        setLinkedProject (OMEModelObject::indexed_container<ome::xml::model::Project, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

        /**
         * Link Project.
         *
         * @param project_BackReference the Project to link.
         * @returns @c true if the object was added to the internal
         * projectLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkProject (const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

        /**
         * Unlink Project.
         *
         * @param project_BackReference the Project to unlink.
         *
         * @returns @c true if the Project was unlinked, otherwise
         * @c false if the Project was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkProject (const std::shared_ptr<ome::xml::model::Project>& project_BackReference);

        /**
         * Get size of linked ExperimenterGroup list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::ExperimenterGroup, std::weak_ptr>::type::size_type
        sizeOfLinkedExperimenterGroupList () const;

        /**
         * Get the linked ExperimenterGroup list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::ExperimenterGroup, std::weak_ptr>::type
        getLinkedExperimenterGroupList () const;

        /**
         * Get linked ExperimenterGroup.
         *
         * @param index the index number of the ExperimenterGroup.
         * @returns a weak pointer to the ExperimenterGroup.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::ExperimenterGroup>&
        getLinkedExperimenterGroup (OMEModelObject::indexed_container<ome::xml::model::ExperimenterGroup, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked ExperimenterGroup.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the ExperimenterGroup.
         * @param experimenterGroup_BackReference the ExperimenterGroup to set.
         * @returns a weak pointer to the ExperimenterGroup.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::ExperimenterGroup>&
        setLinkedExperimenterGroup (OMEModelObject::indexed_container<ome::xml::model::ExperimenterGroup, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup_BackReference);

        /**
         * Link ExperimenterGroup.
         *
         * @param experimenterGroup_BackReference the ExperimenterGroup to link.
         * @returns @c true if the object was added to the internal
         * experimenterGroupLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkExperimenterGroup (const std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup_BackReference);

        /**
         * Unlink ExperimenterGroup.
         *
         * @param experimenterGroup_BackReference the ExperimenterGroup to unlink.
         *
         * @returns @c true if the ExperimenterGroup was unlinked, otherwise
         * @c false if the ExperimenterGroup was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkExperimenterGroup (const std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup_BackReference);

        /**
         * Get size of linked Dataset list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Dataset, std::weak_ptr>::type::size_type
        sizeOfLinkedDatasetList () const;

        /**
         * Get the linked Dataset list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Dataset, std::weak_ptr>::type
        getLinkedDatasetList () const;

        /**
         * Get linked Dataset.
         *
         * @param index the index number of the Dataset.
         * @returns a weak pointer to the Dataset.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Dataset>&
        getLinkedDataset (OMEModelObject::indexed_container<ome::xml::model::Dataset, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Dataset.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Dataset.
         * @param dataset_BackReference the Dataset to set.
         * @returns a weak pointer to the Dataset.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Dataset>&
        setLinkedDataset (OMEModelObject::indexed_container<ome::xml::model::Dataset, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Dataset>& dataset_BackReference);

        /**
         * Link Dataset.
         *
         * @param dataset_BackReference the Dataset to link.
         * @returns @c true if the object was added to the internal
         * datasetLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkDataset (const std::shared_ptr<ome::xml::model::Dataset>& dataset_BackReference);

        /**
         * Unlink Dataset.
         *
         * @param dataset_BackReference the Dataset to unlink.
         *
         * @returns @c true if the Dataset was unlinked, otherwise
         * @c false if the Dataset was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkDataset (const std::shared_ptr<ome::xml::model::Dataset>& dataset_BackReference);

        /**
         * Get size of linked Experimenter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Experimenter, std::weak_ptr>::type::size_type
        sizeOfLinkedExperimenterList () const;

        /**
         * Get the linked Experimenter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Experimenter, std::weak_ptr>::type
        getLinkedExperimenterList () const;

        /**
         * Get linked Experimenter.
         *
         * @param index the index number of the Experimenter.
         * @returns a weak pointer to the Experimenter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Experimenter>&
        getLinkedExperimenter (OMEModelObject::indexed_container<ome::xml::model::Experimenter, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Experimenter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Experimenter.
         * @param experimenter_BackReference the Experimenter to set.
         * @returns a weak pointer to the Experimenter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Experimenter>&
        setLinkedExperimenter (OMEModelObject::indexed_container<ome::xml::model::Experimenter, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Experimenter>& experimenter_BackReference);

        /**
         * Link Experimenter.
         *
         * @param experimenter_BackReference the Experimenter to link.
         * @returns @c true if the object was added to the internal
         * experimenterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkExperimenter (const std::shared_ptr<ome::xml::model::Experimenter>& experimenter_BackReference);

        /**
         * Unlink Experimenter.
         *
         * @param experimenter_BackReference the Experimenter to unlink.
         *
         * @returns @c true if the Experimenter was unlinked, otherwise
         * @c false if the Experimenter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkExperimenter (const std::shared_ptr<ome::xml::model::Experimenter>& experimenter_BackReference);

        /**
         * Get size of linked Folder list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type
        sizeOfLinkedFolderList () const;

        /**
         * Get the linked Folder list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type
        getLinkedFolderList () const;

        /**
         * Get linked Folder.
         *
         * @param index the index number of the Folder.
         * @returns a weak pointer to the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Folder>&
        getLinkedFolder (OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Folder.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Folder.
         * @param folder_BackReference the Folder to set.
         * @returns a weak pointer to the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Folder>&
        setLinkedFolder (OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

        /**
         * Link Folder.
         *
         * @param folder_BackReference the Folder to link.
         * @returns @c true if the object was added to the internal
         * folderLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkFolder (const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

        /**
         * Unlink Folder.
         *
         * @param folder_BackReference the Folder to unlink.
         *
         * @returns @c true if the Folder was unlinked, otherwise
         * @c false if the Folder was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkFolder (const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

        /**
         * Get size of linked Objective list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Objective, std::weak_ptr>::type::size_type
        sizeOfLinkedObjectiveList () const;

        /**
         * Get the linked Objective list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Objective, std::weak_ptr>::type
        getLinkedObjectiveList () const;

        /**
         * Get linked Objective.
         *
         * @param index the index number of the Objective.
         * @returns a weak pointer to the Objective.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Objective>&
        getLinkedObjective (OMEModelObject::indexed_container<ome::xml::model::Objective, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Objective.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Objective.
         * @param objective_BackReference the Objective to set.
         * @returns a weak pointer to the Objective.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Objective>&
        setLinkedObjective (OMEModelObject::indexed_container<ome::xml::model::Objective, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Objective>& objective_BackReference);

        /**
         * Link Objective.
         *
         * @param objective_BackReference the Objective to link.
         * @returns @c true if the object was added to the internal
         * objectiveLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkObjective (const std::shared_ptr<ome::xml::model::Objective>& objective_BackReference);

        /**
         * Unlink Objective.
         *
         * @param objective_BackReference the Objective to unlink.
         *
         * @returns @c true if the Objective was unlinked, otherwise
         * @c false if the Objective was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkObjective (const std::shared_ptr<ome::xml::model::Objective>& objective_BackReference);

        /**
         * Get size of linked Detector list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Detector, std::weak_ptr>::type::size_type
        sizeOfLinkedDetectorList () const;

        /**
         * Get the linked Detector list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Detector, std::weak_ptr>::type
        getLinkedDetectorList () const;

        /**
         * Get linked Detector.
         *
         * @param index the index number of the Detector.
         * @returns a weak pointer to the Detector.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Detector>&
        getLinkedDetector (OMEModelObject::indexed_container<ome::xml::model::Detector, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Detector.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Detector.
         * @param detector_BackReference the Detector to set.
         * @returns a weak pointer to the Detector.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Detector>&
        setLinkedDetector (OMEModelObject::indexed_container<ome::xml::model::Detector, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Detector>& detector_BackReference);

        /**
         * Link Detector.
         *
         * @param detector_BackReference the Detector to link.
         * @returns @c true if the object was added to the internal
         * detectorLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkDetector (const std::shared_ptr<ome::xml::model::Detector>& detector_BackReference);

        /**
         * Unlink Detector.
         *
         * @param detector_BackReference the Detector to unlink.
         *
         * @returns @c true if the Detector was unlinked, otherwise
         * @c false if the Detector was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkDetector (const std::shared_ptr<ome::xml::model::Detector>& detector_BackReference);

        /**
         * Get size of linked Filter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type
        sizeOfLinkedFilterList () const;

        /**
         * Get the linked Filter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type
        getLinkedFilterList () const;

        /**
         * Get linked Filter.
         *
         * @param index the index number of the Filter.
         * @returns a weak pointer to the Filter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        getLinkedFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Filter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Filter.
         * @param filter_BackReference the Filter to set.
         * @returns a weak pointer to the Filter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        setLinkedFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Filter>& filter_BackReference);

        /**
         * Link Filter.
         *
         * @param filter_BackReference the Filter to link.
         * @returns @c true if the object was added to the internal
         * filterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkFilter (const std::shared_ptr<ome::xml::model::Filter>& filter_BackReference);

        /**
         * Unlink Filter.
         *
         * @param filter_BackReference the Filter to unlink.
         *
         * @returns @c true if the Filter was unlinked, otherwise
         * @c false if the Filter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkFilter (const std::shared_ptr<ome::xml::model::Filter>& filter_BackReference);

        /**
         * Get size of linked Dichroic list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Dichroic, std::weak_ptr>::type::size_type
        sizeOfLinkedDichroicList () const;

        /**
         * Get the linked Dichroic list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Dichroic, std::weak_ptr>::type
        getLinkedDichroicList () const;

        /**
         * Get linked Dichroic.
         *
         * @param index the index number of the Dichroic.
         * @returns a weak pointer to the Dichroic.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Dichroic>&
        getLinkedDichroic (OMEModelObject::indexed_container<ome::xml::model::Dichroic, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Dichroic.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Dichroic.
         * @param dichroic_BackReference the Dichroic to set.
         * @returns a weak pointer to the Dichroic.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Dichroic>&
        setLinkedDichroic (OMEModelObject::indexed_container<ome::xml::model::Dichroic, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Dichroic>& dichroic_BackReference);

        /**
         * Link Dichroic.
         *
         * @param dichroic_BackReference the Dichroic to link.
         * @returns @c true if the object was added to the internal
         * dichroicLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkDichroic (const std::shared_ptr<ome::xml::model::Dichroic>& dichroic_BackReference);

        /**
         * Unlink Dichroic.
         *
         * @param dichroic_BackReference the Dichroic to unlink.
         *
         * @returns @c true if the Dichroic was unlinked, otherwise
         * @c false if the Dichroic was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkDichroic (const std::shared_ptr<ome::xml::model::Dichroic>& dichroic_BackReference);

        /**
         * Get size of linked LightPath list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type
        sizeOfLinkedLightPathList () const;

        /**
         * Get the linked LightPath list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type
        getLinkedLightPathList () const;

        /**
         * Get linked LightPath.
         *
         * @param index the index number of the LightPath.
         * @returns a weak pointer to the LightPath.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        getLinkedLightPath (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked LightPath.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the LightPath.
         * @param lightPath_BackReference the LightPath to set.
         * @returns a weak pointer to the LightPath.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        setLinkedLightPath (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Link LightPath.
         *
         * @param lightPath_BackReference the LightPath to link.
         * @returns @c true if the object was added to the internal
         * lightPathLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkLightPath (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Unlink LightPath.
         *
         * @param lightPath_BackReference the LightPath to unlink.
         *
         * @returns @c true if the LightPath was unlinked, otherwise
         * @c false if the LightPath was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkLightPath (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Get size of linked ROI list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::ROI, std::weak_ptr>::type::size_type
        sizeOfLinkedROIList () const;

        /**
         * Get the linked ROI list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::ROI, std::weak_ptr>::type
        getLinkedROIList () const;

        /**
         * Get linked ROI.
         *
         * @param index the index number of the ROI.
         * @returns a weak pointer to the ROI.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::ROI>&
        getLinkedROI (OMEModelObject::indexed_container<ome::xml::model::ROI, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked ROI.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the ROI.
         * @param roi_BackReference the ROI to set.
         * @returns a weak pointer to the ROI.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::ROI>&
        setLinkedROI (OMEModelObject::indexed_container<ome::xml::model::ROI, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::ROI>& roi_BackReference);

        /**
         * Link ROI.
         *
         * @param roi_BackReference the ROI to link.
         * @returns @c true if the object was added to the internal
         * roiLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkROI (const std::shared_ptr<ome::xml::model::ROI>& roi_BackReference);

        /**
         * Unlink ROI.
         *
         * @param roi_BackReference the ROI to unlink.
         *
         * @returns @c true if the ROI was unlinked, otherwise
         * @c false if the ROI was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkROI (const std::shared_ptr<ome::xml::model::ROI>& roi_BackReference);

        /**
         * Get size of linked Shape list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Shape, std::weak_ptr>::type::size_type
        sizeOfLinkedShapeList () const;

        /**
         * Get the linked Shape list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Shape, std::weak_ptr>::type
        getLinkedShapeList () const;

        /**
         * Get linked Shape.
         *
         * @param index the index number of the Shape.
         * @returns a weak pointer to the Shape.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Shape>&
        getLinkedShape (OMEModelObject::indexed_container<ome::xml::model::Shape, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Shape.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Shape.
         * @param shape_BackReference the Shape to set.
         * @returns a weak pointer to the Shape.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Shape>&
        setLinkedShape (OMEModelObject::indexed_container<ome::xml::model::Shape, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Shape>& shape_BackReference);

        /**
         * Link Shape.
         *
         * @param shape_BackReference the Shape to link.
         * @returns @c true if the object was added to the internal
         * shapeLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkShape (const std::shared_ptr<ome::xml::model::Shape>& shape_BackReference);

        /**
         * Unlink Shape.
         *
         * @param shape_BackReference the Shape to unlink.
         *
         * @returns @c true if the Shape was unlinked, otherwise
         * @c false if the Shape was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkShape (const std::shared_ptr<ome::xml::model::Shape>& shape_BackReference);

        /**
         * Get size of linked Plate list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Plate, std::weak_ptr>::type::size_type
        sizeOfLinkedPlateList () const;

        /**
         * Get the linked Plate list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Plate, std::weak_ptr>::type
        getLinkedPlateList () const;

        /**
         * Get linked Plate.
         *
         * @param index the index number of the Plate.
         * @returns a weak pointer to the Plate.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Plate>&
        getLinkedPlate (OMEModelObject::indexed_container<ome::xml::model::Plate, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Plate.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Plate.
         * @param plate_BackReference the Plate to set.
         * @returns a weak pointer to the Plate.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Plate>&
        setLinkedPlate (OMEModelObject::indexed_container<ome::xml::model::Plate, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Plate>& plate_BackReference);

        /**
         * Link Plate.
         *
         * @param plate_BackReference the Plate to link.
         * @returns @c true if the object was added to the internal
         * plateLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkPlate (const std::shared_ptr<ome::xml::model::Plate>& plate_BackReference);

        /**
         * Unlink Plate.
         *
         * @param plate_BackReference the Plate to unlink.
         *
         * @returns @c true if the Plate was unlinked, otherwise
         * @c false if the Plate was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkPlate (const std::shared_ptr<ome::xml::model::Plate>& plate_BackReference);

        /**
         * Get size of linked Reagent list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Reagent, std::weak_ptr>::type::size_type
        sizeOfLinkedReagentList () const;

        /**
         * Get the linked Reagent list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Reagent, std::weak_ptr>::type
        getLinkedReagentList () const;

        /**
         * Get linked Reagent.
         *
         * @param index the index number of the Reagent.
         * @returns a weak pointer to the Reagent.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Reagent>&
        getLinkedReagent (OMEModelObject::indexed_container<ome::xml::model::Reagent, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Reagent.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Reagent.
         * @param reagent_BackReference the Reagent to set.
         * @returns a weak pointer to the Reagent.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Reagent>&
        setLinkedReagent (OMEModelObject::indexed_container<ome::xml::model::Reagent, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Reagent>& reagent_BackReference);

        /**
         * Link Reagent.
         *
         * @param reagent_BackReference the Reagent to link.
         * @returns @c true if the object was added to the internal
         * reagentLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkReagent (const std::shared_ptr<ome::xml::model::Reagent>& reagent_BackReference);

        /**
         * Unlink Reagent.
         *
         * @param reagent_BackReference the Reagent to unlink.
         *
         * @returns @c true if the Reagent was unlinked, otherwise
         * @c false if the Reagent was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkReagent (const std::shared_ptr<ome::xml::model::Reagent>& reagent_BackReference);

        /**
         * Get size of linked Screen list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type
        sizeOfLinkedScreenList () const;

        /**
         * Get the linked Screen list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type
        getLinkedScreenList () const;

        /**
         * Get linked Screen.
         *
         * @param index the index number of the Screen.
         * @returns a weak pointer to the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Screen>&
        getLinkedScreen (OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Screen.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Screen.
         * @param screen_BackReference the Screen to set.
         * @returns a weak pointer to the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Screen>&
        setLinkedScreen (OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Link Screen.
         *
         * @param screen_BackReference the Screen to link.
         * @returns @c true if the object was added to the internal
         * screenLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkScreen (const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Unlink Screen.
         *
         * @param screen_BackReference the Screen to unlink.
         *
         * @returns @c true if the Screen was unlinked, otherwise
         * @c false if the Screen was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkScreen (const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Get size of linked PlateAcquisition list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::PlateAcquisition, std::weak_ptr>::type::size_type
        sizeOfLinkedPlateAcquisitionList () const;

        /**
         * Get the linked PlateAcquisition list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::PlateAcquisition, std::weak_ptr>::type
        getLinkedPlateAcquisitionList () const;

        /**
         * Get linked PlateAcquisition.
         *
         * @param index the index number of the PlateAcquisition.
         * @returns a weak pointer to the PlateAcquisition.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::PlateAcquisition>&
        getLinkedPlateAcquisition (OMEModelObject::indexed_container<ome::xml::model::PlateAcquisition, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked PlateAcquisition.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the PlateAcquisition.
         * @param plateAcquisition_BackReference the PlateAcquisition to set.
         * @returns a weak pointer to the PlateAcquisition.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::PlateAcquisition>&
        setLinkedPlateAcquisition (OMEModelObject::indexed_container<ome::xml::model::PlateAcquisition, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition_BackReference);

        /**
         * Link PlateAcquisition.
         *
         * @param plateAcquisition_BackReference the PlateAcquisition to link.
         * @returns @c true if the object was added to the internal
         * plateAcquisitionLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkPlateAcquisition (const std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition_BackReference);

        /**
         * Unlink PlateAcquisition.
         *
         * @param plateAcquisition_BackReference the PlateAcquisition to unlink.
         *
         * @returns @c true if the PlateAcquisition was unlinked, otherwise
         * @c false if the PlateAcquisition was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkPlateAcquisition (const std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition_BackReference);

        /**
         * Get size of linked Well list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type
        sizeOfLinkedWellList () const;

        /**
         * Get the linked Well list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type
        getLinkedWellList () const;

        /**
         * Get linked Well.
         *
         * @param index the index number of the Well.
         * @returns a weak pointer to the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Well>&
        getLinkedWell (OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Well.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Well.
         * @param well_BackReference the Well to set.
         * @returns a weak pointer to the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Well>&
        setLinkedWell (OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

        /**
         * Link Well.
         *
         * @param well_BackReference the Well to link.
         * @returns @c true if the object was added to the internal
         * wellLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkWell (const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

        /**
         * Unlink Well.
         *
         * @param well_BackReference the Well to unlink.
         *
         * @returns @c true if the Well was unlinked, otherwise
         * @c false if the Well was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkWell (const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_ANNOTATION_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
