/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_FILTERSET_H
#define OME_XML_MODEL_FILTERSET_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Dichroic.h>
#include <ome/xml/model/Instrument.h>
#include <ome/xml/model/ManufacturerSpec.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Channel;
      class Filter;
      class OMEModel;

      /**
       * FilterSet model object.
       */
      class FilterSet : public ManufacturerSpec
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        FilterSet();

        /**
         * Copy constructor.
         *
         * @param copy the FilterSet to copy.
         */
        FilterSet (const FilterSet& copy);

        /// Destructor.
        virtual
        ~FilterSet ();

        /**
         * Create a FilterSet model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<FilterSet>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        FilterSet&
        operator= (const FilterSet&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- FilterSet API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get size of linked ExcitationFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type
        sizeOfLinkedExcitationFilterList () const;

        /**
         * Get the linked ExcitationFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type
        getLinkedExcitationFilterList () const;

        /**
         * Get linked ExcitationFilter.
         *
         * @param index the index number of the ExcitationFilter.
         * @returns a weak pointer to the ExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        getLinkedExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked ExcitationFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the ExcitationFilter.
         * @param excitationFilter the ExcitationFilter to set.
         * @returns a weak pointer to the ExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        setLinkedExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Filter>& excitationFilter);

        /**
         * Link ExcitationFilter.
         *
         * @param excitationFilter the ExcitationFilter to link.
         * @returns @c true if the object was added to the internal
         * excitationFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkExcitationFilter (const std::shared_ptr<ome::xml::model::Filter>& excitationFilter);

        /**
         * Unlink ExcitationFilter.
         *
         * @param excitationFilter the ExcitationFilter to unlink.
         *
         * @returns @c true if the ExcitationFilter was unlinked, otherwise
         * @c false if the ExcitationFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkExcitationFilter (const std::shared_ptr<ome::xml::model::Filter>& excitationFilter);

        /**
         * Get linked Dichroic.
         *
         * @returns the linked Dichroic.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::Dichroic>
        getLinkedDichroic ();

        /**
         * Get linked Dichroic.
         *
         * @returns the linked Dichroic.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::Dichroic>
        getLinkedDichroic () const;

        /**
         * Link Dichroic.
         *
         * @param dichroic the Dichroic to link.
         */
        void
        linkDichroic (std::shared_ptr<ome::xml::model::Dichroic>& dichroic);

        /**
         * Unlink Dichroic.
         *
         * @param dichroic the Dichroic to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkDichroic (std::shared_ptr<ome::xml::model::Dichroic>& dichroic);

        /**
         * Get size of linked EmissionFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type
        sizeOfLinkedEmissionFilterList () const;

        /**
         * Get the linked EmissionFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type
        getLinkedEmissionFilterList () const;

        /**
         * Get linked EmissionFilter.
         *
         * @param index the index number of the EmissionFilter.
         * @returns a weak pointer to the EmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        getLinkedEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked EmissionFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the EmissionFilter.
         * @param emissionFilter the EmissionFilter to set.
         * @returns a weak pointer to the EmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Filter>&
        setLinkedEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::Filter, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Filter>& emissionFilter);

        /**
         * Link EmissionFilter.
         *
         * @param emissionFilter the EmissionFilter to link.
         * @returns @c true if the object was added to the internal
         * emissionFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkEmissionFilter (const std::shared_ptr<ome::xml::model::Filter>& emissionFilter);

        /**
         * Unlink EmissionFilter.
         *
         * @param emissionFilter the EmissionFilter to unlink.
         *
         * @returns @c true if the EmissionFilter was unlinked, otherwise
         * @c false if the EmissionFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkEmissionFilter (const std::shared_ptr<ome::xml::model::Filter>& emissionFilter);

        /**
         * Get size of linked Channel list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type
        sizeOfLinkedChannelList () const;

        /**
         * Get the linked Channel list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type
        getLinkedChannelList () const;

        /**
         * Get linked Channel.
         *
         * @param index the index number of the Channel.
         * @returns a weak pointer to the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Channel>&
        getLinkedChannel (OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Channel.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Channel.
         * @param channel_BackReference the Channel to set.
         * @returns a weak pointer to the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Channel>&
        setLinkedChannel (OMEModelObject::indexed_container<ome::xml::model::Channel, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Link Channel.
         *
         * @param channel_BackReference the Channel to link.
         * @returns @c true if the object was added to the internal
         * channels list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkChannel (const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Unlink Channel.
         *
         * @param channel_BackReference the Channel to unlink.
         *
         * @returns @c true if the Channel was unlinked, otherwise
         * @c false if the Channel was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkChannel (const std::shared_ptr<ome::xml::model::Channel>& channel_BackReference);

        /**
         * Get the Instrument property.
         *
         * @returns the Instrument property.
         */
        std::weak_ptr<ome::xml::model::Instrument>
        getInstrument ();

        /**
         * Get the Instrument property.
         *
         * @returns the Instrument property.
         */
        const std::weak_ptr<ome::xml::model::Instrument>
        getInstrument () const;

        /**
         * Set the Instrument property.
         *
         * @param instrument_BackReference the value to set.
         */
        void
        setInstrument (std::weak_ptr<ome::xml::model::Instrument>& instrument_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_FILTERSET_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
