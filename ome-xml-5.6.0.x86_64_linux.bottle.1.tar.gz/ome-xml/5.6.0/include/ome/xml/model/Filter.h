/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_FILTER_H
#define OME_XML_MODEL_FILTER_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Instrument.h>
#include <ome/xml/model/ManufacturerSpec.h>
#include <ome/xml/model/TransmittanceRange.h>
#include <ome/xml/model/enums/FilterType.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class FilterSet;
      class LightPath;
      class OMEModel;

      /**
       * Filter model object.
       */
      class Filter : public ManufacturerSpec
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Filter();

        /**
         * Copy constructor.
         *
         * @param copy the Filter to copy.
         */
        Filter (const Filter& copy);

        /// Destructor.
        virtual
        ~Filter ();

        /**
         * Create a Filter model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Filter>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Filter&
        operator= (const Filter&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Filter API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the FilterWheel property.
         *
         * @returns the FilterWheel property.
         */
        std::shared_ptr<std::string>
        getFilterWheel ();

        /**
         * Get the FilterWheel property.
         *
         * @returns the FilterWheel property.
         */
        const std::shared_ptr<std::string>
        getFilterWheel () const;

        /**
         * Set the FilterWheel property.
         *
         * @param filterWheel the value to set.
         */
        void
        setFilterWheel (std::shared_ptr<std::string>& filterWheel);

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        std::shared_ptr<ome::xml::model::enums::FilterType>
        getType ();

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        const std::shared_ptr<ome::xml::model::enums::FilterType>
        getType () const;

        /**
         * Set the Type property.
         *
         * @param type the value to set.
         */
        void
        setType (std::shared_ptr<ome::xml::model::enums::FilterType>& type);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the TransmittanceRange property.
         *
         * @returns the TransmittanceRange property.
         */
        std::shared_ptr<ome::xml::model::TransmittanceRange>
        getTransmittanceRange ();

        /**
         * Get the TransmittanceRange property.
         *
         * @returns the TransmittanceRange property.
         */
        const std::shared_ptr<ome::xml::model::TransmittanceRange>
        getTransmittanceRange () const;

        /**
         * Set the TransmittanceRange property.
         *
         * @param transmittanceRange the value to set.
         */
        void
        setTransmittanceRange (std::shared_ptr<ome::xml::model::TransmittanceRange>& transmittanceRange);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Instrument property.
         *
         * @returns the Instrument property.
         */
        std::weak_ptr<ome::xml::model::Instrument>
        getInstrument ();

        /**
         * Get the Instrument property.
         *
         * @returns the Instrument property.
         */
        const std::weak_ptr<ome::xml::model::Instrument>
        getInstrument () const;

        /**
         * Set the Instrument property.
         *
         * @param instrument_BackReference the value to set.
         */
        void
        setInstrument (std::weak_ptr<ome::xml::model::Instrument>& instrument_BackReference);

        /**
         * Get size of linked FilterSetExcitationFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type
        sizeOfLinkedFilterSetExcitationFilterList () const;

        /**
         * Get the linked FilterSetExcitationFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type
        getLinkedFilterSetExcitationFilterList () const;

        /**
         * Get linked FilterSetExcitationFilter.
         *
         * @param index the index number of the FilterSetExcitationFilter.
         * @returns a weak pointer to the FilterSetExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::FilterSet>&
        getLinkedFilterSetExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked FilterSetExcitationFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the FilterSetExcitationFilter.
         * @param filterSet_BackReference the FilterSetExcitationFilter to set.
         * @returns a weak pointer to the FilterSetExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::FilterSet>&
        setLinkedFilterSetExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Link FilterSetExcitationFilter.
         *
         * @param filterSet_BackReference the FilterSetExcitationFilter to link.
         * @returns @c true if the object was added to the internal
         * filterSetExcitationFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkFilterSetExcitationFilter (const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Unlink FilterSetExcitationFilter.
         *
         * @param filterSet_BackReference the FilterSetExcitationFilter to unlink.
         *
         * @returns @c true if the FilterSetExcitationFilter was unlinked, otherwise
         * @c false if the FilterSetExcitationFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkFilterSetExcitationFilter (const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Get size of linked FilterSetEmissionFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type
        sizeOfLinkedFilterSetEmissionFilterList () const;

        /**
         * Get the linked FilterSetEmissionFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type
        getLinkedFilterSetEmissionFilterList () const;

        /**
         * Get linked FilterSetEmissionFilter.
         *
         * @param index the index number of the FilterSetEmissionFilter.
         * @returns a weak pointer to the FilterSetEmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::FilterSet>&
        getLinkedFilterSetEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked FilterSetEmissionFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the FilterSetEmissionFilter.
         * @param filterSet_BackReference the FilterSetEmissionFilter to set.
         * @returns a weak pointer to the FilterSetEmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::FilterSet>&
        setLinkedFilterSetEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::FilterSet, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Link FilterSetEmissionFilter.
         *
         * @param filterSet_BackReference the FilterSetEmissionFilter to link.
         * @returns @c true if the object was added to the internal
         * filterSetEmissionFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkFilterSetEmissionFilter (const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Unlink FilterSetEmissionFilter.
         *
         * @param filterSet_BackReference the FilterSetEmissionFilter to unlink.
         *
         * @returns @c true if the FilterSetEmissionFilter was unlinked, otherwise
         * @c false if the FilterSetEmissionFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkFilterSetEmissionFilter (const std::shared_ptr<ome::xml::model::FilterSet>& filterSet_BackReference);

        /**
         * Get size of linked LightPathExcitationFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type
        sizeOfLinkedLightPathExcitationFilterList () const;

        /**
         * Get the linked LightPathExcitationFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type
        getLinkedLightPathExcitationFilterList () const;

        /**
         * Get linked LightPathExcitationFilter.
         *
         * @param index the index number of the LightPathExcitationFilter.
         * @returns a weak pointer to the LightPathExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        getLinkedLightPathExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked LightPathExcitationFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the LightPathExcitationFilter.
         * @param lightPath_BackReference the LightPathExcitationFilter to set.
         * @returns a weak pointer to the LightPathExcitationFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        setLinkedLightPathExcitationFilter (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Link LightPathExcitationFilter.
         *
         * @param lightPath_BackReference the LightPathExcitationFilter to link.
         * @returns @c true if the object was added to the internal
         * lightPathExcitationFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkLightPathExcitationFilter (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Unlink LightPathExcitationFilter.
         *
         * @param lightPath_BackReference the LightPathExcitationFilter to unlink.
         *
         * @returns @c true if the LightPathExcitationFilter was unlinked, otherwise
         * @c false if the LightPathExcitationFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkLightPathExcitationFilter (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Get size of linked LightPathEmissionFilter list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type
        sizeOfLinkedLightPathEmissionFilterList () const;

        /**
         * Get the linked LightPathEmissionFilter list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type
        getLinkedLightPathEmissionFilterList () const;

        /**
         * Get linked LightPathEmissionFilter.
         *
         * @param index the index number of the LightPathEmissionFilter.
         * @returns a weak pointer to the LightPathEmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        getLinkedLightPathEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked LightPathEmissionFilter.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the LightPathEmissionFilter.
         * @param lightPath_BackReference the LightPathEmissionFilter to set.
         * @returns a weak pointer to the LightPathEmissionFilter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::LightPath>&
        setLinkedLightPathEmissionFilter (OMEModelObject::indexed_container<ome::xml::model::LightPath, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Link LightPathEmissionFilter.
         *
         * @param lightPath_BackReference the LightPathEmissionFilter to link.
         * @returns @c true if the object was added to the internal
         * lightPathEmissionFilterLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkLightPathEmissionFilter (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

        /**
         * Unlink LightPathEmissionFilter.
         *
         * @param lightPath_BackReference the LightPathEmissionFilter to unlink.
         *
         * @returns @c true if the LightPathEmissionFilter was unlinked, otherwise
         * @c false if the LightPathEmissionFilter was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkLightPathEmissionFilter (const std::shared_ptr<ome::xml::model::LightPath>& lightPath_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_FILTER_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
