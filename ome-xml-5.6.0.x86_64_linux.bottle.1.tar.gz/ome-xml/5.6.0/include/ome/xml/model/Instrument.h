/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_INSTRUMENT_H
#define OME_XML_MODEL_INSTRUMENT_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Microscope.h>
#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class Detector;
      class Dichroic;
      class Filter;
      class FilterSet;
      class Image;
      class LightSource;
      class OMEModel;
      class Objective;

      /**
       * Instrument model object.
       */
      class Instrument : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Instrument();

        /**
         * Copy constructor.
         *
         * @param copy the Instrument to copy.
         */
        Instrument (const Instrument& copy);

        /// Destructor.
        virtual
        ~Instrument ();

        /**
         * Create a Instrument model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Instrument>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Instrument&
        operator= (const Instrument&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Instrument API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Microscope property.
         *
         * @returns the Microscope property.
         */
        std::shared_ptr<ome::xml::model::Microscope>
        getMicroscope ();

        /**
         * Get the Microscope property.
         *
         * @returns the Microscope property.
         */
        const std::shared_ptr<ome::xml::model::Microscope>
        getMicroscope () const;

        /**
         * Set the Microscope property.
         *
         * @param microscope the value to set.
         */
        void
        setMicroscope (std::shared_ptr<ome::xml::model::Microscope>& microscope);

        /**
         * Get size of linked LightSource list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::LightSource>>::size_type
        sizeOfLightSourceList () const;

        /**
         * Get the LightSource list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::LightSource>>&
        getLightSourceList ();

        /**
         * Get the LightSource list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::LightSource>>&
        getLightSourceList () const;

        /**
         * Get LightSource.
         *
         * @param index the index number of the LightSource.
         * @returns the LightSource.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::LightSource>&
        getLightSource (std::vector<std::shared_ptr<ome::xml::model::LightSource>>::size_type index);

        /**
         * Get LightSource.
         *
         * @param index the index number of the LightSource.
         * @returns the LightSource.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::LightSource>&
        getLightSource (std::vector<std::shared_ptr<ome::xml::model::LightSource>>::size_type index) const;

        /**
         * Set LightSource.
         *
         * @param index the index number of the LightSource.
         * @param lightSource the LightSource to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setLightSource (std::vector<std::shared_ptr<ome::xml::model::LightSource>>::size_type index,
                               std::shared_ptr<ome::xml::model::LightSource>& lightSource);

        /**
         * Add LightSource.
         *
         * @param lightSource the LightSource to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addLightSource (std::shared_ptr<ome::xml::model::LightSource>& lightSource);

        /**
         * Remove LightSource.
         *
         * @param lightSource the LightSource to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeLightSource (std::shared_ptr<ome::xml::model::LightSource>& lightSource);

        /**
         * Get size of linked Detector list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Detector>>::size_type
        sizeOfDetectorList () const;

        /**
         * Get the Detector list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Detector>>&
        getDetectorList ();

        /**
         * Get the Detector list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Detector>>&
        getDetectorList () const;

        /**
         * Get Detector.
         *
         * @param index the index number of the Detector.
         * @returns the Detector.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Detector>&
        getDetector (std::vector<std::shared_ptr<ome::xml::model::Detector>>::size_type index);

        /**
         * Get Detector.
         *
         * @param index the index number of the Detector.
         * @returns the Detector.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Detector>&
        getDetector (std::vector<std::shared_ptr<ome::xml::model::Detector>>::size_type index) const;

        /**
         * Set Detector.
         *
         * @param index the index number of the Detector.
         * @param detector the Detector to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setDetector (std::vector<std::shared_ptr<ome::xml::model::Detector>>::size_type index,
                               std::shared_ptr<ome::xml::model::Detector>& detector);

        /**
         * Add Detector.
         *
         * @param detector the Detector to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addDetector (std::shared_ptr<ome::xml::model::Detector>& detector);

        /**
         * Remove Detector.
         *
         * @param detector the Detector to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeDetector (std::shared_ptr<ome::xml::model::Detector>& detector);

        /**
         * Get size of linked Objective list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Objective>>::size_type
        sizeOfObjectiveList () const;

        /**
         * Get the Objective list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Objective>>&
        getObjectiveList ();

        /**
         * Get the Objective list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Objective>>&
        getObjectiveList () const;

        /**
         * Get Objective.
         *
         * @param index the index number of the Objective.
         * @returns the Objective.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Objective>&
        getObjective (std::vector<std::shared_ptr<ome::xml::model::Objective>>::size_type index);

        /**
         * Get Objective.
         *
         * @param index the index number of the Objective.
         * @returns the Objective.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Objective>&
        getObjective (std::vector<std::shared_ptr<ome::xml::model::Objective>>::size_type index) const;

        /**
         * Set Objective.
         *
         * @param index the index number of the Objective.
         * @param objective the Objective to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setObjective (std::vector<std::shared_ptr<ome::xml::model::Objective>>::size_type index,
                               std::shared_ptr<ome::xml::model::Objective>& objective);

        /**
         * Add Objective.
         *
         * @param objective the Objective to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addObjective (std::shared_ptr<ome::xml::model::Objective>& objective);

        /**
         * Remove Objective.
         *
         * @param objective the Objective to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeObjective (std::shared_ptr<ome::xml::model::Objective>& objective);

        /**
         * Get size of linked FilterSet list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::FilterSet>>::size_type
        sizeOfFilterSetList () const;

        /**
         * Get the FilterSet list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::FilterSet>>&
        getFilterSetList ();

        /**
         * Get the FilterSet list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::FilterSet>>&
        getFilterSetList () const;

        /**
         * Get FilterSet.
         *
         * @param index the index number of the FilterSet.
         * @returns the FilterSet.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::FilterSet>&
        getFilterSet (std::vector<std::shared_ptr<ome::xml::model::FilterSet>>::size_type index);

        /**
         * Get FilterSet.
         *
         * @param index the index number of the FilterSet.
         * @returns the FilterSet.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::FilterSet>&
        getFilterSet (std::vector<std::shared_ptr<ome::xml::model::FilterSet>>::size_type index) const;

        /**
         * Set FilterSet.
         *
         * @param index the index number of the FilterSet.
         * @param filterSet the FilterSet to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setFilterSet (std::vector<std::shared_ptr<ome::xml::model::FilterSet>>::size_type index,
                               std::shared_ptr<ome::xml::model::FilterSet>& filterSet);

        /**
         * Add FilterSet.
         *
         * @param filterSet the FilterSet to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addFilterSet (std::shared_ptr<ome::xml::model::FilterSet>& filterSet);

        /**
         * Remove FilterSet.
         *
         * @param filterSet the FilterSet to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeFilterSet (std::shared_ptr<ome::xml::model::FilterSet>& filterSet);

        /**
         * Get size of linked Filter list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Filter>>::size_type
        sizeOfFilterList () const;

        /**
         * Get the Filter list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Filter>>&
        getFilterList ();

        /**
         * Get the Filter list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Filter>>&
        getFilterList () const;

        /**
         * Get Filter.
         *
         * @param index the index number of the Filter.
         * @returns the Filter.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Filter>&
        getFilter (std::vector<std::shared_ptr<ome::xml::model::Filter>>::size_type index);

        /**
         * Get Filter.
         *
         * @param index the index number of the Filter.
         * @returns the Filter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Filter>&
        getFilter (std::vector<std::shared_ptr<ome::xml::model::Filter>>::size_type index) const;

        /**
         * Set Filter.
         *
         * @param index the index number of the Filter.
         * @param filter the Filter to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setFilter (std::vector<std::shared_ptr<ome::xml::model::Filter>>::size_type index,
                               std::shared_ptr<ome::xml::model::Filter>& filter);

        /**
         * Add Filter.
         *
         * @param filter the Filter to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addFilter (std::shared_ptr<ome::xml::model::Filter>& filter);

        /**
         * Remove Filter.
         *
         * @param filter the Filter to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeFilter (std::shared_ptr<ome::xml::model::Filter>& filter);

        /**
         * Get size of linked Dichroic list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Dichroic>>::size_type
        sizeOfDichroicList () const;

        /**
         * Get the Dichroic list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Dichroic>>&
        getDichroicList ();

        /**
         * Get the Dichroic list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Dichroic>>&
        getDichroicList () const;

        /**
         * Get Dichroic.
         *
         * @param index the index number of the Dichroic.
         * @returns the Dichroic.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Dichroic>&
        getDichroic (std::vector<std::shared_ptr<ome::xml::model::Dichroic>>::size_type index);

        /**
         * Get Dichroic.
         *
         * @param index the index number of the Dichroic.
         * @returns the Dichroic.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Dichroic>&
        getDichroic (std::vector<std::shared_ptr<ome::xml::model::Dichroic>>::size_type index) const;

        /**
         * Set Dichroic.
         *
         * @param index the index number of the Dichroic.
         * @param dichroic the Dichroic to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setDichroic (std::vector<std::shared_ptr<ome::xml::model::Dichroic>>::size_type index,
                               std::shared_ptr<ome::xml::model::Dichroic>& dichroic);

        /**
         * Add Dichroic.
         *
         * @param dichroic the Dichroic to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addDichroic (std::shared_ptr<ome::xml::model::Dichroic>& dichroic);

        /**
         * Remove Dichroic.
         *
         * @param dichroic the Dichroic to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeDichroic (std::shared_ptr<ome::xml::model::Dichroic>& dichroic);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type
        sizeOfLinkedImageList () const;

        /**
         * Get the linked Image list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type
        getLinkedImageList () const;

        /**
         * Get linked Image.
         *
         * @param index the index number of the Image.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        getLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Image.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Image.
         * @param image_BackReference the Image to set.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        setLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Link Image.
         *
         * @param image_BackReference the Image to link.
         * @returns @c true if the object was added to the internal
         * images list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Unlink Image.
         *
         * @param image_BackReference the Image to unlink.
         *
         * @returns @c true if the Image was unlinked, otherwise
         * @c false if the Image was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_INSTRUMENT_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
