/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_IMAGINGENVIRONMENT_H
#define OME_XML_MODEL_IMAGINGENVIRONMENT_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/UnitsPressure.h>
#include <ome/xml/model/enums/UnitsTemperature.h>
#include <ome/xml/model/primitives/OrderedMultimap.h>
#include <ome/xml/model/primitives/PercentFraction.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class OMEModel;

      /**
       * ImagingEnvironment model object.
       */
      class ImagingEnvironment : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        ImagingEnvironment();

        /**
         * Copy constructor.
         *
         * @param copy the ImagingEnvironment to copy.
         */
        ImagingEnvironment (const ImagingEnvironment& copy);

        /// Destructor.
        virtual
        ~ImagingEnvironment ();

        /**
         * Create a ImagingEnvironment model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<ImagingEnvironment>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        ImagingEnvironment&
        operator= (const ImagingEnvironment&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- ImagingEnvironment API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the CO2Percent property.
         *
         * @returns the CO2Percent property.
         */
        std::shared_ptr<ome::xml::model::primitives::PercentFraction>
        getCO2Percent ();

        /**
         * Get the CO2Percent property.
         *
         * @returns the CO2Percent property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PercentFraction>
        getCO2Percent () const;

        /**
         * Set the CO2Percent property.
         *
         * @param co2Percent the value to set.
         */
        void
        setCO2Percent (std::shared_ptr<ome::xml::model::primitives::PercentFraction>& co2Percent);

        /**
         * Get the Temperature property.
         *
         * @returns the Temperature property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature > >&
        getTemperature ();

        /**
         * Get the Temperature property.
         *
         * @returns the Temperature property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature > >&
        getTemperature () const;

        /**
         * Set the Temperature property.
         *
         * @param temperature the value to set.
         */
        void
        setTemperature (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature > >& temperature);

        /**
         * Get the AirPressure property.
         *
         * @returns the AirPressure property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure > >&
        getAirPressure ();

        /**
         * Get the AirPressure property.
         *
         * @returns the AirPressure property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure > >&
        getAirPressure () const;

        /**
         * Set the AirPressure property.
         *
         * @param airPressure the value to set.
         */
        void
        setAirPressure (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure > >& airPressure);

        /**
         * Get the Humidity property.
         *
         * @returns the Humidity property.
         */
        std::shared_ptr<ome::xml::model::primitives::PercentFraction>
        getHumidity ();

        /**
         * Get the Humidity property.
         *
         * @returns the Humidity property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PercentFraction>
        getHumidity () const;

        /**
         * Set the Humidity property.
         *
         * @param humidity the value to set.
         */
        void
        setHumidity (std::shared_ptr<ome::xml::model::primitives::PercentFraction>& humidity);

        /**
         * Get the Map property.
         *
         * @returns the Map property.
         */
        std::shared_ptr<ome::xml::model::primitives::OrderedMultimap>
        getMap ();

        /**
         * Get the Map property.
         *
         * @returns the Map property.
         */
        const std::shared_ptr<ome::xml::model::primitives::OrderedMultimap>
        getMap () const;

        /**
         * Set the Map property.
         *
         * @param map the value to set.
         */
        void
        setMap (std::shared_ptr<ome::xml::model::primitives::OrderedMultimap>& map);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_IMAGINGENVIRONMENT_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
