/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_OME_H
#define OME_XML_MODEL_OME_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/BinaryOnly.h>
#include <ome/xml/model/Rights.h>
#include <ome/xml/model/StructuredAnnotations.h>
#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Dataset;
      class Experiment;
      class Experimenter;
      class ExperimenterGroup;
      class Folder;
      class Image;
      class Instrument;
      class OMEModel;
      class Plate;
      class Project;
      class ROI;
      class Screen;

      /**
       * OME model object.
       */
      class OME : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        OME();

        /**
         * Copy constructor.
         *
         * @param copy the OME to copy.
         */
        OME (const OME& copy);

        /// Destructor.
        virtual
        ~OME ();

        /**
         * Create a OME model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<OME>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        OME&
        operator= (const OME&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- OME API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the UUID property.
         *
         * @returns the UUID property.
         */
        std::shared_ptr<std::string>
        getUUID ();

        /**
         * Get the UUID property.
         *
         * @returns the UUID property.
         */
        const std::shared_ptr<std::string>
        getUUID () const;

        /**
         * Set the UUID property.
         *
         * @param uuid the value to set.
         */
        void
        setUUID (std::shared_ptr<std::string>& uuid);

        /**
         * Get the Creator property.
         *
         * @returns the Creator property.
         */
        std::shared_ptr<std::string>
        getCreator ();

        /**
         * Get the Creator property.
         *
         * @returns the Creator property.
         */
        const std::shared_ptr<std::string>
        getCreator () const;

        /**
         * Set the Creator property.
         *
         * @param creator the value to set.
         */
        void
        setCreator (std::shared_ptr<std::string>& creator);

        /**
         * Get the Rights property.
         *
         * @returns the Rights property.
         */
        std::shared_ptr<ome::xml::model::Rights>
        getRights ();

        /**
         * Get the Rights property.
         *
         * @returns the Rights property.
         */
        const std::shared_ptr<ome::xml::model::Rights>
        getRights () const;

        /**
         * Set the Rights property.
         *
         * @param rights the value to set.
         */
        void
        setRights (std::shared_ptr<ome::xml::model::Rights>& rights);

        /**
         * Get size of linked Project list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Project>>::size_type
        sizeOfProjectList () const;

        /**
         * Get the Project list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Project>>&
        getProjectList ();

        /**
         * Get the Project list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Project>>&
        getProjectList () const;

        /**
         * Get Project.
         *
         * @param index the index number of the Project.
         * @returns the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Project>&
        getProject (std::vector<std::shared_ptr<ome::xml::model::Project>>::size_type index);

        /**
         * Get Project.
         *
         * @param index the index number of the Project.
         * @returns the Project.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Project>&
        getProject (std::vector<std::shared_ptr<ome::xml::model::Project>>::size_type index) const;

        /**
         * Set Project.
         *
         * @param index the index number of the Project.
         * @param project the Project to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setProject (std::vector<std::shared_ptr<ome::xml::model::Project>>::size_type index,
                               std::shared_ptr<ome::xml::model::Project>& project);

        /**
         * Add Project.
         *
         * @param project the Project to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addProject (std::shared_ptr<ome::xml::model::Project>& project);

        /**
         * Remove Project.
         *
         * @param project the Project to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeProject (std::shared_ptr<ome::xml::model::Project>& project);

        /**
         * Get size of linked Dataset list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Dataset>>::size_type
        sizeOfDatasetList () const;

        /**
         * Get the Dataset list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Dataset>>&
        getDatasetList ();

        /**
         * Get the Dataset list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Dataset>>&
        getDatasetList () const;

        /**
         * Get Dataset.
         *
         * @param index the index number of the Dataset.
         * @returns the Dataset.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Dataset>&
        getDataset (std::vector<std::shared_ptr<ome::xml::model::Dataset>>::size_type index);

        /**
         * Get Dataset.
         *
         * @param index the index number of the Dataset.
         * @returns the Dataset.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Dataset>&
        getDataset (std::vector<std::shared_ptr<ome::xml::model::Dataset>>::size_type index) const;

        /**
         * Set Dataset.
         *
         * @param index the index number of the Dataset.
         * @param dataset the Dataset to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setDataset (std::vector<std::shared_ptr<ome::xml::model::Dataset>>::size_type index,
                               std::shared_ptr<ome::xml::model::Dataset>& dataset);

        /**
         * Add Dataset.
         *
         * @param dataset the Dataset to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addDataset (std::shared_ptr<ome::xml::model::Dataset>& dataset);

        /**
         * Remove Dataset.
         *
         * @param dataset the Dataset to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeDataset (std::shared_ptr<ome::xml::model::Dataset>& dataset);

        /**
         * Get size of linked Folder list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Folder>>::size_type
        sizeOfFolderList () const;

        /**
         * Get the Folder list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Folder>>&
        getFolderList ();

        /**
         * Get the Folder list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Folder>>&
        getFolderList () const;

        /**
         * Get Folder.
         *
         * @param index the index number of the Folder.
         * @returns the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Folder>&
        getFolder (std::vector<std::shared_ptr<ome::xml::model::Folder>>::size_type index);

        /**
         * Get Folder.
         *
         * @param index the index number of the Folder.
         * @returns the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Folder>&
        getFolder (std::vector<std::shared_ptr<ome::xml::model::Folder>>::size_type index) const;

        /**
         * Set Folder.
         *
         * @param index the index number of the Folder.
         * @param folder the Folder to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setFolder (std::vector<std::shared_ptr<ome::xml::model::Folder>>::size_type index,
                               std::shared_ptr<ome::xml::model::Folder>& folder);

        /**
         * Add Folder.
         *
         * @param folder the Folder to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addFolder (std::shared_ptr<ome::xml::model::Folder>& folder);

        /**
         * Remove Folder.
         *
         * @param folder the Folder to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeFolder (std::shared_ptr<ome::xml::model::Folder>& folder);

        /**
         * Get size of linked Experiment list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Experiment>>::size_type
        sizeOfExperimentList () const;

        /**
         * Get the Experiment list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Experiment>>&
        getExperimentList ();

        /**
         * Get the Experiment list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Experiment>>&
        getExperimentList () const;

        /**
         * Get Experiment.
         *
         * @param index the index number of the Experiment.
         * @returns the Experiment.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Experiment>&
        getExperiment (std::vector<std::shared_ptr<ome::xml::model::Experiment>>::size_type index);

        /**
         * Get Experiment.
         *
         * @param index the index number of the Experiment.
         * @returns the Experiment.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Experiment>&
        getExperiment (std::vector<std::shared_ptr<ome::xml::model::Experiment>>::size_type index) const;

        /**
         * Set Experiment.
         *
         * @param index the index number of the Experiment.
         * @param experiment the Experiment to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setExperiment (std::vector<std::shared_ptr<ome::xml::model::Experiment>>::size_type index,
                               std::shared_ptr<ome::xml::model::Experiment>& experiment);

        /**
         * Add Experiment.
         *
         * @param experiment the Experiment to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addExperiment (std::shared_ptr<ome::xml::model::Experiment>& experiment);

        /**
         * Remove Experiment.
         *
         * @param experiment the Experiment to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeExperiment (std::shared_ptr<ome::xml::model::Experiment>& experiment);

        /**
         * Get size of linked Plate list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Plate>>::size_type
        sizeOfPlateList () const;

        /**
         * Get the Plate list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Plate>>&
        getPlateList ();

        /**
         * Get the Plate list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Plate>>&
        getPlateList () const;

        /**
         * Get Plate.
         *
         * @param index the index number of the Plate.
         * @returns the Plate.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Plate>&
        getPlate (std::vector<std::shared_ptr<ome::xml::model::Plate>>::size_type index);

        /**
         * Get Plate.
         *
         * @param index the index number of the Plate.
         * @returns the Plate.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Plate>&
        getPlate (std::vector<std::shared_ptr<ome::xml::model::Plate>>::size_type index) const;

        /**
         * Set Plate.
         *
         * @param index the index number of the Plate.
         * @param plate the Plate to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setPlate (std::vector<std::shared_ptr<ome::xml::model::Plate>>::size_type index,
                               std::shared_ptr<ome::xml::model::Plate>& plate);

        /**
         * Add Plate.
         *
         * @param plate the Plate to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addPlate (std::shared_ptr<ome::xml::model::Plate>& plate);

        /**
         * Remove Plate.
         *
         * @param plate the Plate to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removePlate (std::shared_ptr<ome::xml::model::Plate>& plate);

        /**
         * Get size of linked Screen list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Screen>>::size_type
        sizeOfScreenList () const;

        /**
         * Get the Screen list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Screen>>&
        getScreenList ();

        /**
         * Get the Screen list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Screen>>&
        getScreenList () const;

        /**
         * Get Screen.
         *
         * @param index the index number of the Screen.
         * @returns the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Screen>&
        getScreen (std::vector<std::shared_ptr<ome::xml::model::Screen>>::size_type index);

        /**
         * Get Screen.
         *
         * @param index the index number of the Screen.
         * @returns the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Screen>&
        getScreen (std::vector<std::shared_ptr<ome::xml::model::Screen>>::size_type index) const;

        /**
         * Set Screen.
         *
         * @param index the index number of the Screen.
         * @param screen the Screen to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setScreen (std::vector<std::shared_ptr<ome::xml::model::Screen>>::size_type index,
                               std::shared_ptr<ome::xml::model::Screen>& screen);

        /**
         * Add Screen.
         *
         * @param screen the Screen to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addScreen (std::shared_ptr<ome::xml::model::Screen>& screen);

        /**
         * Remove Screen.
         *
         * @param screen the Screen to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeScreen (std::shared_ptr<ome::xml::model::Screen>& screen);

        /**
         * Get size of linked Experimenter list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Experimenter>>::size_type
        sizeOfExperimenterList () const;

        /**
         * Get the Experimenter list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Experimenter>>&
        getExperimenterList ();

        /**
         * Get the Experimenter list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Experimenter>>&
        getExperimenterList () const;

        /**
         * Get Experimenter.
         *
         * @param index the index number of the Experimenter.
         * @returns the Experimenter.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Experimenter>&
        getExperimenter (std::vector<std::shared_ptr<ome::xml::model::Experimenter>>::size_type index);

        /**
         * Get Experimenter.
         *
         * @param index the index number of the Experimenter.
         * @returns the Experimenter.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Experimenter>&
        getExperimenter (std::vector<std::shared_ptr<ome::xml::model::Experimenter>>::size_type index) const;

        /**
         * Set Experimenter.
         *
         * @param index the index number of the Experimenter.
         * @param experimenter the Experimenter to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setExperimenter (std::vector<std::shared_ptr<ome::xml::model::Experimenter>>::size_type index,
                               std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Add Experimenter.
         *
         * @param experimenter the Experimenter to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Remove Experimenter.
         *
         * @param experimenter the Experimenter to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeExperimenter (std::shared_ptr<ome::xml::model::Experimenter>& experimenter);

        /**
         * Get size of linked ExperimenterGroup list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>::size_type
        sizeOfExperimenterGroupList () const;

        /**
         * Get the ExperimenterGroup list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>&
        getExperimenterGroupList ();

        /**
         * Get the ExperimenterGroup list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>&
        getExperimenterGroupList () const;

        /**
         * Get ExperimenterGroup.
         *
         * @param index the index number of the ExperimenterGroup.
         * @returns the ExperimenterGroup.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::ExperimenterGroup>&
        getExperimenterGroup (std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>::size_type index);

        /**
         * Get ExperimenterGroup.
         *
         * @param index the index number of the ExperimenterGroup.
         * @returns the ExperimenterGroup.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::ExperimenterGroup>&
        getExperimenterGroup (std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>::size_type index) const;

        /**
         * Set ExperimenterGroup.
         *
         * @param index the index number of the ExperimenterGroup.
         * @param experimenterGroup the ExperimenterGroup to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setExperimenterGroup (std::vector<std::shared_ptr<ome::xml::model::ExperimenterGroup>>::size_type index,
                               std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup);

        /**
         * Add ExperimenterGroup.
         *
         * @param experimenterGroup the ExperimenterGroup to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addExperimenterGroup (std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup);

        /**
         * Remove ExperimenterGroup.
         *
         * @param experimenterGroup the ExperimenterGroup to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeExperimenterGroup (std::shared_ptr<ome::xml::model::ExperimenterGroup>& experimenterGroup);

        /**
         * Get size of linked Instrument list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Instrument>>::size_type
        sizeOfInstrumentList () const;

        /**
         * Get the Instrument list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Instrument>>&
        getInstrumentList ();

        /**
         * Get the Instrument list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Instrument>>&
        getInstrumentList () const;

        /**
         * Get Instrument.
         *
         * @param index the index number of the Instrument.
         * @returns the Instrument.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Instrument>&
        getInstrument (std::vector<std::shared_ptr<ome::xml::model::Instrument>>::size_type index);

        /**
         * Get Instrument.
         *
         * @param index the index number of the Instrument.
         * @returns the Instrument.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Instrument>&
        getInstrument (std::vector<std::shared_ptr<ome::xml::model::Instrument>>::size_type index) const;

        /**
         * Set Instrument.
         *
         * @param index the index number of the Instrument.
         * @param instrument the Instrument to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setInstrument (std::vector<std::shared_ptr<ome::xml::model::Instrument>>::size_type index,
                               std::shared_ptr<ome::xml::model::Instrument>& instrument);

        /**
         * Add Instrument.
         *
         * @param instrument the Instrument to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addInstrument (std::shared_ptr<ome::xml::model::Instrument>& instrument);

        /**
         * Remove Instrument.
         *
         * @param instrument the Instrument to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeInstrument (std::shared_ptr<ome::xml::model::Instrument>& instrument);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Image>>::size_type
        sizeOfImageList () const;

        /**
         * Get the Image list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Image>>&
        getImageList ();

        /**
         * Get the Image list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Image>>&
        getImageList () const;

        /**
         * Get Image.
         *
         * @param index the index number of the Image.
         * @returns the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Image>&
        getImage (std::vector<std::shared_ptr<ome::xml::model::Image>>::size_type index);

        /**
         * Get Image.
         *
         * @param index the index number of the Image.
         * @returns the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Image>&
        getImage (std::vector<std::shared_ptr<ome::xml::model::Image>>::size_type index) const;

        /**
         * Set Image.
         *
         * @param index the index number of the Image.
         * @param image the Image to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setImage (std::vector<std::shared_ptr<ome::xml::model::Image>>::size_type index,
                               std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Add Image.
         *
         * @param image the Image to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addImage (std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Remove Image.
         *
         * @param image the Image to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeImage (std::shared_ptr<ome::xml::model::Image>& image);

        /**
         * Get the StructuredAnnotations property.
         *
         * @returns the StructuredAnnotations property.
         */
        std::shared_ptr<ome::xml::model::StructuredAnnotations>
        getStructuredAnnotations ();

        /**
         * Get the StructuredAnnotations property.
         *
         * @returns the StructuredAnnotations property.
         */
        const std::shared_ptr<ome::xml::model::StructuredAnnotations>
        getStructuredAnnotations () const;

        /**
         * Set the StructuredAnnotations property.
         *
         * @param structuredAnnotations the value to set.
         */
        void
        setStructuredAnnotations (std::shared_ptr<ome::xml::model::StructuredAnnotations>& structuredAnnotations);

        /**
         * Get size of linked ROI list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::ROI>>::size_type
        sizeOfROIList () const;

        /**
         * Get the ROI list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::ROI>>&
        getROIList ();

        /**
         * Get the ROI list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::ROI>>&
        getROIList () const;

        /**
         * Get ROI.
         *
         * @param index the index number of the ROI.
         * @returns the ROI.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::ROI>&
        getROI (std::vector<std::shared_ptr<ome::xml::model::ROI>>::size_type index);

        /**
         * Get ROI.
         *
         * @param index the index number of the ROI.
         * @returns the ROI.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::ROI>&
        getROI (std::vector<std::shared_ptr<ome::xml::model::ROI>>::size_type index) const;

        /**
         * Set ROI.
         *
         * @param index the index number of the ROI.
         * @param roi the ROI to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setROI (std::vector<std::shared_ptr<ome::xml::model::ROI>>::size_type index,
                               std::shared_ptr<ome::xml::model::ROI>& roi);

        /**
         * Add ROI.
         *
         * @param roi the ROI to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addROI (std::shared_ptr<ome::xml::model::ROI>& roi);

        /**
         * Remove ROI.
         *
         * @param roi the ROI to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeROI (std::shared_ptr<ome::xml::model::ROI>& roi);

        /**
         * Get the BinaryOnly property.
         *
         * @returns the BinaryOnly property.
         */
        std::shared_ptr<ome::xml::model::BinaryOnly>
        getBinaryOnly ();

        /**
         * Get the BinaryOnly property.
         *
         * @returns the BinaryOnly property.
         */
        const std::shared_ptr<ome::xml::model::BinaryOnly>
        getBinaryOnly () const;

        /**
         * Set the BinaryOnly property.
         *
         * @param binaryOnly the value to set.
         */
        void
        setBinaryOnly (std::shared_ptr<ome::xml::model::BinaryOnly>& binaryOnly);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_OME_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
