/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_LASER_H
#define OME_XML_MODEL_LASER_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/LightSource.h>
#include <ome/xml/model/enums/LaserMedium.h>
#include <ome/xml/model/enums/LaserType.h>
#include <ome/xml/model/enums/Pulse.h>
#include <ome/xml/model/enums/UnitsFrequency.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/primitives/PositiveFloat.h>
#include <ome/xml/model/primitives/PositiveInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class OMEModel;

      /**
       * Laser model object.
       */
      class Laser : public LightSource
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Laser();

        /**
         * Copy constructor.
         *
         * @param copy the Laser to copy.
         */
        Laser (const Laser& copy);

        /// Destructor.
        virtual
        ~Laser ();

        /**
         * Create a Laser model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Laser>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Laser&
        operator= (const Laser&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Laser API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the PockelCell property.
         *
         * @returns the PockelCell property.
         */
        std::shared_ptr<bool>
        getPockelCell ();

        /**
         * Get the PockelCell property.
         *
         * @returns the PockelCell property.
         */
        const std::shared_ptr<bool>
        getPockelCell () const;

        /**
         * Set the PockelCell property.
         *
         * @param pockelCell the value to set.
         */
        void
        setPockelCell (std::shared_ptr<bool>& pockelCell);

        /**
         * Get the Tuneable property.
         *
         * @returns the Tuneable property.
         */
        std::shared_ptr<bool>
        getTuneable ();

        /**
         * Get the Tuneable property.
         *
         * @returns the Tuneable property.
         */
        const std::shared_ptr<bool>
        getTuneable () const;

        /**
         * Set the Tuneable property.
         *
         * @param tuneable the value to set.
         */
        void
        setTuneable (std::shared_ptr<bool>& tuneable);

        /**
         * Get the LaserMedium property.
         *
         * @returns the LaserMedium property.
         */
        std::shared_ptr<ome::xml::model::enums::LaserMedium>
        getLaserMedium ();

        /**
         * Get the LaserMedium property.
         *
         * @returns the LaserMedium property.
         */
        const std::shared_ptr<ome::xml::model::enums::LaserMedium>
        getLaserMedium () const;

        /**
         * Set the LaserMedium property.
         *
         * @param laserMedium the value to set.
         */
        void
        setLaserMedium (std::shared_ptr<ome::xml::model::enums::LaserMedium>& laserMedium);

        /**
         * Get the Pulse property.
         *
         * @returns the Pulse property.
         */
        std::shared_ptr<ome::xml::model::enums::Pulse>
        getPulse ();

        /**
         * Get the Pulse property.
         *
         * @returns the Pulse property.
         */
        const std::shared_ptr<ome::xml::model::enums::Pulse>
        getPulse () const;

        /**
         * Set the Pulse property.
         *
         * @param pulse the value to set.
         */
        void
        setPulse (std::shared_ptr<ome::xml::model::enums::Pulse>& pulse);

        /**
         * Get the Wavelength property.
         *
         * @returns the Wavelength property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getWavelength ();

        /**
         * Get the Wavelength property.
         *
         * @returns the Wavelength property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getWavelength () const;

        /**
         * Set the Wavelength property.
         *
         * @param wavelength the value to set.
         */
        void
        setWavelength (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& wavelength);

        /**
         * Get the FrequencyMultiplication property.
         *
         * @returns the FrequencyMultiplication property.
         */
        std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getFrequencyMultiplication ();

        /**
         * Get the FrequencyMultiplication property.
         *
         * @returns the FrequencyMultiplication property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getFrequencyMultiplication () const;

        /**
         * Set the FrequencyMultiplication property.
         *
         * @param frequencyMultiplication the value to set.
         */
        void
        setFrequencyMultiplication (std::shared_ptr<ome::xml::model::primitives::PositiveInteger>& frequencyMultiplication);

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        std::shared_ptr<ome::xml::model::enums::LaserType>
        getType ();

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        const std::shared_ptr<ome::xml::model::enums::LaserType>
        getType () const;

        /**
         * Set the Type property.
         *
         * @param type the value to set.
         */
        void
        setType (std::shared_ptr<ome::xml::model::enums::LaserType>& type);

        /**
         * Get the RepetitionRate property.
         *
         * @returns the RepetitionRate property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > >&
        getRepetitionRate ();

        /**
         * Get the RepetitionRate property.
         *
         * @returns the RepetitionRate property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > >&
        getRepetitionRate () const;

        /**
         * Set the RepetitionRate property.
         *
         * @param repetitionRate the value to set.
         */
        void
        setRepetitionRate (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > >& repetitionRate);

        /**
         * Get linked Pump.
         *
         * @returns the linked Pump.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::LightSource>
        getLinkedPump ();

        /**
         * Get linked Pump.
         *
         * @returns the linked Pump.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::LightSource>
        getLinkedPump () const;

        /**
         * Link Pump.
         *
         * @param pump the Pump to link.
         */
        void
        linkPump (std::shared_ptr<ome::xml::model::LightSource>& pump);

        /**
         * Unlink Pump.
         *
         * @param pump the Pump to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkPump (std::shared_ptr<ome::xml::model::LightSource>& pump);

        const std::string&
        getLightSourceType() const;

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_LASER_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
