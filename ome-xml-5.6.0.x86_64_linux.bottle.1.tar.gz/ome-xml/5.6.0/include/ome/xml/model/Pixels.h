/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_PIXELS_H
#define OME_XML_MODEL_PIXELS_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/MetadataOnly.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/DimensionOrder.h>
#include <ome/xml/model/enums/PixelType.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/enums/UnitsTime.h>
#include <ome/xml/model/primitives/PositiveFloat.h>
#include <ome/xml/model/primitives/PositiveInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class BinData;
      class Channel;
      class OMEModel;
      class Plane;
      class TiffData;

      /**
       * Pixels model object.
       */
      class Pixels : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Pixels();

        /**
         * Copy constructor.
         *
         * @param copy the Pixels to copy.
         */
        Pixels (const Pixels& copy);

        /// Destructor.
        virtual
        ~Pixels ();

        /**
         * Create a Pixels model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Pixels>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Pixels&
        operator= (const Pixels&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Pixels API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the SizeT property.
         *
         * @returns the SizeT property.
         */
        const ome::xml::model::primitives::PositiveInteger&
        getSizeT () const;

        /**
         * Set the SizeT property.
         *
         * @param sizeT the value to set.
         */
        void
        setSizeT (const ome::xml::model::primitives::PositiveInteger& sizeT);

        /**
         * Get the DimensionOrder property.
         *
         * @returns the DimensionOrder property.
         */
        ome::xml::model::enums::DimensionOrder&
        getDimensionOrder ();

        /**
         * Get the DimensionOrder property.
         *
         * @returns the DimensionOrder property.
         */
        const ome::xml::model::enums::DimensionOrder&
        getDimensionOrder () const;

        /**
         * Set the DimensionOrder property.
         *
         * @param dimensionOrder the value to set.
         */
        void
        setDimensionOrder (const ome::xml::model::enums::DimensionOrder& dimensionOrder);

        /**
         * Get the PhysicalSizeZ property.
         *
         * @returns the PhysicalSizeZ property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeZ ();

        /**
         * Get the PhysicalSizeZ property.
         *
         * @returns the PhysicalSizeZ property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeZ () const;

        /**
         * Set the PhysicalSizeZ property.
         *
         * @param physicalSizeZ the value to set.
         */
        void
        setPhysicalSizeZ (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& physicalSizeZ);

        /**
         * Get the PhysicalSizeY property.
         *
         * @returns the PhysicalSizeY property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeY ();

        /**
         * Get the PhysicalSizeY property.
         *
         * @returns the PhysicalSizeY property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeY () const;

        /**
         * Set the PhysicalSizeY property.
         *
         * @param physicalSizeY the value to set.
         */
        void
        setPhysicalSizeY (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& physicalSizeY);

        /**
         * Get the PhysicalSizeX property.
         *
         * @returns the PhysicalSizeX property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeX ();

        /**
         * Get the PhysicalSizeX property.
         *
         * @returns the PhysicalSizeX property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >&
        getPhysicalSizeX () const;

        /**
         * Set the PhysicalSizeX property.
         *
         * @param physicalSizeX the value to set.
         */
        void
        setPhysicalSizeX (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > >& physicalSizeX);

        /**
         * Get the SizeX property.
         *
         * @returns the SizeX property.
         */
        const ome::xml::model::primitives::PositiveInteger&
        getSizeX () const;

        /**
         * Set the SizeX property.
         *
         * @param sizeX the value to set.
         */
        void
        setSizeX (const ome::xml::model::primitives::PositiveInteger& sizeX);

        /**
         * Get the SizeY property.
         *
         * @returns the SizeY property.
         */
        const ome::xml::model::primitives::PositiveInteger&
        getSizeY () const;

        /**
         * Set the SizeY property.
         *
         * @param sizeY the value to set.
         */
        void
        setSizeY (const ome::xml::model::primitives::PositiveInteger& sizeY);

        /**
         * Get the SizeZ property.
         *
         * @returns the SizeZ property.
         */
        const ome::xml::model::primitives::PositiveInteger&
        getSizeZ () const;

        /**
         * Set the SizeZ property.
         *
         * @param sizeZ the value to set.
         */
        void
        setSizeZ (const ome::xml::model::primitives::PositiveInteger& sizeZ);

        /**
         * Get the BigEndian property.
         *
         * @returns the BigEndian property.
         */
        std::shared_ptr<bool>
        getBigEndian ();

        /**
         * Get the BigEndian property.
         *
         * @returns the BigEndian property.
         */
        const std::shared_ptr<bool>
        getBigEndian () const;

        /**
         * Set the BigEndian property.
         *
         * @param bigEndian the value to set.
         */
        void
        setBigEndian (std::shared_ptr<bool>& bigEndian);

        /**
         * Get the TimeIncrement property.
         *
         * @returns the TimeIncrement property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getTimeIncrement ();

        /**
         * Get the TimeIncrement property.
         *
         * @returns the TimeIncrement property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >&
        getTimeIncrement () const;

        /**
         * Set the TimeIncrement property.
         *
         * @param timeIncrement the value to set.
         */
        void
        setTimeIncrement (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > >& timeIncrement);

        /**
         * Get the SignificantBits property.
         *
         * @returns the SignificantBits property.
         */
        std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getSignificantBits ();

        /**
         * Get the SignificantBits property.
         *
         * @returns the SignificantBits property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getSignificantBits () const;

        /**
         * Set the SignificantBits property.
         *
         * @param significantBits the value to set.
         */
        void
        setSignificantBits (std::shared_ptr<ome::xml::model::primitives::PositiveInteger>& significantBits);

        /**
         * Get the SizeC property.
         *
         * @returns the SizeC property.
         */
        const ome::xml::model::primitives::PositiveInteger&
        getSizeC () const;

        /**
         * Set the SizeC property.
         *
         * @param sizeC the value to set.
         */
        void
        setSizeC (const ome::xml::model::primitives::PositiveInteger& sizeC);

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        ome::xml::model::enums::PixelType&
        getType ();

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        const ome::xml::model::enums::PixelType&
        getType () const;

        /**
         * Set the Type property.
         *
         * @param type the value to set.
         */
        void
        setType (const ome::xml::model::enums::PixelType& type);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Interleaved property.
         *
         * @returns the Interleaved property.
         */
        std::shared_ptr<bool>
        getInterleaved ();

        /**
         * Get the Interleaved property.
         *
         * @returns the Interleaved property.
         */
        const std::shared_ptr<bool>
        getInterleaved () const;

        /**
         * Set the Interleaved property.
         *
         * @param interleaved the value to set.
         */
        void
        setInterleaved (std::shared_ptr<bool>& interleaved);

        /**
         * Get size of linked Channel list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Channel>>::size_type
        sizeOfChannelList () const;

        /**
         * Get the Channel list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Channel>>&
        getChannelList ();

        /**
         * Get the Channel list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Channel>>&
        getChannelList () const;

        /**
         * Get Channel.
         *
         * @param index the index number of the Channel.
         * @returns the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Channel>&
        getChannel (std::vector<std::shared_ptr<ome::xml::model::Channel>>::size_type index);

        /**
         * Get Channel.
         *
         * @param index the index number of the Channel.
         * @returns the Channel.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Channel>&
        getChannel (std::vector<std::shared_ptr<ome::xml::model::Channel>>::size_type index) const;

        /**
         * Set Channel.
         *
         * @param index the index number of the Channel.
         * @param channel the Channel to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setChannel (std::vector<std::shared_ptr<ome::xml::model::Channel>>::size_type index,
                               std::shared_ptr<ome::xml::model::Channel>& channel);

        /**
         * Add Channel.
         *
         * @param channel the Channel to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addChannel (std::shared_ptr<ome::xml::model::Channel>& channel);

        /**
         * Remove Channel.
         *
         * @param channel the Channel to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeChannel (std::shared_ptr<ome::xml::model::Channel>& channel);

        /**
         * Get size of linked BinData list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::BinData>>::size_type
        sizeOfBinDataList () const;

        /**
         * Get the BinData list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::BinData>>&
        getBinDataList ();

        /**
         * Get the BinData list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::BinData>>&
        getBinDataList () const;

        /**
         * Get BinData.
         *
         * @param index the index number of the BinData.
         * @returns the BinData.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::BinData>&
        getBinData (std::vector<std::shared_ptr<ome::xml::model::BinData>>::size_type index);

        /**
         * Get BinData.
         *
         * @param index the index number of the BinData.
         * @returns the BinData.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::BinData>&
        getBinData (std::vector<std::shared_ptr<ome::xml::model::BinData>>::size_type index) const;

        /**
         * Set BinData.
         *
         * @param index the index number of the BinData.
         * @param binData the BinData to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setBinData (std::vector<std::shared_ptr<ome::xml::model::BinData>>::size_type index,
                               std::shared_ptr<ome::xml::model::BinData>& binData);

        /**
         * Add BinData.
         *
         * @param binData the BinData to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addBinData (std::shared_ptr<ome::xml::model::BinData>& binData);

        /**
         * Remove BinData.
         *
         * @param binData the BinData to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeBinData (std::shared_ptr<ome::xml::model::BinData>& binData);

        /**
         * Get size of linked TiffData list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::TiffData>>::size_type
        sizeOfTiffDataList () const;

        /**
         * Get the TiffData list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::TiffData>>&
        getTiffDataList ();

        /**
         * Get the TiffData list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::TiffData>>&
        getTiffDataList () const;

        /**
         * Get TiffData.
         *
         * @param index the index number of the TiffData.
         * @returns the TiffData.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::TiffData>&
        getTiffData (std::vector<std::shared_ptr<ome::xml::model::TiffData>>::size_type index);

        /**
         * Get TiffData.
         *
         * @param index the index number of the TiffData.
         * @returns the TiffData.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::TiffData>&
        getTiffData (std::vector<std::shared_ptr<ome::xml::model::TiffData>>::size_type index) const;

        /**
         * Set TiffData.
         *
         * @param index the index number of the TiffData.
         * @param tiffData the TiffData to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setTiffData (std::vector<std::shared_ptr<ome::xml::model::TiffData>>::size_type index,
                               std::shared_ptr<ome::xml::model::TiffData>& tiffData);

        /**
         * Add TiffData.
         *
         * @param tiffData the TiffData to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addTiffData (std::shared_ptr<ome::xml::model::TiffData>& tiffData);

        /**
         * Remove TiffData.
         *
         * @param tiffData the TiffData to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeTiffData (std::shared_ptr<ome::xml::model::TiffData>& tiffData);

        /**
         * Get the MetadataOnly property.
         *
         * @returns the MetadataOnly property.
         */
        std::shared_ptr<ome::xml::model::MetadataOnly>
        getMetadataOnly ();

        /**
         * Get the MetadataOnly property.
         *
         * @returns the MetadataOnly property.
         */
        const std::shared_ptr<ome::xml::model::MetadataOnly>
        getMetadataOnly () const;

        /**
         * Set the MetadataOnly property.
         *
         * @param metadataOnly the value to set.
         */
        void
        setMetadataOnly (std::shared_ptr<ome::xml::model::MetadataOnly>& metadataOnly);

        /**
         * Get size of linked Plane list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Plane>>::size_type
        sizeOfPlaneList () const;

        /**
         * Get the Plane list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Plane>>&
        getPlaneList ();

        /**
         * Get the Plane list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Plane>>&
        getPlaneList () const;

        /**
         * Get Plane.
         *
         * @param index the index number of the Plane.
         * @returns the Plane.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Plane>&
        getPlane (std::vector<std::shared_ptr<ome::xml::model::Plane>>::size_type index);

        /**
         * Get Plane.
         *
         * @param index the index number of the Plane.
         * @returns the Plane.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Plane>&
        getPlane (std::vector<std::shared_ptr<ome::xml::model::Plane>>::size_type index) const;

        /**
         * Set Plane.
         *
         * @param index the index number of the Plane.
         * @param plane the Plane to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setPlane (std::vector<std::shared_ptr<ome::xml::model::Plane>>::size_type index,
                               std::shared_ptr<ome::xml::model::Plane>& plane);

        /**
         * Add Plane.
         *
         * @param plane the Plane to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addPlane (std::shared_ptr<ome::xml::model::Plane>& plane);

        /**
         * Remove Plane.
         *
         * @param plane the Plane to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removePlane (std::shared_ptr<ome::xml::model::Plane>& plane);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_PIXELS_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
