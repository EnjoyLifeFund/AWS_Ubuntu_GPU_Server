/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_ROI_H
#define OME_XML_MODEL_ROI_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Union.h>
#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class Folder;
      class Image;
      class MicrobeamManipulation;
      class OMEModel;

      /**
       * ROI model object.
       */
      class ROI : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        ROI();

        /**
         * Copy constructor.
         *
         * @param copy the ROI to copy.
         */
        ROI (const ROI& copy);

        /// Destructor.
        virtual
        ~ROI ();

        /**
         * Create a ROI model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<ROI>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        ROI&
        operator= (const ROI&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- ROI API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        std::shared_ptr<std::string>
        getName ();

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        const std::shared_ptr<std::string>
        getName () const;

        /**
         * Set the Name property.
         *
         * @param name the value to set.
         */
        void
        setName (std::shared_ptr<std::string>& name);

        /**
         * Get the Union property.
         *
         * @returns the Union property.
         */
        std::shared_ptr<ome::xml::model::Union>
        getUnion ();

        /**
         * Get the Union property.
         *
         * @returns the Union property.
         */
        const std::shared_ptr<ome::xml::model::Union>
        getUnion () const;

        /**
         * Set the Union property.
         *
         * @param union_ the value to set.
         */
        void
        setUnion (std::shared_ptr<ome::xml::model::Union>& union_);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get size of linked Image list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type
        sizeOfLinkedImageList () const;

        /**
         * Get the linked Image list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type
        getLinkedImageList () const;

        /**
         * Get linked Image.
         *
         * @param index the index number of the Image.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        getLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Image.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Image.
         * @param image_BackReference the Image to set.
         * @returns a weak pointer to the Image.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Image>&
        setLinkedImage (OMEModelObject::indexed_container<ome::xml::model::Image, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Link Image.
         *
         * @param image_BackReference the Image to link.
         * @returns @c true if the object was added to the internal
         * imageLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Unlink Image.
         *
         * @param image_BackReference the Image to unlink.
         *
         * @returns @c true if the Image was unlinked, otherwise
         * @c false if the Image was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkImage (const std::shared_ptr<ome::xml::model::Image>& image_BackReference);

        /**
         * Get size of linked MicrobeamManipulation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::MicrobeamManipulation, std::weak_ptr>::type::size_type
        sizeOfLinkedMicrobeamManipulationList () const;

        /**
         * Get the linked MicrobeamManipulation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::MicrobeamManipulation, std::weak_ptr>::type
        getLinkedMicrobeamManipulationList () const;

        /**
         * Get linked MicrobeamManipulation.
         *
         * @param index the index number of the MicrobeamManipulation.
         * @returns a weak pointer to the MicrobeamManipulation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::MicrobeamManipulation>&
        getLinkedMicrobeamManipulation (OMEModelObject::indexed_container<ome::xml::model::MicrobeamManipulation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked MicrobeamManipulation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the MicrobeamManipulation.
         * @param microbeamManipulation_BackReference the MicrobeamManipulation to set.
         * @returns a weak pointer to the MicrobeamManipulation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::MicrobeamManipulation>&
        setLinkedMicrobeamManipulation (OMEModelObject::indexed_container<ome::xml::model::MicrobeamManipulation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation_BackReference);

        /**
         * Link MicrobeamManipulation.
         *
         * @param microbeamManipulation_BackReference the MicrobeamManipulation to link.
         * @returns @c true if the object was added to the internal
         * microbeamManipulationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkMicrobeamManipulation (const std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation_BackReference);

        /**
         * Unlink MicrobeamManipulation.
         *
         * @param microbeamManipulation_BackReference the MicrobeamManipulation to unlink.
         *
         * @returns @c true if the MicrobeamManipulation was unlinked, otherwise
         * @c false if the MicrobeamManipulation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkMicrobeamManipulation (const std::shared_ptr<ome::xml::model::MicrobeamManipulation>& microbeamManipulation_BackReference);

        /**
         * Get size of linked Folder list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type
        sizeOfLinkedFolderList () const;

        /**
         * Get the linked Folder list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type
        getLinkedFolderList () const;

        /**
         * Get linked Folder.
         *
         * @param index the index number of the Folder.
         * @returns a weak pointer to the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Folder>&
        getLinkedFolder (OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Folder.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Folder.
         * @param folder_BackReference the Folder to set.
         * @returns a weak pointer to the Folder.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Folder>&
        setLinkedFolder (OMEModelObject::indexed_container<ome::xml::model::Folder, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

        /**
         * Link Folder.
         *
         * @param folder_BackReference the Folder to link.
         * @returns @c true if the object was added to the internal
         * folderLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkFolder (const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

        /**
         * Unlink Folder.
         *
         * @param folder_BackReference the Folder to unlink.
         *
         * @returns @c true if the Folder was unlinked, otherwise
         * @c false if the Folder was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkFolder (const std::shared_ptr<ome::xml::model::Folder>& folder_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_ROI_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
