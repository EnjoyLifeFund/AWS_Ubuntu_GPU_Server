/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_STRUCTUREDANNOTATIONS_H
#define OME_XML_MODEL_STRUCTUREDANNOTATIONS_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class BooleanAnnotation;
      class CommentAnnotation;
      class DoubleAnnotation;
      class FileAnnotation;
      class ListAnnotation;
      class LongAnnotation;
      class MapAnnotation;
      class OMEModel;
      class TagAnnotation;
      class TermAnnotation;
      class TimestampAnnotation;
      class XMLAnnotation;

      /**
       * StructuredAnnotations model object.
       */
      class StructuredAnnotations : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        StructuredAnnotations();

        /**
         * Copy constructor.
         *
         * @param copy the StructuredAnnotations to copy.
         */
        StructuredAnnotations (const StructuredAnnotations& copy);

        /// Destructor.
        virtual
        ~StructuredAnnotations ();

        /**
         * Create a StructuredAnnotations model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<StructuredAnnotations>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        StructuredAnnotations&
        operator= (const StructuredAnnotations&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- StructuredAnnotations API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get size of linked XMLAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>::size_type
        sizeOfXMLAnnotationList () const;

        /**
         * Get the XMLAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>&
        getXMLAnnotationList ();

        /**
         * Get the XMLAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>&
        getXMLAnnotationList () const;

        /**
         * Get XMLAnnotation.
         *
         * @param index the index number of the XMLAnnotation.
         * @returns the XMLAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::XMLAnnotation>&
        getXMLAnnotation (std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>::size_type index);

        /**
         * Get XMLAnnotation.
         *
         * @param index the index number of the XMLAnnotation.
         * @returns the XMLAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::XMLAnnotation>&
        getXMLAnnotation (std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>::size_type index) const;

        /**
         * Set XMLAnnotation.
         *
         * @param index the index number of the XMLAnnotation.
         * @param xmlAnnotation the XMLAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setXMLAnnotation (std::vector<std::shared_ptr<ome::xml::model::XMLAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::XMLAnnotation>& xmlAnnotation);

        /**
         * Add XMLAnnotation.
         *
         * @param xmlAnnotation the XMLAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addXMLAnnotation (std::shared_ptr<ome::xml::model::XMLAnnotation>& xmlAnnotation);

        /**
         * Remove XMLAnnotation.
         *
         * @param xmlAnnotation the XMLAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeXMLAnnotation (std::shared_ptr<ome::xml::model::XMLAnnotation>& xmlAnnotation);

        /**
         * Get size of linked FileAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>::size_type
        sizeOfFileAnnotationList () const;

        /**
         * Get the FileAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>&
        getFileAnnotationList ();

        /**
         * Get the FileAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>&
        getFileAnnotationList () const;

        /**
         * Get FileAnnotation.
         *
         * @param index the index number of the FileAnnotation.
         * @returns the FileAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::FileAnnotation>&
        getFileAnnotation (std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>::size_type index);

        /**
         * Get FileAnnotation.
         *
         * @param index the index number of the FileAnnotation.
         * @returns the FileAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::FileAnnotation>&
        getFileAnnotation (std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>::size_type index) const;

        /**
         * Set FileAnnotation.
         *
         * @param index the index number of the FileAnnotation.
         * @param fileAnnotation the FileAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setFileAnnotation (std::vector<std::shared_ptr<ome::xml::model::FileAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::FileAnnotation>& fileAnnotation);

        /**
         * Add FileAnnotation.
         *
         * @param fileAnnotation the FileAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addFileAnnotation (std::shared_ptr<ome::xml::model::FileAnnotation>& fileAnnotation);

        /**
         * Remove FileAnnotation.
         *
         * @param fileAnnotation the FileAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeFileAnnotation (std::shared_ptr<ome::xml::model::FileAnnotation>& fileAnnotation);

        /**
         * Get size of linked ListAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>::size_type
        sizeOfListAnnotationList () const;

        /**
         * Get the ListAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>&
        getListAnnotationList ();

        /**
         * Get the ListAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>&
        getListAnnotationList () const;

        /**
         * Get ListAnnotation.
         *
         * @param index the index number of the ListAnnotation.
         * @returns the ListAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::ListAnnotation>&
        getListAnnotation (std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>::size_type index);

        /**
         * Get ListAnnotation.
         *
         * @param index the index number of the ListAnnotation.
         * @returns the ListAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::ListAnnotation>&
        getListAnnotation (std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>::size_type index) const;

        /**
         * Set ListAnnotation.
         *
         * @param index the index number of the ListAnnotation.
         * @param listAnnotation the ListAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setListAnnotation (std::vector<std::shared_ptr<ome::xml::model::ListAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::ListAnnotation>& listAnnotation);

        /**
         * Add ListAnnotation.
         *
         * @param listAnnotation the ListAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addListAnnotation (std::shared_ptr<ome::xml::model::ListAnnotation>& listAnnotation);

        /**
         * Remove ListAnnotation.
         *
         * @param listAnnotation the ListAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeListAnnotation (std::shared_ptr<ome::xml::model::ListAnnotation>& listAnnotation);

        /**
         * Get size of linked LongAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>::size_type
        sizeOfLongAnnotationList () const;

        /**
         * Get the LongAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>&
        getLongAnnotationList ();

        /**
         * Get the LongAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>&
        getLongAnnotationList () const;

        /**
         * Get LongAnnotation.
         *
         * @param index the index number of the LongAnnotation.
         * @returns the LongAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::LongAnnotation>&
        getLongAnnotation (std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>::size_type index);

        /**
         * Get LongAnnotation.
         *
         * @param index the index number of the LongAnnotation.
         * @returns the LongAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::LongAnnotation>&
        getLongAnnotation (std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>::size_type index) const;

        /**
         * Set LongAnnotation.
         *
         * @param index the index number of the LongAnnotation.
         * @param longAnnotation the LongAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setLongAnnotation (std::vector<std::shared_ptr<ome::xml::model::LongAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::LongAnnotation>& longAnnotation);

        /**
         * Add LongAnnotation.
         *
         * @param longAnnotation the LongAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addLongAnnotation (std::shared_ptr<ome::xml::model::LongAnnotation>& longAnnotation);

        /**
         * Remove LongAnnotation.
         *
         * @param longAnnotation the LongAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeLongAnnotation (std::shared_ptr<ome::xml::model::LongAnnotation>& longAnnotation);

        /**
         * Get size of linked DoubleAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>::size_type
        sizeOfDoubleAnnotationList () const;

        /**
         * Get the DoubleAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>&
        getDoubleAnnotationList ();

        /**
         * Get the DoubleAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>&
        getDoubleAnnotationList () const;

        /**
         * Get DoubleAnnotation.
         *
         * @param index the index number of the DoubleAnnotation.
         * @returns the DoubleAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::DoubleAnnotation>&
        getDoubleAnnotation (std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>::size_type index);

        /**
         * Get DoubleAnnotation.
         *
         * @param index the index number of the DoubleAnnotation.
         * @returns the DoubleAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::DoubleAnnotation>&
        getDoubleAnnotation (std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>::size_type index) const;

        /**
         * Set DoubleAnnotation.
         *
         * @param index the index number of the DoubleAnnotation.
         * @param doubleAnnotation the DoubleAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setDoubleAnnotation (std::vector<std::shared_ptr<ome::xml::model::DoubleAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::DoubleAnnotation>& doubleAnnotation);

        /**
         * Add DoubleAnnotation.
         *
         * @param doubleAnnotation the DoubleAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addDoubleAnnotation (std::shared_ptr<ome::xml::model::DoubleAnnotation>& doubleAnnotation);

        /**
         * Remove DoubleAnnotation.
         *
         * @param doubleAnnotation the DoubleAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeDoubleAnnotation (std::shared_ptr<ome::xml::model::DoubleAnnotation>& doubleAnnotation);

        /**
         * Get size of linked CommentAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>::size_type
        sizeOfCommentAnnotationList () const;

        /**
         * Get the CommentAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>&
        getCommentAnnotationList ();

        /**
         * Get the CommentAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>&
        getCommentAnnotationList () const;

        /**
         * Get CommentAnnotation.
         *
         * @param index the index number of the CommentAnnotation.
         * @returns the CommentAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::CommentAnnotation>&
        getCommentAnnotation (std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>::size_type index);

        /**
         * Get CommentAnnotation.
         *
         * @param index the index number of the CommentAnnotation.
         * @returns the CommentAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::CommentAnnotation>&
        getCommentAnnotation (std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>::size_type index) const;

        /**
         * Set CommentAnnotation.
         *
         * @param index the index number of the CommentAnnotation.
         * @param commentAnnotation the CommentAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setCommentAnnotation (std::vector<std::shared_ptr<ome::xml::model::CommentAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::CommentAnnotation>& commentAnnotation);

        /**
         * Add CommentAnnotation.
         *
         * @param commentAnnotation the CommentAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addCommentAnnotation (std::shared_ptr<ome::xml::model::CommentAnnotation>& commentAnnotation);

        /**
         * Remove CommentAnnotation.
         *
         * @param commentAnnotation the CommentAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeCommentAnnotation (std::shared_ptr<ome::xml::model::CommentAnnotation>& commentAnnotation);

        /**
         * Get size of linked BooleanAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>::size_type
        sizeOfBooleanAnnotationList () const;

        /**
         * Get the BooleanAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>&
        getBooleanAnnotationList ();

        /**
         * Get the BooleanAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>&
        getBooleanAnnotationList () const;

        /**
         * Get BooleanAnnotation.
         *
         * @param index the index number of the BooleanAnnotation.
         * @returns the BooleanAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::BooleanAnnotation>&
        getBooleanAnnotation (std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>::size_type index);

        /**
         * Get BooleanAnnotation.
         *
         * @param index the index number of the BooleanAnnotation.
         * @returns the BooleanAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::BooleanAnnotation>&
        getBooleanAnnotation (std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>::size_type index) const;

        /**
         * Set BooleanAnnotation.
         *
         * @param index the index number of the BooleanAnnotation.
         * @param booleanAnnotation the BooleanAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setBooleanAnnotation (std::vector<std::shared_ptr<ome::xml::model::BooleanAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::BooleanAnnotation>& booleanAnnotation);

        /**
         * Add BooleanAnnotation.
         *
         * @param booleanAnnotation the BooleanAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addBooleanAnnotation (std::shared_ptr<ome::xml::model::BooleanAnnotation>& booleanAnnotation);

        /**
         * Remove BooleanAnnotation.
         *
         * @param booleanAnnotation the BooleanAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeBooleanAnnotation (std::shared_ptr<ome::xml::model::BooleanAnnotation>& booleanAnnotation);

        /**
         * Get size of linked TimestampAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>::size_type
        sizeOfTimestampAnnotationList () const;

        /**
         * Get the TimestampAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>&
        getTimestampAnnotationList ();

        /**
         * Get the TimestampAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>&
        getTimestampAnnotationList () const;

        /**
         * Get TimestampAnnotation.
         *
         * @param index the index number of the TimestampAnnotation.
         * @returns the TimestampAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::TimestampAnnotation>&
        getTimestampAnnotation (std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>::size_type index);

        /**
         * Get TimestampAnnotation.
         *
         * @param index the index number of the TimestampAnnotation.
         * @returns the TimestampAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::TimestampAnnotation>&
        getTimestampAnnotation (std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>::size_type index) const;

        /**
         * Set TimestampAnnotation.
         *
         * @param index the index number of the TimestampAnnotation.
         * @param timestampAnnotation the TimestampAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setTimestampAnnotation (std::vector<std::shared_ptr<ome::xml::model::TimestampAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::TimestampAnnotation>& timestampAnnotation);

        /**
         * Add TimestampAnnotation.
         *
         * @param timestampAnnotation the TimestampAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addTimestampAnnotation (std::shared_ptr<ome::xml::model::TimestampAnnotation>& timestampAnnotation);

        /**
         * Remove TimestampAnnotation.
         *
         * @param timestampAnnotation the TimestampAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeTimestampAnnotation (std::shared_ptr<ome::xml::model::TimestampAnnotation>& timestampAnnotation);

        /**
         * Get size of linked TagAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>::size_type
        sizeOfTagAnnotationList () const;

        /**
         * Get the TagAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>&
        getTagAnnotationList ();

        /**
         * Get the TagAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>&
        getTagAnnotationList () const;

        /**
         * Get TagAnnotation.
         *
         * @param index the index number of the TagAnnotation.
         * @returns the TagAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::TagAnnotation>&
        getTagAnnotation (std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>::size_type index);

        /**
         * Get TagAnnotation.
         *
         * @param index the index number of the TagAnnotation.
         * @returns the TagAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::TagAnnotation>&
        getTagAnnotation (std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>::size_type index) const;

        /**
         * Set TagAnnotation.
         *
         * @param index the index number of the TagAnnotation.
         * @param tagAnnotation the TagAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setTagAnnotation (std::vector<std::shared_ptr<ome::xml::model::TagAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::TagAnnotation>& tagAnnotation);

        /**
         * Add TagAnnotation.
         *
         * @param tagAnnotation the TagAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addTagAnnotation (std::shared_ptr<ome::xml::model::TagAnnotation>& tagAnnotation);

        /**
         * Remove TagAnnotation.
         *
         * @param tagAnnotation the TagAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeTagAnnotation (std::shared_ptr<ome::xml::model::TagAnnotation>& tagAnnotation);

        /**
         * Get size of linked TermAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>::size_type
        sizeOfTermAnnotationList () const;

        /**
         * Get the TermAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>&
        getTermAnnotationList ();

        /**
         * Get the TermAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>&
        getTermAnnotationList () const;

        /**
         * Get TermAnnotation.
         *
         * @param index the index number of the TermAnnotation.
         * @returns the TermAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::TermAnnotation>&
        getTermAnnotation (std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>::size_type index);

        /**
         * Get TermAnnotation.
         *
         * @param index the index number of the TermAnnotation.
         * @returns the TermAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::TermAnnotation>&
        getTermAnnotation (std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>::size_type index) const;

        /**
         * Set TermAnnotation.
         *
         * @param index the index number of the TermAnnotation.
         * @param termAnnotation the TermAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setTermAnnotation (std::vector<std::shared_ptr<ome::xml::model::TermAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::TermAnnotation>& termAnnotation);

        /**
         * Add TermAnnotation.
         *
         * @param termAnnotation the TermAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addTermAnnotation (std::shared_ptr<ome::xml::model::TermAnnotation>& termAnnotation);

        /**
         * Remove TermAnnotation.
         *
         * @param termAnnotation the TermAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeTermAnnotation (std::shared_ptr<ome::xml::model::TermAnnotation>& termAnnotation);

        /**
         * Get size of linked MapAnnotation list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>::size_type
        sizeOfMapAnnotationList () const;

        /**
         * Get the MapAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>&
        getMapAnnotationList ();

        /**
         * Get the MapAnnotation list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>&
        getMapAnnotationList () const;

        /**
         * Get MapAnnotation.
         *
         * @param index the index number of the MapAnnotation.
         * @returns the MapAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::MapAnnotation>&
        getMapAnnotation (std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>::size_type index);

        /**
         * Get MapAnnotation.
         *
         * @param index the index number of the MapAnnotation.
         * @returns the MapAnnotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::MapAnnotation>&
        getMapAnnotation (std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>::size_type index) const;

        /**
         * Set MapAnnotation.
         *
         * @param index the index number of the MapAnnotation.
         * @param mapAnnotation the MapAnnotation to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setMapAnnotation (std::vector<std::shared_ptr<ome::xml::model::MapAnnotation>>::size_type index,
                               std::shared_ptr<ome::xml::model::MapAnnotation>& mapAnnotation);

        /**
         * Add MapAnnotation.
         *
         * @param mapAnnotation the MapAnnotation to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addMapAnnotation (std::shared_ptr<ome::xml::model::MapAnnotation>& mapAnnotation);

        /**
         * Remove MapAnnotation.
         *
         * @param mapAnnotation the MapAnnotation to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeMapAnnotation (std::shared_ptr<ome::xml::model::MapAnnotation>& mapAnnotation);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_STRUCTUREDANNOTATIONS_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
