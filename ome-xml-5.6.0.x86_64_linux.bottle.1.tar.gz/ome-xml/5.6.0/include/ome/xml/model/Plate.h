/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_PLATE_H
#define OME_XML_MODEL_PLATE_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/NamingConvention.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>
#include <ome/xml/model/primitives/PositiveInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;
      class PlateAcquisition;
      class Screen;
      class Well;

      /**
       * Plate model object.
       */
      class Plate : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Plate();

        /**
         * Copy constructor.
         *
         * @param copy the Plate to copy.
         */
        Plate (const Plate& copy);

        /// Destructor.
        virtual
        ~Plate ();

        /**
         * Create a Plate model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Plate>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Plate&
        operator= (const Plate&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Plate API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the Status property.
         *
         * @returns the Status property.
         */
        std::shared_ptr<std::string>
        getStatus ();

        /**
         * Get the Status property.
         *
         * @returns the Status property.
         */
        const std::shared_ptr<std::string>
        getStatus () const;

        /**
         * Set the Status property.
         *
         * @param status the value to set.
         */
        void
        setStatus (std::shared_ptr<std::string>& status);

        /**
         * Get the Rows property.
         *
         * @returns the Rows property.
         */
        std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getRows ();

        /**
         * Get the Rows property.
         *
         * @returns the Rows property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getRows () const;

        /**
         * Set the Rows property.
         *
         * @param rows the value to set.
         */
        void
        setRows (std::shared_ptr<ome::xml::model::primitives::PositiveInteger>& rows);

        /**
         * Get the ExternalIdentifier property.
         *
         * @returns the ExternalIdentifier property.
         */
        std::shared_ptr<std::string>
        getExternalIdentifier ();

        /**
         * Get the ExternalIdentifier property.
         *
         * @returns the ExternalIdentifier property.
         */
        const std::shared_ptr<std::string>
        getExternalIdentifier () const;

        /**
         * Set the ExternalIdentifier property.
         *
         * @param externalIdentifier the value to set.
         */
        void
        setExternalIdentifier (std::shared_ptr<std::string>& externalIdentifier);

        /**
         * Get the RowNamingConvention property.
         *
         * @returns the RowNamingConvention property.
         */
        std::shared_ptr<ome::xml::model::enums::NamingConvention>
        getRowNamingConvention ();

        /**
         * Get the RowNamingConvention property.
         *
         * @returns the RowNamingConvention property.
         */
        const std::shared_ptr<ome::xml::model::enums::NamingConvention>
        getRowNamingConvention () const;

        /**
         * Set the RowNamingConvention property.
         *
         * @param rowNamingConvention the value to set.
         */
        void
        setRowNamingConvention (std::shared_ptr<ome::xml::model::enums::NamingConvention>& rowNamingConvention);

        /**
         * Get the ColumnNamingConvention property.
         *
         * @returns the ColumnNamingConvention property.
         */
        std::shared_ptr<ome::xml::model::enums::NamingConvention>
        getColumnNamingConvention ();

        /**
         * Get the ColumnNamingConvention property.
         *
         * @returns the ColumnNamingConvention property.
         */
        const std::shared_ptr<ome::xml::model::enums::NamingConvention>
        getColumnNamingConvention () const;

        /**
         * Set the ColumnNamingConvention property.
         *
         * @param columnNamingConvention the value to set.
         */
        void
        setColumnNamingConvention (std::shared_ptr<ome::xml::model::enums::NamingConvention>& columnNamingConvention);

        /**
         * Get the FieldIndex property.
         *
         * @returns the FieldIndex property.
         */
        std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getFieldIndex ();

        /**
         * Get the FieldIndex property.
         *
         * @returns the FieldIndex property.
         */
        const std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getFieldIndex () const;

        /**
         * Set the FieldIndex property.
         *
         * @param fieldIndex the value to set.
         */
        void
        setFieldIndex (std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>& fieldIndex);

        /**
         * Get the Columns property.
         *
         * @returns the Columns property.
         */
        std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getColumns ();

        /**
         * Get the Columns property.
         *
         * @returns the Columns property.
         */
        const std::shared_ptr<ome::xml::model::primitives::PositiveInteger>
        getColumns () const;

        /**
         * Set the Columns property.
         *
         * @param columns the value to set.
         */
        void
        setColumns (std::shared_ptr<ome::xml::model::primitives::PositiveInteger>& columns);

        /**
         * Get the WellOriginY property.
         *
         * @returns the WellOriginY property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getWellOriginY ();

        /**
         * Get the WellOriginY property.
         *
         * @returns the WellOriginY property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getWellOriginY () const;

        /**
         * Set the WellOriginY property.
         *
         * @param wellOriginY the value to set.
         */
        void
        setWellOriginY (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& wellOriginY);

        /**
         * Get the WellOriginX property.
         *
         * @returns the WellOriginX property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getWellOriginX ();

        /**
         * Get the WellOriginX property.
         *
         * @returns the WellOriginX property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getWellOriginX () const;

        /**
         * Set the WellOriginX property.
         *
         * @param wellOriginX the value to set.
         */
        void
        setWellOriginX (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& wellOriginX);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        std::shared_ptr<std::string>
        getName ();

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        const std::shared_ptr<std::string>
        getName () const;

        /**
         * Set the Name property.
         *
         * @param name the value to set.
         */
        void
        setName (std::shared_ptr<std::string>& name);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get size of linked Well list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Well>>::size_type
        sizeOfWellList () const;

        /**
         * Get the Well list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Well>>&
        getWellList ();

        /**
         * Get the Well list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Well>>&
        getWellList () const;

        /**
         * Get Well.
         *
         * @param index the index number of the Well.
         * @returns the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Well>&
        getWell (std::vector<std::shared_ptr<ome::xml::model::Well>>::size_type index);

        /**
         * Get Well.
         *
         * @param index the index number of the Well.
         * @returns the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Well>&
        getWell (std::vector<std::shared_ptr<ome::xml::model::Well>>::size_type index) const;

        /**
         * Set Well.
         *
         * @param index the index number of the Well.
         * @param well the Well to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setWell (std::vector<std::shared_ptr<ome::xml::model::Well>>::size_type index,
                               std::shared_ptr<ome::xml::model::Well>& well);

        /**
         * Add Well.
         *
         * @param well the Well to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addWell (std::shared_ptr<ome::xml::model::Well>& well);

        /**
         * Remove Well.
         *
         * @param well the Well to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeWell (std::shared_ptr<ome::xml::model::Well>& well);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get size of linked PlateAcquisition list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>::size_type
        sizeOfPlateAcquisitionList () const;

        /**
         * Get the PlateAcquisition list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>&
        getPlateAcquisitionList ();

        /**
         * Get the PlateAcquisition list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>&
        getPlateAcquisitionList () const;

        /**
         * Get PlateAcquisition.
         *
         * @param index the index number of the PlateAcquisition.
         * @returns the PlateAcquisition.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::PlateAcquisition>&
        getPlateAcquisition (std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>::size_type index);

        /**
         * Get PlateAcquisition.
         *
         * @param index the index number of the PlateAcquisition.
         * @returns the PlateAcquisition.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::PlateAcquisition>&
        getPlateAcquisition (std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>::size_type index) const;

        /**
         * Set PlateAcquisition.
         *
         * @param index the index number of the PlateAcquisition.
         * @param plateAcquisition the PlateAcquisition to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setPlateAcquisition (std::vector<std::shared_ptr<ome::xml::model::PlateAcquisition>>::size_type index,
                               std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition);

        /**
         * Add PlateAcquisition.
         *
         * @param plateAcquisition the PlateAcquisition to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addPlateAcquisition (std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition);

        /**
         * Remove PlateAcquisition.
         *
         * @param plateAcquisition the PlateAcquisition to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removePlateAcquisition (std::shared_ptr<ome::xml::model::PlateAcquisition>& plateAcquisition);

        /**
         * Get size of linked Screen list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type
        sizeOfLinkedScreenList () const;

        /**
         * Get the linked Screen list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type
        getLinkedScreenList () const;

        /**
         * Get linked Screen.
         *
         * @param index the index number of the Screen.
         * @returns a weak pointer to the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Screen>&
        getLinkedScreen (OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Screen.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Screen.
         * @param screen_BackReference the Screen to set.
         * @returns a weak pointer to the Screen.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Screen>&
        setLinkedScreen (OMEModelObject::indexed_container<ome::xml::model::Screen, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Link Screen.
         *
         * @param screen_BackReference the Screen to link.
         * @returns @c true if the object was added to the internal
         * screenLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkScreen (const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Unlink Screen.
         *
         * @param screen_BackReference the Screen to unlink.
         *
         * @returns @c true if the Screen was unlinked, otherwise
         * @c false if the Screen was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkScreen (const std::shared_ptr<ome::xml::model::Screen>& screen_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_PLATE_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
