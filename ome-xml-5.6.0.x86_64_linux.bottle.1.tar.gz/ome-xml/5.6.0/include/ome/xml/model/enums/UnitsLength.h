/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_ENUMS_UNITSLENGTH_H
#define OME_XML_MODEL_ENUMS_UNITSLENGTH_H

#include <ostream>
#include <map>
#include <string>

#include <ome/common/log.h>

#include <ome/xml/model/enums/EnumerationException.h>

#include <ome/xml/model/primitives/Quantity.h>

// All values in the UnitsLength enumeration.
#define OME_XML_MODEL_ENUMS_UNITSLENGTH_VALUES (YOTTAMETER)(ZETTAMETER)(EXAMETER)(PETAMETER)(TERAMETER)(GIGAMETER)(MEGAMETER)(KILOMETER)(HECTOMETER)(DECAMETER)(METER)(DECIMETER)(CENTIMETER)(MILLIMETER)(MICROMETER)(NANOMETER)(PICOMETER)(FEMTOMETER)(ATTOMETER)(ZEPTOMETER)(YOCTOMETER)(ANGSTROM)(THOU)(LINE)(INCH)(FOOT)(YARD)(MILE)(ASTRONOMICALUNIT)(LIGHTYEAR)(PARSEC)(POINT)(PIXEL)(REFERENCEFRAME)

namespace ome
{
  namespace xml
  {
    namespace model
    {
      namespace enums
      {

        /**
         * UnitsLength enumeration.
         */
        class UnitsLength
        {
        public:
          /// Enumeration values.
          enum enum_value
            {
              /**
              yottameter SI unit.
              */
              YOTTAMETER,
              /**
              zettameter SI unit.
              */
              ZETTAMETER,
              /**
               exameter SI unit.
              */
              EXAMETER,
              /**
              petameter SI unit.
              */
              PETAMETER,
              /**
              terameter SI unit.
              */
              TERAMETER,
              /**
              gigameter SI unit.
              */
              GIGAMETER,
              /**
              megameter SI unit.
              */
              MEGAMETER,
              /**
              kilometer SI unit.
              */
              KILOMETER,
              /**
              hectometer SI unit.
              */
              HECTOMETER,
              /**
              decameter SI unit.
              */
              DECAMETER,
              /**
              meter SI unit.
              */
              METER,
              /**
              decimeter SI unit.
              */
              DECIMETER,
              /**
              centimeter SI unit.
              */
              CENTIMETER,
              /**
              millimeter SI unit.
              */
              MILLIMETER,
              /**
              micrometer SI unit.
              */
              MICROMETER,
              /**
              nanometer SI unit.
              */
              NANOMETER,
              /**
              picometer SI unit.
              */
              PICOMETER,
              /**
              femtometer SI unit.
              */
              FEMTOMETER,
              /**
              attometer SI unit.
              */
              ATTOMETER,
              /**
              zeptometer SI unit.
              */
              ZEPTOMETER,
              /**
              yoctometer SI unit.
              */
              YOCTOMETER,
              /**
              ångström SI-derived unit.
              */
              ANGSTROM,
              /**
              thou Imperial unit (or mil, 1/1000 inch).
              */
              THOU,
              /**
              line Imperial unit (1/12 inch).
              */
              LINE,
              /**
              inch Imperial unit.
              */
              INCH,
              /**
              foot Imperial unit.
              */
              FOOT,
              /**
              yard Imperial unit.
              */
              YARD,
              /**
              terrestrial mile Imperial unit.
              */
              MILE,
              /**
              astronomical unit SI-derived unit. The official term is ua as the SI standard assigned AU to absorbance unit.
              */
              ASTRONOMICALUNIT,
              /**
              light year.
              */
              LIGHTYEAR,
              /**
              parsec.
              */
              PARSEC,
              /**
              typography point Imperial-derived unit (1/72 inch). Use of this unit should be limited to font sizes.
              */
              POINT,
              /**
              pixel abstract unit.  This is not convertible to any other length unit without a calibrated scaling factor. Its use should should be limited to ROI objects, and converted to an appropriate length units using the PhysicalSize units of the Image the ROI is attached to.
              */
              PIXEL,
              /**
              reference frame abstract unit.  This is not convertible to any other length unit without a scaling factor.  Its use should be limited to uncalibrated stage positions, and converted to an appropriate length unit using a calibrated scaling factor.
              */
              REFERENCEFRAME
            };

          /**
           * Construct a UnitsLength enumeration by an enumeration value.
           *
           * @param value the value of the enumeration.
           */
          UnitsLength (enum_value value);

          /**
           * Construct a UnitsLength enumeration by an enumeration name.
           *
           * Exact matching of the name will require the name to match
           * one of the valid enumeration names.  Inexact matching will
           * strip leading and trailing whitespace and perform a
           * case-insensitive match.  Exact matching is recommended for
           * use in program code which does not process user input;
           * inexact matching is recommended when processing
           * potentially malformed user input.
           *
           * @param name the name of the enumeration.
           * @param strict true to require an exact name, false to allow an inexact match.
           */
          UnitsLength (const std::string& name, bool strict = true);

          /**
           * Copy constructor.
           *
           * @param original the instance to copy.
           */
          UnitsLength (const UnitsLength& original);

          /**
           * Assignment operator.
           *
           * @param rhs the value to assign.
           * @returns the assigned value.
           */
          inline UnitsLength&
          operator=  (const UnitsLength& rhs)
          {
            this->value = rhs.value;
            this->name = rhs.name;
            return *this;
          }

          /**
           * Cast the enumeration to its value.
           *
           * @returns the enumeration value.
           */
          inline
          operator enum_value () const
          {
            return this->value;
          }

          /**
           * Cast the enumeration to its name.
           *
           * @returns the enumeration value.
           */
          inline
          operator const std::string& () const
          {
            return *this->name;
          }

          /// String map type.
          typedef std::map<std::string, UnitsLength::enum_value> string_map_type;
          /// Value map type.
          typedef std::map<UnitsLength::enum_value, std::string> value_map_type;

          /**
           * Get a map of valid string names and enum values.
           *
           * @returns a map of string names to enum values.
           */
          static const string_map_type&
          strings();

          /**
           * Get a map of valid enum values and string names.
           *
           * @returns a map of enum values to string names.
           */
          static const value_map_type&
          values();

        private:
          /**
           * Get a map of valid lowercased string names and enum values.
           *
           * @returns a map of lowercased string names to enum values.
           */
          static const string_map_type&
          lowercase_strings();

          /// Enumeration value.
          enum_value         value;
          /// Enumeration name.
          const std::string *name;
        };

        /**
         * Compare two UnitsLength objects for equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are the same, otherwise false.
         */
        inline bool
        operator== (const UnitsLength& lhs,
                    const UnitsLength& rhs)
        {
          return static_cast<UnitsLength::enum_value>(lhs) == static_cast<UnitsLength::enum_value>(rhs);
        }

        /**
         * Compare UnitsLength object and enum value for equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength enum value.
         * @returns true if the enum values are the same, otherwise false.
         */
        inline bool
        operator== (const UnitsLength& lhs,
                    const UnitsLength::enum_value& rhs)
        {
          return static_cast<UnitsLength::enum_value>(lhs) == rhs;
        }

        /**
         * Compare enum value and UnitsLength for equality.
         *
         * @param lhs a UnitsLength enum value.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are the same, otherwise false.
         */
        inline bool
        operator== (const UnitsLength::enum_value& lhs,
                    const UnitsLength& rhs)
        {
          return lhs == static_cast<UnitsLength::enum_value>(rhs);
        }

        /**
         * Compare UnitsLength object and enum string value for equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength enum string value.
         * @returns true if the enum values are the same, otherwise false.
         */
        inline bool
        operator== (const UnitsLength& lhs,
                    const std::string& rhs)
        {
          return static_cast<const std::string&>(lhs) == rhs;
        }

        /**
         * Compare enum string value and UnitsLength object for equality.
         *
         * @param lhs a UnitsLength enum string value.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are the same, otherwise false.
         */
        inline bool
        operator== (const std::string& lhs,
                    const UnitsLength& rhs)
        {
          return lhs == static_cast<const std::string&>(rhs);
        }

        /**
         * Compare two UnitsLength objects for non-equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are not the same, otherwise false.
         */
        inline bool
        operator!= (const UnitsLength& lhs,
                    const UnitsLength& rhs)
        {
          return static_cast<UnitsLength::enum_value>(lhs) != static_cast<UnitsLength::enum_value>(rhs);
        }

        /**
         * Compare UnitsLength object and enum value for non-equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength enum value.
         * @returns true if the enum values are not the same, otherwise false.
         */
        inline bool
        operator!= (const UnitsLength& lhs,
                    const UnitsLength::enum_value& rhs)
        {
          return static_cast<UnitsLength::enum_value>(lhs) != rhs;
        }

        /**
         * Compare enum value and UnitsLength object for non-equality.
         *
         * @param lhs a UnitsLength enum value.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are not the same, otherwise false.
         */
        inline bool
        operator!= (const UnitsLength::enum_value& lhs,
                    const UnitsLength& rhs)
        {
          return lhs != static_cast<UnitsLength::enum_value>(rhs);
        }

        /**
         * Compare UnitsLength object and enum string value for non-equality.
         *
         * @param lhs a UnitsLength object.
         * @param rhs a UnitsLength enum string value.
         * @returns true if the enum values are not the same, otherwise false.
         */
        inline bool
        operator!= (const UnitsLength& lhs,
                    const std::string& rhs)
        {
          return static_cast<const std::string&>(lhs) != rhs;
        }

        /**
         * Compare enum string value and UnitsLength object for non-equality.
         *
         * @param lhs a UnitsLength enum string value.
         * @param rhs a UnitsLength object.
         * @returns true if the enum values are not the same, otherwise false.
         */
        inline bool
        operator!= (const std::string& lhs,
                    const UnitsLength& rhs)
        {
          return lhs != static_cast<const std::string&>(rhs);
        }

        /**
         * Output UnitsLength to output stream.
         *
         * @param os the output stream.
         * @param enumeration the UnitsLength to output.
         * @returns the output stream.
         */
        template<class charT, class traits>
        inline std::basic_ostream<charT,traits>&
        operator<< (std::basic_ostream<charT,traits>& os,
                    const UnitsLength& enumeration)
        {
          return os << static_cast<const std::string&>(enumeration);
        }

        /**
         * Set UnitsLength from input stream.
         *
         * @param is the input stream.
         * @param enumeration the UnitsLength to input.
         * @returns the input stream.
         */
        template<class charT, class traits>
        inline std::basic_istream<charT,traits>&
        operator>> (std::basic_istream<charT,traits>& is,
                    UnitsLength& enumeration)
        {
          std::string value;
          is >> value;
          if (is)
            {
              try
                {
                  enumeration = UnitsLength(value, false);
                }
              catch (const EnumerationException&)
                {
                  is.setstate(std::ios::failbit);
                }
            }

          return is;
        }

      }
    }
  }
}

#include <ome/xml/model/enums/UnitsLengthConvert.h>

#endif // OME_XML_MODEL_ENUMS_UNITSLENGTH_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
