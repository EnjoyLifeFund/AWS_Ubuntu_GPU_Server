/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_WELL_H
#define OME_XML_MODEL_WELL_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Plate.h>
#include <ome/xml/model/Reagent.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/primitives/Color.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;
      class WellSample;

      /**
       * Well model object.
       */
      class Well : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Well();

        /**
         * Copy constructor.
         *
         * @param copy the Well to copy.
         */
        Well (const Well& copy);

        /// Destructor.
        virtual
        ~Well ();

        /**
         * Create a Well model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Well>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Well&
        operator= (const Well&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Well API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ExternalIdentifier property.
         *
         * @returns the ExternalIdentifier property.
         */
        std::shared_ptr<std::string>
        getExternalIdentifier ();

        /**
         * Get the ExternalIdentifier property.
         *
         * @returns the ExternalIdentifier property.
         */
        const std::shared_ptr<std::string>
        getExternalIdentifier () const;

        /**
         * Set the ExternalIdentifier property.
         *
         * @param externalIdentifier the value to set.
         */
        void
        setExternalIdentifier (std::shared_ptr<std::string>& externalIdentifier);

        /**
         * Get the Column property.
         *
         * @returns the Column property.
         */
        const ome::xml::model::primitives::NonNegativeInteger&
        getColumn () const;

        /**
         * Set the Column property.
         *
         * @param column the value to set.
         */
        void
        setColumn (const ome::xml::model::primitives::NonNegativeInteger& column);

        /**
         * Get the ExternalDescription property.
         *
         * @returns the ExternalDescription property.
         */
        std::shared_ptr<std::string>
        getExternalDescription ();

        /**
         * Get the ExternalDescription property.
         *
         * @returns the ExternalDescription property.
         */
        const std::shared_ptr<std::string>
        getExternalDescription () const;

        /**
         * Set the ExternalDescription property.
         *
         * @param externalDescription the value to set.
         */
        void
        setExternalDescription (std::shared_ptr<std::string>& externalDescription);

        /**
         * Get the Color property.
         *
         * @returns the Color property.
         */
        std::shared_ptr<ome::xml::model::primitives::Color>
        getColor ();

        /**
         * Get the Color property.
         *
         * @returns the Color property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Color>
        getColor () const;

        /**
         * Set the Color property.
         *
         * @param color the value to set.
         */
        void
        setColor (std::shared_ptr<ome::xml::model::primitives::Color>& color);

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        std::shared_ptr<std::string>
        getType ();

        /**
         * Get the Type property.
         *
         * @returns the Type property.
         */
        const std::shared_ptr<std::string>
        getType () const;

        /**
         * Set the Type property.
         *
         * @param type the value to set.
         */
        void
        setType (std::shared_ptr<std::string>& type);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Row property.
         *
         * @returns the Row property.
         */
        const ome::xml::model::primitives::NonNegativeInteger&
        getRow () const;

        /**
         * Set the Row property.
         *
         * @param row the value to set.
         */
        void
        setRow (const ome::xml::model::primitives::NonNegativeInteger& row);

        /**
         * Get size of linked WellSample list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::WellSample>>::size_type
        sizeOfWellSampleList () const;

        /**
         * Get the WellSample list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::WellSample>>&
        getWellSampleList ();

        /**
         * Get the WellSample list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::WellSample>>&
        getWellSampleList () const;

        /**
         * Get WellSample.
         *
         * @param index the index number of the WellSample.
         * @returns the WellSample.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::WellSample>&
        getWellSample (std::vector<std::shared_ptr<ome::xml::model::WellSample>>::size_type index);

        /**
         * Get WellSample.
         *
         * @param index the index number of the WellSample.
         * @returns the WellSample.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::WellSample>&
        getWellSample (std::vector<std::shared_ptr<ome::xml::model::WellSample>>::size_type index) const;

        /**
         * Set WellSample.
         *
         * @param index the index number of the WellSample.
         * @param wellSample the WellSample to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setWellSample (std::vector<std::shared_ptr<ome::xml::model::WellSample>>::size_type index,
                               std::shared_ptr<ome::xml::model::WellSample>& wellSample);

        /**
         * Add WellSample.
         *
         * @param wellSample the WellSample to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addWellSample (std::shared_ptr<ome::xml::model::WellSample>& wellSample);

        /**
         * Remove WellSample.
         *
         * @param wellSample the WellSample to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeWellSample (std::shared_ptr<ome::xml::model::WellSample>& wellSample);

        /**
         * Get linked Reagent.
         *
         * @returns the linked Reagent.  The pointer may be
         * null.
         */
        std::weak_ptr<ome::xml::model::Reagent>
        getLinkedReagent ();

        /**
         * Get linked Reagent.
         *
         * @returns the linked Reagent.  The pointer may be
         * null.
         */
        const std::weak_ptr<ome::xml::model::Reagent>
        getLinkedReagent () const;

        /**
         * Link Reagent.
         *
         * @param reagent the Reagent to link.
         */
        void
        linkReagent (std::shared_ptr<ome::xml::model::Reagent>& reagent);

        /**
         * Unlink Reagent.
         *
         * @param reagent the Reagent to unlink.
         *
         * @todo This method is fairly pointless since it's equivalent
         * to linking a null pointer.  It could call @c link(0)
         * internally.
         */
        void
        unlinkReagent (std::shared_ptr<ome::xml::model::Reagent>& reagent);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Plate property.
         *
         * @returns the Plate property.
         */
        std::weak_ptr<ome::xml::model::Plate>
        getPlate ();

        /**
         * Get the Plate property.
         *
         * @returns the Plate property.
         */
        const std::weak_ptr<ome::xml::model::Plate>
        getPlate () const;

        /**
         * Set the Plate property.
         *
         * @param plate_BackReference the value to set.
         */
        void
        setPlate (std::weak_ptr<ome::xml::model::Plate>& plate_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_WELL_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
