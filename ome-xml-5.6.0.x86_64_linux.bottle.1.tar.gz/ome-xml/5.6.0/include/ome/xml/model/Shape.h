/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_SHAPE_H
#define OME_XML_MODEL_SHAPE_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/AffineTransform.h>
#include <ome/xml/model/Union.h>
#include <ome/xml/model/detail/OMEModelObject.h>
#include <ome/xml/model/enums/FillRule.h>
#include <ome/xml/model/enums/FontFamily.h>
#include <ome/xml/model/enums/FontStyle.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/primitives/Color.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;

      /**
       * Shape model object.
       */
      class Shape : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Shape();

        /**
         * Copy constructor.
         *
         * @param copy the Shape to copy.
         */
        Shape (const Shape& copy);

        /// Destructor.
        virtual
        ~Shape ();

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Shape&
        operator= (const Shape&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Shape API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the StrokeDashArray property.
         *
         * @returns the StrokeDashArray property.
         */
        std::shared_ptr<std::string>
        getStrokeDashArray ();

        /**
         * Get the StrokeDashArray property.
         *
         * @returns the StrokeDashArray property.
         */
        const std::shared_ptr<std::string>
        getStrokeDashArray () const;

        /**
         * Set the StrokeDashArray property.
         *
         * @param strokeDashArray the value to set.
         */
        void
        setStrokeDashArray (std::shared_ptr<std::string>& strokeDashArray);

        /**
         * Get the StrokeWidth property.
         *
         * @returns the StrokeWidth property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getStrokeWidth ();

        /**
         * Get the StrokeWidth property.
         *
         * @returns the StrokeWidth property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >&
        getStrokeWidth () const;

        /**
         * Set the StrokeWidth property.
         *
         * @param strokeWidth the value to set.
         */
        void
        setStrokeWidth (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > >& strokeWidth);

        /**
         * Get the Locked property.
         *
         * @returns the Locked property.
         */
        std::shared_ptr<bool>
        getLocked ();

        /**
         * Get the Locked property.
         *
         * @returns the Locked property.
         */
        const std::shared_ptr<bool>
        getLocked () const;

        /**
         * Set the Locked property.
         *
         * @param locked the value to set.
         */
        void
        setLocked (std::shared_ptr<bool>& locked);

        /**
         * Get the FillRule property.
         *
         * @returns the FillRule property.
         */
        std::shared_ptr<ome::xml::model::enums::FillRule>
        getFillRule ();

        /**
         * Get the FillRule property.
         *
         * @returns the FillRule property.
         */
        const std::shared_ptr<ome::xml::model::enums::FillRule>
        getFillRule () const;

        /**
         * Set the FillRule property.
         *
         * @param fillRule the value to set.
         */
        void
        setFillRule (std::shared_ptr<ome::xml::model::enums::FillRule>& fillRule);

        /**
         * Get the Text property.
         *
         * @returns the Text property.
         */
        std::shared_ptr<std::string>
        getText ();

        /**
         * Get the Text property.
         *
         * @returns the Text property.
         */
        const std::shared_ptr<std::string>
        getText () const;

        /**
         * Set the Text property.
         *
         * @param text the value to set.
         */
        void
        setText (std::shared_ptr<std::string>& text);

        /**
         * Get the TheC property.
         *
         * @returns the TheC property.
         */
        std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheC ();

        /**
         * Get the TheC property.
         *
         * @returns the TheC property.
         */
        const std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheC () const;

        /**
         * Set the TheC property.
         *
         * @param theC the value to set.
         */
        void
        setTheC (std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>& theC);

        /**
         * Get the FontFamily property.
         *
         * @returns the FontFamily property.
         */
        std::shared_ptr<ome::xml::model::enums::FontFamily>
        getFontFamily ();

        /**
         * Get the FontFamily property.
         *
         * @returns the FontFamily property.
         */
        const std::shared_ptr<ome::xml::model::enums::FontFamily>
        getFontFamily () const;

        /**
         * Set the FontFamily property.
         *
         * @param fontFamily the value to set.
         */
        void
        setFontFamily (std::shared_ptr<ome::xml::model::enums::FontFamily>& fontFamily);

        /**
         * Get the FontStyle property.
         *
         * @returns the FontStyle property.
         */
        std::shared_ptr<ome::xml::model::enums::FontStyle>
        getFontStyle ();

        /**
         * Get the FontStyle property.
         *
         * @returns the FontStyle property.
         */
        const std::shared_ptr<ome::xml::model::enums::FontStyle>
        getFontStyle () const;

        /**
         * Set the FontStyle property.
         *
         * @param fontStyle the value to set.
         */
        void
        setFontStyle (std::shared_ptr<ome::xml::model::enums::FontStyle>& fontStyle);

        /**
         * Get the FontSize property.
         *
         * @returns the FontSize property.
         */
        std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > >&
        getFontSize ();

        /**
         * Get the FontSize property.
         *
         * @returns the FontSize property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > >&
        getFontSize () const;

        /**
         * Set the FontSize property.
         *
         * @param fontSize the value to set.
         */
        void
        setFontSize (const std::shared_ptr<ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > >& fontSize);

        /**
         * Get the FillColor property.
         *
         * @returns the FillColor property.
         */
        std::shared_ptr<ome::xml::model::primitives::Color>
        getFillColor ();

        /**
         * Get the FillColor property.
         *
         * @returns the FillColor property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Color>
        getFillColor () const;

        /**
         * Set the FillColor property.
         *
         * @param fillColor the value to set.
         */
        void
        setFillColor (std::shared_ptr<ome::xml::model::primitives::Color>& fillColor);

        /**
         * Get the StrokeColor property.
         *
         * @returns the StrokeColor property.
         */
        std::shared_ptr<ome::xml::model::primitives::Color>
        getStrokeColor ();

        /**
         * Get the StrokeColor property.
         *
         * @returns the StrokeColor property.
         */
        const std::shared_ptr<ome::xml::model::primitives::Color>
        getStrokeColor () const;

        /**
         * Set the StrokeColor property.
         *
         * @param strokeColor the value to set.
         */
        void
        setStrokeColor (std::shared_ptr<ome::xml::model::primitives::Color>& strokeColor);

        /**
         * Get the TheT property.
         *
         * @returns the TheT property.
         */
        std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheT ();

        /**
         * Get the TheT property.
         *
         * @returns the TheT property.
         */
        const std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheT () const;

        /**
         * Set the TheT property.
         *
         * @param theT the value to set.
         */
        void
        setTheT (std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>& theT);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the TheZ property.
         *
         * @returns the TheZ property.
         */
        std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheZ ();

        /**
         * Get the TheZ property.
         *
         * @returns the TheZ property.
         */
        const std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>
        getTheZ () const;

        /**
         * Set the TheZ property.
         *
         * @param theZ the value to set.
         */
        void
        setTheZ (std::shared_ptr<ome::xml::model::primitives::NonNegativeInteger>& theZ);

        /**
         * Get the Transform property.
         *
         * @returns the Transform property.
         */
        std::shared_ptr<ome::xml::model::AffineTransform>
        getTransform ();

        /**
         * Get the Transform property.
         *
         * @returns the Transform property.
         */
        const std::shared_ptr<ome::xml::model::AffineTransform>
        getTransform () const;

        /**
         * Set the Transform property.
         *
         * @param transform the value to set.
         */
        void
        setTransform (std::shared_ptr<ome::xml::model::AffineTransform>& transform);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Union property.
         *
         * @returns the Union property.
         */
        std::weak_ptr<ome::xml::model::Union>
        getUnion ();

        /**
         * Get the Union property.
         *
         * @returns the Union property.
         */
        const std::weak_ptr<ome::xml::model::Union>
        getUnion () const;

        /**
         * Set the Union property.
         *
         * @param union_BackReference the value to set.
         */
        void
        setUnion (std::weak_ptr<ome::xml::model::Union>& union_BackReference);

        /**
         * Get the Shape type.
         *
         * @returns the concrete type of the Shape.
         */
        virtual const std::string&
        getShapeType() const = 0;

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_SHAPE_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
