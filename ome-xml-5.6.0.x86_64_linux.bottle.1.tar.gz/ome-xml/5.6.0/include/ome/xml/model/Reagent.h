/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_REAGENT_H
#define OME_XML_MODEL_REAGENT_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/Screen.h>
#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class Annotation;
      class OMEModel;
      class Well;

      /**
       * Reagent model object.
       */
      class Reagent : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Reagent();

        /**
         * Copy constructor.
         *
         * @param copy the Reagent to copy.
         */
        Reagent (const Reagent& copy);

        /// Destructor.
        virtual
        ~Reagent ();

        /**
         * Create a Reagent model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Reagent>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Reagent&
        operator= (const Reagent&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Reagent API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get the ReagentIdentifier property.
         *
         * @returns the ReagentIdentifier property.
         */
        std::shared_ptr<std::string>
        getReagentIdentifier ();

        /**
         * Get the ReagentIdentifier property.
         *
         * @returns the ReagentIdentifier property.
         */
        const std::shared_ptr<std::string>
        getReagentIdentifier () const;

        /**
         * Set the ReagentIdentifier property.
         *
         * @param reagentIdentifier the value to set.
         */
        void
        setReagentIdentifier (std::shared_ptr<std::string>& reagentIdentifier);

        /**
         * Get the ID property.
         *
         * @returns the ID property.
         */
        const std::string&
        getID () const;

        /**
         * Set the ID property.
         *
         * @param id the value to set.
         */
        void
        setID (const std::string& id);

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        std::shared_ptr<std::string>
        getName ();

        /**
         * Get the Name property.
         *
         * @returns the Name property.
         */
        const std::shared_ptr<std::string>
        getName () const;

        /**
         * Set the Name property.
         *
         * @param name the value to set.
         */
        void
        setName (std::shared_ptr<std::string>& name);

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        std::shared_ptr<std::string>
        getDescription ();

        /**
         * Get the Description property.
         *
         * @returns the Description property.
         */
        const std::shared_ptr<std::string>
        getDescription () const;

        /**
         * Set the Description property.
         *
         * @param description the value to set.
         */
        void
        setDescription (std::shared_ptr<std::string>& description);

        /**
         * Get size of linked Annotation list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type
        sizeOfLinkedAnnotationList () const;

        /**
         * Get the linked Annotation list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type
        getLinkedAnnotationList () const;

        /**
         * Get linked Annotation.
         *
         * @param index the index number of the Annotation.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        getLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Annotation.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Annotation.
         * @param annotation the Annotation to set.
         * @returns a weak pointer to the Annotation.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Annotation>&
        setLinkedAnnotation (OMEModelObject::indexed_container<ome::xml::model::Annotation, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Link Annotation.
         *
         * @param annotation the Annotation to link.
         * @returns @c true if the object was added to the internal
         * annotationLinks list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Unlink Annotation.
         *
         * @param annotation the Annotation to unlink.
         *
         * @returns @c true if the Annotation was unlinked, otherwise
         * @c false if the Annotation was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkAnnotation (const std::shared_ptr<ome::xml::model::Annotation>& annotation);

        /**
         * Get the Screen property.
         *
         * @returns the Screen property.
         */
        std::weak_ptr<ome::xml::model::Screen>
        getScreen ();

        /**
         * Get the Screen property.
         *
         * @returns the Screen property.
         */
        const std::weak_ptr<ome::xml::model::Screen>
        getScreen () const;

        /**
         * Set the Screen property.
         *
         * @param screen_BackReference the value to set.
         */
        void
        setScreen (std::weak_ptr<ome::xml::model::Screen>& screen_BackReference);

        /**
         * Get size of linked Well list.
         *
         * @returns the size of the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type
        sizeOfLinkedWellList () const;

        /**
         * Get the linked Well list.
         *
         * @returns a reference to the list.
         */
        OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type
        getLinkedWellList () const;

        /**
         * Get linked Well.
         *
         * @param index the index number of the Well.
         * @returns a weak pointer to the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Well>&
        getLinkedWell (OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type index) const;

        /**
         * Set linked Well.
         *
         * @note The index must be valid.
         *
         * @param index the index number of the Well.
         * @param well_BackReference the Well to set.
         * @returns a weak pointer to the Well.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::weak_ptr<ome::xml::model::Well>&
        setLinkedWell (OMEModelObject::indexed_container<ome::xml::model::Well, std::weak_ptr>::type::size_type index,
                                     const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

        /**
         * Link Well.
         *
         * @param well_BackReference the Well to link.
         * @returns @c true if the object was added to the internal
         * wells list, otherwise @c false.
         *
         * @todo Why have a return value here; what is it used for?
         * Is this an artifact of the Java API?
         */
        bool
        linkWell (const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

        /**
         * Unlink Well.
         *
         * @param well_BackReference the Well to unlink.
         *
         * @returns @c true if the Well was unlinked, otherwise
         * @c false if the Well was not linked and could hence not be
         * unlinked.
         *
         * @todo Does the return value serve any useful purpose?  Is
         * this also inherited Java API?
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        bool
        unlinkWell (const std::shared_ptr<ome::xml::model::Well>& well_BackReference);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_REAGENT_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
