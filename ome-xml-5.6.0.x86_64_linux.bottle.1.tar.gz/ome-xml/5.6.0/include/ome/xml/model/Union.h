/*
 * #%L
 * OME-XML C++ library for working with OME-XML metadata structures.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_MODEL_UNION_H
#define OME_XML_MODEL_UNION_H

#include <algorithm>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <ome/common/log.h>

#include <ome/common/xml/dom/Document.h>
#include <ome/common/xml/dom/Element.h>
#include <ome/common/xml/dom/Node.h>

#include <ome/xml/model/primitives/Quantity.h>

#include <ome/xml/model/detail/OMEModelObject.h>

namespace ome
{
  namespace xml
  {
    namespace model
    {

      // Forward declarations.
      class OMEModel;
      class Shape;

      /**
       * Union model object.
       */
      class Union : public detail::OMEModelObject
      {
      private:
        class Impl;
        /// Private implementation details.
        std::shared_ptr<Impl> impl;

      public:
        /// Default constructor.
        Union();

        /**
         * Copy constructor.
         *
         * @param copy the Union to copy.
         */
        Union (const Union& copy);

        /// Destructor.
        virtual
        ~Union ();

        /**
         * Create a Union model object from DOM element.
         *
         * @param element root of the XML DOM tree to from which to
         * construct the model object graph.
         * @param model handler for the OME model used to track
         * instances and references seen during the update.
         * @throws EnumerationException if there is an error
         * instantiating an enumeration during model object creation,
         * or ModelException if there are any consistency or validity
         * errors found during processing.
         *
         * @returns a new model object.
         */
        static std::shared_ptr<Union>
        create(const common::xml::dom::Element& element,
               ome::xml::model::OMEModel& model);

        // Documented in superclass.
        const std::string&
        elementName() const;

        // Documented in superclass.
        bool
        validElementName(const std::string& name) const;

        /// @cond SKIP
        Union&
        operator= (const Union&) = delete;
        /// @endcond SKIP

        // -- OMEModelObject API methods --

        /// @copydoc ome::xml::model::OMEModelObject::update
        virtual void
        update(const common::xml::dom::Element&  element,
               ome::xml::model::OMEModel& model);

      public:
        // -- Union API methods --

        /// @copydoc ome::xml::model::OMEModelObject::link
        bool
        link (std::shared_ptr<Reference>& reference,
              std::shared_ptr<ome::xml::model::OMEModelObject>& object);

        /**
         * Get size of linked Shape list.
         *
         * @returns the size of the list.
         */
        std::vector<std::shared_ptr<ome::xml::model::Shape>>::size_type
        sizeOfShapeList () const;

        /**
         * Get the Shape list.
         *
         * @returns a reference to the list.
         *
         */
        std::vector<std::shared_ptr<ome::xml::model::Shape>>&
        getShapeList ();

        /**
         * Get the Shape list.
         *
         * @returns a reference to the list.
         *
         */
        const std::vector<std::shared_ptr<ome::xml::model::Shape>>&
        getShapeList () const;

        /**
         * Get Shape.
         *
         * @param index the index number of the Shape.
         * @returns the Shape.
         * @throws std::out_of_range if the index is invalid.
         */
        std::shared_ptr<ome::xml::model::Shape>&
        getShape (std::vector<std::shared_ptr<ome::xml::model::Shape>>::size_type index);

        /**
         * Get Shape.
         *
         * @param index the index number of the Shape.
         * @returns the Shape.
         * @throws std::out_of_range if the index is invalid.
         */
        const std::shared_ptr<ome::xml::model::Shape>&
        getShape (std::vector<std::shared_ptr<ome::xml::model::Shape>>::size_type index) const;

        /**
         * Set Shape.
         *
         * @param index the index number of the Shape.
         * @param shape the Shape to set.
         * @throws std::out_of_range if the index is invalid.
         */
        void
        setShape (std::vector<std::shared_ptr<ome::xml::model::Shape>>::size_type index,
                               std::shared_ptr<ome::xml::model::Shape>& shape);

        /**
         * Add Shape.
         *
         * @param shape the Shape to add.
         *
         * @todo Return list position?
         * @todo Detect and handle duplicates?
         */
        void
        addShape (std::shared_ptr<ome::xml::model::Shape>& shape);

        /**
         * Remove Shape.
         *
         * @param shape the Shape to remove.
         *
         * @todo Doesn't the removal break the indexing?
         * @todo Does the removal deal with multiple instances; we
         * aren't preventing duplicates on insertion.
         */
        void
        removeShape (std::shared_ptr<ome::xml::model::Shape>& shape);

      protected:
        // Documented in base class.
        virtual void
        asXMLElementInternal (common::xml::dom::Document& document,
                              common::xml::dom::Element&  element) const;

      public:
       // Documented in superclass.
       const std::string&
       getXMLNamespace() const;
      };

    }
  }
}

#endif // OME_XML_MODEL_UNION_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
