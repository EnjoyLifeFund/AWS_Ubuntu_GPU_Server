/*
 * #%L
 * OME-BIOFORMATS C++ library for image IO.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_META_METADATASTORE_H
#define OME_XML_META_METADATASTORE_H

#include <memory>
#include <string>

#include <ome/xml/meta/BaseMetadata.h>
#include <ome/xml/meta/MetadataRoot.h>
#include <ome/xml/model/AffineTransform.h>

#include <ome/xml/model/enums/AcquisitionMode.h>
#include <ome/xml/model/enums/ArcType.h>
#include <ome/xml/model/enums/Binning.h>
#include <ome/xml/model/enums/Compression.h>
#include <ome/xml/model/enums/ContrastMethod.h>
#include <ome/xml/model/enums/Correction.h>
#include <ome/xml/model/enums/DetectorType.h>
#include <ome/xml/model/enums/DimensionOrder.h>
#include <ome/xml/model/enums/ExperimentType.h>
#include <ome/xml/model/enums/FilamentType.h>
#include <ome/xml/model/enums/FillRule.h>
#include <ome/xml/model/enums/FilterType.h>
#include <ome/xml/model/enums/FontFamily.h>
#include <ome/xml/model/enums/FontStyle.h>
#include <ome/xml/model/enums/IlluminationType.h>
#include <ome/xml/model/enums/Immersion.h>
#include <ome/xml/model/enums/LaserMedium.h>
#include <ome/xml/model/enums/LaserType.h>
#include <ome/xml/model/enums/Marker.h>
#include <ome/xml/model/enums/Medium.h>
#include <ome/xml/model/enums/MicrobeamManipulationType.h>
#include <ome/xml/model/enums/MicroscopeType.h>
#include <ome/xml/model/enums/NamingConvention.h>
#include <ome/xml/model/enums/PixelType.h>
#include <ome/xml/model/enums/Pulse.h>
#include <ome/xml/model/enums/UnitsElectricPotential.h>
#include <ome/xml/model/enums/UnitsFrequency.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/enums/UnitsPower.h>
#include <ome/xml/model/enums/UnitsPressure.h>
#include <ome/xml/model/enums/UnitsTemperature.h>
#include <ome/xml/model/enums/UnitsTime.h>

#include <ome/xml/model/primitives/Color.h>
#include <ome/xml/model/primitives/ConstrainedNumeric.h>
#include <ome/xml/model/primitives/NonNegativeFloat.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>
#include <ome/xml/model/primitives/NonNegativeLong.h>
#include <ome/xml/model/primitives/NumericConstraints.h>
#include <ome/xml/model/primitives/OrderedMultimap.h>
#include <ome/xml/model/primitives/PercentFraction.h>
#include <ome/xml/model/primitives/PositiveFloat.h>
#include <ome/xml/model/primitives/PositiveInteger.h>
#include <ome/xml/model/primitives/PositiveLong.h>
#include <ome/xml/model/primitives/Timestamp.h>

namespace ome
{
  namespace xml
  {
    namespace meta
    {

      /**
       * Metadata storage interface.
       *
       * MetadataStore is a proxy whose responsibility it is to
       * marshal biological image data into a particular storage
       * medium.  This interface encompasses the metadata that any
       * specific storage medium (file, relational database, etc.)
       * should be expected to store into its backing data model.
       *
       * The MetadataStore interface goes hand in hand with the
       * MetadataRetrieve interface. Essentially, MetadataRetrieve
       * provides the "getter" methods for a storage medium, and
       * MetadataStore provides the "setter" methods.  Since it often
       * makes sense for a storage medium to implement both
       * interfaces, there is also an Metadata interface encompassing
       * both MetadataStore and MetadataRetrieve, which reduces the
       * need to cast between object types.
       *
       * See ome::xml::meta::OMEXMLMetadata for an
       * example implementation.
       *
       * @note It is strongly recommended that applications (e.g.,
       * file format readers) using MetadataStore fill it with
       * information in a linear order. Specifically, iterating over
       * entities from "leftmost" index to "rightmost" index is
       * required for certain implementations such as OMERO's
       * OMEROMetadataStore. For example, when filling
       * ::ome::xml::model::Image, ::ome::xml::model::Pixels and
       * ::ome::xml::model::Plane information, an outer loop should
       * iterate across @c imageIndex, an inner loop should iterate
       * across @c pixelsIndex, and an innermost loop should handle @c
       * planeIndex. For an illustration of the ideal traversal order,
       * see MetadataConverter.
       *
       * @sa MetadataRetrieve, Metadata,
       * ome::xml::meta::OMEXMLMetadata.
       */
      class MetadataStore : virtual public BaseMetadata
      {
      protected:
        /// Constructor.
        MetadataStore()
        {}

      public:
        /// Destructor.
        virtual
        ~MetadataStore()
        {}

        /// @cond SKIP
        MetadataStore (const MetadataStore&) = delete;

        MetadataStore&
        operator= (const MetadataStore&) = delete;
        /// @endcond SKIP

        /**
         * Create root node.  The action taken here is specific to the
         * concrete metadata implementation.
         */
        virtual void
        createRoot() = 0;

        /**
         * Get the root node of the metadata.  Note that the root node
         * type will be specific to the concrete metadata
         * implementation.
         *
         * @returns a pointer to the root node.
         *
         * @todo should this be a reference or shared_ptr?
         */
        virtual std::shared_ptr<MetadataRoot>
        getRoot() = 0;

        /**
         * Set the root node of the metadata.  Note that the root node
         * type will be specific to the concrete metadata
         * implementation.  An exception will be thrown if the root
         * node is of an incompatible type.
         *
         * @param root a pointer to the root node.
         *
         * @todo should this be a reference or shared_ptr?
         */
        virtual void
        setRoot(std::shared_ptr<MetadataRoot> root) = 0;

        /**
         * Set the UUID associated with this collection of metadata.
         *
         * @param uuid the UUID to set.
         */
        virtual void
        setUUID(const std::string& uuid) = 0;

        /**
         * Set the map value of MapAnnotation.
         *
         * @param value the map value to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         */
        virtual void
        setMapAnnotationValue(const ome::xml::model::primitives::OrderedMultimap& value,
                              index_type                                          mapAnnotationIndex) = 0;

       /**
         * Set the map value of GenericExcitationSource.
         *
         * @param map the map value to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceMap(const ome::xml::model::primitives::OrderedMultimap& map,
                                      index_type                                          instrumentIndex,
                                      index_type                                          lightSourceIndex) = 0;

       /**
         * Set the map value of ImagingEnvironment.
         *
         * @param map the map value to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImagingEnvironmentMap(const ome::xml::model::primitives::OrderedMultimap& map,
                                 index_type                                          imageIndex) = 0;

        /**
         * Set the AnnotationRef property of Arc.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setArcAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of Arc.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LotNumber property of Arc.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Manufacturer property of Arc.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Model property of Arc.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Power property of Arc.
         *
         * @param power Power to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the SerialNumber property of Arc.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Type property of Arc.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setArcType(ome::xml::model::enums::ArcType type, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Base64Binary property of BinData.
         *
         * @param base64Binary Base64Binary to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileBinData(const std::vector<uint8_t>& base64Binary, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Base64Binary property of BinData.
         *
         * @param base64Binary Base64Binary to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskBinData(const std::vector<uint8_t>& base64Binary, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Base64Binary property of BinData.
         *
         * @param base64Binary Base64Binary to set.
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         */
        virtual void
        setPixelsBinData(const std::vector<uint8_t>& base64Binary, index_type imageIndex, index_type binDataIndex) = 0;

        /**
         * Set the BigEndian property of BinData.
         *
         * @param bigEndian BigEndian to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileBinDataBigEndian(bool bigEndian, index_type fileAnnotationIndex) = 0;

        /**
         * Set the BigEndian property of BinData.
         *
         * @param bigEndian BigEndian to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskBinDataBigEndian(bool bigEndian, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the BigEndian property of BinData.
         *
         * @param bigEndian BigEndian to set.
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         */
        virtual void
        setPixelsBinDataBigEndian(bool bigEndian, index_type imageIndex, index_type binDataIndex) = 0;

        /**
         * Set the Compression property of BinData.
         *
         * @param compression Compression to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileBinDataCompression(ome::xml::model::enums::Compression compression, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Compression property of BinData.
         *
         * @param compression Compression to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskBinDataCompression(ome::xml::model::enums::Compression compression, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Compression property of BinData.
         *
         * @param compression Compression to set.
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         */
        virtual void
        setPixelsBinDataCompression(ome::xml::model::enums::Compression compression, index_type imageIndex, index_type binDataIndex) = 0;

        /**
         * Set the Length property of BinData.
         *
         * @param length Length to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Length property of BinData.
         *
         * @param length Length to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Length property of BinData.
         *
         * @param length Length to set.
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         */
        virtual void
        setPixelsBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type imageIndex, index_type binDataIndex) = 0;

        /**
         * Set the FileName property of BinaryFile.
         *
         * @param fileName FileName to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileFileName(const std::string& fileName, index_type fileAnnotationIndex) = 0;

        /**
         * Set the MIMEType property of BinaryFile.
         *
         * @param mimeType MIMEType to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileMIMEType(const std::string& mimeType, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Size property of BinaryFile.
         *
         * @param size Size to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setBinaryFileSize(ome::xml::model::primitives::NonNegativeLong size, index_type fileAnnotationIndex) = 0;

        /**
         * Set the MetadataFile property of BinaryOnly.
         *
         * @param metadataFile MetadataFile to set.
         */
        virtual void
        setBinaryOnlyMetadataFile(const std::string& metadataFile) = 0;

        /**
         * Set the UUID property of BinaryOnly.
         *
         * @param uuid UUID to set.
         */
        virtual void
        setBinaryOnlyUUID(const std::string& uuid) = 0;

        /**
         * Set the AnnotationRef property of BooleanAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setBooleanAnnotationAnnotationRef(const std::string& annotation, index_type booleanAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of BooleanAnnotation.
         *
         * @param annotator Annotator to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         */
        virtual void
        setBooleanAnnotationAnnotator(const std::string& annotator, index_type booleanAnnotationIndex) = 0;

        /**
         * Set the Description property of BooleanAnnotation.
         *
         * @param description Description to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         */
        virtual void
        setBooleanAnnotationDescription(const std::string& description, index_type booleanAnnotationIndex) = 0;

        /**
         * Set the ID property of BooleanAnnotation.
         *
         * @param id ID to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         */
        virtual void
        setBooleanAnnotationID(const std::string& id, index_type booleanAnnotationIndex) = 0;

        /**
         * Set the Namespace property of BooleanAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         */
        virtual void
        setBooleanAnnotationNamespace(const std::string& namespace_, index_type booleanAnnotationIndex) = 0;

        /**
         * Set the Value property of BooleanAnnotation.
         *
         * @param value Value to set.
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         */
        virtual void
        setBooleanAnnotationValue(bool value, index_type booleanAnnotationIndex) = 0;

        /**
         * Set the AcquisitionMode property of Channel.
         *
         * @param acquisitionMode AcquisitionMode to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelAcquisitionMode(ome::xml::model::enums::AcquisitionMode acquisitionMode, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the AnnotationRef property of Channel.
         *
         * @param annotation AnnotationRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setChannelAnnotationRef(const std::string& annotation, index_type imageIndex, index_type channelIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Color property of Channel.
         *
         * @param color Color to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelColor(ome::xml::model::primitives::Color color, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ContrastMethod property of Channel.
         *
         * @param contrastMethod ContrastMethod to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelContrastMethod(ome::xml::model::enums::ContrastMethod contrastMethod, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the EmissionWavelength property of Channel.
         *
         * @param emissionWavelength EmissionWavelength to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelEmissionWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  emissionWavelength, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ExcitationWavelength property of Channel.
         *
         * @param excitationWavelength ExcitationWavelength to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelExcitationWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  excitationWavelength, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the FilterSetRef property of Channel.
         *
         * @param filterSet FilterSetRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelFilterSetRef(const std::string& filterSet, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Fluor property of Channel.
         *
         * @param fluor Fluor to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelFluor(const std::string& fluor, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ID property of Channel.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelID(const std::string& id, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the IlluminationType property of Channel.
         *
         * @param illuminationType IlluminationType to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelIlluminationType(ome::xml::model::enums::IlluminationType illuminationType, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the NDFilter property of Channel.
         *
         * @param ndFilter NDFilter to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelNDFilter(double ndFilter, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Name property of Channel.
         *
         * @param name Name to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelName(const std::string& name, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the PinholeSize property of Channel.
         *
         * @param pinholeSize PinholeSize to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelPinholeSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  pinholeSize, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the PockelCellSetting property of Channel.
         *
         * @param pockelCellSetting PockelCellSetting to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelPockelCellSetting(int32_t pockelCellSetting, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the SamplesPerPixel property of Channel.
         *
         * @param samplesPerPixel SamplesPerPixel to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelSamplesPerPixel(ome::xml::model::primitives::PositiveInteger samplesPerPixel, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the AnnotationRef property of CommentAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setCommentAnnotationAnnotationRef(const std::string& annotation, index_type commentAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of CommentAnnotation.
         *
         * @param annotator Annotator to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         */
        virtual void
        setCommentAnnotationAnnotator(const std::string& annotator, index_type commentAnnotationIndex) = 0;

        /**
         * Set the Description property of CommentAnnotation.
         *
         * @param description Description to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         */
        virtual void
        setCommentAnnotationDescription(const std::string& description, index_type commentAnnotationIndex) = 0;

        /**
         * Set the ID property of CommentAnnotation.
         *
         * @param id ID to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         */
        virtual void
        setCommentAnnotationID(const std::string& id, index_type commentAnnotationIndex) = 0;

        /**
         * Set the Namespace property of CommentAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         */
        virtual void
        setCommentAnnotationNamespace(const std::string& namespace_, index_type commentAnnotationIndex) = 0;

        /**
         * Set the Value property of CommentAnnotation.
         *
         * @param value Value to set.
         * @param commentAnnotationIndex the CommentAnnotation index.
         */
        virtual void
        setCommentAnnotationValue(const std::string& value, index_type commentAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of Dataset.
         *
         * @param annotation AnnotationRef to set.
         * @param datasetIndex the Dataset index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setDatasetAnnotationRef(const std::string& annotation, index_type datasetIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of Dataset.
         *
         * @param description Description to set.
         * @param datasetIndex the Dataset index.
         */
        virtual void
        setDatasetDescription(const std::string& description, index_type datasetIndex) = 0;

        /**
         * Set the ExperimenterGroupRef property of Dataset.
         *
         * @param experimenterGroup ExperimenterGroupRef to set.
         * @param datasetIndex the Dataset index.
         */
        virtual void
        setDatasetExperimenterGroupRef(const std::string& experimenterGroup, index_type datasetIndex) = 0;

        /**
         * Set the ExperimenterRef property of Dataset.
         *
         * @param experimenter ExperimenterRef to set.
         * @param datasetIndex the Dataset index.
         */
        virtual void
        setDatasetExperimenterRef(const std::string& experimenter, index_type datasetIndex) = 0;

        /**
         * Set the ID property of Dataset.
         *
         * @param id ID to set.
         * @param datasetIndex the Dataset index.
         */
        virtual void
        setDatasetID(const std::string& id, index_type datasetIndex) = 0;

        /**
         * Set the ImageRef property of Dataset.
         *
         * @param image ImageRef to set.
         * @param datasetIndex the Dataset index.
         * @param imageRefIndex ImageRef index (unused).
         */
        virtual void
        setDatasetImageRef(const std::string& image, index_type datasetIndex, index_type imageRefIndex = 0) = 0;

        /**
         * Set the Name property of Dataset.
         *
         * @param name Name to set.
         * @param datasetIndex the Dataset index.
         */
        virtual void
        setDatasetName(const std::string& name, index_type datasetIndex) = 0;

        /**
         * Set the AmplificationGain property of Detector.
         *
         * @param amplificationGain AmplificationGain to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorAmplificationGain(double amplificationGain, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the AnnotationRef property of Detector.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setDetectorAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type detectorIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Gain property of Detector.
         *
         * @param gain Gain to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorGain(double gain, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the ID property of Detector.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorID(const std::string& id, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the LotNumber property of Detector.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Manufacturer property of Detector.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Model property of Detector.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorModel(const std::string& model, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Offset property of Detector.
         *
         * @param offset Offset to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorOffset(double offset, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the SerialNumber property of Detector.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Type property of Detector.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorType(ome::xml::model::enums::DetectorType type, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Voltage property of Detector.
         *
         * @param voltage Voltage to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorVoltage(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential >  voltage, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Zoom property of Detector.
         *
         * @param zoom Zoom to set.
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         */
        virtual void
        setDetectorZoom(double zoom, index_type instrumentIndex, index_type detectorIndex) = 0;

        /**
         * Set the Binning property of DetectorSettings.
         *
         * @param binning Binning to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsBinning(ome::xml::model::enums::Binning binning, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Gain property of DetectorSettings.
         *
         * @param gain Gain to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsGain(double gain, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ID property of DetectorSettings.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsID(const std::string& id, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Integration property of DetectorSettings.
         *
         * @param integration Integration to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsIntegration(ome::xml::model::primitives::PositiveInteger integration, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Offset property of DetectorSettings.
         *
         * @param offset Offset to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsOffset(double offset, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ReadOutRate property of DetectorSettings.
         *
         * @param readOutRate ReadOutRate to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsReadOutRate(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency >  readOutRate, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Voltage property of DetectorSettings.
         *
         * @param voltage Voltage to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsVoltage(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential >  voltage, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Zoom property of DetectorSettings.
         *
         * @param zoom Zoom to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setDetectorSettingsZoom(double zoom, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the AnnotationRef property of Dichroic.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setDichroicAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type dichroicIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of Dichroic.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         */
        virtual void
        setDichroicID(const std::string& id, index_type instrumentIndex, index_type dichroicIndex) = 0;

        /**
         * Set the LotNumber property of Dichroic.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         */
        virtual void
        setDichroicLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type dichroicIndex) = 0;

        /**
         * Set the Manufacturer property of Dichroic.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         */
        virtual void
        setDichroicManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type dichroicIndex) = 0;

        /**
         * Set the Model property of Dichroic.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         */
        virtual void
        setDichroicModel(const std::string& model, index_type instrumentIndex, index_type dichroicIndex) = 0;

        /**
         * Set the SerialNumber property of Dichroic.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         */
        virtual void
        setDichroicSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type dichroicIndex) = 0;

        /**
         * Set the AnnotationRef property of DoubleAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setDoubleAnnotationAnnotationRef(const std::string& annotation, index_type doubleAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of DoubleAnnotation.
         *
         * @param annotator Annotator to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         */
        virtual void
        setDoubleAnnotationAnnotator(const std::string& annotator, index_type doubleAnnotationIndex) = 0;

        /**
         * Set the Description property of DoubleAnnotation.
         *
         * @param description Description to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         */
        virtual void
        setDoubleAnnotationDescription(const std::string& description, index_type doubleAnnotationIndex) = 0;

        /**
         * Set the ID property of DoubleAnnotation.
         *
         * @param id ID to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         */
        virtual void
        setDoubleAnnotationID(const std::string& id, index_type doubleAnnotationIndex) = 0;

        /**
         * Set the Namespace property of DoubleAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         */
        virtual void
        setDoubleAnnotationNamespace(const std::string& namespace_, index_type doubleAnnotationIndex) = 0;

        /**
         * Set the Value property of DoubleAnnotation.
         *
         * @param value Value to set.
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         */
        virtual void
        setDoubleAnnotationValue(double value, index_type doubleAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of Ellipse.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setEllipseAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Ellipse.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Ellipse.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Ellipse.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Ellipse.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Ellipse.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Ellipse.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Ellipse.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the RadiusX property of Ellipse.
         *
         * @param radiusX RadiusX to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseRadiusX(double radiusX, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the RadiusY property of Ellipse.
         *
         * @param radiusY RadiusY to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseRadiusY(double radiusY, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Ellipse.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Ellipse.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Ellipse.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Ellipse.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Ellipse.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Ellipse.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Ellipse.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Ellipse.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X property of Ellipse.
         *
         * @param x X to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseX(double x, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y property of Ellipse.
         *
         * @param y Y to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setEllipseY(double y, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Description property of Experiment.
         *
         * @param description Description to set.
         * @param experimentIndex the Experiment index.
         */
        virtual void
        setExperimentDescription(const std::string& description, index_type experimentIndex) = 0;

        /**
         * Set the ExperimenterRef property of Experiment.
         *
         * @param experimenter ExperimenterRef to set.
         * @param experimentIndex the Experiment index.
         */
        virtual void
        setExperimentExperimenterRef(const std::string& experimenter, index_type experimentIndex) = 0;

        /**
         * Set the ID property of Experiment.
         *
         * @param id ID to set.
         * @param experimentIndex the Experiment index.
         */
        virtual void
        setExperimentID(const std::string& id, index_type experimentIndex) = 0;

        /**
         * Set the Type property of Experiment.
         *
         * @param type Type to set.
         * @param experimentIndex the Experiment index.
         */
        virtual void
        setExperimentType(ome::xml::model::enums::ExperimentType type, index_type experimentIndex) = 0;

        /**
         * Set the AnnotationRef property of Experimenter.
         *
         * @param annotation AnnotationRef to set.
         * @param experimenterIndex the Experimenter index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setExperimenterAnnotationRef(const std::string& annotation, index_type experimenterIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Email property of Experimenter.
         *
         * @param email Email to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterEmail(const std::string& email, index_type experimenterIndex) = 0;

        /**
         * Set the FirstName property of Experimenter.
         *
         * @param firstName FirstName to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterFirstName(const std::string& firstName, index_type experimenterIndex) = 0;

        /**
         * Set the ID property of Experimenter.
         *
         * @param id ID to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterID(const std::string& id, index_type experimenterIndex) = 0;

        /**
         * Set the Institution property of Experimenter.
         *
         * @param institution Institution to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterInstitution(const std::string& institution, index_type experimenterIndex) = 0;

        /**
         * Set the LastName property of Experimenter.
         *
         * @param lastName LastName to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterLastName(const std::string& lastName, index_type experimenterIndex) = 0;

        /**
         * Set the MiddleName property of Experimenter.
         *
         * @param middleName MiddleName to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterMiddleName(const std::string& middleName, index_type experimenterIndex) = 0;

        /**
         * Set the UserName property of Experimenter.
         *
         * @param userName UserName to set.
         * @param experimenterIndex the Experimenter index.
         */
        virtual void
        setExperimenterUserName(const std::string& userName, index_type experimenterIndex) = 0;

        /**
         * Set the AnnotationRef property of ExperimenterGroup.
         *
         * @param annotation AnnotationRef to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setExperimenterGroupAnnotationRef(const std::string& annotation, index_type experimenterGroupIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of ExperimenterGroup.
         *
         * @param description Description to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         */
        virtual void
        setExperimenterGroupDescription(const std::string& description, index_type experimenterGroupIndex) = 0;

        /**
         * Set the ExperimenterRef property of ExperimenterGroup.
         *
         * @param experimenter ExperimenterRef to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param experimenterRefIndex ExperimenterRef index (unused).
         */
        virtual void
        setExperimenterGroupExperimenterRef(const std::string& experimenter, index_type experimenterGroupIndex, index_type experimenterRefIndex = 0) = 0;

        /**
         * Set the ID property of ExperimenterGroup.
         *
         * @param id ID to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         */
        virtual void
        setExperimenterGroupID(const std::string& id, index_type experimenterGroupIndex) = 0;

        /**
         * Set the Leader property of ExperimenterGroup.
         *
         * @param leader Leader to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param leaderIndex Leader index (unused).
         */
        virtual void
        setExperimenterGroupLeader(const std::string& leader, index_type experimenterGroupIndex, index_type leaderIndex = 0) = 0;

        /**
         * Set the Name property of ExperimenterGroup.
         *
         * @param name Name to set.
         * @param experimenterGroupIndex the ExperimenterGroup index.
         */
        virtual void
        setExperimenterGroupName(const std::string& name, index_type experimenterGroupIndex) = 0;

        /**
         * Set the AnnotationRef property of Filament.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setFilamentAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of Filament.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LotNumber property of Filament.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Manufacturer property of Filament.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Model property of Filament.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Power property of Filament.
         *
         * @param power Power to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the SerialNumber property of Filament.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Type property of Filament.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setFilamentType(ome::xml::model::enums::FilamentType type, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the AnnotationRef property of FileAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setFileAnnotationAnnotationRef(const std::string& annotation, index_type fileAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of FileAnnotation.
         *
         * @param annotator Annotator to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setFileAnnotationAnnotator(const std::string& annotator, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Description property of FileAnnotation.
         *
         * @param description Description to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setFileAnnotationDescription(const std::string& description, index_type fileAnnotationIndex) = 0;

        /**
         * Set the ID property of FileAnnotation.
         *
         * @param id ID to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setFileAnnotationID(const std::string& id, index_type fileAnnotationIndex) = 0;

        /**
         * Set the Namespace property of FileAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param fileAnnotationIndex the FileAnnotation index.
         */
        virtual void
        setFileAnnotationNamespace(const std::string& namespace_, index_type fileAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of Filter.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setFilterAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type filterIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FilterWheel property of Filter.
         *
         * @param filterWheel FilterWheel to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterFilterWheel(const std::string& filterWheel, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the ID property of Filter.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterID(const std::string& id, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the LotNumber property of Filter.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the Manufacturer property of Filter.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the Model property of Filter.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterModel(const std::string& model, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the SerialNumber property of Filter.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the Type property of Filter.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setFilterType(ome::xml::model::enums::FilterType type, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the DichroicRef property of FilterSet.
         *
         * @param dichroic DichroicRef to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetDichroicRef(const std::string& dichroic, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the EmissionFilterRef property of FilterSet.
         *
         * @param emissionFilter EmissionFilterRef to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @param emissionFilterRefIndex EmissionFilterRef index (unused).
         */
        virtual void
        setFilterSetEmissionFilterRef(const std::string& emissionFilter, index_type instrumentIndex, index_type filterSetIndex, index_type emissionFilterRefIndex = 0) = 0;

        /**
         * Set the ExcitationFilterRef property of FilterSet.
         *
         * @param excitationFilter ExcitationFilterRef to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @param excitationFilterRefIndex ExcitationFilterRef index (unused).
         */
        virtual void
        setFilterSetExcitationFilterRef(const std::string& excitationFilter, index_type instrumentIndex, index_type filterSetIndex, index_type excitationFilterRefIndex = 0) = 0;

        /**
         * Set the ID property of FilterSet.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetID(const std::string& id, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the LotNumber property of FilterSet.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the Manufacturer property of FilterSet.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the Model property of FilterSet.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetModel(const std::string& model, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the SerialNumber property of FilterSet.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         */
        virtual void
        setFilterSetSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type filterSetIndex) = 0;

        /**
         * Set the AnnotationRef property of Folder.
         *
         * @param annotation AnnotationRef to set.
         * @param folderIndex the Folder index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setFolderAnnotationRef(const std::string& annotation, index_type folderIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of Folder.
         *
         * @param description Description to set.
         * @param folderIndex the Folder index.
         */
        virtual void
        setFolderDescription(const std::string& description, index_type folderIndex) = 0;

        /**
         * Set the FolderRef property of Folder.
         *
         * @param folder FolderRef to set.
         * @param folderIndex the Folder index.
         * @param folderRefIndex FolderRef index (unused).
         */
        virtual void
        setFolderFolderRef(const std::string& folder, index_type folderIndex, index_type folderRefIndex = 0) = 0;

        /**
         * Set the ID property of Folder.
         *
         * @param id ID to set.
         * @param folderIndex the Folder index.
         */
        virtual void
        setFolderID(const std::string& id, index_type folderIndex) = 0;

        /**
         * Set the ImageRef property of Folder.
         *
         * @param image ImageRef to set.
         * @param folderIndex the Folder index.
         * @param imageRefIndex ImageRef index (unused).
         */
        virtual void
        setFolderImageRef(const std::string& image, index_type folderIndex, index_type imageRefIndex = 0) = 0;

        /**
         * Set the Name property of Folder.
         *
         * @param name Name to set.
         * @param folderIndex the Folder index.
         */
        virtual void
        setFolderName(const std::string& name, index_type folderIndex) = 0;

        /**
         * Set the ROIRef property of Folder.
         *
         * @param roi ROIRef to set.
         * @param folderIndex the Folder index.
         * @param ROIRefIndex ROIRef index (unused).
         */
        virtual void
        setFolderROIRef(const std::string& roi, index_type folderIndex, index_type ROIRefIndex = 0) = 0;

        /**
         * Set the AnnotationRef property of GenericExcitationSource.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setGenericExcitationSourceAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of GenericExcitationSource.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LotNumber property of GenericExcitationSource.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Manufacturer property of GenericExcitationSource.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Model property of GenericExcitationSource.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Power property of GenericExcitationSource.
         *
         * @param power Power to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourcePower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the SerialNumber property of GenericExcitationSource.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setGenericExcitationSourceSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the AcquisitionDate property of Image.
         *
         * @param acquisitionDate AcquisitionDate to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageAcquisitionDate(ome::xml::model::primitives::Timestamp acquisitionDate, index_type imageIndex) = 0;

        /**
         * Set the AnnotationRef property of Image.
         *
         * @param annotation AnnotationRef to set.
         * @param imageIndex the Image index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setImageAnnotationRef(const std::string& annotation, index_type imageIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of Image.
         *
         * @param description Description to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageDescription(const std::string& description, index_type imageIndex) = 0;

        /**
         * Set the ExperimentRef property of Image.
         *
         * @param experiment ExperimentRef to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageExperimentRef(const std::string& experiment, index_type imageIndex) = 0;

        /**
         * Set the ExperimenterGroupRef property of Image.
         *
         * @param experimenterGroup ExperimenterGroupRef to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageExperimenterGroupRef(const std::string& experimenterGroup, index_type imageIndex) = 0;

        /**
         * Set the ExperimenterRef property of Image.
         *
         * @param experimenter ExperimenterRef to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageExperimenterRef(const std::string& experimenter, index_type imageIndex) = 0;

        /**
         * Set the ID property of Image.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageID(const std::string& id, index_type imageIndex) = 0;

        /**
         * Set the InstrumentRef property of Image.
         *
         * @param instrument InstrumentRef to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageInstrumentRef(const std::string& instrument, index_type imageIndex) = 0;

        /**
         * Set the MicrobeamManipulationRef property of Image.
         *
         * @param microbeamManipulation MicrobeamManipulationRef to set.
         * @param imageIndex the Image index.
         * @param microbeamManipulationRefIndex MicrobeamManipulationRef index (unused).
         */
        virtual void
        setImageMicrobeamManipulationRef(const std::string& microbeamManipulation, index_type imageIndex, index_type microbeamManipulationRefIndex = 0) = 0;

        /**
         * Set the Name property of Image.
         *
         * @param name Name to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImageName(const std::string& name, index_type imageIndex) = 0;

        /**
         * Set the ROIRef property of Image.
         *
         * @param roi ROIRef to set.
         * @param imageIndex the Image index.
         * @param ROIRefIndex ROIRef index (unused).
         */
        virtual void
        setImageROIRef(const std::string& roi, index_type imageIndex, index_type ROIRefIndex = 0) = 0;

        /**
         * Set the AirPressure property of ImagingEnvironment.
         *
         * @param airPressure AirPressure to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImagingEnvironmentAirPressure(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure >  airPressure, index_type imageIndex) = 0;

        /**
         * Set the CO2Percent property of ImagingEnvironment.
         *
         * @param co2Percent CO2Percent to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImagingEnvironmentCO2Percent(ome::xml::model::primitives::PercentFraction co2Percent, index_type imageIndex) = 0;

        /**
         * Set the Humidity property of ImagingEnvironment.
         *
         * @param humidity Humidity to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImagingEnvironmentHumidity(ome::xml::model::primitives::PercentFraction humidity, index_type imageIndex) = 0;

        /**
         * Set the Temperature property of ImagingEnvironment.
         *
         * @param temperature Temperature to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setImagingEnvironmentTemperature(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature >  temperature, index_type imageIndex) = 0;

        /**
         * Set the AnnotationRef property of Instrument.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setInstrumentAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of Instrument.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setInstrumentID(const std::string& id, index_type instrumentIndex) = 0;

        /**
         * Set the AnnotationRef property of Label.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLabelAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Label.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Label.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Label.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Label.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Label.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Label.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Label.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Label.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Label.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Label.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Label.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Label.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Label.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Label.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Label.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X property of Label.
         *
         * @param x X to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelX(double x, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y property of Label.
         *
         * @param y Y to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLabelY(double y, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the AnnotationRef property of Laser.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLaserAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FrequencyMultiplication property of Laser.
         *
         * @param frequencyMultiplication FrequencyMultiplication to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserFrequencyMultiplication(ome::xml::model::primitives::PositiveInteger frequencyMultiplication, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the ID property of Laser.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LaserMedium property of Laser.
         *
         * @param laserMedium LaserMedium to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserLaserMedium(ome::xml::model::enums::LaserMedium laserMedium, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LotNumber property of Laser.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Manufacturer property of Laser.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Model property of Laser.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the PockelCell property of Laser.
         *
         * @param pockelCell PockelCell to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserPockelCell(bool pockelCell, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Power property of Laser.
         *
         * @param power Power to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Pulse property of Laser.
         *
         * @param pulse Pulse to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserPulse(ome::xml::model::enums::Pulse pulse, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Pump property of Laser.
         *
         * @param pump Pump to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserPump(const std::string& pump, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the RepetitionRate property of Laser.
         *
         * @param repetitionRate RepetitionRate to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserRepetitionRate(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency >  repetitionRate, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the SerialNumber property of Laser.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Tuneable property of Laser.
         *
         * @param tuneable Tuneable to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserTuneable(bool tuneable, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Type property of Laser.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserType(ome::xml::model::enums::LaserType type, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Wavelength property of Laser.
         *
         * @param wavelength Wavelength to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLaserWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the AnnotationRef property of LightEmittingDiode.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLightEmittingDiodeAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ID property of LightEmittingDiode.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodeID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the LotNumber property of LightEmittingDiode.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodeLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Manufacturer property of LightEmittingDiode.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodeManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Model property of LightEmittingDiode.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodeModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the Power property of LightEmittingDiode.
         *
         * @param power Power to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodePower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the SerialNumber property of LightEmittingDiode.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         */
        virtual void
        setLightEmittingDiodeSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex) = 0;

        /**
         * Set the AnnotationRef property of LightPath.
         *
         * @param annotation AnnotationRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLightPathAnnotationRef(const std::string& annotation, index_type imageIndex, index_type channelIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the DichroicRef property of LightPath.
         *
         * @param dichroic DichroicRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setLightPathDichroicRef(const std::string& dichroic, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the EmissionFilterRef property of LightPath.
         *
         * @param emissionFilter EmissionFilterRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param emissionFilterRefIndex EmissionFilterRef index (unused).
         */
        virtual void
        setLightPathEmissionFilterRef(const std::string& emissionFilter, index_type imageIndex, index_type channelIndex, index_type emissionFilterRefIndex = 0) = 0;

        /**
         * Set the ExcitationFilterRef property of LightPath.
         *
         * @param excitationFilter ExcitationFilterRef to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param excitationFilterRefIndex ExcitationFilterRef index (unused).
         */
        virtual void
        setLightPathExcitationFilterRef(const std::string& excitationFilter, index_type imageIndex, index_type channelIndex, index_type excitationFilterRefIndex = 0) = 0;

        /**
         * Set the Attenuation property of LightSourceSettings.
         *
         * @param attenuation Attenuation to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelLightSourceSettingsAttenuation(ome::xml::model::primitives::PercentFraction attenuation, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Attenuation property of LightSourceSettings.
         *
         * @param attenuation Attenuation to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         */
        virtual void
        setMicrobeamManipulationLightSourceSettingsAttenuation(ome::xml::model::primitives::PercentFraction attenuation, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) = 0;

        /**
         * Set the ID property of LightSourceSettings.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelLightSourceSettingsID(const std::string& id, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the ID property of LightSourceSettings.
         *
         * @param id ID to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         */
        virtual void
        setMicrobeamManipulationLightSourceSettingsID(const std::string& id, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) = 0;

        /**
         * Set the Wavelength property of LightSourceSettings.
         *
         * @param wavelength Wavelength to set.
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         */
        virtual void
        setChannelLightSourceSettingsWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type imageIndex, index_type channelIndex) = 0;

        /**
         * Set the Wavelength property of LightSourceSettings.
         *
         * @param wavelength Wavelength to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         */
        virtual void
        setMicrobeamManipulationLightSourceSettingsWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) = 0;

        /**
         * Set the AnnotationRef property of Line.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLineAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Line.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Line.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Line.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Line.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Line.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Line.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Line.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the MarkerEnd property of Line.
         *
         * @param markerEnd MarkerEnd to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineMarkerEnd(ome::xml::model::enums::Marker markerEnd, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the MarkerStart property of Line.
         *
         * @param markerStart MarkerStart to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineMarkerStart(ome::xml::model::enums::Marker markerStart, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Line.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Line.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Line.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Line.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Line.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Line.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Line.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Line.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X1 property of Line.
         *
         * @param x1 X1 to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineX1(double x1, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X2 property of Line.
         *
         * @param x2 X2 to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineX2(double x2, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y1 property of Line.
         *
         * @param y1 Y1 to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineY1(double y1, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y2 property of Line.
         *
         * @param y2 Y2 to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setLineY2(double y2, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the AnnotationRef property of ListAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param listAnnotationIndex the ListAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setListAnnotationAnnotationRef(const std::string& annotation, index_type listAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of ListAnnotation.
         *
         * @param annotator Annotator to set.
         * @param listAnnotationIndex the ListAnnotation index.
         */
        virtual void
        setListAnnotationAnnotator(const std::string& annotator, index_type listAnnotationIndex) = 0;

        /**
         * Set the Description property of ListAnnotation.
         *
         * @param description Description to set.
         * @param listAnnotationIndex the ListAnnotation index.
         */
        virtual void
        setListAnnotationDescription(const std::string& description, index_type listAnnotationIndex) = 0;

        /**
         * Set the ID property of ListAnnotation.
         *
         * @param id ID to set.
         * @param listAnnotationIndex the ListAnnotation index.
         */
        virtual void
        setListAnnotationID(const std::string& id, index_type listAnnotationIndex) = 0;

        /**
         * Set the Namespace property of ListAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param listAnnotationIndex the ListAnnotation index.
         */
        virtual void
        setListAnnotationNamespace(const std::string& namespace_, index_type listAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of LongAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param longAnnotationIndex the LongAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setLongAnnotationAnnotationRef(const std::string& annotation, index_type longAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of LongAnnotation.
         *
         * @param annotator Annotator to set.
         * @param longAnnotationIndex the LongAnnotation index.
         */
        virtual void
        setLongAnnotationAnnotator(const std::string& annotator, index_type longAnnotationIndex) = 0;

        /**
         * Set the Description property of LongAnnotation.
         *
         * @param description Description to set.
         * @param longAnnotationIndex the LongAnnotation index.
         */
        virtual void
        setLongAnnotationDescription(const std::string& description, index_type longAnnotationIndex) = 0;

        /**
         * Set the ID property of LongAnnotation.
         *
         * @param id ID to set.
         * @param longAnnotationIndex the LongAnnotation index.
         */
        virtual void
        setLongAnnotationID(const std::string& id, index_type longAnnotationIndex) = 0;

        /**
         * Set the Namespace property of LongAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param longAnnotationIndex the LongAnnotation index.
         */
        virtual void
        setLongAnnotationNamespace(const std::string& namespace_, index_type longAnnotationIndex) = 0;

        /**
         * Set the Value property of LongAnnotation.
         *
         * @param value Value to set.
         * @param longAnnotationIndex the LongAnnotation index.
         */
        virtual void
        setLongAnnotationValue(int64_t value, index_type longAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of MapAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setMapAnnotationAnnotationRef(const std::string& annotation, index_type mapAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of MapAnnotation.
         *
         * @param annotator Annotator to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         */
        virtual void
        setMapAnnotationAnnotator(const std::string& annotator, index_type mapAnnotationIndex) = 0;

        /**
         * Set the Description property of MapAnnotation.
         *
         * @param description Description to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         */
        virtual void
        setMapAnnotationDescription(const std::string& description, index_type mapAnnotationIndex) = 0;

        /**
         * Set the ID property of MapAnnotation.
         *
         * @param id ID to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         */
        virtual void
        setMapAnnotationID(const std::string& id, index_type mapAnnotationIndex) = 0;

        /**
         * Set the Namespace property of MapAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param mapAnnotationIndex the MapAnnotation index.
         */
        virtual void
        setMapAnnotationNamespace(const std::string& namespace_, index_type mapAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of Mask.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setMaskAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Mask.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Mask.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Mask.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Mask.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Mask.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Height property of Mask.
         *
         * @param height Height to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskHeight(double height, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Mask.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Mask.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Mask.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Mask.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Mask.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Mask.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Mask.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Mask.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Mask.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Mask.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Width property of Mask.
         *
         * @param width Width to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskWidth(double width, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X property of Mask.
         *
         * @param x X to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskX(double x, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y property of Mask.
         *
         * @param y Y to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setMaskY(double y, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Description property of MicrobeamManipulation.
         *
         * @param description Description to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         */
        virtual void
        setMicrobeamManipulationDescription(const std::string& description, index_type experimentIndex, index_type microbeamManipulationIndex) = 0;

        /**
         * Set the ExperimenterRef property of MicrobeamManipulation.
         *
         * @param experimenter ExperimenterRef to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         */
        virtual void
        setMicrobeamManipulationExperimenterRef(const std::string& experimenter, index_type experimentIndex, index_type microbeamManipulationIndex) = 0;

        /**
         * Set the ID property of MicrobeamManipulation.
         *
         * @param id ID to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         */
        virtual void
        setMicrobeamManipulationID(const std::string& id, index_type experimentIndex, index_type microbeamManipulationIndex) = 0;

        /**
         * Set the ROIRef property of MicrobeamManipulation.
         *
         * @param roi ROIRef to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param ROIRefIndex ROIRef index (unused).
         */
        virtual void
        setMicrobeamManipulationROIRef(const std::string& roi, index_type experimentIndex, index_type microbeamManipulationIndex, index_type ROIRefIndex = 0) = 0;

        /**
         * Set the Type property of MicrobeamManipulation.
         *
         * @param type Type to set.
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         */
        virtual void
        setMicrobeamManipulationType(ome::xml::model::enums::MicrobeamManipulationType type, index_type experimentIndex, index_type microbeamManipulationIndex) = 0;

        /**
         * Set the LotNumber property of Microscope.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setMicroscopeLotNumber(const std::string& lotNumber, index_type instrumentIndex) = 0;

        /**
         * Set the Manufacturer property of Microscope.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setMicroscopeManufacturer(const std::string& manufacturer, index_type instrumentIndex) = 0;

        /**
         * Set the Model property of Microscope.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setMicroscopeModel(const std::string& model, index_type instrumentIndex) = 0;

        /**
         * Set the SerialNumber property of Microscope.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setMicroscopeSerialNumber(const std::string& serialNumber, index_type instrumentIndex) = 0;

        /**
         * Set the Type property of Microscope.
         *
         * @param type Type to set.
         * @param instrumentIndex the Instrument index.
         */
        virtual void
        setMicroscopeType(ome::xml::model::enums::MicroscopeType type, index_type instrumentIndex) = 0;

        /**
         * Set the AnnotationRef property of Objective.
         *
         * @param annotation AnnotationRef to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setObjectiveAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type objectiveIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the CalibratedMagnification property of Objective.
         *
         * @param calibratedMagnification CalibratedMagnification to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveCalibratedMagnification(double calibratedMagnification, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the Correction property of Objective.
         *
         * @param correction Correction to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveCorrection(ome::xml::model::enums::Correction correction, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the ID property of Objective.
         *
         * @param id ID to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveID(const std::string& id, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the Immersion property of Objective.
         *
         * @param immersion Immersion to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveImmersion(ome::xml::model::enums::Immersion immersion, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the Iris property of Objective.
         *
         * @param iris Iris to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveIris(bool iris, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the LensNA property of Objective.
         *
         * @param lensNA LensNA to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveLensNA(double lensNA, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the LotNumber property of Objective.
         *
         * @param lotNumber LotNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the Manufacturer property of Objective.
         *
         * @param manufacturer Manufacturer to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the Model property of Objective.
         *
         * @param model Model to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveModel(const std::string& model, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the NominalMagnification property of Objective.
         *
         * @param nominalMagnification NominalMagnification to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveNominalMagnification(double nominalMagnification, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the SerialNumber property of Objective.
         *
         * @param serialNumber SerialNumber to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the WorkingDistance property of Objective.
         *
         * @param workingDistance WorkingDistance to set.
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         */
        virtual void
        setObjectiveWorkingDistance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  workingDistance, index_type instrumentIndex, index_type objectiveIndex) = 0;

        /**
         * Set the CorrectionCollar property of ObjectiveSettings.
         *
         * @param correctionCollar CorrectionCollar to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setObjectiveSettingsCorrectionCollar(double correctionCollar, index_type imageIndex) = 0;

        /**
         * Set the ID property of ObjectiveSettings.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setObjectiveSettingsID(const std::string& id, index_type imageIndex) = 0;

        /**
         * Set the Medium property of ObjectiveSettings.
         *
         * @param medium Medium to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setObjectiveSettingsMedium(ome::xml::model::enums::Medium medium, index_type imageIndex) = 0;

        /**
         * Set the RefractiveIndex property of ObjectiveSettings.
         *
         * @param refractiveIndex RefractiveIndex to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setObjectiveSettingsRefractiveIndex(double refractiveIndex, index_type imageIndex) = 0;

        /**
         * Set the BigEndian property of Pixels.
         *
         * @param bigEndian BigEndian to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsBigEndian(bool bigEndian, index_type imageIndex) = 0;

        /**
         * Set the DimensionOrder property of Pixels.
         *
         * @param dimensionOrder DimensionOrder to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsDimensionOrder(ome::xml::model::enums::DimensionOrder dimensionOrder, index_type imageIndex) = 0;

        /**
         * Set the ID property of Pixels.
         *
         * @param id ID to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsID(const std::string& id, index_type imageIndex) = 0;

        /**
         * Set the Interleaved property of Pixels.
         *
         * @param interleaved Interleaved to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsInterleaved(bool interleaved, index_type imageIndex) = 0;

        /**
         * Set the PhysicalSizeX property of Pixels.
         *
         * @param physicalSizeX PhysicalSizeX to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsPhysicalSizeX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeX, index_type imageIndex) = 0;

        /**
         * Set the PhysicalSizeY property of Pixels.
         *
         * @param physicalSizeY PhysicalSizeY to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsPhysicalSizeY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeY, index_type imageIndex) = 0;

        /**
         * Set the PhysicalSizeZ property of Pixels.
         *
         * @param physicalSizeZ PhysicalSizeZ to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsPhysicalSizeZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeZ, index_type imageIndex) = 0;

        /**
         * Set the SignificantBits property of Pixels.
         *
         * @param significantBits SignificantBits to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSignificantBits(ome::xml::model::primitives::PositiveInteger significantBits, index_type imageIndex) = 0;

        /**
         * Set the SizeC property of Pixels.
         *
         * @param sizeC SizeC to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSizeC(ome::xml::model::primitives::PositiveInteger sizeC, index_type imageIndex) = 0;

        /**
         * Set the SizeT property of Pixels.
         *
         * @param sizeT SizeT to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSizeT(ome::xml::model::primitives::PositiveInteger sizeT, index_type imageIndex) = 0;

        /**
         * Set the SizeX property of Pixels.
         *
         * @param sizeX SizeX to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSizeX(ome::xml::model::primitives::PositiveInteger sizeX, index_type imageIndex) = 0;

        /**
         * Set the SizeY property of Pixels.
         *
         * @param sizeY SizeY to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSizeY(ome::xml::model::primitives::PositiveInteger sizeY, index_type imageIndex) = 0;

        /**
         * Set the SizeZ property of Pixels.
         *
         * @param sizeZ SizeZ to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsSizeZ(ome::xml::model::primitives::PositiveInteger sizeZ, index_type imageIndex) = 0;

        /**
         * Set the TimeIncrement property of Pixels.
         *
         * @param timeIncrement TimeIncrement to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsTimeIncrement(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  timeIncrement, index_type imageIndex) = 0;

        /**
         * Set the Type property of Pixels.
         *
         * @param type Type to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setPixelsType(ome::xml::model::enums::PixelType type, index_type imageIndex) = 0;

        /**
         * Set the AnnotationRef property of Plane.
         *
         * @param annotation AnnotationRef to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPlaneAnnotationRef(const std::string& annotation, index_type imageIndex, index_type planeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the DeltaT property of Plane.
         *
         * @param deltaT DeltaT to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneDeltaT(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  deltaT, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the ExposureTime property of Plane.
         *
         * @param exposureTime ExposureTime to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneExposureTime(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  exposureTime, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the HashSHA1 property of Plane.
         *
         * @param hashSHA1 HashSHA1 to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneHashSHA1(const std::string& hashSHA1, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the PositionX property of Plane.
         *
         * @param positionX PositionX to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlanePositionX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionX, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the PositionY property of Plane.
         *
         * @param positionY PositionY to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlanePositionY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionY, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the PositionZ property of Plane.
         *
         * @param positionZ PositionZ to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlanePositionZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionZ, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the TheC property of Plane.
         *
         * @param theC TheC to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the TheT property of Plane.
         *
         * @param theT TheT to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the TheZ property of Plane.
         *
         * @param theZ TheZ to set.
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         */
        virtual void
        setPlaneTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type imageIndex, index_type planeIndex) = 0;

        /**
         * Set the AnnotationRef property of Plate.
         *
         * @param annotation AnnotationRef to set.
         * @param plateIndex the Plate index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPlateAnnotationRef(const std::string& annotation, index_type plateIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the ColumnNamingConvention property of Plate.
         *
         * @param columnNamingConvention ColumnNamingConvention to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateColumnNamingConvention(ome::xml::model::enums::NamingConvention columnNamingConvention, index_type plateIndex) = 0;

        /**
         * Set the Columns property of Plate.
         *
         * @param columns Columns to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateColumns(ome::xml::model::primitives::PositiveInteger columns, index_type plateIndex) = 0;

        /**
         * Set the Description property of Plate.
         *
         * @param description Description to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateDescription(const std::string& description, index_type plateIndex) = 0;

        /**
         * Set the ExternalIdentifier property of Plate.
         *
         * @param externalIdentifier ExternalIdentifier to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateExternalIdentifier(const std::string& externalIdentifier, index_type plateIndex) = 0;

        /**
         * Set the FieldIndex property of Plate.
         *
         * @param fieldIndex FieldIndex to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateFieldIndex(ome::xml::model::primitives::NonNegativeInteger fieldIndex, index_type plateIndex) = 0;

        /**
         * Set the ID property of Plate.
         *
         * @param id ID to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateID(const std::string& id, index_type plateIndex) = 0;

        /**
         * Set the Name property of Plate.
         *
         * @param name Name to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateName(const std::string& name, index_type plateIndex) = 0;

        /**
         * Set the RowNamingConvention property of Plate.
         *
         * @param rowNamingConvention RowNamingConvention to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateRowNamingConvention(ome::xml::model::enums::NamingConvention rowNamingConvention, index_type plateIndex) = 0;

        /**
         * Set the Rows property of Plate.
         *
         * @param rows Rows to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateRows(ome::xml::model::primitives::PositiveInteger rows, index_type plateIndex) = 0;

        /**
         * Set the Status property of Plate.
         *
         * @param status Status to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateStatus(const std::string& status, index_type plateIndex) = 0;

        /**
         * Set the WellOriginX property of Plate.
         *
         * @param wellOriginX WellOriginX to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateWellOriginX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  wellOriginX, index_type plateIndex) = 0;

        /**
         * Set the WellOriginY property of Plate.
         *
         * @param wellOriginY WellOriginY to set.
         * @param plateIndex the Plate index.
         */
        virtual void
        setPlateWellOriginY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  wellOriginY, index_type plateIndex) = 0;

        /**
         * Set the AnnotationRef property of PlateAcquisition.
         *
         * @param annotation AnnotationRef to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPlateAcquisitionAnnotationRef(const std::string& annotation, index_type plateIndex, index_type plateAcquisitionIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of PlateAcquisition.
         *
         * @param description Description to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionDescription(const std::string& description, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the EndTime property of PlateAcquisition.
         *
         * @param endTime EndTime to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionEndTime(ome::xml::model::primitives::Timestamp endTime, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the ID property of PlateAcquisition.
         *
         * @param id ID to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionID(const std::string& id, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the MaximumFieldCount property of PlateAcquisition.
         *
         * @param maximumFieldCount MaximumFieldCount to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionMaximumFieldCount(ome::xml::model::primitives::PositiveInteger maximumFieldCount, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the Name property of PlateAcquisition.
         *
         * @param name Name to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionName(const std::string& name, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the StartTime property of PlateAcquisition.
         *
         * @param startTime StartTime to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         */
        virtual void
        setPlateAcquisitionStartTime(ome::xml::model::primitives::Timestamp startTime, index_type plateIndex, index_type plateAcquisitionIndex) = 0;

        /**
         * Set the WellSampleRef property of PlateAcquisition.
         *
         * @param wellSample WellSampleRef to set.
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @param wellSampleRefIndex WellSampleRef index (unused).
         */
        virtual void
        setPlateAcquisitionWellSampleRef(const std::string& wellSample, index_type plateIndex, index_type plateAcquisitionIndex, index_type wellSampleRefIndex = 0) = 0;

        /**
         * Set the AnnotationRef property of Point.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPointAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Point.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Point.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Point.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Point.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Point.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Point.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Point.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Point.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Point.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Point.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Point.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Point.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Point.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Point.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Point.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X property of Point.
         *
         * @param x X to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointX(double x, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y property of Point.
         *
         * @param y Y to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPointY(double y, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the AnnotationRef property of Polygon.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPolygonAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Polygon.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Polygon.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Polygon.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Polygon.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Polygon.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Polygon.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Polygon.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Points property of Polygon.
         *
         * @param points Points to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonPoints(const std::string& points, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Polygon.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Polygon.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Polygon.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Polygon.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Polygon.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Polygon.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Polygon.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Polygon.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolygonTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the AnnotationRef property of Polyline.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setPolylineAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Polyline.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Polyline.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Polyline.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Polyline.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Polyline.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Polyline.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Polyline.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the MarkerEnd property of Polyline.
         *
         * @param markerEnd MarkerEnd to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineMarkerEnd(ome::xml::model::enums::Marker markerEnd, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the MarkerStart property of Polyline.
         *
         * @param markerStart MarkerStart to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineMarkerStart(ome::xml::model::enums::Marker markerStart, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Points property of Polyline.
         *
         * @param points Points to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylinePoints(const std::string& points, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Polyline.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Polyline.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Polyline.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Polyline.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Polyline.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Polyline.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Polyline.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Polyline.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setPolylineTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the AnnotationRef property of Project.
         *
         * @param annotation AnnotationRef to set.
         * @param projectIndex the Project index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setProjectAnnotationRef(const std::string& annotation, index_type projectIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the DatasetRef property of Project.
         *
         * @param dataset DatasetRef to set.
         * @param projectIndex the Project index.
         * @param datasetRefIndex DatasetRef index (unused).
         */
        virtual void
        setProjectDatasetRef(const std::string& dataset, index_type projectIndex, index_type datasetRefIndex = 0) = 0;

        /**
         * Set the Description property of Project.
         *
         * @param description Description to set.
         * @param projectIndex the Project index.
         */
        virtual void
        setProjectDescription(const std::string& description, index_type projectIndex) = 0;

        /**
         * Set the ExperimenterGroupRef property of Project.
         *
         * @param experimenterGroup ExperimenterGroupRef to set.
         * @param projectIndex the Project index.
         */
        virtual void
        setProjectExperimenterGroupRef(const std::string& experimenterGroup, index_type projectIndex) = 0;

        /**
         * Set the ExperimenterRef property of Project.
         *
         * @param experimenter ExperimenterRef to set.
         * @param projectIndex the Project index.
         */
        virtual void
        setProjectExperimenterRef(const std::string& experimenter, index_type projectIndex) = 0;

        /**
         * Set the ID property of Project.
         *
         * @param id ID to set.
         * @param projectIndex the Project index.
         */
        virtual void
        setProjectID(const std::string& id, index_type projectIndex) = 0;

        /**
         * Set the Name property of Project.
         *
         * @param name Name to set.
         * @param projectIndex the Project index.
         */
        virtual void
        setProjectName(const std::string& name, index_type projectIndex) = 0;

        /**
         * Set the AnnotationRef property of ROI.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setROIAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of ROI.
         *
         * @param description Description to set.
         * @param ROIIndex the ROI index.
         */
        virtual void
        setROIDescription(const std::string& description, index_type ROIIndex) = 0;

        /**
         * Set the ID property of ROI.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         */
        virtual void
        setROIID(const std::string& id, index_type ROIIndex) = 0;

        /**
         * Set the Name property of ROI.
         *
         * @param name Name to set.
         * @param ROIIndex the ROI index.
         */
        virtual void
        setROIName(const std::string& name, index_type ROIIndex) = 0;

        /**
         * Set the AnnotationRef property of Reagent.
         *
         * @param annotation AnnotationRef to set.
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setReagentAnnotationRef(const std::string& annotation, index_type screenIndex, index_type reagentIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of Reagent.
         *
         * @param description Description to set.
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         */
        virtual void
        setReagentDescription(const std::string& description, index_type screenIndex, index_type reagentIndex) = 0;

        /**
         * Set the ID property of Reagent.
         *
         * @param id ID to set.
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         */
        virtual void
        setReagentID(const std::string& id, index_type screenIndex, index_type reagentIndex) = 0;

        /**
         * Set the Name property of Reagent.
         *
         * @param name Name to set.
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         */
        virtual void
        setReagentName(const std::string& name, index_type screenIndex, index_type reagentIndex) = 0;

        /**
         * Set the ReagentIdentifier property of Reagent.
         *
         * @param reagentIdentifier ReagentIdentifier to set.
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         */
        virtual void
        setReagentReagentIdentifier(const std::string& reagentIdentifier, index_type screenIndex, index_type reagentIndex) = 0;

        /**
         * Set the AnnotationRef property of Rectangle.
         *
         * @param annotation AnnotationRef to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setRectangleAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the FillColor property of Rectangle.
         *
         * @param fillColor FillColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FillRule property of Rectangle.
         *
         * @param fillRule FillRule to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontFamily property of Rectangle.
         *
         * @param fontFamily FontFamily to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontSize property of Rectangle.
         *
         * @param fontSize FontSize to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the FontStyle property of Rectangle.
         *
         * @param fontStyle FontStyle to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Height property of Rectangle.
         *
         * @param height Height to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleHeight(double height, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the ID property of Rectangle.
         *
         * @param id ID to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleID(const std::string& id, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Locked property of Rectangle.
         *
         * @param locked Locked to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleLocked(bool locked, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeColor property of Rectangle.
         *
         * @param strokeColor StrokeColor to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeDashArray property of Rectangle.
         *
         * @param strokeDashArray StrokeDashArray to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the StrokeWidth property of Rectangle.
         *
         * @param strokeWidth StrokeWidth to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Text property of Rectangle.
         *
         * @param text Text to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleText(const std::string& text, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheC property of Rectangle.
         *
         * @param theC TheC to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheT property of Rectangle.
         *
         * @param theT TheT to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the TheZ property of Rectangle.
         *
         * @param theZ TheZ to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Transform property of Rectangle.
         *
         * @param transform Transform to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Width property of Rectangle.
         *
         * @param width Width to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleWidth(double width, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the X property of Rectangle.
         *
         * @param x X to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleX(double x, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the Y property of Rectangle.
         *
         * @param y Y to set.
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         */
        virtual void
        setRectangleY(double y, index_type ROIIndex, index_type shapeIndex) = 0;

        /**
         * Set the RightsHeld property of Rights.
         *
         * @param rightsHeld RightsHeld to set.
         */
        virtual void
        setRightsRightsHeld(const std::string& rightsHeld) = 0;

        /**
         * Set the RightsHolder property of Rights.
         *
         * @param rightsHolder RightsHolder to set.
         */
        virtual void
        setRightsRightsHolder(const std::string& rightsHolder) = 0;

        /**
         * Set the AnnotationRef property of Screen.
         *
         * @param annotation AnnotationRef to set.
         * @param screenIndex the Screen index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setScreenAnnotationRef(const std::string& annotation, index_type screenIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Description property of Screen.
         *
         * @param description Description to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenDescription(const std::string& description, index_type screenIndex) = 0;

        /**
         * Set the ID property of Screen.
         *
         * @param id ID to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenID(const std::string& id, index_type screenIndex) = 0;

        /**
         * Set the Name property of Screen.
         *
         * @param name Name to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenName(const std::string& name, index_type screenIndex) = 0;

        /**
         * Set the PlateRef property of Screen.
         *
         * @param plate PlateRef to set.
         * @param screenIndex the Screen index.
         * @param plateRefIndex PlateRef index (unused).
         */
        virtual void
        setScreenPlateRef(const std::string& plate, index_type screenIndex, index_type plateRefIndex = 0) = 0;

        /**
         * Set the ProtocolDescription property of Screen.
         *
         * @param protocolDescription ProtocolDescription to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenProtocolDescription(const std::string& protocolDescription, index_type screenIndex) = 0;

        /**
         * Set the ProtocolIdentifier property of Screen.
         *
         * @param protocolIdentifier ProtocolIdentifier to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenProtocolIdentifier(const std::string& protocolIdentifier, index_type screenIndex) = 0;

        /**
         * Set the ReagentSetDescription property of Screen.
         *
         * @param reagentSetDescription ReagentSetDescription to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenReagentSetDescription(const std::string& reagentSetDescription, index_type screenIndex) = 0;

        /**
         * Set the ReagentSetIdentifier property of Screen.
         *
         * @param reagentSetIdentifier ReagentSetIdentifier to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenReagentSetIdentifier(const std::string& reagentSetIdentifier, index_type screenIndex) = 0;

        /**
         * Set the Type property of Screen.
         *
         * @param type Type to set.
         * @param screenIndex the Screen index.
         */
        virtual void
        setScreenType(const std::string& type, index_type screenIndex) = 0;

        /**
         * Set the Name property of StageLabel.
         *
         * @param name Name to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setStageLabelName(const std::string& name, index_type imageIndex) = 0;

        /**
         * Set the X property of StageLabel.
         *
         * @param x X to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setStageLabelX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  x, index_type imageIndex) = 0;

        /**
         * Set the Y property of StageLabel.
         *
         * @param y Y to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setStageLabelY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  y, index_type imageIndex) = 0;

        /**
         * Set the Z property of StageLabel.
         *
         * @param z Z to set.
         * @param imageIndex the Image index.
         */
        virtual void
        setStageLabelZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  z, index_type imageIndex) = 0;

        /**
         * Set the AnnotationRef property of TagAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setTagAnnotationAnnotationRef(const std::string& annotation, index_type tagAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of TagAnnotation.
         *
         * @param annotator Annotator to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         */
        virtual void
        setTagAnnotationAnnotator(const std::string& annotator, index_type tagAnnotationIndex) = 0;

        /**
         * Set the Description property of TagAnnotation.
         *
         * @param description Description to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         */
        virtual void
        setTagAnnotationDescription(const std::string& description, index_type tagAnnotationIndex) = 0;

        /**
         * Set the ID property of TagAnnotation.
         *
         * @param id ID to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         */
        virtual void
        setTagAnnotationID(const std::string& id, index_type tagAnnotationIndex) = 0;

        /**
         * Set the Namespace property of TagAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         */
        virtual void
        setTagAnnotationNamespace(const std::string& namespace_, index_type tagAnnotationIndex) = 0;

        /**
         * Set the Value property of TagAnnotation.
         *
         * @param value Value to set.
         * @param tagAnnotationIndex the TagAnnotation index.
         */
        virtual void
        setTagAnnotationValue(const std::string& value, index_type tagAnnotationIndex) = 0;

        /**
         * Set the AnnotationRef property of TermAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param termAnnotationIndex the TermAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setTermAnnotationAnnotationRef(const std::string& annotation, index_type termAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of TermAnnotation.
         *
         * @param annotator Annotator to set.
         * @param termAnnotationIndex the TermAnnotation index.
         */
        virtual void
        setTermAnnotationAnnotator(const std::string& annotator, index_type termAnnotationIndex) = 0;

        /**
         * Set the Description property of TermAnnotation.
         *
         * @param description Description to set.
         * @param termAnnotationIndex the TermAnnotation index.
         */
        virtual void
        setTermAnnotationDescription(const std::string& description, index_type termAnnotationIndex) = 0;

        /**
         * Set the ID property of TermAnnotation.
         *
         * @param id ID to set.
         * @param termAnnotationIndex the TermAnnotation index.
         */
        virtual void
        setTermAnnotationID(const std::string& id, index_type termAnnotationIndex) = 0;

        /**
         * Set the Namespace property of TermAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param termAnnotationIndex the TermAnnotation index.
         */
        virtual void
        setTermAnnotationNamespace(const std::string& namespace_, index_type termAnnotationIndex) = 0;

        /**
         * Set the Value property of TermAnnotation.
         *
         * @param value Value to set.
         * @param termAnnotationIndex the TermAnnotation index.
         */
        virtual void
        setTermAnnotationValue(const std::string& value, index_type termAnnotationIndex) = 0;

        /**
         * Set the FirstC property of TiffData.
         *
         * @param firstC FirstC to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setTiffDataFirstC(ome::xml::model::primitives::NonNegativeInteger firstC, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the FirstT property of TiffData.
         *
         * @param firstT FirstT to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setTiffDataFirstT(ome::xml::model::primitives::NonNegativeInteger firstT, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the FirstZ property of TiffData.
         *
         * @param firstZ FirstZ to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setTiffDataFirstZ(ome::xml::model::primitives::NonNegativeInteger firstZ, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the IFD property of TiffData.
         *
         * @param ifd IFD to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setTiffDataIFD(ome::xml::model::primitives::NonNegativeInteger ifd, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the PlaneCount property of TiffData.
         *
         * @param planeCount PlaneCount to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setTiffDataPlaneCount(ome::xml::model::primitives::NonNegativeInteger planeCount, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the AnnotationRef property of TimestampAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setTimestampAnnotationAnnotationRef(const std::string& annotation, index_type timestampAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of TimestampAnnotation.
         *
         * @param annotator Annotator to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         */
        virtual void
        setTimestampAnnotationAnnotator(const std::string& annotator, index_type timestampAnnotationIndex) = 0;

        /**
         * Set the Description property of TimestampAnnotation.
         *
         * @param description Description to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         */
        virtual void
        setTimestampAnnotationDescription(const std::string& description, index_type timestampAnnotationIndex) = 0;

        /**
         * Set the ID property of TimestampAnnotation.
         *
         * @param id ID to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         */
        virtual void
        setTimestampAnnotationID(const std::string& id, index_type timestampAnnotationIndex) = 0;

        /**
         * Set the Namespace property of TimestampAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         */
        virtual void
        setTimestampAnnotationNamespace(const std::string& namespace_, index_type timestampAnnotationIndex) = 0;

        /**
         * Set the Value property of TimestampAnnotation.
         *
         * @param value Value to set.
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         */
        virtual void
        setTimestampAnnotationValue(ome::xml::model::primitives::Timestamp value, index_type timestampAnnotationIndex) = 0;

        /**
         * Set the CutIn property of TransmittanceRange.
         *
         * @param cutIn CutIn to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setTransmittanceRangeCutIn(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  cutIn, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the CutInTolerance property of TransmittanceRange.
         *
         * @param cutInTolerance CutInTolerance to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setTransmittanceRangeCutInTolerance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat >  cutInTolerance, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the CutOut property of TransmittanceRange.
         *
         * @param cutOut CutOut to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setTransmittanceRangeCutOut(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  cutOut, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the CutOutTolerance property of TransmittanceRange.
         *
         * @param cutOutTolerance CutOutTolerance to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setTransmittanceRangeCutOutTolerance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat >  cutOutTolerance, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the Transmittance property of TransmittanceRange.
         *
         * @param transmittance Transmittance to set.
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         */
        virtual void
        setTransmittanceRangeTransmittance(ome::xml::model::primitives::PercentFraction transmittance, index_type instrumentIndex, index_type filterIndex) = 0;

        /**
         * Set the text value of UUID.
         *
         * @param value text value.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setUUIDValue(std::string value, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the FileName property of UUID.
         *
         * @param fileName FileName to set.
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         */
        virtual void
        setUUIDFileName(const std::string& fileName, index_type imageIndex, index_type tiffDataIndex) = 0;

        /**
         * Set the AnnotationRef property of Well.
         *
         * @param annotation AnnotationRef to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setWellAnnotationRef(const std::string& annotation, index_type plateIndex, index_type wellIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Color property of Well.
         *
         * @param color Color to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellColor(ome::xml::model::primitives::Color color, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the Column property of Well.
         *
         * @param column Column to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellColumn(ome::xml::model::primitives::NonNegativeInteger column, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the ExternalDescription property of Well.
         *
         * @param externalDescription ExternalDescription to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellExternalDescription(const std::string& externalDescription, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the ExternalIdentifier property of Well.
         *
         * @param externalIdentifier ExternalIdentifier to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellExternalIdentifier(const std::string& externalIdentifier, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the ID property of Well.
         *
         * @param id ID to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellID(const std::string& id, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the ReagentRef property of Well.
         *
         * @param reagent ReagentRef to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellReagentRef(const std::string& reagent, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the Row property of Well.
         *
         * @param row Row to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellRow(ome::xml::model::primitives::NonNegativeInteger row, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the Type property of Well.
         *
         * @param type Type to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         */
        virtual void
        setWellType(const std::string& type, index_type plateIndex, index_type wellIndex) = 0;

        /**
         * Set the ID property of WellSample.
         *
         * @param id ID to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSampleID(const std::string& id, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the ImageRef property of WellSample.
         *
         * @param image ImageRef to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSampleImageRef(const std::string& image, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the Index property of WellSample.
         *
         * @param index Index to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSampleIndex(ome::xml::model::primitives::NonNegativeInteger index, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the PositionX property of WellSample.
         *
         * @param positionX PositionX to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSamplePositionX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionX, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the PositionY property of WellSample.
         *
         * @param positionY PositionY to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSamplePositionY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionY, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the Timepoint property of WellSample.
         *
         * @param timepoint Timepoint to set.
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         */
        virtual void
        setWellSampleTimepoint(ome::xml::model::primitives::Timestamp timepoint, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) = 0;

        /**
         * Set the AnnotationRef property of XMLAnnotation.
         *
         * @param annotation AnnotationRef to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @param annotationRefIndex AnnotationRef index (unused).
         */
        virtual void
        setXMLAnnotationAnnotationRef(const std::string& annotation, index_type XMLAnnotationIndex, index_type annotationRefIndex = 0) = 0;

        /**
         * Set the Annotator property of XMLAnnotation.
         *
         * @param annotator Annotator to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         */
        virtual void
        setXMLAnnotationAnnotator(const std::string& annotator, index_type XMLAnnotationIndex) = 0;

        /**
         * Set the Description property of XMLAnnotation.
         *
         * @param description Description to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         */
        virtual void
        setXMLAnnotationDescription(const std::string& description, index_type XMLAnnotationIndex) = 0;

        /**
         * Set the ID property of XMLAnnotation.
         *
         * @param id ID to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         */
        virtual void
        setXMLAnnotationID(const std::string& id, index_type XMLAnnotationIndex) = 0;

        /**
         * Set the Namespace property of XMLAnnotation.
         *
         * @param namespace_ Namespace to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         */
        virtual void
        setXMLAnnotationNamespace(const std::string& namespace_, index_type XMLAnnotationIndex) = 0;

        /**
         * Set the Value property of XMLAnnotation.
         *
         * @param value Value to set.
         * @param XMLAnnotationIndex the XMLAnnotation index.
         */
        virtual void
        setXMLAnnotationValue(const std::string& value, index_type XMLAnnotationIndex) = 0;

      };

    }
  }
}

#endif // OME_XML_META_METADATASTORE_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
