/*
 * #%L
 * OME-BIOFORMATS C++ library for image IO.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_META_AGGREGATEMETADATA_H
#define OME_XML_META_AGGREGATEMETADATA_H

#include <ome/xml/meta/BaseMetadata.h>
#include <ome/xml/meta/Metadata.h>
#include <ome/xml/meta/MetadataException.h>

namespace ome
{
  namespace xml
  {
    namespace meta
    {

      /**
       * Aggregating metadata store.
       *
       * An implementation of MetadataStore and MetadataRetreive which
       * delegates the storage and retrieval to one or more
       * sub-stores.
       */
      class AggregateMetadata : virtual public Metadata
      {
      public:
        /// A list of MetadataStore and MetadataRetrieve instances.
        typedef std::vector<std::shared_ptr<BaseMetadata>> delegate_list_type;

      private:
        /** The active metadata store delegates. */
        delegate_list_type delegates;

      public:
        /**
         * Constructor.
         *
         * @param delegates a list containing MetadataRetrieve and/or
         * MetadataStore instances.
         */
        AggregateMetadata(delegate_list_type& delegates);

        /// Destructor.
        virtual
        ~AggregateMetadata();

        // Documented in base class.
        void
        createRoot();

        /**
         * @copydoc MetadataStore::getRoot()
         * @note Unsupported by AggregateMetadata, which will throw an
         * exception if called.
         * @throws MetadataException always.
         */
        std::shared_ptr<MetadataRoot>
        getRoot();

        /**
         * @copydoc MetadataStore::setRoot()
         * @note Unsupported by AggregateMetadata, which will throw an
         * exception if called.
         * @throws MetadataException always.
         */
        void
        setRoot(std::shared_ptr<MetadataRoot> root);

        // Documented in base class.
        index_type
        getBooleanAnnotationAnnotationCount(index_type booleanAnnotationIndex) const;

        // Documented in base class.
        index_type
        getCommentAnnotationAnnotationCount(index_type commentAnnotationIndex) const;

        // Documented in base class.
        index_type
        getDoubleAnnotationAnnotationCount(index_type doubleAnnotationIndex) const;

        // Documented in base class.
        index_type
        getFileAnnotationAnnotationCount(index_type fileAnnotationIndex) const;

        // Documented in base class.
        index_type
        getListAnnotationAnnotationCount(index_type listAnnotationIndex) const;

        // Documented in base class.
        index_type
        getLongAnnotationAnnotationCount(index_type longAnnotationIndex) const;

        // Documented in base class.
        index_type
        getMapAnnotationAnnotationCount(index_type mapAnnotationIndex) const;

        // Documented in base class.
        index_type
        getTagAnnotationAnnotationCount(index_type tagAnnotationIndex) const;

        // Documented in base class.
        index_type
        getTermAnnotationAnnotationCount(index_type termAnnotationIndex) const;

        // Documented in base class.
        index_type
        getTimestampAnnotationAnnotationCount(index_type timestampAnnotationIndex) const;

        // Documented in base class.
        index_type
        getXMLAnnotationAnnotationCount(index_type xmlAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getLightSourceType(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        index_type
        getLightSourceCount(index_type instrumentIndex) const;
        // Documented in base class.
        const std::string&
        getShapeType(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        index_type
        getShapeCount(index_type ROIIndex) const;

        // Documented in base class.
        index_type
        getLightSourceAnnotationRefCount(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        index_type
        getInstrumentAnnotationRefCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getObjectiveAnnotationRefCount(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        index_type
        getFolderAnnotationRefCount(index_type folderIndex) const;

        // Documented in base class.
        index_type
        getDetectorAnnotationRefCount(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        index_type
        getChannelAnnotationRefCount(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        index_type
        getPlateAnnotationRefCount(index_type plateIndex) const;

        // Documented in base class.
        index_type
        getExperimenterGroupAnnotationRefCount(index_type experimenterGroupIndex) const;

        // Documented in base class.
        index_type
        getScreenAnnotationRefCount(index_type screenIndex) const;

        // Documented in base class.
        index_type
        getReagentAnnotationRefCount(index_type screenIndex, index_type reagentIndex) const;

        // Documented in base class.
        index_type
        getPlaneAnnotationRefCount(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        index_type
        getExperimenterAnnotationRefCount(index_type experimenterIndex) const;

        // Documented in base class.
        index_type
        getDichroicAnnotationRefCount(index_type instrumentIndex, index_type dichroicIndex) const;

        // Documented in base class.
        index_type
        getWellAnnotationRefCount(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        index_type
        getFilterAnnotationRefCount(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        index_type
        getPlateAcquisitionAnnotationRefCount(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        index_type
        getROIAnnotationRefCount(index_type ROIIndex) const;

        // Documented in base class.
        index_type
        getProjectAnnotationRefCount(index_type projectIndex) const;

        // Documented in base class.
        index_type
        getLightPathAnnotationRefCount(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        index_type
        getImageAnnotationRefCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getDatasetAnnotationRefCount(index_type datasetIndex) const;

        // Documented in base class.
        index_type
        getShapeAnnotationRefCount(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        index_type
        getPixelsBinDataCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getBooleanAnnotationCount() const;

        // Documented in base class.
        index_type
        getChannelCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getCommentAnnotationCount() const;

        // Documented in base class.
        index_type
        getDatasetCount() const;

        // Documented in base class.
        index_type
        getDatasetRefCount(index_type projectIndex) const;

        // Documented in base class.
        index_type
        getDetectorCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getDichroicCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getDoubleAnnotationCount() const;

        // Documented in base class.
        index_type
        getLightPathEmissionFilterRefCount(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        index_type
        getFilterSetEmissionFilterRefCount(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        index_type
        getLightPathExcitationFilterRefCount(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        index_type
        getFilterSetExcitationFilterRefCount(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        index_type
        getExperimentCount() const;

        // Documented in base class.
        index_type
        getExperimenterCount() const;

        // Documented in base class.
        index_type
        getExperimenterGroupCount() const;

        // Documented in base class.
        index_type
        getExperimenterGroupExperimenterRefCount(index_type experimenterGroupIndex) const;

        // Documented in base class.
        index_type
        getFileAnnotationCount() const;

        // Documented in base class.
        index_type
        getFilterCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getFilterSetCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getFolderCount() const;

        // Documented in base class.
        index_type
        getFolderRefCount(index_type folderIndex) const;

        // Documented in base class.
        index_type
        getImageCount() const;

        // Documented in base class.
        index_type
        getFolderImageRefCount(index_type folderIndex) const;

        // Documented in base class.
        index_type
        getDatasetImageRefCount(index_type datasetIndex) const;

        // Documented in base class.
        index_type
        getInstrumentCount() const;

        // Documented in base class.
        index_type
        getLeaderCount(index_type experimenterGroupIndex) const;

        // Documented in base class.
        index_type
        getMicrobeamManipulationLightSourceSettingsCount(index_type experimentIndex, index_type microbeamManipulationIndex) const;

        // Documented in base class.
        index_type
        getListAnnotationCount() const;

        // Documented in base class.
        index_type
        getLongAnnotationCount() const;

        // Documented in base class.
        index_type
        getMapAnnotationCount() const;

        // Documented in base class.
        index_type
        getMicrobeamManipulationCount(index_type experimentIndex) const;

        // Documented in base class.
        index_type
        getMicrobeamManipulationRefCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getObjectiveCount(index_type instrumentIndex) const;

        // Documented in base class.
        index_type
        getPlaneCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getPlateCount() const;

        // Documented in base class.
        index_type
        getPlateAcquisitionCount(index_type plateIndex) const;

        // Documented in base class.
        index_type
        getPlateRefCount(index_type screenIndex) const;

        // Documented in base class.
        index_type
        getProjectCount() const;

        // Documented in base class.
        index_type
        getROICount() const;

        // Documented in base class.
        index_type
        getImageROIRefCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getFolderROIRefCount(index_type folderIndex) const;

        // Documented in base class.
        index_type
        getMicrobeamManipulationROIRefCount(index_type experimentIndex, index_type microbeamManipulationIndex) const;

        // Documented in base class.
        index_type
        getReagentCount(index_type screenIndex) const;

        // Documented in base class.
        index_type
        getScreenCount() const;

        // Documented in base class.
        index_type
        getTagAnnotationCount() const;

        // Documented in base class.
        index_type
        getTermAnnotationCount() const;

        // Documented in base class.
        index_type
        getTiffDataCount(index_type imageIndex) const;

        // Documented in base class.
        index_type
        getTimestampAnnotationCount() const;

        // Documented in base class.
        void
        setUUIDValue(std::string value, index_type imageIndex, index_type tiffDataIndex);

        std::string
        getUUIDValue(index_type imageIndex, index_type tiffDataIndex) const;

        // Documented in base class.
        index_type
        getWellCount(index_type plateIndex) const;

        // Documented in base class.
        index_type
        getWellSampleCount(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        index_type
        getWellSampleRefCount(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        index_type
        getXMLAnnotationCount() const;


        // Documented in base class.
        const std::string&
        getUUID() const;

        // Documented in base class.
        const ome::xml::model::primitives::OrderedMultimap&
        getMapAnnotationValue(index_type mapAnnotationIndex) const;

        // Documented in base class.
        const ome::xml::model::primitives::OrderedMultimap&
        getGenericExcitationSourceMap(index_type instrumentIndex,
                                      index_type lightSourceIndex) const;

        // Documented in base class.
        const ome::xml::model::primitives::OrderedMultimap&
        getImagingEnvironmentMap(index_type imageIndex) const;



        // Documented in base class.
        const std::string&
        getArcAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getArcID(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getArcLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getArcManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getArcModel(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getArcPower(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getArcSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::enums::ArcType
        getArcType(index_type instrumentIndex, index_type lightSourceIndex) const;


        // Documented in base class.
        const std::vector<uint8_t>&
        getBinaryFileBinData(index_type fileAnnotationIndex) const;

        // Documented in base class.
        const std::vector<uint8_t>&
        getMaskBinData(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::vector<uint8_t>&
        getPixelsBinData(index_type imageIndex, index_type binDataIndex) const;

        // Documented in base class.
        bool
        getBinaryFileBinDataBigEndian(index_type fileAnnotationIndex) const;

        // Documented in base class.
        bool
        getMaskBinDataBigEndian(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getPixelsBinDataBigEndian(index_type imageIndex, index_type binDataIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Compression
        getBinaryFileBinDataCompression(index_type fileAnnotationIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Compression
        getMaskBinDataCompression(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Compression
        getPixelsBinDataCompression(index_type imageIndex, index_type binDataIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeLong
        getBinaryFileBinDataLength(index_type fileAnnotationIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeLong
        getMaskBinDataLength(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeLong
        getPixelsBinDataLength(index_type imageIndex, index_type binDataIndex) const;


        // Documented in base class.
        const std::string&
        getBinaryFileFileName(index_type fileAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getBinaryFileMIMEType(index_type fileAnnotationIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeLong
        getBinaryFileSize(index_type fileAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getBinaryOnlyMetadataFile() const;

        // Documented in base class.
        const std::string&
        getBinaryOnlyUUID() const;


        // Documented in base class.
        const std::string&
        getBooleanAnnotationAnnotationRef(index_type booleanAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getBooleanAnnotationAnnotator(index_type booleanAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getBooleanAnnotationDescription(index_type booleanAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getBooleanAnnotationID(index_type booleanAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getBooleanAnnotationNamespace(index_type booleanAnnotationIndex) const;

        // Documented in base class.
        bool
        getBooleanAnnotationValue(index_type booleanAnnotationIndex) const;


        // Documented in base class.
        ome::xml::model::enums::AcquisitionMode
        getChannelAcquisitionMode(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getChannelAnnotationRef(index_type imageIndex, index_type channelIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getChannelColor(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::enums::ContrastMethod
        getChannelContrastMethod(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelEmissionWavelength(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelExcitationWavelength(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getChannelFilterSetRef(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getChannelFluor(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getChannelID(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::enums::IlluminationType
        getChannelIlluminationType(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        double
        getChannelNDFilter(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getChannelName(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getChannelPinholeSize(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        int32_t
        getChannelPockelCellSetting(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getChannelSamplesPerPixel(index_type imageIndex, index_type channelIndex) const;


        // Documented in base class.
        const std::string&
        getCommentAnnotationAnnotationRef(index_type commentAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getCommentAnnotationAnnotator(index_type commentAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getCommentAnnotationDescription(index_type commentAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getCommentAnnotationID(index_type commentAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getCommentAnnotationNamespace(index_type commentAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getCommentAnnotationValue(index_type commentAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getDatasetAnnotationRef(index_type datasetIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetDescription(index_type datasetIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetExperimenterGroupRef(index_type datasetIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetExperimenterRef(index_type datasetIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetID(index_type datasetIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetImageRef(index_type datasetIndex, index_type imageRefIndex) const;

        // Documented in base class.
        const std::string&
        getDatasetName(index_type datasetIndex) const;



        // Documented in base class.
        double
        getDetectorAmplificationGain(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorAnnotationRef(index_type instrumentIndex, index_type detectorIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        double
        getDetectorGain(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorID(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorLotNumber(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorManufacturer(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorModel(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        double
        getDetectorOffset(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorSerialNumber(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        ome::xml::model::enums::DetectorType
        getDetectorType(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential > 
        getDetectorVoltage(index_type instrumentIndex, index_type detectorIndex) const;

        // Documented in base class.
        double
        getDetectorZoom(index_type instrumentIndex, index_type detectorIndex) const;


        // Documented in base class.
        ome::xml::model::enums::Binning
        getDetectorSettingsBinning(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        double
        getDetectorSettingsGain(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getDetectorSettingsID(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getDetectorSettingsIntegration(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        double
        getDetectorSettingsOffset(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > 
        getDetectorSettingsReadOutRate(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential > 
        getDetectorSettingsVoltage(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        double
        getDetectorSettingsZoom(index_type imageIndex, index_type channelIndex) const;


        // Documented in base class.
        const std::string&
        getDichroicAnnotationRef(index_type instrumentIndex, index_type dichroicIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getDichroicID(index_type instrumentIndex, index_type dichroicIndex) const;

        // Documented in base class.
        const std::string&
        getDichroicLotNumber(index_type instrumentIndex, index_type dichroicIndex) const;

        // Documented in base class.
        const std::string&
        getDichroicManufacturer(index_type instrumentIndex, index_type dichroicIndex) const;

        // Documented in base class.
        const std::string&
        getDichroicModel(index_type instrumentIndex, index_type dichroicIndex) const;

        // Documented in base class.
        const std::string&
        getDichroicSerialNumber(index_type instrumentIndex, index_type dichroicIndex) const;



        // Documented in base class.
        const std::string&
        getDoubleAnnotationAnnotationRef(index_type doubleAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getDoubleAnnotationAnnotator(index_type doubleAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getDoubleAnnotationDescription(index_type doubleAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getDoubleAnnotationID(index_type doubleAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getDoubleAnnotationNamespace(index_type doubleAnnotationIndex) const;

        // Documented in base class.
        double
        getDoubleAnnotationValue(index_type doubleAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getEllipseAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getEllipseFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getEllipseFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getEllipseFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getEllipseFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getEllipseFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getEllipseID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getEllipseLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getEllipseRadiusX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getEllipseRadiusY(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getEllipseStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getEllipseStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getEllipseStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getEllipseText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getEllipseTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getEllipseX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getEllipseY(index_type ROIIndex, index_type shapeIndex) const;




        // Documented in base class.
        const std::string&
        getExperimentDescription(index_type experimentIndex) const;

        // Documented in base class.
        const std::string&
        getExperimentExperimenterRef(index_type experimentIndex) const;

        // Documented in base class.
        const std::string&
        getExperimentID(index_type experimentIndex) const;

        // Documented in base class.
        ome::xml::model::enums::ExperimentType
        getExperimentType(index_type experimentIndex) const;



        // Documented in base class.
        const std::string&
        getExperimenterAnnotationRef(index_type experimenterIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterEmail(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterFirstName(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterID(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterInstitution(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterLastName(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterMiddleName(index_type experimenterIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterUserName(index_type experimenterIndex) const;


        // Documented in base class.
        const std::string&
        getExperimenterGroupAnnotationRef(index_type experimenterGroupIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterGroupDescription(index_type experimenterGroupIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterGroupExperimenterRef(index_type experimenterGroupIndex, index_type experimenterRefIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterGroupID(index_type experimenterGroupIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterGroupLeader(index_type experimenterGroupIndex, index_type leaderIndex) const;

        // Documented in base class.
        const std::string&
        getExperimenterGroupName(index_type experimenterGroupIndex) const;




        // Documented in base class.
        const std::string&
        getFilamentAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getFilamentID(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getFilamentLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getFilamentManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getFilamentModel(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getFilamentPower(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getFilamentSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FilamentType
        getFilamentType(index_type instrumentIndex, index_type lightSourceIndex) const;


        // Documented in base class.
        const std::string&
        getFileAnnotationAnnotationRef(index_type fileAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getFileAnnotationAnnotator(index_type fileAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getFileAnnotationDescription(index_type fileAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getFileAnnotationID(index_type fileAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getFileAnnotationNamespace(index_type fileAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getFilterAnnotationRef(index_type instrumentIndex, index_type filterIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getFilterFilterWheel(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        const std::string&
        getFilterID(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        const std::string&
        getFilterLotNumber(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        const std::string&
        getFilterManufacturer(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        const std::string&
        getFilterModel(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSerialNumber(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FilterType
        getFilterType(index_type instrumentIndex, index_type filterIndex) const;


        // Documented in base class.
        const std::string&
        getFilterSetDichroicRef(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetEmissionFilterRef(index_type instrumentIndex, index_type filterSetIndex, index_type emissionFilterRefIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetExcitationFilterRef(index_type instrumentIndex, index_type filterSetIndex, index_type excitationFilterRefIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetID(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetLotNumber(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetManufacturer(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetModel(index_type instrumentIndex, index_type filterSetIndex) const;

        // Documented in base class.
        const std::string&
        getFilterSetSerialNumber(index_type instrumentIndex, index_type filterSetIndex) const;



        // Documented in base class.
        const std::string&
        getFolderAnnotationRef(index_type folderIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getFolderDescription(index_type folderIndex) const;

        // Documented in base class.
        const std::string&
        getFolderFolderRef(index_type folderIndex, index_type folderRefIndex) const;

        // Documented in base class.
        const std::string&
        getFolderID(index_type folderIndex) const;

        // Documented in base class.
        const std::string&
        getFolderImageRef(index_type folderIndex, index_type imageRefIndex) const;

        // Documented in base class.
        const std::string&
        getFolderName(index_type folderIndex) const;

        // Documented in base class.
        const std::string&
        getFolderROIRef(index_type folderIndex, index_type ROIRefIndex) const;



        // Documented in base class.
        const std::string&
        getGenericExcitationSourceAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getGenericExcitationSourceID(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getGenericExcitationSourceLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getGenericExcitationSourceManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getGenericExcitationSourceModel(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getGenericExcitationSourcePower(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getGenericExcitationSourceSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const;


        // Documented in base class.
        ome::xml::model::primitives::Timestamp
        getImageAcquisitionDate(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageAnnotationRef(index_type imageIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getImageDescription(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageExperimentRef(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageExperimenterGroupRef(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageExperimenterRef(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageID(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageInstrumentRef(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageMicrobeamManipulationRef(index_type imageIndex, index_type microbeamManipulationRefIndex) const;

        // Documented in base class.
        const std::string&
        getImageName(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getImageROIRef(index_type imageIndex, index_type ROIRefIndex) const;



        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure > 
        getImagingEnvironmentAirPressure(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PercentFraction
        getImagingEnvironmentCO2Percent(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PercentFraction
        getImagingEnvironmentHumidity(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature > 
        getImagingEnvironmentTemperature(index_type imageIndex) const;


        // Documented in base class.
        const std::string&
        getInstrumentAnnotationRef(index_type instrumentIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getInstrumentID(index_type instrumentIndex) const;



        // Documented in base class.
        const std::string&
        getLabelAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getLabelFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getLabelFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getLabelFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getLabelFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getLabelFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLabelID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getLabelLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getLabelStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLabelStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getLabelStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLabelText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLabelTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLabelTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLabelTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getLabelTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLabelX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLabelY(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getLaserAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getLaserFrequencyMultiplication(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserID(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::enums::LaserMedium
        getLaserLaserMedium(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserModel(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        bool
        getLaserPockelCell(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getLaserPower(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Pulse
        getLaserPulse(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserPump(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > 
        getLaserRepetitionRate(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLaserSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        bool
        getLaserTuneable(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::enums::LaserType
        getLaserType(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getLaserWavelength(index_type instrumentIndex, index_type lightSourceIndex) const;



        // Documented in base class.
        const std::string&
        getLightEmittingDiodeAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getLightEmittingDiodeID(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLightEmittingDiodeLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLightEmittingDiodeManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLightEmittingDiodeModel(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getLightEmittingDiodePower(index_type instrumentIndex, index_type lightSourceIndex) const;

        // Documented in base class.
        const std::string&
        getLightEmittingDiodeSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const;


        // Documented in base class.
        const std::string&
        getLightPathAnnotationRef(index_type imageIndex, index_type channelIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getLightPathDichroicRef(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getLightPathEmissionFilterRef(index_type imageIndex, index_type channelIndex, index_type emissionFilterRefIndex) const;

        // Documented in base class.
        const std::string&
        getLightPathExcitationFilterRef(index_type imageIndex, index_type channelIndex, index_type excitationFilterRefIndex) const;


        // Documented in base class.
        ome::xml::model::primitives::PercentFraction
        getChannelLightSourceSettingsAttenuation(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PercentFraction
        getMicrobeamManipulationLightSourceSettingsAttenuation(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const;

        // Documented in base class.
        const std::string&
        getChannelLightSourceSettingsID(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        const std::string&
        getMicrobeamManipulationLightSourceSettingsID(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelLightSourceSettingsWavelength(index_type imageIndex, index_type channelIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getMicrobeamManipulationLightSourceSettingsWavelength(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const;


        // Documented in base class.
        const std::string&
        getLineAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getLineFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getLineFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getLineFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getLineFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getLineFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLineID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getLineLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Marker
        getLineMarkerEnd(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Marker
        getLineMarkerStart(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getLineStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLineStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getLineStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getLineText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLineTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLineTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getLineTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getLineTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLineX1(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLineX2(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLineY1(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getLineY2(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getListAnnotationAnnotationRef(index_type listAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getListAnnotationAnnotator(index_type listAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getListAnnotationDescription(index_type listAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getListAnnotationID(index_type listAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getListAnnotationNamespace(index_type listAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getLongAnnotationAnnotationRef(index_type longAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getLongAnnotationAnnotator(index_type longAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getLongAnnotationDescription(index_type longAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getLongAnnotationID(index_type longAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getLongAnnotationNamespace(index_type longAnnotationIndex) const;

        // Documented in base class.
        int64_t
        getLongAnnotationValue(index_type longAnnotationIndex) const;



        // Documented in base class.
        const std::string&
        getMapAnnotationAnnotationRef(index_type mapAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getMapAnnotationAnnotator(index_type mapAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getMapAnnotationDescription(index_type mapAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getMapAnnotationID(index_type mapAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getMapAnnotationNamespace(index_type mapAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getMaskAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getMaskFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getMaskFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getMaskFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getMaskFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getMaskFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getMaskHeight(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getMaskID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getMaskLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getMaskStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getMaskStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getMaskStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getMaskText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getMaskTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getMaskTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getMaskTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getMaskTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getMaskWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getMaskX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getMaskY(index_type ROIIndex, index_type shapeIndex) const;



        // Documented in base class.
        const std::string&
        getMicrobeamManipulationDescription(index_type experimentIndex, index_type microbeamManipulationIndex) const;

        // Documented in base class.
        const std::string&
        getMicrobeamManipulationExperimenterRef(index_type experimentIndex, index_type microbeamManipulationIndex) const;

        // Documented in base class.
        const std::string&
        getMicrobeamManipulationID(index_type experimentIndex, index_type microbeamManipulationIndex) const;

        // Documented in base class.
        const std::string&
        getMicrobeamManipulationROIRef(index_type experimentIndex, index_type microbeamManipulationIndex, index_type ROIRefIndex) const;

        // Documented in base class.
        ome::xml::model::enums::MicrobeamManipulationType
        getMicrobeamManipulationType(index_type experimentIndex, index_type microbeamManipulationIndex) const;



        // Documented in base class.
        const std::string&
        getMicroscopeLotNumber(index_type instrumentIndex) const;

        // Documented in base class.
        const std::string&
        getMicroscopeManufacturer(index_type instrumentIndex) const;

        // Documented in base class.
        const std::string&
        getMicroscopeModel(index_type instrumentIndex) const;

        // Documented in base class.
        const std::string&
        getMicroscopeSerialNumber(index_type instrumentIndex) const;

        // Documented in base class.
        ome::xml::model::enums::MicroscopeType
        getMicroscopeType(index_type instrumentIndex) const;


        // Documented in base class.
        const std::string&
        getObjectiveAnnotationRef(index_type instrumentIndex, index_type objectiveIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        double
        getObjectiveCalibratedMagnification(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Correction
        getObjectiveCorrection(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveID(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Immersion
        getObjectiveImmersion(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        bool
        getObjectiveIris(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        double
        getObjectiveLensNA(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveLotNumber(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveManufacturer(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveModel(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        double
        getObjectiveNominalMagnification(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveSerialNumber(index_type instrumentIndex, index_type objectiveIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getObjectiveWorkingDistance(index_type instrumentIndex, index_type objectiveIndex) const;


        // Documented in base class.
        double
        getObjectiveSettingsCorrectionCollar(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getObjectiveSettingsID(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Medium
        getObjectiveSettingsMedium(index_type imageIndex) const;

        // Documented in base class.
        double
        getObjectiveSettingsRefractiveIndex(index_type imageIndex) const;


        // Documented in base class.
        bool
        getPixelsBigEndian(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::enums::DimensionOrder
        getPixelsDimensionOrder(index_type imageIndex) const;

        // Documented in base class.
        const std::string&
        getPixelsID(index_type imageIndex) const;

        // Documented in base class.
        bool
        getPixelsInterleaved(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeX(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeY(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeZ(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSignificantBits(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSizeC(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSizeT(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSizeX(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSizeY(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPixelsSizeZ(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPixelsTimeIncrement(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::enums::PixelType
        getPixelsType(index_type imageIndex) const;


        // Documented in base class.
        const std::string&
        getPlaneAnnotationRef(index_type imageIndex, index_type planeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPlaneDeltaT(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPlaneExposureTime(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        const std::string&
        getPlaneHashSHA1(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionX(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionY(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionZ(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheC(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheT(index_type imageIndex, index_type planeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheZ(index_type imageIndex, index_type planeIndex) const;


        // Documented in base class.
        const std::string&
        getPlateAnnotationRef(index_type plateIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::enums::NamingConvention
        getPlateColumnNamingConvention(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPlateColumns(index_type plateIndex) const;

        // Documented in base class.
        const std::string&
        getPlateDescription(index_type plateIndex) const;

        // Documented in base class.
        const std::string&
        getPlateExternalIdentifier(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPlateFieldIndex(index_type plateIndex) const;

        // Documented in base class.
        const std::string&
        getPlateID(index_type plateIndex) const;

        // Documented in base class.
        const std::string&
        getPlateName(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::enums::NamingConvention
        getPlateRowNamingConvention(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPlateRows(index_type plateIndex) const;

        // Documented in base class.
        const std::string&
        getPlateStatus(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlateWellOriginX(index_type plateIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlateWellOriginY(index_type plateIndex) const;


        // Documented in base class.
        const std::string&
        getPlateAcquisitionAnnotationRef(index_type plateIndex, index_type plateAcquisitionIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getPlateAcquisitionDescription(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Timestamp
        getPlateAcquisitionEndTime(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        const std::string&
        getPlateAcquisitionID(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PositiveInteger
        getPlateAcquisitionMaximumFieldCount(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        const std::string&
        getPlateAcquisitionName(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Timestamp
        getPlateAcquisitionStartTime(index_type plateIndex, index_type plateAcquisitionIndex) const;

        // Documented in base class.
        const std::string&
        getPlateAcquisitionWellSampleRef(index_type plateIndex, index_type plateAcquisitionIndex, index_type wellSampleRefIndex) const;



        // Documented in base class.
        const std::string&
        getPointAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPointFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getPointFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getPointFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPointFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getPointFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPointID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getPointLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPointStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPointStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPointStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPointText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPointTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPointTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPointTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getPointTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getPointX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getPointY(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getPolygonAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPolygonFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getPolygonFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getPolygonFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPolygonFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getPolygonFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolygonID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getPolygonLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolygonPoints(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPolygonStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolygonStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPolygonStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolygonText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getPolygonTransform(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getPolylineAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPolylineFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getPolylineFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getPolylineFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPolylineFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getPolylineFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolylineID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getPolylineLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Marker
        getPolylineMarkerEnd(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::Marker
        getPolylineMarkerStart(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolylinePoints(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getPolylineStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolylineStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPolylineStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getPolylineText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getPolylineTransform(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getProjectAnnotationRef(index_type projectIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getProjectDatasetRef(index_type projectIndex, index_type datasetRefIndex) const;

        // Documented in base class.
        const std::string&
        getProjectDescription(index_type projectIndex) const;

        // Documented in base class.
        const std::string&
        getProjectExperimenterGroupRef(index_type projectIndex) const;

        // Documented in base class.
        const std::string&
        getProjectExperimenterRef(index_type projectIndex) const;

        // Documented in base class.
        const std::string&
        getProjectID(index_type projectIndex) const;

        // Documented in base class.
        const std::string&
        getProjectName(index_type projectIndex) const;



        // Documented in base class.
        const std::string&
        getROIAnnotationRef(index_type ROIIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getROIDescription(index_type ROIIndex) const;

        // Documented in base class.
        const std::string&
        getROIID(index_type ROIIndex) const;

        // Documented in base class.
        const std::string&
        getROIName(index_type ROIIndex) const;



        // Documented in base class.
        const std::string&
        getReagentAnnotationRef(index_type screenIndex, index_type reagentIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getReagentDescription(index_type screenIndex, index_type reagentIndex) const;

        // Documented in base class.
        const std::string&
        getReagentID(index_type screenIndex, index_type reagentIndex) const;

        // Documented in base class.
        const std::string&
        getReagentName(index_type screenIndex, index_type reagentIndex) const;

        // Documented in base class.
        const std::string&
        getReagentReagentIdentifier(index_type screenIndex, index_type reagentIndex) const;



        // Documented in base class.
        const std::string&
        getRectangleAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getRectangleFillColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FillRule
        getRectangleFillRule(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontFamily
        getRectangleFontFamily(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getRectangleFontSize(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::enums::FontStyle
        getRectangleFontStyle(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getRectangleHeight(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getRectangleID(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        bool
        getRectangleLocked(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getRectangleStrokeColor(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getRectangleStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getRectangleStrokeWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const std::string&
        getRectangleText(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheC(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheT(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheZ(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        const ::ome::xml::model::AffineTransform&
        getRectangleTransform(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getRectangleWidth(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getRectangleX(index_type ROIIndex, index_type shapeIndex) const;

        // Documented in base class.
        double
        getRectangleY(index_type ROIIndex, index_type shapeIndex) const;


        // Documented in base class.
        const std::string&
        getRightsRightsHeld() const;

        // Documented in base class.
        const std::string&
        getRightsRightsHolder() const;


        // Documented in base class.
        const std::string&
        getScreenAnnotationRef(index_type screenIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getScreenDescription(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenID(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenName(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenPlateRef(index_type screenIndex, index_type plateRefIndex) const;

        // Documented in base class.
        const std::string&
        getScreenProtocolDescription(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenProtocolIdentifier(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenReagentSetDescription(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenReagentSetIdentifier(index_type screenIndex) const;

        // Documented in base class.
        const std::string&
        getScreenType(index_type screenIndex) const;


        // Documented in base class.
        const std::string&
        getStageLabelName(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelX(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelY(index_type imageIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelZ(index_type imageIndex) const;



        // Documented in base class.
        const std::string&
        getTagAnnotationAnnotationRef(index_type tagAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getTagAnnotationAnnotator(index_type tagAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTagAnnotationDescription(index_type tagAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTagAnnotationID(index_type tagAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTagAnnotationNamespace(index_type tagAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTagAnnotationValue(index_type tagAnnotationIndex) const;


        // Documented in base class.
        const std::string&
        getTermAnnotationAnnotationRef(index_type termAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getTermAnnotationAnnotator(index_type termAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTermAnnotationDescription(index_type termAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTermAnnotationID(index_type termAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTermAnnotationNamespace(index_type termAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTermAnnotationValue(index_type termAnnotationIndex) const;


        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstC(index_type imageIndex, index_type tiffDataIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstT(index_type imageIndex, index_type tiffDataIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstZ(index_type imageIndex, index_type tiffDataIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getTiffDataIFD(index_type imageIndex, index_type tiffDataIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getTiffDataPlaneCount(index_type imageIndex, index_type tiffDataIndex) const;


        // Documented in base class.
        const std::string&
        getTimestampAnnotationAnnotationRef(index_type timestampAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getTimestampAnnotationAnnotator(index_type timestampAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTimestampAnnotationDescription(index_type timestampAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTimestampAnnotationID(index_type timestampAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getTimestampAnnotationNamespace(index_type timestampAnnotationIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Timestamp
        getTimestampAnnotationValue(index_type timestampAnnotationIndex) const;


        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getTransmittanceRangeCutIn(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat > 
        getTransmittanceRangeCutInTolerance(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getTransmittanceRangeCutOut(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat > 
        getTransmittanceRangeCutOutTolerance(index_type instrumentIndex, index_type filterIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::PercentFraction
        getTransmittanceRangeTransmittance(index_type instrumentIndex, index_type filterIndex) const;


        // Documented in base class.
        const std::string&
        getUUIDFileName(index_type imageIndex, index_type tiffDataIndex) const;



        // Documented in base class.
        const std::string&
        getWellAnnotationRef(index_type plateIndex, index_type wellIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Color
        getWellColor(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getWellColumn(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        const std::string&
        getWellExternalDescription(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        const std::string&
        getWellExternalIdentifier(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        const std::string&
        getWellID(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        const std::string&
        getWellReagentRef(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getWellRow(index_type plateIndex, index_type wellIndex) const;

        // Documented in base class.
        const std::string&
        getWellType(index_type plateIndex, index_type wellIndex) const;


        // Documented in base class.
        const std::string&
        getWellSampleID(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;

        // Documented in base class.
        const std::string&
        getWellSampleImageRef(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::NonNegativeInteger
        getWellSampleIndex(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getWellSamplePositionX(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getWellSamplePositionY(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;

        // Documented in base class.
        ome::xml::model::primitives::Timestamp
        getWellSampleTimepoint(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const;



        // Documented in base class.
        const std::string&
        getXMLAnnotationAnnotationRef(index_type XMLAnnotationIndex, index_type annotationRefIndex) const;

        // Documented in base class.
        const std::string&
        getXMLAnnotationAnnotator(index_type XMLAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getXMLAnnotationDescription(index_type XMLAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getXMLAnnotationID(index_type XMLAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getXMLAnnotationNamespace(index_type XMLAnnotationIndex) const;

        // Documented in base class.
        const std::string&
        getXMLAnnotationValue(index_type XMLAnnotationIndex) const;


        // Documented in base class.
        void
        setUUID(const std::string& uuid);

        // Documented in base class.
        void
        setMapAnnotationValue(const ome::xml::model::primitives::OrderedMultimap& value,
                              index_type                                          mapAnnotationIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceMap(const ome::xml::model::primitives::OrderedMultimap& value,
                                      index_type                                          instrumentIndex,
                                      index_type                                          lightSourceIndex);

        // Documented in base class.
        void
        setImagingEnvironmentMap(const ome::xml::model::primitives::OrderedMultimap& value,
                                 index_type                                          imageIndex);



        // Documented in base class.
        void
        setArcAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setArcID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setArcType(ome::xml::model::enums::ArcType type, index_type instrumentIndex, index_type lightSourceIndex);


        // Documented in base class.
        void
        setBinaryFileBinData(const std::vector<uint8_t>& base64Binary, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setMaskBinData(const std::vector<uint8_t>& base64Binary, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPixelsBinData(const std::vector<uint8_t>& base64Binary, index_type imageIndex, index_type binDataIndex);

        // Documented in base class.
        void
        setBinaryFileBinDataBigEndian(bool bigEndian, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setMaskBinDataBigEndian(bool bigEndian, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPixelsBinDataBigEndian(bool bigEndian, index_type imageIndex, index_type binDataIndex);

        // Documented in base class.
        void
        setBinaryFileBinDataCompression(ome::xml::model::enums::Compression compression, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setMaskBinDataCompression(ome::xml::model::enums::Compression compression, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPixelsBinDataCompression(ome::xml::model::enums::Compression compression, index_type imageIndex, index_type binDataIndex);

        // Documented in base class.
        void
        setBinaryFileBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setMaskBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPixelsBinDataLength(ome::xml::model::primitives::NonNegativeLong length, index_type imageIndex, index_type binDataIndex);


        // Documented in base class.
        void
        setBinaryFileFileName(const std::string& fileName, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setBinaryFileMIMEType(const std::string& mimeType, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setBinaryFileSize(ome::xml::model::primitives::NonNegativeLong size, index_type fileAnnotationIndex);


        // Documented in base class.
        void
        setBinaryOnlyMetadataFile(const std::string& metadataFile);

        // Documented in base class.
        void
        setBinaryOnlyUUID(const std::string& uuid);


        // Documented in base class.
        void
        setBooleanAnnotationAnnotationRef(const std::string& annotation, index_type booleanAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setBooleanAnnotationAnnotator(const std::string& annotator, index_type booleanAnnotationIndex);

        // Documented in base class.
        void
        setBooleanAnnotationDescription(const std::string& description, index_type booleanAnnotationIndex);

        // Documented in base class.
        void
        setBooleanAnnotationID(const std::string& id, index_type booleanAnnotationIndex);

        // Documented in base class.
        void
        setBooleanAnnotationNamespace(const std::string& namespace_, index_type booleanAnnotationIndex);

        // Documented in base class.
        void
        setBooleanAnnotationValue(bool value, index_type booleanAnnotationIndex);


        // Documented in base class.
        void
        setChannelAcquisitionMode(ome::xml::model::enums::AcquisitionMode acquisitionMode, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelAnnotationRef(const std::string& annotation, index_type imageIndex, index_type channelIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setChannelColor(ome::xml::model::primitives::Color color, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelContrastMethod(ome::xml::model::enums::ContrastMethod contrastMethod, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelEmissionWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  emissionWavelength, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelExcitationWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  excitationWavelength, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelFilterSetRef(const std::string& filterSet, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelFluor(const std::string& fluor, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelID(const std::string& id, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelIlluminationType(ome::xml::model::enums::IlluminationType illuminationType, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelNDFilter(double ndFilter, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelName(const std::string& name, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelPinholeSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  pinholeSize, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelPockelCellSetting(int32_t pockelCellSetting, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setChannelSamplesPerPixel(ome::xml::model::primitives::PositiveInteger samplesPerPixel, index_type imageIndex, index_type channelIndex);


        // Documented in base class.
        void
        setCommentAnnotationAnnotationRef(const std::string& annotation, index_type commentAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setCommentAnnotationAnnotator(const std::string& annotator, index_type commentAnnotationIndex);

        // Documented in base class.
        void
        setCommentAnnotationDescription(const std::string& description, index_type commentAnnotationIndex);

        // Documented in base class.
        void
        setCommentAnnotationID(const std::string& id, index_type commentAnnotationIndex);

        // Documented in base class.
        void
        setCommentAnnotationNamespace(const std::string& namespace_, index_type commentAnnotationIndex);

        // Documented in base class.
        void
        setCommentAnnotationValue(const std::string& value, index_type commentAnnotationIndex);


        // Documented in base class.
        void
        setDatasetAnnotationRef(const std::string& annotation, index_type datasetIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setDatasetDescription(const std::string& description, index_type datasetIndex);

        // Documented in base class.
        void
        setDatasetExperimenterGroupRef(const std::string& experimenterGroup, index_type datasetIndex);

        // Documented in base class.
        void
        setDatasetExperimenterRef(const std::string& experimenter, index_type datasetIndex);

        // Documented in base class.
        void
        setDatasetID(const std::string& id, index_type datasetIndex);

        // Documented in base class.
        void
        setDatasetImageRef(const std::string& image, index_type datasetIndex, index_type imageRefIndex);

        // Documented in base class.
        void
        setDatasetName(const std::string& name, index_type datasetIndex);



        // Documented in base class.
        void
        setDetectorAmplificationGain(double amplificationGain, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type detectorIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setDetectorGain(double gain, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorID(const std::string& id, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorModel(const std::string& model, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorOffset(double offset, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorType(ome::xml::model::enums::DetectorType type, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorVoltage(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential >  voltage, index_type instrumentIndex, index_type detectorIndex);

        // Documented in base class.
        void
        setDetectorZoom(double zoom, index_type instrumentIndex, index_type detectorIndex);


        // Documented in base class.
        void
        setDetectorSettingsBinning(ome::xml::model::enums::Binning binning, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsGain(double gain, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsID(const std::string& id, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsIntegration(ome::xml::model::primitives::PositiveInteger integration, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsOffset(double offset, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsReadOutRate(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency >  readOutRate, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsVoltage(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential >  voltage, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setDetectorSettingsZoom(double zoom, index_type imageIndex, index_type channelIndex);


        // Documented in base class.
        void
        setDichroicAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type dichroicIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setDichroicID(const std::string& id, index_type instrumentIndex, index_type dichroicIndex);

        // Documented in base class.
        void
        setDichroicLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type dichroicIndex);

        // Documented in base class.
        void
        setDichroicManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type dichroicIndex);

        // Documented in base class.
        void
        setDichroicModel(const std::string& model, index_type instrumentIndex, index_type dichroicIndex);

        // Documented in base class.
        void
        setDichroicSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type dichroicIndex);



        // Documented in base class.
        void
        setDoubleAnnotationAnnotationRef(const std::string& annotation, index_type doubleAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setDoubleAnnotationAnnotator(const std::string& annotator, index_type doubleAnnotationIndex);

        // Documented in base class.
        void
        setDoubleAnnotationDescription(const std::string& description, index_type doubleAnnotationIndex);

        // Documented in base class.
        void
        setDoubleAnnotationID(const std::string& id, index_type doubleAnnotationIndex);

        // Documented in base class.
        void
        setDoubleAnnotationNamespace(const std::string& namespace_, index_type doubleAnnotationIndex);

        // Documented in base class.
        void
        setDoubleAnnotationValue(double value, index_type doubleAnnotationIndex);


        // Documented in base class.
        void
        setEllipseAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setEllipseFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseRadiusX(double radiusX, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseRadiusY(double radiusY, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseX(double x, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setEllipseY(double y, index_type ROIIndex, index_type shapeIndex);




        // Documented in base class.
        void
        setExperimentDescription(const std::string& description, index_type experimentIndex);

        // Documented in base class.
        void
        setExperimentExperimenterRef(const std::string& experimenter, index_type experimentIndex);

        // Documented in base class.
        void
        setExperimentID(const std::string& id, index_type experimentIndex);

        // Documented in base class.
        void
        setExperimentType(ome::xml::model::enums::ExperimentType type, index_type experimentIndex);



        // Documented in base class.
        void
        setExperimenterAnnotationRef(const std::string& annotation, index_type experimenterIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setExperimenterEmail(const std::string& email, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterFirstName(const std::string& firstName, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterID(const std::string& id, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterInstitution(const std::string& institution, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterLastName(const std::string& lastName, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterMiddleName(const std::string& middleName, index_type experimenterIndex);

        // Documented in base class.
        void
        setExperimenterUserName(const std::string& userName, index_type experimenterIndex);


        // Documented in base class.
        void
        setExperimenterGroupAnnotationRef(const std::string& annotation, index_type experimenterGroupIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setExperimenterGroupDescription(const std::string& description, index_type experimenterGroupIndex);

        // Documented in base class.
        void
        setExperimenterGroupExperimenterRef(const std::string& experimenter, index_type experimenterGroupIndex, index_type experimenterRefIndex);

        // Documented in base class.
        void
        setExperimenterGroupID(const std::string& id, index_type experimenterGroupIndex);

        // Documented in base class.
        void
        setExperimenterGroupLeader(const std::string& leader, index_type experimenterGroupIndex, index_type leaderIndex);

        // Documented in base class.
        void
        setExperimenterGroupName(const std::string& name, index_type experimenterGroupIndex);




        // Documented in base class.
        void
        setFilamentAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setFilamentID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setFilamentType(ome::xml::model::enums::FilamentType type, index_type instrumentIndex, index_type lightSourceIndex);


        // Documented in base class.
        void
        setFileAnnotationAnnotationRef(const std::string& annotation, index_type fileAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setFileAnnotationAnnotator(const std::string& annotator, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setFileAnnotationDescription(const std::string& description, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setFileAnnotationID(const std::string& id, index_type fileAnnotationIndex);

        // Documented in base class.
        void
        setFileAnnotationNamespace(const std::string& namespace_, index_type fileAnnotationIndex);


        // Documented in base class.
        void
        setFilterAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type filterIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setFilterFilterWheel(const std::string& filterWheel, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterID(const std::string& id, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterModel(const std::string& model, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setFilterType(ome::xml::model::enums::FilterType type, index_type instrumentIndex, index_type filterIndex);


        // Documented in base class.
        void
        setFilterSetDichroicRef(const std::string& dichroic, index_type instrumentIndex, index_type filterSetIndex);

        // Documented in base class.
        void
        setFilterSetEmissionFilterRef(const std::string& emissionFilter, index_type instrumentIndex, index_type filterSetIndex, index_type emissionFilterRefIndex);

        // Documented in base class.
        void
        setFilterSetExcitationFilterRef(const std::string& excitationFilter, index_type instrumentIndex, index_type filterSetIndex, index_type excitationFilterRefIndex);

        // Documented in base class.
        void
        setFilterSetID(const std::string& id, index_type instrumentIndex, index_type filterSetIndex);

        // Documented in base class.
        void
        setFilterSetLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type filterSetIndex);

        // Documented in base class.
        void
        setFilterSetManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type filterSetIndex);

        // Documented in base class.
        void
        setFilterSetModel(const std::string& model, index_type instrumentIndex, index_type filterSetIndex);

        // Documented in base class.
        void
        setFilterSetSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type filterSetIndex);



        // Documented in base class.
        void
        setFolderAnnotationRef(const std::string& annotation, index_type folderIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setFolderDescription(const std::string& description, index_type folderIndex);

        // Documented in base class.
        void
        setFolderFolderRef(const std::string& folder, index_type folderIndex, index_type folderRefIndex);

        // Documented in base class.
        void
        setFolderID(const std::string& id, index_type folderIndex);

        // Documented in base class.
        void
        setFolderImageRef(const std::string& image, index_type folderIndex, index_type imageRefIndex);

        // Documented in base class.
        void
        setFolderName(const std::string& name, index_type folderIndex);

        // Documented in base class.
        void
        setFolderROIRef(const std::string& roi, index_type folderIndex, index_type ROIRefIndex);



        // Documented in base class.
        void
        setGenericExcitationSourceAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setGenericExcitationSourcePower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setGenericExcitationSourceSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex);


        // Documented in base class.
        void
        setImageAcquisitionDate(ome::xml::model::primitives::Timestamp acquisitionDate, index_type imageIndex);

        // Documented in base class.
        void
        setImageAnnotationRef(const std::string& annotation, index_type imageIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setImageDescription(const std::string& description, index_type imageIndex);

        // Documented in base class.
        void
        setImageExperimentRef(const std::string& experiment, index_type imageIndex);

        // Documented in base class.
        void
        setImageExperimenterGroupRef(const std::string& experimenterGroup, index_type imageIndex);

        // Documented in base class.
        void
        setImageExperimenterRef(const std::string& experimenter, index_type imageIndex);

        // Documented in base class.
        void
        setImageID(const std::string& id, index_type imageIndex);

        // Documented in base class.
        void
        setImageInstrumentRef(const std::string& instrument, index_type imageIndex);

        // Documented in base class.
        void
        setImageMicrobeamManipulationRef(const std::string& microbeamManipulation, index_type imageIndex, index_type microbeamManipulationRefIndex);

        // Documented in base class.
        void
        setImageName(const std::string& name, index_type imageIndex);

        // Documented in base class.
        void
        setImageROIRef(const std::string& roi, index_type imageIndex, index_type ROIRefIndex);



        // Documented in base class.
        void
        setImagingEnvironmentAirPressure(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure >  airPressure, index_type imageIndex);

        // Documented in base class.
        void
        setImagingEnvironmentCO2Percent(ome::xml::model::primitives::PercentFraction co2Percent, index_type imageIndex);

        // Documented in base class.
        void
        setImagingEnvironmentHumidity(ome::xml::model::primitives::PercentFraction humidity, index_type imageIndex);

        // Documented in base class.
        void
        setImagingEnvironmentTemperature(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature >  temperature, index_type imageIndex);


        // Documented in base class.
        void
        setInstrumentAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setInstrumentID(const std::string& id, index_type instrumentIndex);



        // Documented in base class.
        void
        setLabelAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLabelFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelX(double x, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLabelY(double y, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setLaserAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLaserFrequencyMultiplication(ome::xml::model::primitives::PositiveInteger frequencyMultiplication, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserLaserMedium(ome::xml::model::enums::LaserMedium laserMedium, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserPockelCell(bool pockelCell, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserPower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserPulse(ome::xml::model::enums::Pulse pulse, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserPump(const std::string& pump, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserRepetitionRate(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency >  repetitionRate, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserTuneable(bool tuneable, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserType(ome::xml::model::enums::LaserType type, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLaserWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type instrumentIndex, index_type lightSourceIndex);



        // Documented in base class.
        void
        setLightEmittingDiodeAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLightEmittingDiodeID(const std::string& id, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLightEmittingDiodeLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLightEmittingDiodeManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLightEmittingDiodeModel(const std::string& model, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLightEmittingDiodePower(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower >  power, index_type instrumentIndex, index_type lightSourceIndex);

        // Documented in base class.
        void
        setLightEmittingDiodeSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type lightSourceIndex);


        // Documented in base class.
        void
        setLightPathAnnotationRef(const std::string& annotation, index_type imageIndex, index_type channelIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLightPathDichroicRef(const std::string& dichroic, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setLightPathEmissionFilterRef(const std::string& emissionFilter, index_type imageIndex, index_type channelIndex, index_type emissionFilterRefIndex);

        // Documented in base class.
        void
        setLightPathExcitationFilterRef(const std::string& excitationFilter, index_type imageIndex, index_type channelIndex, index_type excitationFilterRefIndex);


        // Documented in base class.
        void
        setChannelLightSourceSettingsAttenuation(ome::xml::model::primitives::PercentFraction attenuation, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationLightSourceSettingsAttenuation(ome::xml::model::primitives::PercentFraction attenuation, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex);

        // Documented in base class.
        void
        setChannelLightSourceSettingsID(const std::string& id, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationLightSourceSettingsID(const std::string& id, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex);

        // Documented in base class.
        void
        setChannelLightSourceSettingsWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type imageIndex, index_type channelIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationLightSourceSettingsWavelength(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  wavelength, index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex);


        // Documented in base class.
        void
        setLineAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLineFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineMarkerEnd(ome::xml::model::enums::Marker markerEnd, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineMarkerStart(ome::xml::model::enums::Marker markerStart, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineX1(double x1, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineX2(double x2, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineY1(double y1, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setLineY2(double y2, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setListAnnotationAnnotationRef(const std::string& annotation, index_type listAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setListAnnotationAnnotator(const std::string& annotator, index_type listAnnotationIndex);

        // Documented in base class.
        void
        setListAnnotationDescription(const std::string& description, index_type listAnnotationIndex);

        // Documented in base class.
        void
        setListAnnotationID(const std::string& id, index_type listAnnotationIndex);

        // Documented in base class.
        void
        setListAnnotationNamespace(const std::string& namespace_, index_type listAnnotationIndex);


        // Documented in base class.
        void
        setLongAnnotationAnnotationRef(const std::string& annotation, index_type longAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setLongAnnotationAnnotator(const std::string& annotator, index_type longAnnotationIndex);

        // Documented in base class.
        void
        setLongAnnotationDescription(const std::string& description, index_type longAnnotationIndex);

        // Documented in base class.
        void
        setLongAnnotationID(const std::string& id, index_type longAnnotationIndex);

        // Documented in base class.
        void
        setLongAnnotationNamespace(const std::string& namespace_, index_type longAnnotationIndex);

        // Documented in base class.
        void
        setLongAnnotationValue(int64_t value, index_type longAnnotationIndex);



        // Documented in base class.
        void
        setMapAnnotationAnnotationRef(const std::string& annotation, index_type mapAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setMapAnnotationAnnotator(const std::string& annotator, index_type mapAnnotationIndex);

        // Documented in base class.
        void
        setMapAnnotationDescription(const std::string& description, index_type mapAnnotationIndex);

        // Documented in base class.
        void
        setMapAnnotationID(const std::string& id, index_type mapAnnotationIndex);

        // Documented in base class.
        void
        setMapAnnotationNamespace(const std::string& namespace_, index_type mapAnnotationIndex);


        // Documented in base class.
        void
        setMaskAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setMaskFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskHeight(double height, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskWidth(double width, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskX(double x, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setMaskY(double y, index_type ROIIndex, index_type shapeIndex);



        // Documented in base class.
        void
        setMicrobeamManipulationDescription(const std::string& description, index_type experimentIndex, index_type microbeamManipulationIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationExperimenterRef(const std::string& experimenter, index_type experimentIndex, index_type microbeamManipulationIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationID(const std::string& id, index_type experimentIndex, index_type microbeamManipulationIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationROIRef(const std::string& roi, index_type experimentIndex, index_type microbeamManipulationIndex, index_type ROIRefIndex);

        // Documented in base class.
        void
        setMicrobeamManipulationType(ome::xml::model::enums::MicrobeamManipulationType type, index_type experimentIndex, index_type microbeamManipulationIndex);



        // Documented in base class.
        void
        setMicroscopeLotNumber(const std::string& lotNumber, index_type instrumentIndex);

        // Documented in base class.
        void
        setMicroscopeManufacturer(const std::string& manufacturer, index_type instrumentIndex);

        // Documented in base class.
        void
        setMicroscopeModel(const std::string& model, index_type instrumentIndex);

        // Documented in base class.
        void
        setMicroscopeSerialNumber(const std::string& serialNumber, index_type instrumentIndex);

        // Documented in base class.
        void
        setMicroscopeType(ome::xml::model::enums::MicroscopeType type, index_type instrumentIndex);


        // Documented in base class.
        void
        setObjectiveAnnotationRef(const std::string& annotation, index_type instrumentIndex, index_type objectiveIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setObjectiveCalibratedMagnification(double calibratedMagnification, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveCorrection(ome::xml::model::enums::Correction correction, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveID(const std::string& id, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveImmersion(ome::xml::model::enums::Immersion immersion, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveIris(bool iris, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveLensNA(double lensNA, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveLotNumber(const std::string& lotNumber, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveManufacturer(const std::string& manufacturer, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveModel(const std::string& model, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveNominalMagnification(double nominalMagnification, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveSerialNumber(const std::string& serialNumber, index_type instrumentIndex, index_type objectiveIndex);

        // Documented in base class.
        void
        setObjectiveWorkingDistance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  workingDistance, index_type instrumentIndex, index_type objectiveIndex);


        // Documented in base class.
        void
        setObjectiveSettingsCorrectionCollar(double correctionCollar, index_type imageIndex);

        // Documented in base class.
        void
        setObjectiveSettingsID(const std::string& id, index_type imageIndex);

        // Documented in base class.
        void
        setObjectiveSettingsMedium(ome::xml::model::enums::Medium medium, index_type imageIndex);

        // Documented in base class.
        void
        setObjectiveSettingsRefractiveIndex(double refractiveIndex, index_type imageIndex);


        // Documented in base class.
        void
        setPixelsBigEndian(bool bigEndian, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsDimensionOrder(ome::xml::model::enums::DimensionOrder dimensionOrder, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsID(const std::string& id, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsInterleaved(bool interleaved, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsPhysicalSizeX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeX, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsPhysicalSizeY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeY, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsPhysicalSizeZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  physicalSizeZ, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSignificantBits(ome::xml::model::primitives::PositiveInteger significantBits, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSizeC(ome::xml::model::primitives::PositiveInteger sizeC, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSizeT(ome::xml::model::primitives::PositiveInteger sizeT, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSizeX(ome::xml::model::primitives::PositiveInteger sizeX, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSizeY(ome::xml::model::primitives::PositiveInteger sizeY, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsSizeZ(ome::xml::model::primitives::PositiveInteger sizeZ, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsTimeIncrement(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  timeIncrement, index_type imageIndex);

        // Documented in base class.
        void
        setPixelsType(ome::xml::model::enums::PixelType type, index_type imageIndex);


        // Documented in base class.
        void
        setPlaneAnnotationRef(const std::string& annotation, index_type imageIndex, index_type planeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPlaneDeltaT(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  deltaT, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlaneExposureTime(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime >  exposureTime, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlaneHashSHA1(const std::string& hashSHA1, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlanePositionX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionX, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlanePositionY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionY, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlanePositionZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionZ, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlaneTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlaneTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type imageIndex, index_type planeIndex);

        // Documented in base class.
        void
        setPlaneTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type imageIndex, index_type planeIndex);


        // Documented in base class.
        void
        setPlateAnnotationRef(const std::string& annotation, index_type plateIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPlateColumnNamingConvention(ome::xml::model::enums::NamingConvention columnNamingConvention, index_type plateIndex);

        // Documented in base class.
        void
        setPlateColumns(ome::xml::model::primitives::PositiveInteger columns, index_type plateIndex);

        // Documented in base class.
        void
        setPlateDescription(const std::string& description, index_type plateIndex);

        // Documented in base class.
        void
        setPlateExternalIdentifier(const std::string& externalIdentifier, index_type plateIndex);

        // Documented in base class.
        void
        setPlateFieldIndex(ome::xml::model::primitives::NonNegativeInteger fieldIndex, index_type plateIndex);

        // Documented in base class.
        void
        setPlateID(const std::string& id, index_type plateIndex);

        // Documented in base class.
        void
        setPlateName(const std::string& name, index_type plateIndex);

        // Documented in base class.
        void
        setPlateRowNamingConvention(ome::xml::model::enums::NamingConvention rowNamingConvention, index_type plateIndex);

        // Documented in base class.
        void
        setPlateRows(ome::xml::model::primitives::PositiveInteger rows, index_type plateIndex);

        // Documented in base class.
        void
        setPlateStatus(const std::string& status, index_type plateIndex);

        // Documented in base class.
        void
        setPlateWellOriginX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  wellOriginX, index_type plateIndex);

        // Documented in base class.
        void
        setPlateWellOriginY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  wellOriginY, index_type plateIndex);


        // Documented in base class.
        void
        setPlateAcquisitionAnnotationRef(const std::string& annotation, index_type plateIndex, index_type plateAcquisitionIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPlateAcquisitionDescription(const std::string& description, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionEndTime(ome::xml::model::primitives::Timestamp endTime, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionID(const std::string& id, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionMaximumFieldCount(ome::xml::model::primitives::PositiveInteger maximumFieldCount, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionName(const std::string& name, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionStartTime(ome::xml::model::primitives::Timestamp startTime, index_type plateIndex, index_type plateAcquisitionIndex);

        // Documented in base class.
        void
        setPlateAcquisitionWellSampleRef(const std::string& wellSample, index_type plateIndex, index_type plateAcquisitionIndex, index_type wellSampleRefIndex);



        // Documented in base class.
        void
        setPointAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPointFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointX(double x, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPointY(double y, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setPolygonAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPolygonFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonPoints(const std::string& points, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolygonTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setPolylineAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setPolylineFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineMarkerEnd(ome::xml::model::enums::Marker markerEnd, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineMarkerStart(ome::xml::model::enums::Marker markerStart, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylinePoints(const std::string& points, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setPolylineTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setProjectAnnotationRef(const std::string& annotation, index_type projectIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setProjectDatasetRef(const std::string& dataset, index_type projectIndex, index_type datasetRefIndex);

        // Documented in base class.
        void
        setProjectDescription(const std::string& description, index_type projectIndex);

        // Documented in base class.
        void
        setProjectExperimenterGroupRef(const std::string& experimenterGroup, index_type projectIndex);

        // Documented in base class.
        void
        setProjectExperimenterRef(const std::string& experimenter, index_type projectIndex);

        // Documented in base class.
        void
        setProjectID(const std::string& id, index_type projectIndex);

        // Documented in base class.
        void
        setProjectName(const std::string& name, index_type projectIndex);



        // Documented in base class.
        void
        setROIAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setROIDescription(const std::string& description, index_type ROIIndex);

        // Documented in base class.
        void
        setROIID(const std::string& id, index_type ROIIndex);

        // Documented in base class.
        void
        setROIName(const std::string& name, index_type ROIIndex);



        // Documented in base class.
        void
        setReagentAnnotationRef(const std::string& annotation, index_type screenIndex, index_type reagentIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setReagentDescription(const std::string& description, index_type screenIndex, index_type reagentIndex);

        // Documented in base class.
        void
        setReagentID(const std::string& id, index_type screenIndex, index_type reagentIndex);

        // Documented in base class.
        void
        setReagentName(const std::string& name, index_type screenIndex, index_type reagentIndex);

        // Documented in base class.
        void
        setReagentReagentIdentifier(const std::string& reagentIdentifier, index_type screenIndex, index_type reagentIndex);



        // Documented in base class.
        void
        setRectangleAnnotationRef(const std::string& annotation, index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setRectangleFillColor(ome::xml::model::primitives::Color fillColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleFillRule(ome::xml::model::enums::FillRule fillRule, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleFontFamily(ome::xml::model::enums::FontFamily fontFamily, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleFontSize(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger >  fontSize, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleFontStyle(ome::xml::model::enums::FontStyle fontStyle, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleHeight(double height, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleID(const std::string& id, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleLocked(bool locked, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleStrokeColor(ome::xml::model::primitives::Color strokeColor, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleStrokeDashArray(const std::string& strokeDashArray, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleStrokeWidth(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  strokeWidth, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleText(const std::string& text, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleTheC(ome::xml::model::primitives::NonNegativeInteger theC, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleTheT(ome::xml::model::primitives::NonNegativeInteger theT, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleTheZ(ome::xml::model::primitives::NonNegativeInteger theZ, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleTransform(const ::ome::xml::model::AffineTransform& transform, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleWidth(double width, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleX(double x, index_type ROIIndex, index_type shapeIndex);

        // Documented in base class.
        void
        setRectangleY(double y, index_type ROIIndex, index_type shapeIndex);


        // Documented in base class.
        void
        setRightsRightsHeld(const std::string& rightsHeld);

        // Documented in base class.
        void
        setRightsRightsHolder(const std::string& rightsHolder);


        // Documented in base class.
        void
        setScreenAnnotationRef(const std::string& annotation, index_type screenIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setScreenDescription(const std::string& description, index_type screenIndex);

        // Documented in base class.
        void
        setScreenID(const std::string& id, index_type screenIndex);

        // Documented in base class.
        void
        setScreenName(const std::string& name, index_type screenIndex);

        // Documented in base class.
        void
        setScreenPlateRef(const std::string& plate, index_type screenIndex, index_type plateRefIndex);

        // Documented in base class.
        void
        setScreenProtocolDescription(const std::string& protocolDescription, index_type screenIndex);

        // Documented in base class.
        void
        setScreenProtocolIdentifier(const std::string& protocolIdentifier, index_type screenIndex);

        // Documented in base class.
        void
        setScreenReagentSetDescription(const std::string& reagentSetDescription, index_type screenIndex);

        // Documented in base class.
        void
        setScreenReagentSetIdentifier(const std::string& reagentSetIdentifier, index_type screenIndex);

        // Documented in base class.
        void
        setScreenType(const std::string& type, index_type screenIndex);


        // Documented in base class.
        void
        setStageLabelName(const std::string& name, index_type imageIndex);

        // Documented in base class.
        void
        setStageLabelX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  x, index_type imageIndex);

        // Documented in base class.
        void
        setStageLabelY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  y, index_type imageIndex);

        // Documented in base class.
        void
        setStageLabelZ(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  z, index_type imageIndex);



        // Documented in base class.
        void
        setTagAnnotationAnnotationRef(const std::string& annotation, index_type tagAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setTagAnnotationAnnotator(const std::string& annotator, index_type tagAnnotationIndex);

        // Documented in base class.
        void
        setTagAnnotationDescription(const std::string& description, index_type tagAnnotationIndex);

        // Documented in base class.
        void
        setTagAnnotationID(const std::string& id, index_type tagAnnotationIndex);

        // Documented in base class.
        void
        setTagAnnotationNamespace(const std::string& namespace_, index_type tagAnnotationIndex);

        // Documented in base class.
        void
        setTagAnnotationValue(const std::string& value, index_type tagAnnotationIndex);


        // Documented in base class.
        void
        setTermAnnotationAnnotationRef(const std::string& annotation, index_type termAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setTermAnnotationAnnotator(const std::string& annotator, index_type termAnnotationIndex);

        // Documented in base class.
        void
        setTermAnnotationDescription(const std::string& description, index_type termAnnotationIndex);

        // Documented in base class.
        void
        setTermAnnotationID(const std::string& id, index_type termAnnotationIndex);

        // Documented in base class.
        void
        setTermAnnotationNamespace(const std::string& namespace_, index_type termAnnotationIndex);

        // Documented in base class.
        void
        setTermAnnotationValue(const std::string& value, index_type termAnnotationIndex);


        // Documented in base class.
        void
        setTiffDataFirstC(ome::xml::model::primitives::NonNegativeInteger firstC, index_type imageIndex, index_type tiffDataIndex);

        // Documented in base class.
        void
        setTiffDataFirstT(ome::xml::model::primitives::NonNegativeInteger firstT, index_type imageIndex, index_type tiffDataIndex);

        // Documented in base class.
        void
        setTiffDataFirstZ(ome::xml::model::primitives::NonNegativeInteger firstZ, index_type imageIndex, index_type tiffDataIndex);

        // Documented in base class.
        void
        setTiffDataIFD(ome::xml::model::primitives::NonNegativeInteger ifd, index_type imageIndex, index_type tiffDataIndex);

        // Documented in base class.
        void
        setTiffDataPlaneCount(ome::xml::model::primitives::NonNegativeInteger planeCount, index_type imageIndex, index_type tiffDataIndex);


        // Documented in base class.
        void
        setTimestampAnnotationAnnotationRef(const std::string& annotation, index_type timestampAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setTimestampAnnotationAnnotator(const std::string& annotator, index_type timestampAnnotationIndex);

        // Documented in base class.
        void
        setTimestampAnnotationDescription(const std::string& description, index_type timestampAnnotationIndex);

        // Documented in base class.
        void
        setTimestampAnnotationID(const std::string& id, index_type timestampAnnotationIndex);

        // Documented in base class.
        void
        setTimestampAnnotationNamespace(const std::string& namespace_, index_type timestampAnnotationIndex);

        // Documented in base class.
        void
        setTimestampAnnotationValue(ome::xml::model::primitives::Timestamp value, index_type timestampAnnotationIndex);


        // Documented in base class.
        void
        setTransmittanceRangeCutIn(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  cutIn, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setTransmittanceRangeCutInTolerance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat >  cutInTolerance, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setTransmittanceRangeCutOut(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat >  cutOut, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setTransmittanceRangeCutOutTolerance(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat >  cutOutTolerance, index_type instrumentIndex, index_type filterIndex);

        // Documented in base class.
        void
        setTransmittanceRangeTransmittance(ome::xml::model::primitives::PercentFraction transmittance, index_type instrumentIndex, index_type filterIndex);


        // Documented in base class.
        void
        setUUIDFileName(const std::string& fileName, index_type imageIndex, index_type tiffDataIndex);



        // Documented in base class.
        void
        setWellAnnotationRef(const std::string& annotation, index_type plateIndex, index_type wellIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setWellColor(ome::xml::model::primitives::Color color, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellColumn(ome::xml::model::primitives::NonNegativeInteger column, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellExternalDescription(const std::string& externalDescription, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellExternalIdentifier(const std::string& externalIdentifier, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellID(const std::string& id, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellReagentRef(const std::string& reagent, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellRow(ome::xml::model::primitives::NonNegativeInteger row, index_type plateIndex, index_type wellIndex);

        // Documented in base class.
        void
        setWellType(const std::string& type, index_type plateIndex, index_type wellIndex);


        // Documented in base class.
        void
        setWellSampleID(const std::string& id, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);

        // Documented in base class.
        void
        setWellSampleImageRef(const std::string& image, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);

        // Documented in base class.
        void
        setWellSampleIndex(ome::xml::model::primitives::NonNegativeInteger index, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);

        // Documented in base class.
        void
        setWellSamplePositionX(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionX, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);

        // Documented in base class.
        void
        setWellSamplePositionY(ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength >  positionY, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);

        // Documented in base class.
        void
        setWellSampleTimepoint(ome::xml::model::primitives::Timestamp timepoint, index_type plateIndex, index_type wellIndex, index_type wellSampleIndex);



        // Documented in base class.
        void
        setXMLAnnotationAnnotationRef(const std::string& annotation, index_type XMLAnnotationIndex, index_type annotationRefIndex);

        // Documented in base class.
        void
        setXMLAnnotationAnnotator(const std::string& annotator, index_type XMLAnnotationIndex);

        // Documented in base class.
        void
        setXMLAnnotationDescription(const std::string& description, index_type XMLAnnotationIndex);

        // Documented in base class.
        void
        setXMLAnnotationID(const std::string& id, index_type XMLAnnotationIndex);

        // Documented in base class.
        void
        setXMLAnnotationNamespace(const std::string& namespace_, index_type XMLAnnotationIndex);

        // Documented in base class.
        void
        setXMLAnnotationValue(const std::string& value, index_type XMLAnnotationIndex);

      };

    }
  }
}

#endif // OME_XML_META_AGGREGATEMETADATA_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
