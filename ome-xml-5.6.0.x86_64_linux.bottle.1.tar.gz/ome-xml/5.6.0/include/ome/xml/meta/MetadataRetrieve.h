/*
 * #%L
 * OME-BIOFORMATS C++ library for image IO.
 * %%
 * Copyright © 2006 - 2016 Open Microscopy Environment:
 *   - Massachusetts Institute of Technology
 *   - National Institutes of Health
 *   - University of Dundee
 *   - Board of Regents of the University of Wisconsin-Madison
 *   - Glencoe Software, Inc.
 * %%
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are
 * those of the authors and should not be interpreted as representing official
 * policies, either expressed or implied, of any organization.
 * #L%
 */

/*─────────────────────────────────────────────────────────────────────────────
 *
 * THIS IS AUTOMATICALLY GENERATED CODE.  DO NOT MODIFY.
 *
 *─────────────────────────────────────────────────────────────────────────────
 */

#ifndef OME_XML_META_METADATARETRIEVE_H
#define OME_XML_META_METADATARETRIEVE_H

#include <memory>
#include <string>

#include <ome/xml/meta/BaseMetadata.h>
#include <ome/xml/model/AffineTransform.h>

#include <ome/xml/model/enums/AcquisitionMode.h>
#include <ome/xml/model/enums/ArcType.h>
#include <ome/xml/model/enums/Binning.h>
#include <ome/xml/model/enums/Compression.h>
#include <ome/xml/model/enums/ContrastMethod.h>
#include <ome/xml/model/enums/Correction.h>
#include <ome/xml/model/enums/DetectorType.h>
#include <ome/xml/model/enums/DimensionOrder.h>
#include <ome/xml/model/enums/ExperimentType.h>
#include <ome/xml/model/enums/FilamentType.h>
#include <ome/xml/model/enums/FillRule.h>
#include <ome/xml/model/enums/FilterType.h>
#include <ome/xml/model/enums/FontFamily.h>
#include <ome/xml/model/enums/FontStyle.h>
#include <ome/xml/model/enums/IlluminationType.h>
#include <ome/xml/model/enums/Immersion.h>
#include <ome/xml/model/enums/LaserMedium.h>
#include <ome/xml/model/enums/LaserType.h>
#include <ome/xml/model/enums/Marker.h>
#include <ome/xml/model/enums/Medium.h>
#include <ome/xml/model/enums/MicrobeamManipulationType.h>
#include <ome/xml/model/enums/MicroscopeType.h>
#include <ome/xml/model/enums/NamingConvention.h>
#include <ome/xml/model/enums/PixelType.h>
#include <ome/xml/model/enums/Pulse.h>
#include <ome/xml/model/enums/UnitsElectricPotential.h>
#include <ome/xml/model/enums/UnitsFrequency.h>
#include <ome/xml/model/enums/UnitsLength.h>
#include <ome/xml/model/enums/UnitsPower.h>
#include <ome/xml/model/enums/UnitsPressure.h>
#include <ome/xml/model/enums/UnitsTemperature.h>
#include <ome/xml/model/enums/UnitsTime.h>

#include <ome/xml/model/primitives/Color.h>
#include <ome/xml/model/primitives/ConstrainedNumeric.h>
#include <ome/xml/model/primitives/NonNegativeFloat.h>
#include <ome/xml/model/primitives/NonNegativeInteger.h>
#include <ome/xml/model/primitives/NonNegativeLong.h>
#include <ome/xml/model/primitives/NumericConstraints.h>
#include <ome/xml/model/primitives/OrderedMultimap.h>
#include <ome/xml/model/primitives/PercentFraction.h>
#include <ome/xml/model/primitives/PositiveFloat.h>
#include <ome/xml/model/primitives/PositiveInteger.h>
#include <ome/xml/model/primitives/PositiveLong.h>
#include <ome/xml/model/primitives/Timestamp.h>

namespace ome
{
  namespace xml
  {
    namespace meta
    {

      /**
       * Metadata retrieval interface.
       *
       * MetadataRetrieve is a proxy whose responsibility it is to
       * extract biological image data from a particular storage
       * medium.  This interface encompasses the metadata that any
       * specific storage medium (file, relational database, etc.)
       * should be expected to access from its backing data model.
       *
       * The MetadataRetrieve interface goes hand in hand with the
       * MetadataStore interface. Essentially, MetadataRetrieve
       * provides the "getter" methods for a storage medium, and
       * MetadataStore provides the "setter" methods.  Since it often
       * makes sense for a storage medium to implement both
       * interfaces, there is also an Metadata interface encompassing
       * both MetadataStore and MetadataRetrieve, which reduces the
       * need to cast between object types.
       *
       * See ome::xml::meta::OMEXMLMetadata for an
       * example implementation.
       *
       * @sa MetadataStore, Metadata,
       * ome::xml::meta::OMEXMLMetadata.
       */
      class MetadataRetrieve : virtual public BaseMetadata
      {
      protected:
        /// Constructor.
        MetadataRetrieve()
        {}

      public:
        /// Destructor.
        virtual
        ~MetadataRetrieve()
        {}

        /// @cond SKIP
        MetadataRetrieve (const MetadataRetrieve&) = delete;

        MetadataRetrieve&
        operator= (const MetadataRetrieve&) = delete;
        /// @endcond SKIP

        /**
         * Get the number of links to a BooleanAnnotation.
         *
         * This method returns the number of references to the
         * specified BooleanAnnotation held by all model objects.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the number of BooleanAnnotation links.
         */
        virtual index_type
        getBooleanAnnotationAnnotationCount(index_type booleanAnnotationIndex) const = 0;

        /**
         * Get the number of links to a CommentAnnotation.
         *
         * This method returns the number of references to the
         * specified CommentAnnotation held by all model objects.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the number of CommentAnnotation links.
         */
        virtual index_type
        getCommentAnnotationAnnotationCount(index_type commentAnnotationIndex) const = 0;

        /**
         * Get the number of links to a DoubleAnnotation.
         *
         * This method returns the number of references to the
         * specified DoubleAnnotation held by all model objects.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the number of DoubleAnnotation links.
         */
        virtual index_type
        getDoubleAnnotationAnnotationCount(index_type doubleAnnotationIndex) const = 0;

        /**
         * Get the number of links to a FileAnnotation.
         *
         * This method returns the number of references to the
         * specified FileAnnotation held by all model objects.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the number of FileAnnotation links.
         */
        virtual index_type
        getFileAnnotationAnnotationCount(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the number of links to a ListAnnotation.
         *
         * This method returns the number of references to the
         * specified ListAnnotation held by all model objects.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @returns the number of ListAnnotation links.
         */
        virtual index_type
        getListAnnotationAnnotationCount(index_type listAnnotationIndex) const = 0;

        /**
         * Get the number of links to a LongAnnotation.
         *
         * This method returns the number of references to the
         * specified LongAnnotation held by all model objects.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the number of LongAnnotation links.
         */
        virtual index_type
        getLongAnnotationAnnotationCount(index_type longAnnotationIndex) const = 0;

        /**
         * Get the number of links to a MapAnnotation.
         *
         * This method returns the number of references to the
         * specified MapAnnotation held by all model objects.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the number of MapAnnotation links.
         */
        virtual index_type
        getMapAnnotationAnnotationCount(index_type mapAnnotationIndex) const = 0;

        /**
         * Get the number of links to a TagAnnotation.
         *
         * This method returns the number of references to the
         * specified TagAnnotation held by all model objects.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the number of TagAnnotation links.
         */
        virtual index_type
        getTagAnnotationAnnotationCount(index_type tagAnnotationIndex) const = 0;

        /**
         * Get the number of links to a TermAnnotation.
         *
         * This method returns the number of references to the
         * specified TermAnnotation held by all model objects.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the number of TermAnnotation links.
         */
        virtual index_type
        getTermAnnotationAnnotationCount(index_type termAnnotationIndex) const = 0;

        /**
         * Get the number of links to a TimestampAnnotation.
         *
         * This method returns the number of references to the
         * specified TimestampAnnotation held by all model objects.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the number of TimestampAnnotation links.
         */
        virtual index_type
        getTimestampAnnotationAnnotationCount(index_type timestampAnnotationIndex) const = 0;

        /**
         * Get the number of links to an XMLAnnotation.
         *
         * This method returns the number of references to the
         * specified XMLAnnotation held by all model objects.
         *
         * @param xmlAnnotationIndex the XMLAnnotation index.
         * @returns the number of XMLAnnotation links.
         */
        virtual index_type
        getXMLAnnotationAnnotationCount(index_type xmlAnnotationIndex) const = 0;

        /**
         * Get the type of a LightSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LightSource type.
         *
         * @todo Can this be a const reference?
         */
        virtual const std::string&
        getLightSourceType(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the number of LightSource elements.
         *
         * @param instrumentIndex the Instrument index.
         * @return the number of LightSource elements.
         */
        virtual index_type
        getLightSourceCount(index_type instrumentIndex) const = 0;

        /**
         * Get the type of a Shape.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Shape type.
         *
         * @todo Can this be a const reference?
         */
        virtual const std::string&
        getShapeType(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the number of Shape elements.
         *
         * @param ROIIndex the ROI index.
         * @return the number of Shape elements.
         */
        virtual index_type
        getShapeCount(index_type ROIIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in LightSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getLightSourceAnnotationRefCount(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Instrument.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getInstrumentAnnotationRefCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getObjectiveAnnotationRefCount(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getFolderAnnotationRefCount(index_type folderIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getDetectorAnnotationRefCount(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getChannelAnnotationRefCount(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getPlateAnnotationRefCount(index_type plateIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getExperimenterGroupAnnotationRefCount(index_type experimenterGroupIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getScreenAnnotationRefCount(index_type screenIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getReagentAnnotationRefCount(index_type screenIndex, index_type reagentIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getPlaneAnnotationRefCount(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getExperimenterAnnotationRefCount(index_type experimenterIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getDichroicAnnotationRefCount(index_type instrumentIndex, index_type dichroicIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getWellAnnotationRefCount(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getFilterAnnotationRefCount(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getPlateAcquisitionAnnotationRefCount(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in ROI.
         *
         * @param ROIIndex the ROI index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getROIAnnotationRefCount(index_type ROIIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Project.
         *
         * @param projectIndex the Project index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getProjectAnnotationRefCount(index_type projectIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getLightPathAnnotationRefCount(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Image.
         *
         * @param imageIndex the Image index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getImageAnnotationRefCount(index_type imageIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getDatasetAnnotationRefCount(index_type datasetIndex) const = 0;

        /**
         * Get the number of AnnotationRef elements in Shape.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the number of AnnotationRef elements.
         */
        virtual index_type
        getShapeAnnotationRefCount(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the number of BinData elements in Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the number of BinData elements.
         */
        virtual index_type
        getPixelsBinDataCount(index_type imageIndex) const = 0;

        /**
         * Get the number of BooleanAnnotation elements.
         *
         * @returns the number of BooleanAnnotation elements.
         */
        virtual index_type
        getBooleanAnnotationCount() const = 0;

        /**
         * Get the number of Channel elements.
         *
         * @param imageIndex the Image index.
         * @returns the number of Channel elements.
         */
        virtual index_type
        getChannelCount(index_type imageIndex) const = 0;

        /**
         * Get the number of CommentAnnotation elements.
         *
         * @returns the number of CommentAnnotation elements.
         */
        virtual index_type
        getCommentAnnotationCount() const = 0;

        /**
         * Get the number of Dataset elements.
         *
         * @returns the number of Dataset elements.
         */
        virtual index_type
        getDatasetCount() const = 0;

        /**
         * Get the number of DatasetRef elements.
         *
         * @param projectIndex the Project index.
         * @returns the number of DatasetRef elements.
         */
        virtual index_type
        getDatasetRefCount(index_type projectIndex) const = 0;

        /**
         * Get the number of Detector elements.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of Detector elements.
         */
        virtual index_type
        getDetectorCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of Dichroic elements.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of Dichroic elements.
         */
        virtual index_type
        getDichroicCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of DoubleAnnotation elements.
         *
         * @returns the number of DoubleAnnotation elements.
         */
        virtual index_type
        getDoubleAnnotationCount() const = 0;

        /**
         * Get the number of EmissionFilterRef elements in LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the number of EmissionFilterRef elements.
         */
        virtual index_type
        getLightPathEmissionFilterRefCount(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the number of EmissionFilterRef elements in FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the number of EmissionFilterRef elements.
         */
        virtual index_type
        getFilterSetEmissionFilterRefCount(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the number of ExcitationFilterRef elements in LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the number of ExcitationFilterRef elements.
         */
        virtual index_type
        getLightPathExcitationFilterRefCount(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the number of ExcitationFilterRef elements in FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the number of ExcitationFilterRef elements.
         */
        virtual index_type
        getFilterSetExcitationFilterRefCount(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the number of Experiment elements.
         *
         * @returns the number of Experiment elements.
         */
        virtual index_type
        getExperimentCount() const = 0;

        /**
         * Get the number of Experimenter elements.
         *
         * @returns the number of Experimenter elements.
         */
        virtual index_type
        getExperimenterCount() const = 0;

        /**
         * Get the number of ExperimenterGroup elements.
         *
         * @returns the number of ExperimenterGroup elements.
         */
        virtual index_type
        getExperimenterGroupCount() const = 0;

        /**
         * Get the number of ExperimenterRef elements in ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the number of ExperimenterRef elements.
         */
        virtual index_type
        getExperimenterGroupExperimenterRefCount(index_type experimenterGroupIndex) const = 0;

        /**
         * Get the number of FileAnnotation elements.
         *
         * @returns the number of FileAnnotation elements.
         */
        virtual index_type
        getFileAnnotationCount() const = 0;

        /**
         * Get the number of Filter elements.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of Filter elements.
         */
        virtual index_type
        getFilterCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of FilterSet elements.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of FilterSet elements.
         */
        virtual index_type
        getFilterSetCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of Folder elements.
         *
         * @returns the number of Folder elements.
         */
        virtual index_type
        getFolderCount() const = 0;

        /**
         * Get the number of FolderRef elements.
         *
         * @param folderIndex the Folder index.
         * @returns the number of FolderRef elements.
         */
        virtual index_type
        getFolderRefCount(index_type folderIndex) const = 0;

        /**
         * Get the number of Image elements.
         *
         * @returns the number of Image elements.
         */
        virtual index_type
        getImageCount() const = 0;

        /**
         * Get the number of ImageRef elements in Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the number of ImageRef elements.
         */
        virtual index_type
        getFolderImageRefCount(index_type folderIndex) const = 0;

        /**
         * Get the number of ImageRef elements in Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the number of ImageRef elements.
         */
        virtual index_type
        getDatasetImageRefCount(index_type datasetIndex) const = 0;

        /**
         * Get the number of Instrument elements.
         *
         * @returns the number of Instrument elements.
         */
        virtual index_type
        getInstrumentCount() const = 0;

        /**
         * Get the number of Leader elements.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the number of Leader elements.
         */
        virtual index_type
        getLeaderCount(index_type experimenterGroupIndex) const = 0;

        /**
         * Get the number of LightSourceSettings elements in MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the number of LightSourceSettings elements.
         */
        virtual index_type
        getMicrobeamManipulationLightSourceSettingsCount(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;

        /**
         * Get the number of ListAnnotation elements.
         *
         * @returns the number of ListAnnotation elements.
         */
        virtual index_type
        getListAnnotationCount() const = 0;

        /**
         * Get the number of LongAnnotation elements.
         *
         * @returns the number of LongAnnotation elements.
         */
        virtual index_type
        getLongAnnotationCount() const = 0;

        /**
         * Get the number of MapAnnotation elements.
         *
         * @returns the number of MapAnnotation elements.
         */
        virtual index_type
        getMapAnnotationCount() const = 0;

        /**
         * Get the number of MicrobeamManipulation elements.
         *
         * @param experimentIndex the Experiment index.
         * @returns the number of MicrobeamManipulation elements.
         */
        virtual index_type
        getMicrobeamManipulationCount(index_type experimentIndex) const = 0;

        /**
         * Get the number of MicrobeamManipulationRef elements.
         *
         * @param imageIndex the Image index.
         * @returns the number of MicrobeamManipulationRef elements.
         */
        virtual index_type
        getMicrobeamManipulationRefCount(index_type imageIndex) const = 0;

        /**
         * Get the number of Objective elements.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the number of Objective elements.
         */
        virtual index_type
        getObjectiveCount(index_type instrumentIndex) const = 0;

        /**
         * Get the number of Plane elements.
         *
         * @param imageIndex the Image index.
         * @returns the number of Plane elements.
         */
        virtual index_type
        getPlaneCount(index_type imageIndex) const = 0;

        /**
         * Get the number of Plate elements.
         *
         * @returns the number of Plate elements.
         */
        virtual index_type
        getPlateCount() const = 0;

        /**
         * Get the number of PlateAcquisition elements.
         *
         * @param plateIndex the Plate index.
         * @returns the number of PlateAcquisition elements.
         */
        virtual index_type
        getPlateAcquisitionCount(index_type plateIndex) const = 0;

        /**
         * Get the number of PlateRef elements.
         *
         * @param screenIndex the Screen index.
         * @returns the number of PlateRef elements.
         */
        virtual index_type
        getPlateRefCount(index_type screenIndex) const = 0;

        /**
         * Get the number of Project elements.
         *
         * @returns the number of Project elements.
         */
        virtual index_type
        getProjectCount() const = 0;

        /**
         * Get the number of ROI elements.
         *
         * @returns the number of ROI elements.
         */
        virtual index_type
        getROICount() const = 0;

        /**
         * Get the number of ROIRef elements in Image.
         *
         * @param imageIndex the Image index.
         * @returns the number of ROIRef elements.
         */
        virtual index_type
        getImageROIRefCount(index_type imageIndex) const = 0;

        /**
         * Get the number of ROIRef elements in Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the number of ROIRef elements.
         */
        virtual index_type
        getFolderROIRefCount(index_type folderIndex) const = 0;

        /**
         * Get the number of ROIRef elements in MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the number of ROIRef elements.
         */
        virtual index_type
        getMicrobeamManipulationROIRefCount(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;

        /**
         * Get the number of Reagent elements.
         *
         * @param screenIndex the Screen index.
         * @returns the number of Reagent elements.
         */
        virtual index_type
        getReagentCount(index_type screenIndex) const = 0;

        /**
         * Get the number of Screen elements.
         *
         * @returns the number of Screen elements.
         */
        virtual index_type
        getScreenCount() const = 0;

        /**
         * Get the number of TagAnnotation elements.
         *
         * @returns the number of TagAnnotation elements.
         */
        virtual index_type
        getTagAnnotationCount() const = 0;

        /**
         * Get the number of TermAnnotation elements.
         *
         * @returns the number of TermAnnotation elements.
         */
        virtual index_type
        getTermAnnotationCount() const = 0;

        /**
         * Get the number of TiffData elements.
         *
         * @param imageIndex the Image index.
         * @returns the number of TiffData elements.
         */
        virtual index_type
        getTiffDataCount(index_type imageIndex) const = 0;

        /**
         * Get the number of TimestampAnnotation elements.
         *
         * @returns the number of TimestampAnnotation elements.
         */
        virtual index_type
        getTimestampAnnotationCount() const = 0;

        /**
         * Get the text value of UUID.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the text value.
         */
        virtual std::string
        getUUIDValue(index_type imageIndex, index_type tiffDataIndex) const = 0;

        /**
         * Get the number of Well elements.
         *
         * @param plateIndex the Plate index.
         * @returns the number of Well elements.
         */
        virtual index_type
        getWellCount(index_type plateIndex) const = 0;

        /**
         * Get the number of WellSample elements.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the number of WellSample elements.
         */
        virtual index_type
        getWellSampleCount(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the number of WellSampleRef elements.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the number of WellSampleRef elements.
         */
        virtual index_type
        getWellSampleRefCount(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the number of XMLAnnotation elements.
         *
         * @returns the number of XMLAnnotation elements.
         */
        virtual index_type
        getXMLAnnotationCount() const = 0;

        /**
         * Get the UUID associated with this collection of metadata.
         *
         * @returns the UUID.
         *
         * @todo Can this be a const reference?
         */
        virtual const std::string&
        getUUID() const = 0;

        /**
         * Get the map value of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the map value.
         */
        virtual const ome::xml::model::primitives::OrderedMultimap&
        getMapAnnotationValue(index_type mapAnnotationIndex) const = 0;

       /**
         * Get the map value of GenericExcitationSource.
         *
         * @param instrumentIndex the LightSource index.
         * @param lightSourceIndex the LightSource index.
         * @returns the map value.
         */
        virtual const ome::xml::model::primitives::OrderedMultimap&
        getGenericExcitationSourceMap(index_type instrumentIndex,
                                      index_type lightSourceIndex) const = 0;

       /**
         * Get the map value of ImagingEnvironment.
         *
         * @param imageIndex the Image index.
         * @returns the map value.
         */
        virtual const ome::xml::model::primitives::OrderedMultimap&
        getImagingEnvironmentMap(index_type imageIndex) const = 0;


        /**
         * Get the AnnotationRef property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getArcAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the ID property.
         */
        virtual const std::string&
        getArcID(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LotNumber property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getArcLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Manufacturer property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getArcManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Model property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Model property.
         */
        virtual const std::string&
        getArcModel(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Power property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Power property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getArcPower(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the SerialNumber property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getArcSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Type property of Arc.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::ArcType
        getArcType(index_type instrumentIndex, index_type lightSourceIndex) const = 0;


        /**
         * Get the Base64Binary property of BinData.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Base64Binary property.
         */
        virtual const std::vector<uint8_t>&
        getBinaryFileBinData(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Base64Binary property of BinData.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Base64Binary property.
         */
        virtual const std::vector<uint8_t>&
        getMaskBinData(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Base64Binary property of BinData.
         *
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         * @returns the Base64Binary property.
         */
        virtual const std::vector<uint8_t>&
        getPixelsBinData(index_type imageIndex, index_type binDataIndex) const = 0;

        /**
         * Get the BigEndian property of BinData.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the BigEndian property.
         */
        virtual bool
        getBinaryFileBinDataBigEndian(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the BigEndian property of BinData.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the BigEndian property.
         */
        virtual bool
        getMaskBinDataBigEndian(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the BigEndian property of BinData.
         *
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         * @returns the BigEndian property.
         */
        virtual bool
        getPixelsBinDataBigEndian(index_type imageIndex, index_type binDataIndex) const = 0;

        /**
         * Get the Compression property of BinData.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Compression property.
         */
        virtual ome::xml::model::enums::Compression
        getBinaryFileBinDataCompression(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Compression property of BinData.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Compression property.
         */
        virtual ome::xml::model::enums::Compression
        getMaskBinDataCompression(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Compression property of BinData.
         *
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         * @returns the Compression property.
         */
        virtual ome::xml::model::enums::Compression
        getPixelsBinDataCompression(index_type imageIndex, index_type binDataIndex) const = 0;

        /**
         * Get the Length property of BinData.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Length property.
         */
        virtual ome::xml::model::primitives::NonNegativeLong
        getBinaryFileBinDataLength(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Length property of BinData.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Length property.
         */
        virtual ome::xml::model::primitives::NonNegativeLong
        getMaskBinDataLength(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Length property of BinData.
         *
         * @param imageIndex the Image index.
         * @param binDataIndex the BinData index.
         * @returns the Length property.
         */
        virtual ome::xml::model::primitives::NonNegativeLong
        getPixelsBinDataLength(index_type imageIndex, index_type binDataIndex) const = 0;


        /**
         * Get the FileName property of BinaryFile.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the FileName property.
         */
        virtual const std::string&
        getBinaryFileFileName(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the MIMEType property of BinaryFile.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the MIMEType property.
         */
        virtual const std::string&
        getBinaryFileMIMEType(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Size property of BinaryFile.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Size property.
         */
        virtual ome::xml::model::primitives::NonNegativeLong
        getBinaryFileSize(index_type fileAnnotationIndex) const = 0;


        /**
         * Get the MetadataFile property of BinaryOnly.
         *
         * @returns the MetadataFile property.
         */
        virtual const std::string&
        getBinaryOnlyMetadataFile() const = 0;

        /**
         * Get the UUID property of BinaryOnly.
         *
         * @returns the UUID property.
         */
        virtual const std::string&
        getBinaryOnlyUUID() const = 0;


        /**
         * Get the AnnotationRef property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getBooleanAnnotationAnnotationRef(index_type booleanAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getBooleanAnnotationAnnotator(index_type booleanAnnotationIndex) const = 0;

        /**
         * Get the Description property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getBooleanAnnotationDescription(index_type booleanAnnotationIndex) const = 0;

        /**
         * Get the ID property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getBooleanAnnotationID(index_type booleanAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getBooleanAnnotationNamespace(index_type booleanAnnotationIndex) const = 0;

        /**
         * Get the Value property of BooleanAnnotation.
         *
         * @param booleanAnnotationIndex the BooleanAnnotation index.
         * @returns the Value property.
         */
        virtual bool
        getBooleanAnnotationValue(index_type booleanAnnotationIndex) const = 0;


        /**
         * Get the AcquisitionMode property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the AcquisitionMode property.
         */
        virtual ome::xml::model::enums::AcquisitionMode
        getChannelAcquisitionMode(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the AnnotationRef property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getChannelAnnotationRef(index_type imageIndex, index_type channelIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Color property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Color property.
         */
        virtual ome::xml::model::primitives::Color
        getChannelColor(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ContrastMethod property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ContrastMethod property.
         */
        virtual ome::xml::model::enums::ContrastMethod
        getChannelContrastMethod(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the EmissionWavelength property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the EmissionWavelength property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelEmissionWavelength(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ExcitationWavelength property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ExcitationWavelength property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelExcitationWavelength(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the FilterSetRef property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the FilterSetRef property.
         */
        virtual const std::string&
        getChannelFilterSetRef(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Fluor property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Fluor property.
         */
        virtual const std::string&
        getChannelFluor(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ID property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ID property.
         */
        virtual const std::string&
        getChannelID(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the IlluminationType property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the IlluminationType property.
         */
        virtual ome::xml::model::enums::IlluminationType
        getChannelIlluminationType(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the NDFilter property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the NDFilter property.
         */
        virtual double
        getChannelNDFilter(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Name property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Name property.
         */
        virtual const std::string&
        getChannelName(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the PinholeSize property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the PinholeSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getChannelPinholeSize(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the PockelCellSetting property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the PockelCellSetting property.
         */
        virtual int32_t
        getChannelPockelCellSetting(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the SamplesPerPixel property of Channel.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the SamplesPerPixel property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getChannelSamplesPerPixel(index_type imageIndex, index_type channelIndex) const = 0;


        /**
         * Get the AnnotationRef property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getCommentAnnotationAnnotationRef(index_type commentAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getCommentAnnotationAnnotator(index_type commentAnnotationIndex) const = 0;

        /**
         * Get the Description property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getCommentAnnotationDescription(index_type commentAnnotationIndex) const = 0;

        /**
         * Get the ID property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getCommentAnnotationID(index_type commentAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getCommentAnnotationNamespace(index_type commentAnnotationIndex) const = 0;

        /**
         * Get the Value property of CommentAnnotation.
         *
         * @param commentAnnotationIndex the CommentAnnotation index.
         * @returns the Value property.
         */
        virtual const std::string&
        getCommentAnnotationValue(index_type commentAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getDatasetAnnotationRef(index_type datasetIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the Description property.
         */
        virtual const std::string&
        getDatasetDescription(index_type datasetIndex) const = 0;

        /**
         * Get the ExperimenterGroupRef property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the ExperimenterGroupRef property.
         */
        virtual const std::string&
        getDatasetExperimenterGroupRef(index_type datasetIndex) const = 0;

        /**
         * Get the ExperimenterRef property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getDatasetExperimenterRef(index_type datasetIndex) const = 0;

        /**
         * Get the ID property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the ID property.
         */
        virtual const std::string&
        getDatasetID(index_type datasetIndex) const = 0;

        /**
         * Get the ImageRef property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @param imageRefIndex ImageRef index.
         * @returns the ImageRef property.
         */
        virtual const std::string&
        getDatasetImageRef(index_type datasetIndex, index_type imageRefIndex) const = 0;

        /**
         * Get the Name property of Dataset.
         *
         * @param datasetIndex the Dataset index.
         * @returns the Name property.
         */
        virtual const std::string&
        getDatasetName(index_type datasetIndex) const = 0;



        /**
         * Get the AmplificationGain property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the AmplificationGain property.
         */
        virtual double
        getDetectorAmplificationGain(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the AnnotationRef property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getDetectorAnnotationRef(index_type instrumentIndex, index_type detectorIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Gain property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Gain property.
         */
        virtual double
        getDetectorGain(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the ID property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the ID property.
         */
        virtual const std::string&
        getDetectorID(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the LotNumber property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getDetectorLotNumber(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Manufacturer property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getDetectorManufacturer(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Model property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Model property.
         */
        virtual const std::string&
        getDetectorModel(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Offset property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Offset property.
         */
        virtual double
        getDetectorOffset(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the SerialNumber property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getDetectorSerialNumber(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Type property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::DetectorType
        getDetectorType(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Voltage property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Voltage property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential > 
        getDetectorVoltage(index_type instrumentIndex, index_type detectorIndex) const = 0;

        /**
         * Get the Zoom property of Detector.
         *
         * @param instrumentIndex the Instrument index.
         * @param detectorIndex the Detector index.
         * @returns the Zoom property.
         */
        virtual double
        getDetectorZoom(index_type instrumentIndex, index_type detectorIndex) const = 0;


        /**
         * Get the Binning property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Binning property.
         */
        virtual ome::xml::model::enums::Binning
        getDetectorSettingsBinning(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Gain property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Gain property.
         */
        virtual double
        getDetectorSettingsGain(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ID property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ID property.
         */
        virtual const std::string&
        getDetectorSettingsID(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Integration property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Integration property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getDetectorSettingsIntegration(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Offset property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Offset property.
         */
        virtual double
        getDetectorSettingsOffset(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ReadOutRate property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ReadOutRate property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > 
        getDetectorSettingsReadOutRate(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Voltage property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Voltage property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsElectricPotential > 
        getDetectorSettingsVoltage(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Zoom property of DetectorSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Zoom property.
         */
        virtual double
        getDetectorSettingsZoom(index_type imageIndex, index_type channelIndex) const = 0;


        /**
         * Get the AnnotationRef property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getDichroicAnnotationRef(index_type instrumentIndex, index_type dichroicIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the ID property.
         */
        virtual const std::string&
        getDichroicID(index_type instrumentIndex, index_type dichroicIndex) const = 0;

        /**
         * Get the LotNumber property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getDichroicLotNumber(index_type instrumentIndex, index_type dichroicIndex) const = 0;

        /**
         * Get the Manufacturer property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getDichroicManufacturer(index_type instrumentIndex, index_type dichroicIndex) const = 0;

        /**
         * Get the Model property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the Model property.
         */
        virtual const std::string&
        getDichroicModel(index_type instrumentIndex, index_type dichroicIndex) const = 0;

        /**
         * Get the SerialNumber property of Dichroic.
         *
         * @param instrumentIndex the Instrument index.
         * @param dichroicIndex the Dichroic index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getDichroicSerialNumber(index_type instrumentIndex, index_type dichroicIndex) const = 0;



        /**
         * Get the AnnotationRef property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getDoubleAnnotationAnnotationRef(index_type doubleAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getDoubleAnnotationAnnotator(index_type doubleAnnotationIndex) const = 0;

        /**
         * Get the Description property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getDoubleAnnotationDescription(index_type doubleAnnotationIndex) const = 0;

        /**
         * Get the ID property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getDoubleAnnotationID(index_type doubleAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getDoubleAnnotationNamespace(index_type doubleAnnotationIndex) const = 0;

        /**
         * Get the Value property of DoubleAnnotation.
         *
         * @param doubleAnnotationIndex the DoubleAnnotation index.
         * @returns the Value property.
         */
        virtual double
        getDoubleAnnotationValue(index_type doubleAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getEllipseAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getEllipseFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getEllipseFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getEllipseFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getEllipseFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getEllipseFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getEllipseID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getEllipseLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the RadiusX property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the RadiusX property.
         */
        virtual double
        getEllipseRadiusX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the RadiusY property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the RadiusY property.
         */
        virtual double
        getEllipseRadiusY(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getEllipseStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getEllipseStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getEllipseStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getEllipseText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getEllipseTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getEllipseTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X property.
         */
        virtual double
        getEllipseX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y property of Ellipse.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y property.
         */
        virtual double
        getEllipseY(index_type ROIIndex, index_type shapeIndex) const = 0;




        /**
         * Get the Description property of Experiment.
         *
         * @param experimentIndex the Experiment index.
         * @returns the Description property.
         */
        virtual const std::string&
        getExperimentDescription(index_type experimentIndex) const = 0;

        /**
         * Get the ExperimenterRef property of Experiment.
         *
         * @param experimentIndex the Experiment index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getExperimentExperimenterRef(index_type experimentIndex) const = 0;

        /**
         * Get the ID property of Experiment.
         *
         * @param experimentIndex the Experiment index.
         * @returns the ID property.
         */
        virtual const std::string&
        getExperimentID(index_type experimentIndex) const = 0;

        /**
         * Get the Type property of Experiment.
         *
         * @param experimentIndex the Experiment index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::ExperimentType
        getExperimentType(index_type experimentIndex) const = 0;



        /**
         * Get the AnnotationRef property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getExperimenterAnnotationRef(index_type experimenterIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Email property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the Email property.
         */
        virtual const std::string&
        getExperimenterEmail(index_type experimenterIndex) const = 0;

        /**
         * Get the FirstName property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the FirstName property.
         */
        virtual const std::string&
        getExperimenterFirstName(index_type experimenterIndex) const = 0;

        /**
         * Get the ID property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the ID property.
         */
        virtual const std::string&
        getExperimenterID(index_type experimenterIndex) const = 0;

        /**
         * Get the Institution property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the Institution property.
         */
        virtual const std::string&
        getExperimenterInstitution(index_type experimenterIndex) const = 0;

        /**
         * Get the LastName property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the LastName property.
         */
        virtual const std::string&
        getExperimenterLastName(index_type experimenterIndex) const = 0;

        /**
         * Get the MiddleName property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the MiddleName property.
         */
        virtual const std::string&
        getExperimenterMiddleName(index_type experimenterIndex) const = 0;

        /**
         * Get the UserName property of Experimenter.
         *
         * @param experimenterIndex the Experimenter index.
         * @returns the UserName property.
         */
        virtual const std::string&
        getExperimenterUserName(index_type experimenterIndex) const = 0;


        /**
         * Get the AnnotationRef property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getExperimenterGroupAnnotationRef(index_type experimenterGroupIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the Description property.
         */
        virtual const std::string&
        getExperimenterGroupDescription(index_type experimenterGroupIndex) const = 0;

        /**
         * Get the ExperimenterRef property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param experimenterRefIndex ExperimenterRef index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getExperimenterGroupExperimenterRef(index_type experimenterGroupIndex, index_type experimenterRefIndex) const = 0;

        /**
         * Get the ID property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the ID property.
         */
        virtual const std::string&
        getExperimenterGroupID(index_type experimenterGroupIndex) const = 0;

        /**
         * Get the Leader property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @param leaderIndex Leader index.
         * @returns the Leader property.
         */
        virtual const std::string&
        getExperimenterGroupLeader(index_type experimenterGroupIndex, index_type leaderIndex) const = 0;

        /**
         * Get the Name property of ExperimenterGroup.
         *
         * @param experimenterGroupIndex the ExperimenterGroup index.
         * @returns the Name property.
         */
        virtual const std::string&
        getExperimenterGroupName(index_type experimenterGroupIndex) const = 0;




        /**
         * Get the AnnotationRef property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getFilamentAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the ID property.
         */
        virtual const std::string&
        getFilamentID(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LotNumber property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getFilamentLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Manufacturer property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getFilamentManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Model property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Model property.
         */
        virtual const std::string&
        getFilamentModel(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Power property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Power property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getFilamentPower(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the SerialNumber property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getFilamentSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Type property of Filament.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::FilamentType
        getFilamentType(index_type instrumentIndex, index_type lightSourceIndex) const = 0;


        /**
         * Get the AnnotationRef property of FileAnnotation.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getFileAnnotationAnnotationRef(index_type fileAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of FileAnnotation.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getFileAnnotationAnnotator(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Description property of FileAnnotation.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getFileAnnotationDescription(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the ID property of FileAnnotation.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getFileAnnotationID(index_type fileAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of FileAnnotation.
         *
         * @param fileAnnotationIndex the FileAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getFileAnnotationNamespace(index_type fileAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getFilterAnnotationRef(index_type instrumentIndex, index_type filterIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FilterWheel property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the FilterWheel property.
         */
        virtual const std::string&
        getFilterFilterWheel(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the ID property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the ID property.
         */
        virtual const std::string&
        getFilterID(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the LotNumber property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getFilterLotNumber(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the Manufacturer property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getFilterManufacturer(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the Model property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the Model property.
         */
        virtual const std::string&
        getFilterModel(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the SerialNumber property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getFilterSerialNumber(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the Type property of Filter.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::FilterType
        getFilterType(index_type instrumentIndex, index_type filterIndex) const = 0;


        /**
         * Get the DichroicRef property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the DichroicRef property.
         */
        virtual const std::string&
        getFilterSetDichroicRef(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the EmissionFilterRef property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @param emissionFilterRefIndex EmissionFilterRef index.
         * @returns the EmissionFilterRef property.
         */
        virtual const std::string&
        getFilterSetEmissionFilterRef(index_type instrumentIndex, index_type filterSetIndex, index_type emissionFilterRefIndex) const = 0;

        /**
         * Get the ExcitationFilterRef property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @param excitationFilterRefIndex ExcitationFilterRef index.
         * @returns the ExcitationFilterRef property.
         */
        virtual const std::string&
        getFilterSetExcitationFilterRef(index_type instrumentIndex, index_type filterSetIndex, index_type excitationFilterRefIndex) const = 0;

        /**
         * Get the ID property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the ID property.
         */
        virtual const std::string&
        getFilterSetID(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the LotNumber property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getFilterSetLotNumber(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the Manufacturer property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getFilterSetManufacturer(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the Model property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the Model property.
         */
        virtual const std::string&
        getFilterSetModel(index_type instrumentIndex, index_type filterSetIndex) const = 0;

        /**
         * Get the SerialNumber property of FilterSet.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterSetIndex the FilterSet index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getFilterSetSerialNumber(index_type instrumentIndex, index_type filterSetIndex) const = 0;



        /**
         * Get the AnnotationRef property of Folder.
         *
         * @param folderIndex the Folder index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getFolderAnnotationRef(index_type folderIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the Description property.
         */
        virtual const std::string&
        getFolderDescription(index_type folderIndex) const = 0;

        /**
         * Get the FolderRef property of Folder.
         *
         * @param folderIndex the Folder index.
         * @param folderRefIndex FolderRef index.
         * @returns the FolderRef property.
         */
        virtual const std::string&
        getFolderFolderRef(index_type folderIndex, index_type folderRefIndex) const = 0;

        /**
         * Get the ID property of Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the ID property.
         */
        virtual const std::string&
        getFolderID(index_type folderIndex) const = 0;

        /**
         * Get the ImageRef property of Folder.
         *
         * @param folderIndex the Folder index.
         * @param imageRefIndex ImageRef index.
         * @returns the ImageRef property.
         */
        virtual const std::string&
        getFolderImageRef(index_type folderIndex, index_type imageRefIndex) const = 0;

        /**
         * Get the Name property of Folder.
         *
         * @param folderIndex the Folder index.
         * @returns the Name property.
         */
        virtual const std::string&
        getFolderName(index_type folderIndex) const = 0;

        /**
         * Get the ROIRef property of Folder.
         *
         * @param folderIndex the Folder index.
         * @param ROIRefIndex ROIRef index.
         * @returns the ROIRef property.
         */
        virtual const std::string&
        getFolderROIRef(index_type folderIndex, index_type ROIRefIndex) const = 0;



        /**
         * Get the AnnotationRef property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getGenericExcitationSourceAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the ID property.
         */
        virtual const std::string&
        getGenericExcitationSourceID(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LotNumber property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getGenericExcitationSourceLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Manufacturer property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getGenericExcitationSourceManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Model property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Model property.
         */
        virtual const std::string&
        getGenericExcitationSourceModel(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Power property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Power property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getGenericExcitationSourcePower(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the SerialNumber property of GenericExcitationSource.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getGenericExcitationSourceSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;


        /**
         * Get the AcquisitionDate property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the AcquisitionDate property.
         */
        virtual ome::xml::model::primitives::Timestamp
        getImageAcquisitionDate(index_type imageIndex) const = 0;

        /**
         * Get the AnnotationRef property of Image.
         *
         * @param imageIndex the Image index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getImageAnnotationRef(index_type imageIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the Description property.
         */
        virtual const std::string&
        getImageDescription(index_type imageIndex) const = 0;

        /**
         * Get the ExperimentRef property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the ExperimentRef property.
         */
        virtual const std::string&
        getImageExperimentRef(index_type imageIndex) const = 0;

        /**
         * Get the ExperimenterGroupRef property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the ExperimenterGroupRef property.
         */
        virtual const std::string&
        getImageExperimenterGroupRef(index_type imageIndex) const = 0;

        /**
         * Get the ExperimenterRef property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getImageExperimenterRef(index_type imageIndex) const = 0;

        /**
         * Get the ID property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the ID property.
         */
        virtual const std::string&
        getImageID(index_type imageIndex) const = 0;

        /**
         * Get the InstrumentRef property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the InstrumentRef property.
         */
        virtual const std::string&
        getImageInstrumentRef(index_type imageIndex) const = 0;

        /**
         * Get the MicrobeamManipulationRef property of Image.
         *
         * @param imageIndex the Image index.
         * @param microbeamManipulationRefIndex MicrobeamManipulationRef index.
         * @returns the MicrobeamManipulationRef property.
         */
        virtual const std::string&
        getImageMicrobeamManipulationRef(index_type imageIndex, index_type microbeamManipulationRefIndex) const = 0;

        /**
         * Get the Name property of Image.
         *
         * @param imageIndex the Image index.
         * @returns the Name property.
         */
        virtual const std::string&
        getImageName(index_type imageIndex) const = 0;

        /**
         * Get the ROIRef property of Image.
         *
         * @param imageIndex the Image index.
         * @param ROIRefIndex ROIRef index.
         * @returns the ROIRef property.
         */
        virtual const std::string&
        getImageROIRef(index_type imageIndex, index_type ROIRefIndex) const = 0;



        /**
         * Get the AirPressure property of ImagingEnvironment.
         *
         * @param imageIndex the Image index.
         * @returns the AirPressure property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPressure > 
        getImagingEnvironmentAirPressure(index_type imageIndex) const = 0;

        /**
         * Get the CO2Percent property of ImagingEnvironment.
         *
         * @param imageIndex the Image index.
         * @returns the CO2Percent property.
         */
        virtual ome::xml::model::primitives::PercentFraction
        getImagingEnvironmentCO2Percent(index_type imageIndex) const = 0;

        /**
         * Get the Humidity property of ImagingEnvironment.
         *
         * @param imageIndex the Image index.
         * @returns the Humidity property.
         */
        virtual ome::xml::model::primitives::PercentFraction
        getImagingEnvironmentHumidity(index_type imageIndex) const = 0;

        /**
         * Get the Temperature property of ImagingEnvironment.
         *
         * @param imageIndex the Image index.
         * @returns the Temperature property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTemperature > 
        getImagingEnvironmentTemperature(index_type imageIndex) const = 0;


        /**
         * Get the AnnotationRef property of Instrument.
         *
         * @param instrumentIndex the Instrument index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getInstrumentAnnotationRef(index_type instrumentIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of Instrument.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the ID property.
         */
        virtual const std::string&
        getInstrumentID(index_type instrumentIndex) const = 0;



        /**
         * Get the AnnotationRef property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLabelAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getLabelFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getLabelFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getLabelFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getLabelFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getLabelFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getLabelID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getLabelLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getLabelStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getLabelStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getLabelStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getLabelText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLabelTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLabelTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLabelTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getLabelTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X property.
         */
        virtual double
        getLabelX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y property of Label.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y property.
         */
        virtual double
        getLabelY(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the AnnotationRef property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLaserAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FrequencyMultiplication property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the FrequencyMultiplication property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getLaserFrequencyMultiplication(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the ID property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the ID property.
         */
        virtual const std::string&
        getLaserID(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LaserMedium property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LaserMedium property.
         */
        virtual ome::xml::model::enums::LaserMedium
        getLaserLaserMedium(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LotNumber property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getLaserLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Manufacturer property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getLaserManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Model property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Model property.
         */
        virtual const std::string&
        getLaserModel(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the PockelCell property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the PockelCell property.
         */
        virtual bool
        getLaserPockelCell(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Power property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Power property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getLaserPower(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Pulse property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Pulse property.
         */
        virtual ome::xml::model::enums::Pulse
        getLaserPulse(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Pump property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Pump property.
         */
        virtual const std::string&
        getLaserPump(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the RepetitionRate property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the RepetitionRate property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsFrequency > 
        getLaserRepetitionRate(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the SerialNumber property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getLaserSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Tuneable property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Tuneable property.
         */
        virtual bool
        getLaserTuneable(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Type property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::LaserType
        getLaserType(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Wavelength property of Laser.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Wavelength property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getLaserWavelength(index_type instrumentIndex, index_type lightSourceIndex) const = 0;



        /**
         * Get the AnnotationRef property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLightEmittingDiodeAnnotationRef(index_type instrumentIndex, index_type lightSourceIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ID property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the ID property.
         */
        virtual const std::string&
        getLightEmittingDiodeID(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the LotNumber property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getLightEmittingDiodeLotNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Manufacturer property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getLightEmittingDiodeManufacturer(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Model property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Model property.
         */
        virtual const std::string&
        getLightEmittingDiodeModel(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the Power property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the Power property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsPower > 
        getLightEmittingDiodePower(index_type instrumentIndex, index_type lightSourceIndex) const = 0;

        /**
         * Get the SerialNumber property of LightEmittingDiode.
         *
         * @param instrumentIndex the Instrument index.
         * @param lightSourceIndex the LightSource index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getLightEmittingDiodeSerialNumber(index_type instrumentIndex, index_type lightSourceIndex) const = 0;


        /**
         * Get the AnnotationRef property of LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLightPathAnnotationRef(index_type imageIndex, index_type channelIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the DichroicRef property of LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the DichroicRef property.
         */
        virtual const std::string&
        getLightPathDichroicRef(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the EmissionFilterRef property of LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param emissionFilterRefIndex EmissionFilterRef index.
         * @returns the EmissionFilterRef property.
         */
        virtual const std::string&
        getLightPathEmissionFilterRef(index_type imageIndex, index_type channelIndex, index_type emissionFilterRefIndex) const = 0;

        /**
         * Get the ExcitationFilterRef property of LightPath.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @param excitationFilterRefIndex ExcitationFilterRef index.
         * @returns the ExcitationFilterRef property.
         */
        virtual const std::string&
        getLightPathExcitationFilterRef(index_type imageIndex, index_type channelIndex, index_type excitationFilterRefIndex) const = 0;


        /**
         * Get the Attenuation property of LightSourceSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Attenuation property.
         */
        virtual ome::xml::model::primitives::PercentFraction
        getChannelLightSourceSettingsAttenuation(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Attenuation property of LightSourceSettings.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         * @returns the Attenuation property.
         */
        virtual ome::xml::model::primitives::PercentFraction
        getMicrobeamManipulationLightSourceSettingsAttenuation(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const = 0;

        /**
         * Get the ID property of LightSourceSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the ID property.
         */
        virtual const std::string&
        getChannelLightSourceSettingsID(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the ID property of LightSourceSettings.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         * @returns the ID property.
         */
        virtual const std::string&
        getMicrobeamManipulationLightSourceSettingsID(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const = 0;

        /**
         * Get the Wavelength property of LightSourceSettings.
         *
         * @param imageIndex the Image index.
         * @param channelIndex the Channel index.
         * @returns the Wavelength property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getChannelLightSourceSettingsWavelength(index_type imageIndex, index_type channelIndex) const = 0;

        /**
         * Get the Wavelength property of LightSourceSettings.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param lightSourceSettingsIndex the LightSourceSettings index.
         * @returns the Wavelength property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getMicrobeamManipulationLightSourceSettingsWavelength(index_type experimentIndex, index_type microbeamManipulationIndex, index_type lightSourceSettingsIndex) const = 0;


        /**
         * Get the AnnotationRef property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLineAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getLineFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getLineFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getLineFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getLineFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getLineFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getLineID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getLineLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the MarkerEnd property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the MarkerEnd property.
         */
        virtual ome::xml::model::enums::Marker
        getLineMarkerEnd(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the MarkerStart property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the MarkerStart property.
         */
        virtual ome::xml::model::enums::Marker
        getLineMarkerStart(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getLineStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getLineStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getLineStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getLineText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLineTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLineTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getLineTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getLineTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X1 property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X1 property.
         */
        virtual double
        getLineX1(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X2 property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X2 property.
         */
        virtual double
        getLineX2(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y1 property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y1 property.
         */
        virtual double
        getLineY1(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y2 property of Line.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y2 property.
         */
        virtual double
        getLineY2(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the AnnotationRef property of ListAnnotation.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getListAnnotationAnnotationRef(index_type listAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of ListAnnotation.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getListAnnotationAnnotator(index_type listAnnotationIndex) const = 0;

        /**
         * Get the Description property of ListAnnotation.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getListAnnotationDescription(index_type listAnnotationIndex) const = 0;

        /**
         * Get the ID property of ListAnnotation.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getListAnnotationID(index_type listAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of ListAnnotation.
         *
         * @param listAnnotationIndex the ListAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getListAnnotationNamespace(index_type listAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getLongAnnotationAnnotationRef(index_type longAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getLongAnnotationAnnotator(index_type longAnnotationIndex) const = 0;

        /**
         * Get the Description property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getLongAnnotationDescription(index_type longAnnotationIndex) const = 0;

        /**
         * Get the ID property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getLongAnnotationID(index_type longAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getLongAnnotationNamespace(index_type longAnnotationIndex) const = 0;

        /**
         * Get the Value property of LongAnnotation.
         *
         * @param longAnnotationIndex the LongAnnotation index.
         * @returns the Value property.
         */
        virtual int64_t
        getLongAnnotationValue(index_type longAnnotationIndex) const = 0;



        /**
         * Get the AnnotationRef property of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getMapAnnotationAnnotationRef(index_type mapAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getMapAnnotationAnnotator(index_type mapAnnotationIndex) const = 0;

        /**
         * Get the Description property of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getMapAnnotationDescription(index_type mapAnnotationIndex) const = 0;

        /**
         * Get the ID property of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getMapAnnotationID(index_type mapAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of MapAnnotation.
         *
         * @param mapAnnotationIndex the MapAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getMapAnnotationNamespace(index_type mapAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getMaskAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getMaskFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getMaskFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getMaskFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getMaskFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getMaskFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Height property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Height property.
         */
        virtual double
        getMaskHeight(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getMaskID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getMaskLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getMaskStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getMaskStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getMaskStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getMaskText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getMaskTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getMaskTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getMaskTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getMaskTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Width property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Width property.
         */
        virtual double
        getMaskWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X property.
         */
        virtual double
        getMaskX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y property of Mask.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y property.
         */
        virtual double
        getMaskY(index_type ROIIndex, index_type shapeIndex) const = 0;



        /**
         * Get the Description property of MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getMicrobeamManipulationDescription(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;

        /**
         * Get the ExperimenterRef property of MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getMicrobeamManipulationExperimenterRef(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;

        /**
         * Get the ID property of MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getMicrobeamManipulationID(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;

        /**
         * Get the ROIRef property of MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @param ROIRefIndex ROIRef index.
         * @returns the ROIRef property.
         */
        virtual const std::string&
        getMicrobeamManipulationROIRef(index_type experimentIndex, index_type microbeamManipulationIndex, index_type ROIRefIndex) const = 0;

        /**
         * Get the Type property of MicrobeamManipulation.
         *
         * @param experimentIndex the Experiment index.
         * @param microbeamManipulationIndex the MicrobeamManipulation index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::MicrobeamManipulationType
        getMicrobeamManipulationType(index_type experimentIndex, index_type microbeamManipulationIndex) const = 0;



        /**
         * Get the LotNumber property of Microscope.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getMicroscopeLotNumber(index_type instrumentIndex) const = 0;

        /**
         * Get the Manufacturer property of Microscope.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getMicroscopeManufacturer(index_type instrumentIndex) const = 0;

        /**
         * Get the Model property of Microscope.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the Model property.
         */
        virtual const std::string&
        getMicroscopeModel(index_type instrumentIndex) const = 0;

        /**
         * Get the SerialNumber property of Microscope.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getMicroscopeSerialNumber(index_type instrumentIndex) const = 0;

        /**
         * Get the Type property of Microscope.
         *
         * @param instrumentIndex the Instrument index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::MicroscopeType
        getMicroscopeType(index_type instrumentIndex) const = 0;


        /**
         * Get the AnnotationRef property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getObjectiveAnnotationRef(index_type instrumentIndex, index_type objectiveIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the CalibratedMagnification property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the CalibratedMagnification property.
         */
        virtual double
        getObjectiveCalibratedMagnification(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the Correction property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the Correction property.
         */
        virtual ome::xml::model::enums::Correction
        getObjectiveCorrection(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the ID property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the ID property.
         */
        virtual const std::string&
        getObjectiveID(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the Immersion property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the Immersion property.
         */
        virtual ome::xml::model::enums::Immersion
        getObjectiveImmersion(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the Iris property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the Iris property.
         */
        virtual bool
        getObjectiveIris(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the LensNA property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the LensNA property.
         */
        virtual double
        getObjectiveLensNA(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the LotNumber property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the LotNumber property.
         */
        virtual const std::string&
        getObjectiveLotNumber(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the Manufacturer property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the Manufacturer property.
         */
        virtual const std::string&
        getObjectiveManufacturer(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the Model property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the Model property.
         */
        virtual const std::string&
        getObjectiveModel(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the NominalMagnification property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the NominalMagnification property.
         */
        virtual double
        getObjectiveNominalMagnification(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the SerialNumber property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the SerialNumber property.
         */
        virtual const std::string&
        getObjectiveSerialNumber(index_type instrumentIndex, index_type objectiveIndex) const = 0;

        /**
         * Get the WorkingDistance property of Objective.
         *
         * @param instrumentIndex the Instrument index.
         * @param objectiveIndex the Objective index.
         * @returns the WorkingDistance property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getObjectiveWorkingDistance(index_type instrumentIndex, index_type objectiveIndex) const = 0;


        /**
         * Get the CorrectionCollar property of ObjectiveSettings.
         *
         * @param imageIndex the Image index.
         * @returns the CorrectionCollar property.
         */
        virtual double
        getObjectiveSettingsCorrectionCollar(index_type imageIndex) const = 0;

        /**
         * Get the ID property of ObjectiveSettings.
         *
         * @param imageIndex the Image index.
         * @returns the ID property.
         */
        virtual const std::string&
        getObjectiveSettingsID(index_type imageIndex) const = 0;

        /**
         * Get the Medium property of ObjectiveSettings.
         *
         * @param imageIndex the Image index.
         * @returns the Medium property.
         */
        virtual ome::xml::model::enums::Medium
        getObjectiveSettingsMedium(index_type imageIndex) const = 0;

        /**
         * Get the RefractiveIndex property of ObjectiveSettings.
         *
         * @param imageIndex the Image index.
         * @returns the RefractiveIndex property.
         */
        virtual double
        getObjectiveSettingsRefractiveIndex(index_type imageIndex) const = 0;


        /**
         * Get the BigEndian property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the BigEndian property.
         */
        virtual bool
        getPixelsBigEndian(index_type imageIndex) const = 0;

        /**
         * Get the DimensionOrder property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the DimensionOrder property.
         */
        virtual ome::xml::model::enums::DimensionOrder
        getPixelsDimensionOrder(index_type imageIndex) const = 0;

        /**
         * Get the ID property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPixelsID(index_type imageIndex) const = 0;

        /**
         * Get the Interleaved property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the Interleaved property.
         */
        virtual bool
        getPixelsInterleaved(index_type imageIndex) const = 0;

        /**
         * Get the PhysicalSizeX property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the PhysicalSizeX property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeX(index_type imageIndex) const = 0;

        /**
         * Get the PhysicalSizeY property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the PhysicalSizeY property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeY(index_type imageIndex) const = 0;

        /**
         * Get the PhysicalSizeZ property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the PhysicalSizeZ property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getPixelsPhysicalSizeZ(index_type imageIndex) const = 0;

        /**
         * Get the SignificantBits property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SignificantBits property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSignificantBits(index_type imageIndex) const = 0;

        /**
         * Get the SizeC property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SizeC property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSizeC(index_type imageIndex) const = 0;

        /**
         * Get the SizeT property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SizeT property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSizeT(index_type imageIndex) const = 0;

        /**
         * Get the SizeX property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SizeX property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSizeX(index_type imageIndex) const = 0;

        /**
         * Get the SizeY property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SizeY property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSizeY(index_type imageIndex) const = 0;

        /**
         * Get the SizeZ property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the SizeZ property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPixelsSizeZ(index_type imageIndex) const = 0;

        /**
         * Get the TimeIncrement property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the TimeIncrement property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPixelsTimeIncrement(index_type imageIndex) const = 0;

        /**
         * Get the Type property of Pixels.
         *
         * @param imageIndex the Image index.
         * @returns the Type property.
         */
        virtual ome::xml::model::enums::PixelType
        getPixelsType(index_type imageIndex) const = 0;


        /**
         * Get the AnnotationRef property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPlaneAnnotationRef(index_type imageIndex, index_type planeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the DeltaT property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the DeltaT property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPlaneDeltaT(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the ExposureTime property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the ExposureTime property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsTime > 
        getPlaneExposureTime(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the HashSHA1 property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the HashSHA1 property.
         */
        virtual const std::string&
        getPlaneHashSHA1(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the PositionX property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the PositionX property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionX(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the PositionY property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the PositionY property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionY(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the PositionZ property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the PositionZ property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlanePositionZ(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the TheC property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheC(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the TheT property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheT(index_type imageIndex, index_type planeIndex) const = 0;

        /**
         * Get the TheZ property of Plane.
         *
         * @param imageIndex the Image index.
         * @param planeIndex the Plane index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPlaneTheZ(index_type imageIndex, index_type planeIndex) const = 0;


        /**
         * Get the AnnotationRef property of Plate.
         *
         * @param plateIndex the Plate index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPlateAnnotationRef(index_type plateIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the ColumnNamingConvention property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the ColumnNamingConvention property.
         */
        virtual ome::xml::model::enums::NamingConvention
        getPlateColumnNamingConvention(index_type plateIndex) const = 0;

        /**
         * Get the Columns property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the Columns property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPlateColumns(index_type plateIndex) const = 0;

        /**
         * Get the Description property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the Description property.
         */
        virtual const std::string&
        getPlateDescription(index_type plateIndex) const = 0;

        /**
         * Get the ExternalIdentifier property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the ExternalIdentifier property.
         */
        virtual const std::string&
        getPlateExternalIdentifier(index_type plateIndex) const = 0;

        /**
         * Get the FieldIndex property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the FieldIndex property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPlateFieldIndex(index_type plateIndex) const = 0;

        /**
         * Get the ID property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPlateID(index_type plateIndex) const = 0;

        /**
         * Get the Name property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the Name property.
         */
        virtual const std::string&
        getPlateName(index_type plateIndex) const = 0;

        /**
         * Get the RowNamingConvention property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the RowNamingConvention property.
         */
        virtual ome::xml::model::enums::NamingConvention
        getPlateRowNamingConvention(index_type plateIndex) const = 0;

        /**
         * Get the Rows property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the Rows property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPlateRows(index_type plateIndex) const = 0;

        /**
         * Get the Status property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the Status property.
         */
        virtual const std::string&
        getPlateStatus(index_type plateIndex) const = 0;

        /**
         * Get the WellOriginX property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the WellOriginX property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlateWellOriginX(index_type plateIndex) const = 0;

        /**
         * Get the WellOriginY property of Plate.
         *
         * @param plateIndex the Plate index.
         * @returns the WellOriginY property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPlateWellOriginY(index_type plateIndex) const = 0;


        /**
         * Get the AnnotationRef property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPlateAcquisitionAnnotationRef(index_type plateIndex, index_type plateAcquisitionIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the Description property.
         */
        virtual const std::string&
        getPlateAcquisitionDescription(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the EndTime property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the EndTime property.
         */
        virtual ome::xml::model::primitives::Timestamp
        getPlateAcquisitionEndTime(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the ID property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPlateAcquisitionID(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the MaximumFieldCount property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the MaximumFieldCount property.
         */
        virtual ome::xml::model::primitives::PositiveInteger
        getPlateAcquisitionMaximumFieldCount(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the Name property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the Name property.
         */
        virtual const std::string&
        getPlateAcquisitionName(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the StartTime property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @returns the StartTime property.
         */
        virtual ome::xml::model::primitives::Timestamp
        getPlateAcquisitionStartTime(index_type plateIndex, index_type plateAcquisitionIndex) const = 0;

        /**
         * Get the WellSampleRef property of PlateAcquisition.
         *
         * @param plateIndex the Plate index.
         * @param plateAcquisitionIndex the PlateAcquisition index.
         * @param wellSampleRefIndex WellSampleRef index.
         * @returns the WellSampleRef property.
         */
        virtual const std::string&
        getPlateAcquisitionWellSampleRef(index_type plateIndex, index_type plateAcquisitionIndex, index_type wellSampleRefIndex) const = 0;



        /**
         * Get the AnnotationRef property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPointAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPointFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getPointFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getPointFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPointFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getPointFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPointID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getPointLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPointStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getPointStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPointStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getPointText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPointTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPointTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPointTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getPointTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X property.
         */
        virtual double
        getPointX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y property of Point.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y property.
         */
        virtual double
        getPointY(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the AnnotationRef property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPolygonAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPolygonFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getPolygonFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getPolygonFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPolygonFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getPolygonFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPolygonID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getPolygonLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Points property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Points property.
         */
        virtual const std::string&
        getPolygonPoints(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPolygonStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getPolygonStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPolygonStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getPolygonText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolygonTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Polygon.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getPolygonTransform(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the AnnotationRef property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getPolylineAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPolylineFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getPolylineFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getPolylineFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getPolylineFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getPolylineFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getPolylineID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getPolylineLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the MarkerEnd property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the MarkerEnd property.
         */
        virtual ome::xml::model::enums::Marker
        getPolylineMarkerEnd(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the MarkerStart property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the MarkerStart property.
         */
        virtual ome::xml::model::enums::Marker
        getPolylineMarkerStart(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Points property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Points property.
         */
        virtual const std::string&
        getPolylinePoints(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getPolylineStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getPolylineStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getPolylineStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getPolylineText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getPolylineTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Polyline.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getPolylineTransform(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the AnnotationRef property of Project.
         *
         * @param projectIndex the Project index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getProjectAnnotationRef(index_type projectIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the DatasetRef property of Project.
         *
         * @param projectIndex the Project index.
         * @param datasetRefIndex DatasetRef index.
         * @returns the DatasetRef property.
         */
        virtual const std::string&
        getProjectDatasetRef(index_type projectIndex, index_type datasetRefIndex) const = 0;

        /**
         * Get the Description property of Project.
         *
         * @param projectIndex the Project index.
         * @returns the Description property.
         */
        virtual const std::string&
        getProjectDescription(index_type projectIndex) const = 0;

        /**
         * Get the ExperimenterGroupRef property of Project.
         *
         * @param projectIndex the Project index.
         * @returns the ExperimenterGroupRef property.
         */
        virtual const std::string&
        getProjectExperimenterGroupRef(index_type projectIndex) const = 0;

        /**
         * Get the ExperimenterRef property of Project.
         *
         * @param projectIndex the Project index.
         * @returns the ExperimenterRef property.
         */
        virtual const std::string&
        getProjectExperimenterRef(index_type projectIndex) const = 0;

        /**
         * Get the ID property of Project.
         *
         * @param projectIndex the Project index.
         * @returns the ID property.
         */
        virtual const std::string&
        getProjectID(index_type projectIndex) const = 0;

        /**
         * Get the Name property of Project.
         *
         * @param projectIndex the Project index.
         * @returns the Name property.
         */
        virtual const std::string&
        getProjectName(index_type projectIndex) const = 0;



        /**
         * Get the AnnotationRef property of ROI.
         *
         * @param ROIIndex the ROI index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getROIAnnotationRef(index_type ROIIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of ROI.
         *
         * @param ROIIndex the ROI index.
         * @returns the Description property.
         */
        virtual const std::string&
        getROIDescription(index_type ROIIndex) const = 0;

        /**
         * Get the ID property of ROI.
         *
         * @param ROIIndex the ROI index.
         * @returns the ID property.
         */
        virtual const std::string&
        getROIID(index_type ROIIndex) const = 0;

        /**
         * Get the Name property of ROI.
         *
         * @param ROIIndex the ROI index.
         * @returns the Name property.
         */
        virtual const std::string&
        getROIName(index_type ROIIndex) const = 0;



        /**
         * Get the AnnotationRef property of Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getReagentAnnotationRef(index_type screenIndex, index_type reagentIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @returns the Description property.
         */
        virtual const std::string&
        getReagentDescription(index_type screenIndex, index_type reagentIndex) const = 0;

        /**
         * Get the ID property of Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @returns the ID property.
         */
        virtual const std::string&
        getReagentID(index_type screenIndex, index_type reagentIndex) const = 0;

        /**
         * Get the Name property of Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @returns the Name property.
         */
        virtual const std::string&
        getReagentName(index_type screenIndex, index_type reagentIndex) const = 0;

        /**
         * Get the ReagentIdentifier property of Reagent.
         *
         * @param screenIndex the Screen index.
         * @param reagentIndex the Reagent index.
         * @returns the ReagentIdentifier property.
         */
        virtual const std::string&
        getReagentReagentIdentifier(index_type screenIndex, index_type reagentIndex) const = 0;



        /**
         * Get the AnnotationRef property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getRectangleAnnotationRef(index_type ROIIndex, index_type shapeIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the FillColor property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillColor property.
         */
        virtual ome::xml::model::primitives::Color
        getRectangleFillColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FillRule property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FillRule property.
         */
        virtual ome::xml::model::enums::FillRule
        getRectangleFillRule(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontFamily property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontFamily property.
         */
        virtual ome::xml::model::enums::FontFamily
        getRectangleFontFamily(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontSize property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontSize property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeInteger > 
        getRectangleFontSize(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the FontStyle property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the FontStyle property.
         */
        virtual ome::xml::model::enums::FontStyle
        getRectangleFontStyle(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Height property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Height property.
         */
        virtual double
        getRectangleHeight(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the ID property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the ID property.
         */
        virtual const std::string&
        getRectangleID(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Locked property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Locked property.
         */
        virtual bool
        getRectangleLocked(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeColor property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeColor property.
         */
        virtual ome::xml::model::primitives::Color
        getRectangleStrokeColor(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeDashArray property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeDashArray property.
         */
        virtual const std::string&
        getRectangleStrokeDashArray(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the StrokeWidth property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the StrokeWidth property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getRectangleStrokeWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Text property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Text property.
         */
        virtual const std::string&
        getRectangleText(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheC property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheC(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheT property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheT(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the TheZ property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the TheZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getRectangleTheZ(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Transform property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Transform property.
         */
        virtual const ::ome::xml::model::AffineTransform&
        getRectangleTransform(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Width property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Width property.
         */
        virtual double
        getRectangleWidth(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the X property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the X property.
         */
        virtual double
        getRectangleX(index_type ROIIndex, index_type shapeIndex) const = 0;

        /**
         * Get the Y property of Rectangle.
         *
         * @param ROIIndex the ROI index.
         * @param shapeIndex the Shape index.
         * @returns the Y property.
         */
        virtual double
        getRectangleY(index_type ROIIndex, index_type shapeIndex) const = 0;


        /**
         * Get the RightsHeld property of Rights.
         *
         * @returns the RightsHeld property.
         */
        virtual const std::string&
        getRightsRightsHeld() const = 0;

        /**
         * Get the RightsHolder property of Rights.
         *
         * @returns the RightsHolder property.
         */
        virtual const std::string&
        getRightsRightsHolder() const = 0;


        /**
         * Get the AnnotationRef property of Screen.
         *
         * @param screenIndex the Screen index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getScreenAnnotationRef(index_type screenIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Description property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the Description property.
         */
        virtual const std::string&
        getScreenDescription(index_type screenIndex) const = 0;

        /**
         * Get the ID property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the ID property.
         */
        virtual const std::string&
        getScreenID(index_type screenIndex) const = 0;

        /**
         * Get the Name property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the Name property.
         */
        virtual const std::string&
        getScreenName(index_type screenIndex) const = 0;

        /**
         * Get the PlateRef property of Screen.
         *
         * @param screenIndex the Screen index.
         * @param plateRefIndex PlateRef index.
         * @returns the PlateRef property.
         */
        virtual const std::string&
        getScreenPlateRef(index_type screenIndex, index_type plateRefIndex) const = 0;

        /**
         * Get the ProtocolDescription property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the ProtocolDescription property.
         */
        virtual const std::string&
        getScreenProtocolDescription(index_type screenIndex) const = 0;

        /**
         * Get the ProtocolIdentifier property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the ProtocolIdentifier property.
         */
        virtual const std::string&
        getScreenProtocolIdentifier(index_type screenIndex) const = 0;

        /**
         * Get the ReagentSetDescription property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the ReagentSetDescription property.
         */
        virtual const std::string&
        getScreenReagentSetDescription(index_type screenIndex) const = 0;

        /**
         * Get the ReagentSetIdentifier property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the ReagentSetIdentifier property.
         */
        virtual const std::string&
        getScreenReagentSetIdentifier(index_type screenIndex) const = 0;

        /**
         * Get the Type property of Screen.
         *
         * @param screenIndex the Screen index.
         * @returns the Type property.
         */
        virtual const std::string&
        getScreenType(index_type screenIndex) const = 0;


        /**
         * Get the Name property of StageLabel.
         *
         * @param imageIndex the Image index.
         * @returns the Name property.
         */
        virtual const std::string&
        getStageLabelName(index_type imageIndex) const = 0;

        /**
         * Get the X property of StageLabel.
         *
         * @param imageIndex the Image index.
         * @returns the X property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelX(index_type imageIndex) const = 0;

        /**
         * Get the Y property of StageLabel.
         *
         * @param imageIndex the Image index.
         * @returns the Y property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelY(index_type imageIndex) const = 0;

        /**
         * Get the Z property of StageLabel.
         *
         * @param imageIndex the Image index.
         * @returns the Z property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getStageLabelZ(index_type imageIndex) const = 0;



        /**
         * Get the AnnotationRef property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getTagAnnotationAnnotationRef(index_type tagAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getTagAnnotationAnnotator(index_type tagAnnotationIndex) const = 0;

        /**
         * Get the Description property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getTagAnnotationDescription(index_type tagAnnotationIndex) const = 0;

        /**
         * Get the ID property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getTagAnnotationID(index_type tagAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getTagAnnotationNamespace(index_type tagAnnotationIndex) const = 0;

        /**
         * Get the Value property of TagAnnotation.
         *
         * @param tagAnnotationIndex the TagAnnotation index.
         * @returns the Value property.
         */
        virtual const std::string&
        getTagAnnotationValue(index_type tagAnnotationIndex) const = 0;


        /**
         * Get the AnnotationRef property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getTermAnnotationAnnotationRef(index_type termAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getTermAnnotationAnnotator(index_type termAnnotationIndex) const = 0;

        /**
         * Get the Description property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getTermAnnotationDescription(index_type termAnnotationIndex) const = 0;

        /**
         * Get the ID property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getTermAnnotationID(index_type termAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getTermAnnotationNamespace(index_type termAnnotationIndex) const = 0;

        /**
         * Get the Value property of TermAnnotation.
         *
         * @param termAnnotationIndex the TermAnnotation index.
         * @returns the Value property.
         */
        virtual const std::string&
        getTermAnnotationValue(index_type termAnnotationIndex) const = 0;


        /**
         * Get the FirstC property of TiffData.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the FirstC property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstC(index_type imageIndex, index_type tiffDataIndex) const = 0;

        /**
         * Get the FirstT property of TiffData.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the FirstT property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstT(index_type imageIndex, index_type tiffDataIndex) const = 0;

        /**
         * Get the FirstZ property of TiffData.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the FirstZ property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getTiffDataFirstZ(index_type imageIndex, index_type tiffDataIndex) const = 0;

        /**
         * Get the IFD property of TiffData.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the IFD property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getTiffDataIFD(index_type imageIndex, index_type tiffDataIndex) const = 0;

        /**
         * Get the PlaneCount property of TiffData.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the PlaneCount property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getTiffDataPlaneCount(index_type imageIndex, index_type tiffDataIndex) const = 0;


        /**
         * Get the AnnotationRef property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getTimestampAnnotationAnnotationRef(index_type timestampAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getTimestampAnnotationAnnotator(index_type timestampAnnotationIndex) const = 0;

        /**
         * Get the Description property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getTimestampAnnotationDescription(index_type timestampAnnotationIndex) const = 0;

        /**
         * Get the ID property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getTimestampAnnotationID(index_type timestampAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getTimestampAnnotationNamespace(index_type timestampAnnotationIndex) const = 0;

        /**
         * Get the Value property of TimestampAnnotation.
         *
         * @param timestampAnnotationIndex the TimestampAnnotation index.
         * @returns the Value property.
         */
        virtual ome::xml::model::primitives::Timestamp
        getTimestampAnnotationValue(index_type timestampAnnotationIndex) const = 0;


        /**
         * Get the CutIn property of TransmittanceRange.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the CutIn property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getTransmittanceRangeCutIn(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the CutInTolerance property of TransmittanceRange.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the CutInTolerance property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat > 
        getTransmittanceRangeCutInTolerance(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the CutOut property of TransmittanceRange.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the CutOut property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::PositiveFloat > 
        getTransmittanceRangeCutOut(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the CutOutTolerance property of TransmittanceRange.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the CutOutTolerance property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength, ome::xml::model::primitives::NonNegativeFloat > 
        getTransmittanceRangeCutOutTolerance(index_type instrumentIndex, index_type filterIndex) const = 0;

        /**
         * Get the Transmittance property of TransmittanceRange.
         *
         * @param instrumentIndex the Instrument index.
         * @param filterIndex the Filter index.
         * @returns the Transmittance property.
         */
        virtual ome::xml::model::primitives::PercentFraction
        getTransmittanceRangeTransmittance(index_type instrumentIndex, index_type filterIndex) const = 0;


        /**
         * Get the FileName property of UUID.
         *
         * @param imageIndex the Image index.
         * @param tiffDataIndex the TiffData index.
         * @returns the FileName property.
         */
        virtual const std::string&
        getUUIDFileName(index_type imageIndex, index_type tiffDataIndex) const = 0;



        /**
         * Get the AnnotationRef property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getWellAnnotationRef(index_type plateIndex, index_type wellIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Color property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the Color property.
         */
        virtual ome::xml::model::primitives::Color
        getWellColor(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the Column property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the Column property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getWellColumn(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the ExternalDescription property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the ExternalDescription property.
         */
        virtual const std::string&
        getWellExternalDescription(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the ExternalIdentifier property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the ExternalIdentifier property.
         */
        virtual const std::string&
        getWellExternalIdentifier(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the ID property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the ID property.
         */
        virtual const std::string&
        getWellID(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the ReagentRef property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the ReagentRef property.
         */
        virtual const std::string&
        getWellReagentRef(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the Row property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the Row property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getWellRow(index_type plateIndex, index_type wellIndex) const = 0;

        /**
         * Get the Type property of Well.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @returns the Type property.
         */
        virtual const std::string&
        getWellType(index_type plateIndex, index_type wellIndex) const = 0;


        /**
         * Get the ID property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the ID property.
         */
        virtual const std::string&
        getWellSampleID(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;

        /**
         * Get the ImageRef property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the ImageRef property.
         */
        virtual const std::string&
        getWellSampleImageRef(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;

        /**
         * Get the Index property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the Index property.
         */
        virtual ome::xml::model::primitives::NonNegativeInteger
        getWellSampleIndex(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;

        /**
         * Get the PositionX property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the PositionX property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getWellSamplePositionX(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;

        /**
         * Get the PositionY property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the PositionY property.
         */
        virtual ome::xml::model::primitives::Quantity<ome::xml::model::enums::UnitsLength > 
        getWellSamplePositionY(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;

        /**
         * Get the Timepoint property of WellSample.
         *
         * @param plateIndex the Plate index.
         * @param wellIndex the Well index.
         * @param wellSampleIndex the WellSample index.
         * @returns the Timepoint property.
         */
        virtual ome::xml::model::primitives::Timestamp
        getWellSampleTimepoint(index_type plateIndex, index_type wellIndex, index_type wellSampleIndex) const = 0;



        /**
         * Get the AnnotationRef property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @param annotationRefIndex AnnotationRef index.
         * @returns the AnnotationRef property.
         */
        virtual const std::string&
        getXMLAnnotationAnnotationRef(index_type XMLAnnotationIndex, index_type annotationRefIndex) const = 0;

        /**
         * Get the Annotator property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @returns the Annotator property.
         */
        virtual const std::string&
        getXMLAnnotationAnnotator(index_type XMLAnnotationIndex) const = 0;

        /**
         * Get the Description property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @returns the Description property.
         */
        virtual const std::string&
        getXMLAnnotationDescription(index_type XMLAnnotationIndex) const = 0;

        /**
         * Get the ID property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @returns the ID property.
         */
        virtual const std::string&
        getXMLAnnotationID(index_type XMLAnnotationIndex) const = 0;

        /**
         * Get the Namespace property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @returns the Namespace property.
         */
        virtual const std::string&
        getXMLAnnotationNamespace(index_type XMLAnnotationIndex) const = 0;

        /**
         * Get the Value property of XMLAnnotation.
         *
         * @param XMLAnnotationIndex the XMLAnnotation index.
         * @returns the Value property.
         */
        virtual const std::string&
        getXMLAnnotationValue(index_type XMLAnnotationIndex) const = 0;

      };

    }
  }
}

#endif // OME_XML_META_METADATARETRIEVE_H

/*
 * Local Variables:
 * mode:C++
 * End:
 */
