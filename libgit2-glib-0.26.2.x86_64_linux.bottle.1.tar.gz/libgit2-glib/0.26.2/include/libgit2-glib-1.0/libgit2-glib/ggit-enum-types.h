
/* Generated data (by glib-mkenums) */

#ifndef __GGIT_ENUM_TYPES_H__
#define __GGIT_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS
/* Enumerations from "./ggit-types.h" */
#define GGIT_TYPE_BRANCH_TYPE	(ggit_branch_type_get_type())
GType ggit_branch_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_FEATURE_FLAGS	(ggit_feature_flags_get_type())
GType ggit_feature_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_BINARY_TYPE	(ggit_diff_binary_type_get_type())
GType ggit_diff_binary_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_BLAME_FLAGS	(ggit_blame_flags_get_type())
GType ggit_blame_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CONFIG_LEVEL	(ggit_config_level_get_type())
GType ggit_config_level_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CREATE_FLAGS	(ggit_create_flags_get_type())
GType ggit_create_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DELTA_TYPE	(ggit_delta_type_get_type())
GType ggit_delta_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_FORMAT_TYPE	(ggit_diff_format_type_get_type())
GType ggit_diff_format_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_OPTION	(ggit_diff_option_get_type())
GType ggit_diff_option_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_FLAG	(ggit_diff_flag_get_type())
GType ggit_diff_flag_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_LINE_TYPE	(ggit_diff_line_type_get_type())
GType ggit_diff_line_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_ERROR	(ggit_error_get_type())
GType ggit_error_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_FILE_MODE	(ggit_file_mode_get_type())
GType ggit_file_mode_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_MERGE_FILE_FAVOR	(ggit_merge_file_favor_get_type())
GType ggit_merge_file_favor_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_MERGE_FILE_FLAGS	(ggit_merge_file_flags_get_type())
GType ggit_merge_file_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_MERGE_FLAGS	(ggit_merge_flags_get_type())
GType ggit_merge_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_PROXY_TYPE	(ggit_proxy_type_get_type())
GType ggit_proxy_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_REBASE_OPERATION_TYPE	(ggit_rebase_operation_type_get_type())
GType ggit_rebase_operation_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_REMOTE_DOWNLOAD_TAGS_TYPE	(ggit_remote_download_tags_type_get_type())
GType ggit_remote_download_tags_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_REMOTE_COMPLETION_TYPE	(ggit_remote_completion_type_get_type())
GType ggit_remote_completion_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_REF_TYPE	(ggit_ref_type_get_type())
GType ggit_ref_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_RESET_TYPE	(ggit_reset_type_get_type())
GType ggit_reset_type_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_SORT_MODE	(ggit_sort_mode_get_type())
GType ggit_sort_mode_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_STASH_FLAGS	(ggit_stash_flags_get_type())
GType ggit_stash_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_STATUS_FLAGS	(ggit_status_flags_get_type())
GType ggit_status_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_SUBMODULE_IGNORE	(ggit_submodule_ignore_get_type())
GType ggit_submodule_ignore_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_SUBMODULE_RECURSE	(ggit_submodule_recurse_get_type())
GType ggit_submodule_recurse_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_SUBMODULE_STATUS	(ggit_submodule_status_get_type())
GType ggit_submodule_status_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_SUBMODULE_UPDATE	(ggit_submodule_update_get_type())
GType ggit_submodule_update_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_TREE_WALK_MODE	(ggit_tree_walk_mode_get_type())
GType ggit_tree_walk_mode_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_STATUS_OPTION	(ggit_status_option_get_type())
GType ggit_status_option_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_STATUS_SHOW	(ggit_status_show_get_type())
GType ggit_status_show_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_ATTRIBUTE_CHECK_FLAGS	(ggit_attribute_check_flags_get_type())
GType ggit_attribute_check_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_PACKBUILDER_STAGE	(ggit_packbuilder_stage_get_type())
GType ggit_packbuilder_stage_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CHECKOUT_STRATEGY	(ggit_checkout_strategy_get_type())
GType ggit_checkout_strategy_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CHECKOUT_NOTIFY_FLAGS	(ggit_checkout_notify_flags_get_type())
GType ggit_checkout_notify_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_FIND_FLAGS	(ggit_diff_find_flags_get_type())
GType ggit_diff_find_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIFF_FORMAT_EMAIL_FLAGS	(ggit_diff_format_email_flags_get_type())
GType ggit_diff_format_email_flags_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CREDTYPE	(ggit_credtype_get_type())
GType ggit_credtype_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_DIRECTION	(ggit_direction_get_type())
GType ggit_direction_get_type	(void) G_GNUC_CONST;
#define GGIT_TYPE_CLONE_LOCAL	(ggit_clone_local_get_type())
GType ggit_clone_local_get_type	(void) G_GNUC_CONST;
G_END_DECLS

#endif /* __GGIT_ENUM_TYPES_H__ */

/* Generated data ends here */

