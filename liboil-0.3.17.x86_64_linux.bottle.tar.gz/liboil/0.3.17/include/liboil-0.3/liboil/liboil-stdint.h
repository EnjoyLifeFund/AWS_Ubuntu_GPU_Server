#ifndef _LIBOIL_LIBOIL_LIBOIL_STDINT_H
#define _LIBOIL_LIBOIL_LIBOIL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "liboil 0.3.17"
/* generated using gnu compiler gcc-6 (Homebrew GCC 6.4.0) 6.4.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
