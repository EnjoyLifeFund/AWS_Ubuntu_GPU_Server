class Mantaflow < Formula
  desc "Open computer graphics fluid simulation framework"
  homepage "http://mantaflow.com/"
  url "http://mantaflow.com/download/manta-src-0.11.tar.gz"
  sha256 "2aa1d26a85696dd233f6b2276c0ef3972192bf2e0e9abb908118ee427cc10463"
  head "https://bitbucket.org/mantaflow/manta.git"

  deprecated_option "with-qt5" => "with-qt"

  option "with-openmp", "Build with OpenMP support"
  option "with-qt", "Build the QT GUI version"

  depends_on "cmake" => :build
  depends_on "qt" => :optional
  depends_on :python if MacOS.version <= :snow_leopard

  needs :openmp if build.with? "openmp"
  needs :cxx11

  def install
    ENV.cxx11
    args = std_cmake_args

    args << "-DOPENMP=ON" if build.with? "openmp"
    args << "-DGUI=ON" if build.with? "qt"

    mkdir "build" do
      system "cmake", "..", *args
      system "make"

      bin.install "manta"

      # Symlink 'mantaflow' to avoid confusion when getting started with mantaflow
      # Actual command is 'manta'
      bin.install_symlink "manta" => "mantaflow"
    end

    # Copy the python sample scene files
    pkgshare.install Dir["scenes/*"]
  end

  test do
    touch "foo.py"
    assert_match "Script finished.", shell_output("#{bin}/manta foo.py")
  end
end
