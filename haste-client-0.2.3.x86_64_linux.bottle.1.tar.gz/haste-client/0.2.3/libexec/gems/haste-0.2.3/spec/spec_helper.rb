require 'ostruct'

require File.dirname(__FILE__) + '/../lib/haste'
