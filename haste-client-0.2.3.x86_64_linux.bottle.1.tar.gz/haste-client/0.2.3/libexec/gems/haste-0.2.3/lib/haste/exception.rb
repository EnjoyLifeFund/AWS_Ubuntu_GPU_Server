module Haste
  class Exception < StandardError
  end
end
