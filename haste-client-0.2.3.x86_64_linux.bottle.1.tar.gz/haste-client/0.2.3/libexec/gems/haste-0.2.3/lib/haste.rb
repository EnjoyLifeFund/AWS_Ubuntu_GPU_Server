require File.dirname(__FILE__) + '/haste/uploader'
require File.dirname(__FILE__) + '/haste/exception'
require File.dirname(__FILE__) + '/haste/cli'

module Haste
end
