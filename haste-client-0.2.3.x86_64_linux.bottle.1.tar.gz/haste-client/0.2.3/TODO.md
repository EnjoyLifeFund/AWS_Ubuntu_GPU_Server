* make streaming
* display feedback from errors in console
