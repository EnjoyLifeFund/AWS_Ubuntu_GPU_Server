# Fn CLI
[![CircleCI](https://circleci.com/gh/fnproject/cli.svg?style=svg)](https://circleci.com/gh/fnproject/cli)

## Install

```sh
curl -LSs https://raw.githubusercontent.com/fnproject/cli/master/install | sh
```

## Quickstart

See the Fn [Quickstart](https://github.com/fnproject/fn/blob/master/README.md) for sample commands.
