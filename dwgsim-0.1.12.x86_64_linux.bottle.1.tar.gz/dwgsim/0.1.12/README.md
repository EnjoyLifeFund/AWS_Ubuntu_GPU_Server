[![Build Status](https://travis-ci.org/nh13/DWGSIM.svg?branch=master)](https://travis-ci.org/nh13/DWGSIM)

Welcome to DWGSIM.

Please see the file LICENSE for details.
Please see the file INSTALL for installation instructions;

This software package has limited support since it is not longer in active development.

Please use the following command when cloning this repository:

```git clone --recursive``` 

Please see the following page for more details:
https://github.com/nh13/DWGSIM/wiki
