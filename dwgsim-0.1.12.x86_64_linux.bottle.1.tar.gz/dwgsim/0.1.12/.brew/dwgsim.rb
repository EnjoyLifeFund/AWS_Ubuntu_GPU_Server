class Dwgsim < Formula
  homepage "https://github.com/nh13/DWGSIM"
  url "https://github.com/nh13/DWGSIM.git",
    :tag => "dwgsim.0.1.12",
    :revision => "4fd56bf39dbba3801856fa0512aed68726e3ca6e"
  head "https://github.com/nh13/DWGSIM.git"
  # tag "bioinformatics"

  unless OS.mac?
    # dwgsim builds a vendored copy of samtools, which requires ncurses.
    depends_on "ncurses" => :build
    depends_on "zlib"
  end

  def install
    system "make"
    bin.install "dwgsim", "dwgsim_eval"
  end

  test do
    assert_match "Usage", shell_output("#{bin}/dwgsim -h 2>&1", 1)
  end
end
