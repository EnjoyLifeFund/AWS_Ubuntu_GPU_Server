var searchData=
[
  ['query',['Query',['../a00309.html',1,'']]]
];
