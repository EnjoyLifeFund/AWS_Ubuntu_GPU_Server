var searchData=
[
  ['quarter',['quarter',['../a00127.html#aa0efc92bb0079287e043bb2c46c4603d',1,'tdsdaterec']]],
  ['query',['query',['../a00096.html#aeec2a01af48693b8b22449f15725d502',1,'tds_cursor::query()'],['../a00101.html#a1cee141e5f7045e691eec830cec1c158',1,'tds_dynamic::query()'],['../a00039.html#afa2e1d84866eb33ef18a19e78c0af7ae',1,'_hstmt::query()']]],
  ['query_5flen',['query_len',['../a00096.html#a062a1a5306aef74ceb8dd445260b06f9',1,'tds_cursor']]],
  ['query_5ftimeout',['query_timeout',['../a00058.html#abf71abb24c7afea7dd7ef440048ea4c9',1,'dblib_context']]]
];
