var searchData=
[
  ['loginrec',['LOGINREC',['../a00070.html',1,'']]]
];
