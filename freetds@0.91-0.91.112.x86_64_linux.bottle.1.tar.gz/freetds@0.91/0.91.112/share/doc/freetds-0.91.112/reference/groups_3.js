var searchData=
[
  ['datetime_20functions',['Datetime functions',['../a00299.html',1,'']]],
  ['dynamic_20string_20functions',['Dynamic string functions',['../a00311.html',1,'']]]
];
