var searchData=
[
  ['options',['options',['../a00096.html#a1be9f69f84a6d83ce86380c33a2bf9f8',1,'tds_cursor']]],
  ['origdsn',['origdsn',['../a00068.html#a8127a82b8c4130820a4c44f88eda8bcf',1,'DSNINFO']]],
  ['out_5fbuf',['out_buf',['../a00122.html#ad6b5121e435d22d640a645b98833cb9d',1,'tds_socket']]],
  ['out_5fflag',['out_flag',['../a00122.html#a9bb663ee7c71f56f1602cbfcd993018c',1,'tds_socket']]],
  ['out_5fpos',['out_pos',['../a00122.html#a426adbd80f29f477377e42e8f78d3ff0',1,'tds_socket']]]
];
