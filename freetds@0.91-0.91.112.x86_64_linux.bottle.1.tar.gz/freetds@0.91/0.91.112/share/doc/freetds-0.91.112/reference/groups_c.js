var searchData=
[
  ['the_20db_2dlib_20api',['The db-lib API',['../a00293.html',1,'']]]
];
