var searchData=
[
  ['odbc_20api',['ODBC API',['../a00302.html',1,'']]],
  ['odbc_20utility',['ODBC utility',['../a00303.html',1,'']]]
];
