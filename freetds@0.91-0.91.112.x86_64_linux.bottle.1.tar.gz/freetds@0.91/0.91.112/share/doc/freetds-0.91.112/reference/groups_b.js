var searchData=
[
  ['remote_20procedure_20functions',['Remote Procedure functions',['../a00295.html',1,'']]],
  ['results_20processing',['Results processing',['../a00312.html',1,'']]]
];
