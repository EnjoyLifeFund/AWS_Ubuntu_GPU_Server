var searchData=
[
  ['_5ftds_5fstate',['_TDS_STATE',['../a00162.html#a4fa5fe915f5b796690c577a55dd71a17',1,'tds.h']]]
];
