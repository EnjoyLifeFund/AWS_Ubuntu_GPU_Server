var searchData=
[
  ['uad',['uad',['../a00034.html#a93c0c73d7161aa0c8fd59016e66def9e',1,'_hdbc']]],
  ['user_5fname',['user_name',['../a00094.html#aed5b79ef1611590fbaafde80d85425cf',1,'tds_connection']]]
];
