var searchData=
[
  ['libtds_20api',['LibTDS API',['../a00313.html',1,'']]]
];
