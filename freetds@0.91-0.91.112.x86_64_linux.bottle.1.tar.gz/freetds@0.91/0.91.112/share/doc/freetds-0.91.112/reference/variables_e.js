var searchData=
[
  ['tds_5fctx',['tds_ctx',['../a00058.html#afb3fb2d591c0f75b9412f8ca77e2629d',1,'dblib_context']]],
  ['tds_5fctx_5fref_5fcount',['tds_ctx_ref_count',['../a00058.html#ad01d901acbc92e8c369e6a6c784d7446',1,'dblib_context']]],
  ['tds_5fnumeric_5fbytes_5fper_5fprec',['tds_numeric_bytes_per_prec',['../a00162.html#a4da9eedb6322f7dfca89d5d89be7b374',1,'numeric.c']]],
  ['tm_5fhour',['tm_hour',['../a00124.html#a6ece03e77f69035da83d5739e16ef905',1,'tds_time']]],
  ['tm_5fmday',['tm_mday',['../a00124.html#a8dfc26d484c247040f521f20288651f1',1,'tds_time']]],
  ['tm_5fmin',['tm_min',['../a00124.html#ab50f30e05dc6b493d347918ab7ded1e9',1,'tds_time']]],
  ['tm_5fmon',['tm_mon',['../a00124.html#adce28126e9bbd4ef005e3bf181d59745',1,'tds_time']]],
  ['tm_5fms',['tm_ms',['../a00124.html#ac5418f5b3754b063d2b822a52cde4cf4',1,'tds_time']]],
  ['tm_5fsec',['tm_sec',['../a00124.html#adeb5e3f535662c0341d28f8d669cb59b',1,'tds_time']]],
  ['tm_5fyear',['tm_year',['../a00124.html#a3e27d50ebb5196356a6a8a9b495c8758',1,'tds_time']]],
  ['type',['type',['../a00096.html#a889aafdde1d57c9be0585326022831f0',1,'tds_cursor']]]
];
