var searchData=
[
  ['remote_20procedure_20functions',['Remote Procedure functions',['../a00295.html',1,'']]],
  ['ref_5fcount',['ref_count',['../a00058.html#a812580afdfca53b6d54a7d09938c65c2',1,'dblib_context::ref_count()'],['../a00096.html#a692ccceff71d836df0d084ec26123c2d',1,'tds_cursor::ref_count()']]],
  ['res_5finfo',['res_info',['../a00101.html#ac736e163c0d4cdbca980a861214d99e7',1,'tds_dynamic']]],
  ['resinfo',['resinfo',['../a00057.html#ad49b82677ae277e5d5b0038f522da293',1,'dblib_buffer_row']]],
  ['ret_5fstatus',['ret_status',['../a00122.html#a355e0b8c6219908747f82cd7482c6efb',1,'tds_socket']]],
  ['row',['row',['../a00057.html#a015599345b266045d8bd3fac731e4675',1,'dblib_buffer_row']]],
  ['row_5fcount',['row_count',['../a00039.html#a8fd44f3c44ae4c83a1bdda0b73776ecd',1,'_hstmt']]],
  ['row_5fdata',['row_data',['../a00057.html#a5a057d6bbecfac1a85a9fbcd09eaf3a0',1,'dblib_buffer_row']]],
  ['row_5fstatus',['row_status',['../a00039.html#a41dd89b2dc41fe0e747580f6ea807063',1,'_hstmt']]],
  ['rows_5faffected',['rows_affected',['../a00122.html#a803e29dabc76d35227f5de2488f29877',1,'tds_socket']]],
  ['rtrim',['rtrim',['../a00297.html#ga4d5be57b25a0654e2170fd656dc35489',1,'bcp.c']]],
  ['results_20processing',['Results processing',['../a00312.html',1,'']]]
];
