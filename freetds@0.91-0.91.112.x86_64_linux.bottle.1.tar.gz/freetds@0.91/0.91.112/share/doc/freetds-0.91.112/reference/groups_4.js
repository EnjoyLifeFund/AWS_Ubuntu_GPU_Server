var searchData=
[
  ['internal_20bcp_20functions',['Internal bcp functions',['../a00297.html',1,'']]],
  ['internals',['Internals',['../a00300.html',1,'']]]
];
