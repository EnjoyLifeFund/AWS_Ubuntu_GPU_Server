libconfig
=========

C/C++ library for processing structured configuration files.

Visit the [libconfig project page](https://hyperrealm.github.io/libconfig/)
for distribution tarballs and other info.
