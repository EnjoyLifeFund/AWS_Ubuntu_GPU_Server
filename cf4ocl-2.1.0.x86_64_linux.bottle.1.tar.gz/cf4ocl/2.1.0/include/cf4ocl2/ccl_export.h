
#ifndef CCL_EXPORT_H
#define CCL_EXPORT_H

#ifdef CCL_STATIC_DEFINE
#  define CCL_EXPORT
#  define CCL_NO_EXPORT
#else
#  ifndef CCL_EXPORT
#    ifdef cf4ocl2_EXPORTS
        /* We are building this library */
#      define CCL_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CCL_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CCL_NO_EXPORT
#    define CCL_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CCL_DEPRECATED
#  define CCL_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CCL_DEPRECATED_EXPORT
#  define CCL_DEPRECATED_EXPORT CCL_EXPORT CCL_DEPRECATED
#endif

#ifndef CCL_DEPRECATED_NO_EXPORT
#  define CCL_DEPRECATED_NO_EXPORT CCL_NO_EXPORT CCL_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CCL_NO_DEPRECATED
#    define CCL_NO_DEPRECATED
#  endif
#endif

#endif
