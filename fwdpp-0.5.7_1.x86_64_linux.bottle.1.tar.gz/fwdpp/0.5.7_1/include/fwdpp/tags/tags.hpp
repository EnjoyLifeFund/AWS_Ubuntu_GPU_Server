#ifndef __FWDPP_TAGS_TAGS_HPP__
#define __FWDPP_TAGS_TAGS_HPP__

namespace KTfwd
{
    namespace tags
    {
        //! Empty struct acts like a dispatch tag for KTfwd::gamete_base 
        struct standard_gamete
        {
        };
    }
}

#endif
