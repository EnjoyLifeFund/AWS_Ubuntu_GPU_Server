/*!
 * \file version.hpp
 * \brief fwdpp version information
 */
#ifndef FWDPP_VERSION_HPP_
#define FWDPP_VERSION_HPP_

#define FWDPP_VERSION_MAJOR 0
#define FWDPP_VERSION_MINOR 5
#define FWDPP_VERSION_REVISION 7
#define FWDPP_VERSION_STRING "0.5.7"

#endif
