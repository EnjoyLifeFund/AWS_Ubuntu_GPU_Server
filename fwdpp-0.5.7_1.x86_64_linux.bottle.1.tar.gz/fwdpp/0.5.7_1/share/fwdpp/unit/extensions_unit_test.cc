#define BOOST_TEST_MODULE extensions_unit_tests
#include <boost/test/included/unit_test.hpp>
