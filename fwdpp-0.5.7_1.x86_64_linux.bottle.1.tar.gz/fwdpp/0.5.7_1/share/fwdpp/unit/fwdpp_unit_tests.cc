#define BOOST_TEST_MODULE fwdpp_unit_tests
#include <boost/test/included/unit_test.hpp>
