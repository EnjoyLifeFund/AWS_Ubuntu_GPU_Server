# Changelog #

## Version 0.1 ##

initial version

## Version 0.2 ##

* new parser (generated with ANTLR3) that is twice as fast as my own parser in 0.1
* some bugfixes

## Version 0.3 and 0.4 ##

* improved encoding handling
* more pbxproj files can be parsed
* fixed handling of strings
