module Lolcat
  VERSION = "90.8.8"
end
