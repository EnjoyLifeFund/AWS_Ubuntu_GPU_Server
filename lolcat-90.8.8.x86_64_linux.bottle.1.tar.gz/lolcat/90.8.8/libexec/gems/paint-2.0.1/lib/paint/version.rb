module Paint
  VERSION = '2.0.1'.freeze
end
