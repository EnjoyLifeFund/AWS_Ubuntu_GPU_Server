var alphabet_8h =
[
    [ "vrna_ptypes", "group__utils.html#ga51a9e86a5f731f5f2f5584ee67cee4a8", null ],
    [ "vrna_seq_encode", "group__utils.html#ga636e7d6f888fd639587296a5eddea660", null ],
    [ "vrna_seq_encode_simple", "group__utils.html#ga3cd79d21d53248ad2634c1c0d43e97d7", null ],
    [ "vrna_nucleotide_encode", "group__utils.html#gac12bf00123f88621c9be847b0879c1fb", null ],
    [ "vrna_nucleotide_decode", "group__utils.html#ga48ef585e697be9c8a08ed68c655e29b6", null ]
];