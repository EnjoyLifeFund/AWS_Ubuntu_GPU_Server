var group__domains =
[
    [ "Unstructured domains", "group__domains__up.html", "group__domains__up" ],
    [ "Structured domains", "group__domains__struc.html", "group__domains__struc" ]
];