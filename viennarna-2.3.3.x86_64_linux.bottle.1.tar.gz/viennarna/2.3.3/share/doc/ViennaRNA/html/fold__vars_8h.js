var fold__vars_8h =
[
    [ "fold_constrained", "fold__vars_8h.html#a0afc287c2464866d94858c39175154af", null ],
    [ "csv", "fold__vars_8h.html#af2763d55a74663a5e60652b8880baa5b", null ],
    [ "RibosumFile", "fold__vars_8h.html#a5dbaa0cca2c8c82048a0f0e38e164944", null ],
    [ "james_rule", "fold__vars_8h.html#af349001ad3b4d008d0051d935b1b6261", null ],
    [ "logML", "fold__vars_8h.html#a80c3c5fd35e7479704cc91d2d0367743", null ],
    [ "cut_point", "fold__vars_8h.html#ab9b2c3a37a5516614c06d0ab54b97cda", null ],
    [ "base_pair", "fold__vars_8h.html#a0244a629b5ab4f58b77590c3dfd130dc", null ],
    [ "pr", "fold__vars_8h.html#ac98ec419070aee6831b44e5c700f090f", null ],
    [ "iindx", "fold__vars_8h.html#a92089ae3a51b5d75a14ce9cc29cc8317", null ]
];