var group__inverse__fold =
[
    [ "inverse.h", "inverse_8h.html", null ],
    [ "inverse_fold", "group__inverse__fold.html#ga7af026de55d4babad879f2c92559cbbc", null ],
    [ "inverse_pf_fold", "group__inverse__fold.html#gaeef52ecbf2a2450ad585a344f9826806", null ],
    [ "symbolset", "group__inverse__fold.html#ga8f791e7740a5a28b9f6fafb4e60301d9", null ],
    [ "final_cost", "group__inverse__fold.html#ga7f17d3b169af048d32bb185039a9c09c", null ],
    [ "give_up", "group__inverse__fold.html#ga7ec4ba51f86e1717a1e174264e4a75ce", null ],
    [ "inv_verbose", "group__inverse__fold.html#gafcfc65fba01b9cca5946726ed9057a63", null ]
];