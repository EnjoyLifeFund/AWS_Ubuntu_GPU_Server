var group__kl__neighborhood__mfe =
[
    [ "vrna_sol_TwoD_t", "group__kl__neighborhood__mfe.html#structvrna__sol__TwoD__t", [
      [ "k", "group__kl__neighborhood__mfe.html#ac111e850bb3b3a11b6b5707912cfa1b8", null ],
      [ "l", "group__kl__neighborhood__mfe.html#ab8e95cd920901175a2cc8de726ab1d36", null ],
      [ "en", "group__kl__neighborhood__mfe.html#a7577863a6a84224dfee39b321c03cab1", null ],
      [ "s", "group__kl__neighborhood__mfe.html#ac5942d2505a6cd7e4a8073a321d5d2d5", null ]
    ] ],
    [ "TwoDfold_vars", "group__kl__neighborhood__mfe.html#structTwoDfold__vars", [
      [ "P", "group__kl__neighborhood__mfe.html#a70da9e83ad87c37013b4bf0b265dd307", null ],
      [ "do_backtrack", "group__kl__neighborhood__mfe.html#ade5c7e9337a458ae20bac75abdc52d64", null ],
      [ "ptype", "group__kl__neighborhood__mfe.html#aedf60b8b26dae05ad266d3e098d18208", null ],
      [ "sequence", "group__kl__neighborhood__mfe.html#a3596f3d4d320318c4b8428e2abc7ab56", null ],
      [ "S1", "group__kl__neighborhood__mfe.html#ab9ee459ffbfb5d2c138a033516056cdc", null ],
      [ "maxD1", "group__kl__neighborhood__mfe.html#a621ed2ab02116f3f8f5e7120dec429eb", null ],
      [ "maxD2", "group__kl__neighborhood__mfe.html#a03f198a4abdb3b784486d2ba5c533aa4", null ],
      [ "mm1", "group__kl__neighborhood__mfe.html#aa11f5bcd8c4fe70a91c155c877c855d5", null ],
      [ "mm2", "group__kl__neighborhood__mfe.html#a2eaa93316b6beb17531f0c078806036c", null ],
      [ "my_iindx", "group__kl__neighborhood__mfe.html#a1a20cb06b58b75d1a3dbdbc8bc60d0a7", null ],
      [ "referenceBPs1", "group__kl__neighborhood__mfe.html#a536525b98c1b633d4c5f2da4f8d78c18", null ],
      [ "referenceBPs2", "group__kl__neighborhood__mfe.html#aa7abf73c3114cb5f0dc90e702fa9dd0f", null ],
      [ "bpdist", "group__kl__neighborhood__mfe.html#af1106e1a592e2dccc92b3452340549e0", null ]
    ] ],
    [ "vrna_sol_TwoD_t", "group__kl__neighborhood__mfe.html#ga6a81a58268d250309712549a3fa0aab2", null ],
    [ "TwoDfold_vars", "group__kl__neighborhood__mfe.html#gaf4f514010a14f9d59d850742b3e96954", null ],
    [ "vrna_mfe_TwoD", "group__kl__neighborhood__mfe.html#ga243c288b463147352829df04de6a2f77", null ],
    [ "vrna_backtrack5_TwoD", "group__kl__neighborhood__mfe.html#ga15a96fc96f4f4c2e01a11b3e17d1ef43", null ],
    [ "get_TwoDfold_variables", "group__kl__neighborhood__mfe.html#gac9284f132cf0eaa0a2f43590eda05488", null ],
    [ "destroy_TwoDfold_variables", "group__kl__neighborhood__mfe.html#ga05bf4f31d216b1b160fd2d3d68e9b487", null ],
    [ "TwoDfoldList", "group__kl__neighborhood__mfe.html#ga7fc5e3e92fe97914ca4eccd33c01c2a7", null ],
    [ "TwoDfold_backtrack_f5", "group__kl__neighborhood__mfe.html#gaf4dc05bf8fc1ea53acd7aeb798ba80c2", null ]
];