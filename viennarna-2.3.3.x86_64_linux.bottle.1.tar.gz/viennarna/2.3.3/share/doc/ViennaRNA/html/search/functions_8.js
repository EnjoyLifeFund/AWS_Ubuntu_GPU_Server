var searchData=
[
  ['init_5fco_5fpf_5ffold',['init_co_pf_fold',['../part__func__co_8h.html#aa12dda9dd6179cdd22bcce87c0682c07',1,'part_func_co.h']]],
  ['init_5fpf_5ffold',['init_pf_fold',['../part__func_8h.html#a15176e23eceeff8c7d14eabcfec8a2af',1,'part_func.h']]],
  ['init_5fpf_5ffoldlp',['init_pf_foldLP',['../LPfold_8h.html#ae85bf55053e9fb295208be322e0fa07a',1,'LPfold.h']]],
  ['init_5frand',['init_rand',['../utils_8h.html#a8aaa6d9be6f803f496d9b97375c371f3',1,'utils.h']]],
  ['initialize_5fcofold',['initialize_cofold',['../group__mfe__cofold.html#gafee0c32208aa2ac97338b6e3fbad7fa5',1,'cofold.h']]],
  ['initialize_5ffold',['initialize_fold',['../group__mfe__fold__single.html#gac3f0a28d9cb609d388b155445073fd20',1,'fold.h']]],
  ['int_5furn',['int_urn',['../utils_8h.html#a68ff0849d44f62fe491800378a5ffcb4',1,'utils.h']]],
  ['inverse_5ffold',['inverse_fold',['../group__inverse__fold.html#ga7af026de55d4babad879f2c92559cbbc',1,'inverse.h']]],
  ['inverse_5fpf_5ffold',['inverse_pf_fold',['../group__inverse__fold.html#gaeef52ecbf2a2450ad585a344f9826806',1,'inverse.h']]]
];
