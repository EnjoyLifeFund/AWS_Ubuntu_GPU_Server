var searchData=
[
  ['destroy_5ftwodfold_5fvariables',['destroy_TwoDfold_variables',['../group__kl__neighborhood__mfe.html#ga05bf4f31d216b1b160fd2d3d68e9b487',1,'2Dfold.h']]],
  ['destroy_5ftwodpfold_5fvariables',['destroy_TwoDpfold_variables',['../2Dpfold_8h.html#afe994291458ee2ac34d3eb825ef62a15',1,'2Dpfold.h']]]
];
