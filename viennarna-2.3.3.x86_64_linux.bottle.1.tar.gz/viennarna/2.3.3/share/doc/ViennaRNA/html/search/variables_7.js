var searchData=
[
  ['h',['H',['../group__data__structures.html#ac9034ac9a84ed0647587659d6e9be1e8',1,'pu_contrib']]],
  ['hc',['hc',['../group__fold__compound.html#aceaa904dbf50092d403ca99422e8f824',1,'vrna_fc_s']]],
  ['header',['header',['../group__data__structures.html#ac9e9e30b16e7d04c770460b8487fb09d',1,'pu_out']]],
  ['helix_5fsize',['helix_size',['../group__struct__utils.html#ga8218c0d581a3fba2a1a56a196abe19a5',1,'RNAstruct.h']]]
];
