var searchData=
[
  ['scripting_20language_20interface_28s_29',['Scripting Language interface(s)',['../scripting.html',1,'']]],
  ['swig_20wrapper_20notes',['SWIG Wrapper Notes',['../wrappers.html',1,'']]]
];
