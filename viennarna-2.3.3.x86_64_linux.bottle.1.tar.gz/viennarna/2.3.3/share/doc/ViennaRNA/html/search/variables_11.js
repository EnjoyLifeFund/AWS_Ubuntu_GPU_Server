var searchData=
[
  ['reference_5fpt1',['reference_pt1',['../group__fold__compound.html#aa279ba4bd0ff541d435d3a049687f3ac',1,'vrna_fc_s']]],
  ['reference_5fpt2',['reference_pt2',['../group__fold__compound.html#a926ad253f5f0eed642bc227493d0278d',1,'vrna_fc_s']]],
  ['referencebps1',['referenceBPs1',['../group__kl__neighborhood__mfe.html#a536525b98c1b633d4c5f2da4f8d78c18',1,'TwoDfold_vars::referenceBPs1()'],['../structTwoDpfold__vars.html#aea15706d27b6b0fc19f5773919f43a8a',1,'TwoDpfold_vars::referenceBPs1()'],['../group__fold__compound.html#a62a8d4ab8dadffbf09da917adff6c71e',1,'vrna_fc_s::referenceBPs1()']]],
  ['referencebps2',['referenceBPs2',['../group__kl__neighborhood__mfe.html#aa7abf73c3114cb5f0dc90e702fa9dd0f',1,'TwoDfold_vars::referenceBPs2()'],['../structTwoDpfold__vars.html#a1221396d712bf76b7f35297f2ab35a9f',1,'TwoDpfold_vars::referenceBPs2()'],['../group__fold__compound.html#a19187f33433e84683730dedff8544f71',1,'vrna_fc_s::referenceBPs2()']]],
  ['ribo',['ribo',['../structvrna__md__s.html#a3df2ae4bd9c133ef8ab92a53b1d035ec',1,'vrna_md_s::ribo()'],['../group__model__details.html#ga0656afca1d2853f9ee6591172f5638de',1,'ribo():&#160;model.h']]],
  ['ribosumfile',['RibosumFile',['../fold__vars_8h.html#a5dbaa0cca2c8c82048a0f0e38e164944',1,'fold_vars.h']]],
  ['rna_5fplot_5ftype',['rna_plot_type',['../group__plotting__utils.html#ga5964c4581431b098b80027d6e14dcdd4',1,'plot_layouts.h']]],
  ['rtype',['rtype',['../structvrna__md__s.html#ad082d0fea31e002b90cdfe5e6382f8b0',1,'vrna_md_s']]]
];
