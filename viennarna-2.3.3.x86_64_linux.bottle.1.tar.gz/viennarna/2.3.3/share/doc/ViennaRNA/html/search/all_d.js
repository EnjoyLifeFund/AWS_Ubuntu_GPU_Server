var searchData=
[
  ['k',['k',['../group__kl__neighborhood__mfe.html#ac111e850bb3b3a11b6b5707912cfa1b8',1,'vrna_sol_TwoD_t::k()'],['../group__kl__neighborhood__pf.html#ad1f23b46dc4ebd373abdeb0382d87b83',1,'vrna_sol_TwoD_pf_t::k()'],['../group__data__structures.html#a61e457fbf943d57364be6ddf1b4e7b8a',1,'interact::k()']]],
  ['k0',['K0',['../energy__const_8h.html#a307c72605e3713972b4f4fb2d53ea20e',1,'energy_const.h']]]
];
