var searchData=
[
  ['dangles',['dangles',['../structvrna__md__s.html#adcda4ff2ea77748ae0e8700288282efc',1,'vrna_md_s::dangles()'],['../group__model__details.html#ga72b511ed1201f7e23ec437e468790d74',1,'dangles():&#160;model.h']]],
  ['data',['data',['../group__hard__constraints.html#acef3d722142cb5f4a8e114e5fbce3b1a',1,'vrna_hc_s::data()'],['../group__soft__constraints.html#a7574680143df97b9029146c2150bf06d',1,'vrna_sc_s::data()'],['../group__domains__up.html#a8802b1b0512999a9f35202031811ce17',1,'vrna_unstructured_domain_s::data()']]],
  ['density_5fof_5fstates',['density_of_states',['../group__dos.html#ga937634a76b46a22530a74906f1957a9e',1,'subopt.h']]],
  ['do_5fbacktrack',['do_backtrack',['../group__kl__neighborhood__mfe.html#ade5c7e9337a458ae20bac75abdc52d64',1,'TwoDfold_vars::do_backtrack()'],['../group__model__details.html#gad512b5dd4dbec60faccfe137bb474489',1,'do_backtrack():&#160;model.h']]],
  ['domains_5fstruc',['domains_struc',['../group__fold__compound.html#ac25a84f2658de0d7a54cd710c16198b1',1,'vrna_fc_s']]],
  ['domains_5fup',['domains_up',['../group__fold__compound.html#a4f70b6d32681fc8ca061236f21819ae7',1,'vrna_fc_s']]]
];
