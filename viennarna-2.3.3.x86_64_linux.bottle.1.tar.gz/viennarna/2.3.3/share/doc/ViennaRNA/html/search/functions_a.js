var searchData=
[
  ['make_5fbp_5fprofile',['Make_bp_profile',['../profiledist_8h.html#a904c7eaf4a2413567c00ac4891749d18',1,'profiledist.h']]],
  ['make_5fbp_5fprofile_5fbppm',['Make_bp_profile_bppm',['../profiledist_8h.html#a3dff26e707a2a2e65a0f759caabde6e7',1,'profiledist.h']]],
  ['make_5fpair_5ftable',['make_pair_table',['../group__struct__utils.html#ga89c32307ee50a0026f4a3131fac0845a',1,'structure_utils.h']]],
  ['make_5fpair_5ftable_5fsnoop',['make_pair_table_snoop',['../group__struct__utils.html#ga9aa3bf3b4346bb7fb88efc154dd07a79',1,'structure_utils.h']]],
  ['make_5freferencebp_5farray',['make_referenceBP_array',['../group__struct__utils.html#ga578cd9712dee812fb1c58aa3cc489864',1,'structure_utils.h']]],
  ['make_5fswstring',['Make_swString',['../stringdist_8h.html#a3125991b3a403b3f89230474deb3f22e',1,'stringdist.h']]],
  ['make_5ftree',['make_tree',['../treedist_8h.html#a08fe4d5afd385dce593b86eaf010c6e3',1,'treedist.h']]],
  ['mea',['MEA',['../group__mea__fold.html#ga396ec6144c6a74fcbab4cea6b42d76c3',1,'MEA.h']]],
  ['mean_5fbp_5fdist',['mean_bp_dist',['../part__func_8h.html#ae9556ba7ded44fe2321b6f67c3fc02a3',1,'part_func.h']]],
  ['mean_5fbp_5fdistance',['mean_bp_distance',['../group__pf__fold.html#ga79cbc375af65f11609feb6b055269e7d',1,'part_func.h']]],
  ['mean_5fbp_5fdistance_5fpr',['mean_bp_distance_pr',['../group__pf__fold.html#gad5ba36cef8d01cf4244cc09b9bf1ce1d',1,'part_func.h']]]
];
