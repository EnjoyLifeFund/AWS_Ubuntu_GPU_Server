var searchData=
[
  ['unexpand_5faligned_5ff',['unexpand_aligned_F',['../group__struct__utils.html#ga1054c4477d53b31d79d4cb132100e87a',1,'RNAstruct.h']]],
  ['unexpand_5ffull',['unexpand_Full',['../group__struct__utils.html#ga260c4b622093b76a883bf96628280de1',1,'RNAstruct.h']]],
  ['unpack_5fstructure',['unpack_structure',['../group__struct__utils.html#ga071c6921efe1eb974f115ee6fefa3c39',1,'structure_utils.h']]],
  ['unweight',['unweight',['../group__struct__utils.html#ga09a80253ac7b6bae606871ba7c6e5136',1,'RNAstruct.h']]],
  ['update_5falifold_5fparams',['update_alifold_params',['../group__consensus__fold.html#gac484c6bd429bafbd353b91044508d8e9',1,'alifold.h']]],
  ['update_5fco_5fpf_5fparams',['update_co_pf_params',['../part__func__co_8h.html#a6e0f36c1f9b7d9dd4bfbad914c1119e5',1,'part_func_co.h']]],
  ['update_5fco_5fpf_5fparams_5fpar',['update_co_pf_params_par',['../part__func__co_8h.html#a75465d7e8793db68a434d83df9a2e794',1,'part_func_co.h']]],
  ['update_5fcofold_5fparams',['update_cofold_params',['../group__mfe__cofold.html#ga4fcbf34e77b99bfbb2333d2ab0c41a57',1,'cofold.h']]],
  ['update_5fcofold_5fparams_5fpar',['update_cofold_params_par',['../group__mfe__cofold.html#gaaadbd28b4e428710529ab4098fdacad3',1,'cofold.h']]],
  ['update_5ffold_5fparams',['update_fold_params',['../group__mfe__fold__single.html#ga41bf8f6fa15b94471f7095cad9f0ccf3',1,'fold.h']]],
  ['update_5ffold_5fparams_5fpar',['update_fold_params_par',['../group__mfe__fold__single.html#gae66dc422efb8f5d56717d92d6002a9f8',1,'fold.h']]],
  ['update_5fpf_5fparams',['update_pf_params',['../group__pf__fold.html#ga384e927890f9c034ff09fa66da102d28',1,'part_func.h']]],
  ['update_5fpf_5fparams_5fpar',['update_pf_params_par',['../group__pf__fold.html#gaafe2d1b21f5418b123b088aa395e827d',1,'part_func.h']]],
  ['update_5fpf_5fparamslp',['update_pf_paramsLP',['../group__local__pf__fold.html#ga5a019014d37fe6105131dfc2fc447880',1,'LPfold.h']]],
  ['urn',['urn',['../utils_8h.html#aaa328491c84996e445d027fde9800f2e',1,'utils.h']]]
];
