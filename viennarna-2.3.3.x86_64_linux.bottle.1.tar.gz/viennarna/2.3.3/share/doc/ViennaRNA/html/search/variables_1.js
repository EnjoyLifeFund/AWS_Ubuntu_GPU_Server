var searchData=
[
  ['b0',['B0',['../group__pf__cofold.html#a5231715f610413dd5a88bc9f958cf5f3',1,'vrna_dimer_conc_s']]],
  ['backtrack',['backtrack',['../structvrna__md__s.html#a31f4471608cbdd03887f63c281823adb',1,'vrna_md_s']]],
  ['backtrack_5ftype',['backtrack_type',['../structvrna__md__s.html#abb265da25121d22ed11c8435861f0e53',1,'vrna_md_s::backtrack_type()'],['../group__model__details.html#ga83bdb43472a259c71e69fa9f70f420c3',1,'backtrack_type():&#160;model.h']]],
  ['base_5fpair',['base_pair',['../fold__vars_8h.html#a0244a629b5ab4f58b77590c3dfd130dc',1,'fold_vars.h']]],
  ['betascale',['betaScale',['../structvrna__md__s.html#a19524bf1d8d7ab590ed36edbbcaaba2c',1,'vrna_md_s']]],
  ['bp',['bp',['../structvrna__pinfo__s.html#aa5feac5559b36dcd7cb38111c45d444d',1,'vrna_pinfo_s']]],
  ['bpdist',['bpdist',['../group__kl__neighborhood__mfe.html#af1106e1a592e2dccc92b3452340549e0',1,'TwoDfold_vars::bpdist()'],['../structTwoDpfold__vars.html#accef8eaa05fa57ca33aa22cbc7b7aaff',1,'TwoDpfold_vars::bpdist()'],['../group__fold__compound.html#a5c53e55583ce096148075bc240fc2bce',1,'vrna_fc_s::bpdist()']]],
  ['bt',['bt',['../group__soft__constraints.html#a2a2aca01782c2b980d7b7fd05b9be89c',1,'vrna_sc_s']]]
];
