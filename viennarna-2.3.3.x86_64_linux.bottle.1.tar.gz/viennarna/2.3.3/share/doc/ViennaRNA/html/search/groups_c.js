var searchData=
[
  ['the_20dynamic_20programming_20matrices',['The Dynamic Programming Matrices',['../group__dp__matrices.html',1,'']]],
  ['the_20fold_20compound',['The Fold Compound',['../group__fold__compound.html',1,'']]],
  ['the_20rna_20folding_20grammar',['The RNA folding grammar',['../group__grammar.html',1,'']]]
];
