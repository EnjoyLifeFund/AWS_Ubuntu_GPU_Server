var searchData=
[
  ['dangles',['dangles',['../structvrna__md__s.html#adcda4ff2ea77748ae0e8700288282efc',1,'vrna_md_s::dangles()'],['../group__model__details.html#ga72b511ed1201f7e23ec437e468790d74',1,'dangles():&#160;model.h']]],
  ['data',['data',['../group__hard__constraints.html#acef3d722142cb5f4a8e114e5fbce3b1a',1,'vrna_hc_s::data()'],['../group__soft__constraints.html#a7574680143df97b9029146c2150bf06d',1,'vrna_sc_s::data()'],['../group__domains__up.html#a8802b1b0512999a9f35202031811ce17',1,'vrna_unstructured_domain_s::data()']]],
  ['data_20structures_20and_20preprocessor_20macros',['Data Structures and Preprocessor Macros',['../group__data__structures.html',1,'']]],
  ['data_5fstructures_2eh',['data_structures.h',['../data__structures_8h.html',1,'']]],
  ['density_5fof_5fstates',['density_of_states',['../group__dos.html#ga937634a76b46a22530a74906f1957a9e',1,'subopt.h']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['destroy_5ftwodfold_5fvariables',['destroy_TwoDfold_variables',['../group__kl__neighborhood__mfe.html#ga05bf4f31d216b1b160fd2d3d68e9b487',1,'2Dfold.h']]],
  ['destroy_5ftwodpfold_5fvariables',['destroy_TwoDpfold_variables',['../2Dpfold_8h.html#afe994291458ee2ac34d3eb825ef62a15',1,'2Dpfold.h']]],
  ['direct_20refolding_20paths_20between_20two_20secondary_20structures',['Direct refolding paths between two secondary structures',['../group__direct__paths.html',1,'']]],
  ['dist_5fvars_2eh',['dist_vars.h',['../dist__vars_8h.html',1,'']]],
  ['do_5fbacktrack',['do_backtrack',['../group__kl__neighborhood__mfe.html#ade5c7e9337a458ae20bac75abdc52d64',1,'TwoDfold_vars::do_backtrack()'],['../group__model__details.html#gad512b5dd4dbec60faccfe137bb474489',1,'do_backtrack():&#160;model.h']]],
  ['domains_5fstruc',['domains_struc',['../group__fold__compound.html#ac25a84f2658de0d7a54cd710c16198b1',1,'vrna_fc_s']]],
  ['domains_5fup',['domains_up',['../group__fold__compound.html#a4f70b6d32681fc8ca061236f21819ae7',1,'vrna_fc_s']]],
  ['dp_5fmatrices_2eh',['dp_matrices.h',['../dp__matrices_8h.html',1,'']]],
  ['duplex_2eh',['duplex.h',['../duplex_8h.html',1,'']]],
  ['duplext',['duplexT',['../group__data__structures.html#structduplexT',1,'']]],
  ['dupvar',['dupVar',['../group__data__structures.html#structdupVar',1,'dupVar'],['../group__data__structures.html#gabd3b93f9aaa9f3acce2d148bae97d24e',1,'dupVar():&#160;data_structures.h']]],
  ['distance_20based_20partitioning_20of_20the_20secondary_20structure_20space',['Distance based partitioning of the Secondary Structure Space',['../group__kl__neighborhood.html',1,'']]]
];
