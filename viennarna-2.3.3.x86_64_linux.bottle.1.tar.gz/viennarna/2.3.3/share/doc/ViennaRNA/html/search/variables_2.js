var searchData=
[
  ['c',['c',['../group__dp__matrices.html#a60a511fd42905ee4f046c56a76865bf9',1,'vrna_mx_mfe_s']]],
  ['c_5flocal',['c_local',['../group__dp__matrices.html#a116c677ece0832e6ab9cc2fd1ebfe452',1,'vrna_mx_mfe_s']]],
  ['canonicalbponly',['canonicalBPonly',['../structvrna__md__s.html#a87edce006e9daff84363ec0e6abd2182',1,'vrna_md_s::canonicalBPonly()'],['../group__model__details.html#ga22ae821b8918930e20ffa3fa84802b4b',1,'canonicalBPonly():&#160;model.h']]],
  ['circ',['circ',['../structvrna__md__s.html#a92762e1008503d4623ff5c01e358a464',1,'vrna_md_s::circ()'],['../group__model__details.html#gaf9202a1a09f5828dc731e2d9a10fa111',1,'circ():&#160;model.h']]],
  ['comp',['comp',['../structvrna__pinfo__s.html#a0720ae74ce53802a759ee9f98e9c8c43',1,'vrna_pinfo_s']]],
  ['compute_5fbpp',['compute_bpp',['../structvrna__md__s.html#aa0c3e03d9064363e27adcc92b8d0380f',1,'vrna_md_s']]],
  ['cons_5fseq',['cons_seq',['../group__fold__compound.html#ac472afde64d8b3c8b84e4809fda7d814',1,'vrna_fc_s']]],
  ['contribs',['contribs',['../group__data__structures.html#a638b0de1837cfd441871d005d3ab2938',1,'pu_out']]],
  ['cost_5fmatrix',['cost_matrix',['../dist__vars_8h.html#ab65d8ff14c6937612212526a60f59b3c',1,'dist_vars.h']]],
  ['csv',['csv',['../fold__vars_8h.html#af2763d55a74663a5e60652b8880baa5b',1,'fold_vars.h']]],
  ['cut_5fpoint',['cut_point',['../group__eval.html#gab9b2c3a37a5516614c06d0ab54b97cda',1,'cut_point():&#160;eval.h'],['../fold__vars_8h.html#ab9b2c3a37a5516614c06d0ab54b97cda',1,'cut_point():&#160;fold_vars.h']]],
  ['cutpoint',['cutpoint',['../group__fold__compound.html#ae1a7bbff0256577e2b22709bac11fdb4',1,'vrna_fc_s']]],
  ['cv_5ffact',['cv_fact',['../structvrna__md__s.html#a62ebefb9d0643e5c4c8a2ec84a105ce6',1,'vrna_md_s::cv_fact()'],['../group__consensus__fold.html#gaf3cbac6ff5d706d6e414677841ddf94c',1,'cv_fact():&#160;alifold.h']]]
];
