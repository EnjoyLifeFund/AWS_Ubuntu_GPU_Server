var searchData=
[
  ['g_2dquadruplexes',['G-quadruplexes',['../group__gquads.html',1,'']]],
  ['generate_20soft_20constraints_20from_20data',['Generate soft constraints from data',['../group__perturbation.html',1,'']]]
];
