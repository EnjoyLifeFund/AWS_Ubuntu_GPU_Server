var searchData=
[
  ['h',['H',['../group__data__structures.html#ac9034ac9a84ed0647587659d6e9be1e8',1,'pu_contrib']]],
  ['hairpin_5floops_2eh',['hairpin_loops.h',['../hairpin__loops_8h.html',1,'']]],
  ['hairpine',['HairpinE',['../group__mfe__fold__single.html#gab327ce11972f5ac069d52c8dedfdb700',1,'fold.h']]],
  ['hamming',['hamming',['../string__utils_8h.html#ad9dc7bfc9aa664dc6698f17ce07fc7e7',1,'string_utils.h']]],
  ['hamming_5fbound',['hamming_bound',['../string__utils_8h.html#a96d3c36717d624514055ce201cab1542',1,'string_utils.h']]],
  ['hard_20constraints',['Hard constraints',['../group__hard__constraints.html',1,'']]],
  ['hc',['hc',['../group__fold__compound.html#aceaa904dbf50092d403ca99422e8f824',1,'vrna_fc_s']]],
  ['header',['header',['../group__data__structures.html#ac9e9e30b16e7d04c770460b8487fb09d',1,'pu_out']]],
  ['helix_5fsize',['helix_size',['../group__struct__utils.html#ga8218c0d581a3fba2a1a56a196abe19a5',1,'RNAstruct.h']]]
];
