var searchData=
[
  ['xrealloc',['xrealloc',['../utils_8h.html#a9037ada838835b1b9db41581a021b0c8',1,'utils.h']]],
  ['xrna_5fplot',['xrna_plot',['../group__plotting__utils.html#ga2f6d5953e6a323df898896b8d6614483',1,'plot_structure.h']]],
  ['xstr',['XSTR',['../group__string__utils.html#ga03943706e48069237cd57f2d35ca987e',1,'string_utils.h']]],
  ['xsubi',['xsubi',['../group__utils.html#gaf9a866c8417afda7368bbac939ab3c47',1,'utils.h']]]
];
