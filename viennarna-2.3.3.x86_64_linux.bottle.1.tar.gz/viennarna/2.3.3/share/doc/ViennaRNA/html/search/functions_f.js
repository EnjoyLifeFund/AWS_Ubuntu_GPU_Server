var searchData=
[
  ['time_5fstamp',['time_stamp',['../utils_8h.html#a7afeb906cb36e9d77379eabc6907ac46',1,'utils.h']]],
  ['tree_5fedit_5fdistance',['tree_edit_distance',['../treedist_8h.html#a3b21f1925f7071f46d93431a835217bb',1,'treedist.h']]],
  ['twodfold_5fbacktrack_5ff5',['TwoDfold_backtrack_f5',['../group__kl__neighborhood__mfe.html#gaf4dc05bf8fc1ea53acd7aeb798ba80c2',1,'2Dfold.h']]],
  ['twodfoldlist',['TwoDfoldList',['../group__kl__neighborhood__mfe.html#ga7fc5e3e92fe97914ca4eccd33c01c2a7',1,'2Dfold.h']]],
  ['twodpfold_5fpbacktrack',['TwoDpfold_pbacktrack',['../2Dpfold_8h.html#ae251288f50dd4ae7d315af0085775f71',1,'2Dpfold.h']]],
  ['twodpfold_5fpbacktrack5',['TwoDpfold_pbacktrack5',['../2Dpfold_8h.html#a13430ac6a7f90df426774f131647d2c7',1,'2Dpfold.h']]],
  ['twodpfoldlist',['TwoDpfoldList',['../2Dpfold_8h.html#a692243dac482a1e158a8e1b7881cfda2',1,'2Dpfold.h']]]
];
