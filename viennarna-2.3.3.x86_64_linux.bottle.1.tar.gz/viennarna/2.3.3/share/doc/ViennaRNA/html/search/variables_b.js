var searchData=
[
  ['l',['l',['../group__kl__neighborhood__mfe.html#ab8e95cd920901175a2cc8de726ab1d36',1,'vrna_sol_TwoD_t::l()'],['../group__kl__neighborhood__pf.html#a01133c264eff2c988d144e07803d1b8b',1,'vrna_sol_TwoD_pf_t::l()'],['../group__data__structures.html#a030ab45056342e12cb3955e4defd3904',1,'interact::l()']]],
  ['len',['len',['../group__data__structures.html#a314b8f43c3ee0bf6060afbeced5dbe6c',1,'pu_out']]],
  ['length',['length',['../group__data__structures.html#a33d5ada6e861db0c81aa3d5b2989262e',1,'pu_contrib::length()'],['../group__data__structures.html#ac9fcb5dca54ec5faa76e02b6488b9524',1,'interact::length()'],['../group__fold__compound.html#a95fbfed770b858e50c766505dc4bf998',1,'vrna_fc_s::length()'],['../group__dp__matrices.html#a1f92a8406fc1fb721dbf9193c34ad826',1,'vrna_mx_mfe_s::length()']]],
  ['logml',['logML',['../structvrna__md__s.html#ae259f89a94acae0c7f1412603e7f57b5',1,'vrna_md_s::logML()'],['../fold__vars_8h.html#a80c3c5fd35e7479704cc91d2d0367743',1,'logML():&#160;fold_vars.h'],['../group__model__details.html#ga80c3c5fd35e7479704cc91d2d0367743',1,'logML():&#160;model.h']]],
  ['loop_5fdegree',['loop_degree',['../group__struct__utils.html#gaef14e2f8ab3f61e8e659ba6b9003b08a',1,'RNAstruct.h']]],
  ['loop_5fsize',['loop_size',['../group__struct__utils.html#ga3f31e0e48125601bfa57b52f8b038e8e',1,'RNAstruct.h']]],
  ['loops',['loops',['../group__struct__utils.html#ga439fcb9f8d4f9f4d2227fde5fbfecb30',1,'RNAstruct.h']]]
];
