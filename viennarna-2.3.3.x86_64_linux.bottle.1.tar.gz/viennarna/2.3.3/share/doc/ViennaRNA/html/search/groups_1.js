var searchData=
[
  ['data_20structures_20and_20preprocessor_20macros',['Data Structures and Preprocessor Macros',['../group__data__structures.html',1,'']]],
  ['direct_20refolding_20paths_20between_20two_20secondary_20structures',['Direct refolding paths between two secondary structures',['../group__direct__paths.html',1,'']]],
  ['distance_20based_20partitioning_20of_20the_20secondary_20structure_20space',['Distance based partitioning of the Secondary Structure Space',['../group__kl__neighborhood.html',1,'']]]
];
