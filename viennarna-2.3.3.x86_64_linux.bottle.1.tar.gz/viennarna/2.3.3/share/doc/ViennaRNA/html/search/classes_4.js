var searchData=
[
  ['node',['node',['../group__data__structures.html#structnode',1,'']]]
];
