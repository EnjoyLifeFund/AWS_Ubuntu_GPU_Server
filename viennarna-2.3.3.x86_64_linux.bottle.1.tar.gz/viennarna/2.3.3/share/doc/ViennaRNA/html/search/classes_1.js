var searchData=
[
  ['constrain',['constrain',['../group__data__structures.html#structconstrain',1,'']]],
  ['coordinate',['COORDINATE',['../structCOORDINATE.html',1,'']]]
];
