var searchData=
[
  ['flt_5for_5fdbl',['FLT_OR_DBL',['../group__data__structures.html#ga31125aeace516926bf7f251f759b6126',1,'data_structures.h']]],
  ['folden',['folden',['../group__data__structures.html#gaaf402058651c8218fa72788d591cda05',1,'data_structures.h']]]
];
