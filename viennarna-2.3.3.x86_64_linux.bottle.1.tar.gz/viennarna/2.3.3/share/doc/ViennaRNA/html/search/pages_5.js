var searchData=
[
  ['rnalib_20api_20v3_2e0',['RNAlib API v3.0',['../newAPI.html',1,'']]]
];
