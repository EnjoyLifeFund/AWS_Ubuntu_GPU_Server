var searchData=
[
  ['rna_2drna_20interaction',['RNA-RNA interaction',['../group__cofold.html',1,'']]],
  ['reading_2fwriting_20energy_20parameter_20sets_20from_2fto_20file',['Reading/Writing Energy Parameter Sets from/to File',['../group__energy__parameters__rw.html',1,'']]],
  ['refolding_20paths_20between_20secondary_20structues',['Refolding paths between secondary structues',['../group__paths.html',1,'']]]
];
