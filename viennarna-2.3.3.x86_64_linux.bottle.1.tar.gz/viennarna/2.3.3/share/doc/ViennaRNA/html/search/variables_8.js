var searchData=
[
  ['i',['i',['../structvrna__pinfo__s.html#ab91db0a87ef8402dc151795ba5a64c6f',1,'vrna_pinfo_s::i()'],['../group__data__structures.html#ab6d031a21388be8763b75ea74c937f17',1,'interact::i()'],['../group__data__structures.html#a8ca0da20536780589fb3e3472ca0581f',1,'pu_contrib::I()']]],
  ['id',['id',['../group__energy__parameters.html#a378d5bcf2bae1f3ec84c912c7d3908d2',1,'vrna_exp_param_s']]],
  ['iindx',['iindx',['../group__fold__compound.html#afdead4cf55c882d3497e779573e17e03',1,'vrna_fc_s::iindx()'],['../fold__vars_8h.html#a92089ae3a51b5d75a14ce9cc29cc8317',1,'iindx():&#160;fold_vars.h']]],
  ['inv_5fverbose',['inv_verbose',['../group__inverse__fold.html#gafcfc65fba01b9cca5946726ed9057a63',1,'inverse.h']]]
];
