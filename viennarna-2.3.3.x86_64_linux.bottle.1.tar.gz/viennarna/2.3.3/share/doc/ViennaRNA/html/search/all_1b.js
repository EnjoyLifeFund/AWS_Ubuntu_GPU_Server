var searchData=
[
  ['zukersubopt',['zukersubopt',['../group__subopt__zuker.html#ga0d5104e3ecf119d8eabd40aa5fe47f90',1,'subopt.h']]],
  ['zukersubopt_5fpar',['zukersubopt_par',['../group__subopt__zuker.html#gab6d0ea8cc1d02f6dd831ca81043c9eb8',1,'subopt.h']]]
];
