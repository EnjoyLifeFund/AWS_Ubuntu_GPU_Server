var searchData=
[
  ['u_5fvals',['u_vals',['../group__data__structures.html#a7697bc7a46cd1b8e37e337e708cb6023',1,'pu_out']]],
  ['u_5fvalues',['u_values',['../group__data__structures.html#a366edbc4170d5c177908e178ff340828',1,'pu_out']]],
  ['uniq_5fml',['uniq_ML',['../structvrna__md__s.html#ade065b814a4e2e72ead93ab502613ed2',1,'vrna_md_s::uniq_ML()'],['../group__model__details.html#ga6c5655c8b272e3e6cab74dd0f540294f',1,'uniq_ML():&#160;model.h']]],
  ['uniq_5fmotif_5fcount',['uniq_motif_count',['../group__domains__up.html#ae17005ef8043aca2fc3864804cd5def6',1,'vrna_unstructured_domain_s']]],
  ['uniq_5fmotif_5fsize',['uniq_motif_size',['../group__domains__up.html#a2b484b0e19a47145db7055ada8b14159',1,'vrna_unstructured_domain_s']]],
  ['unpaired',['unpaired',['../group__struct__utils.html#gadd2f952597e02d66e1116a9d11d252d6',1,'RNAstruct.h']]],
  ['up_5fext',['up_ext',['../group__hard__constraints.html#a60094038af04093b2fee9b883266ff75',1,'vrna_hc_s']]],
  ['up_5fhp',['up_hp',['../group__hard__constraints.html#a853255558e7e7d9eb382ac142ac8de3d',1,'vrna_hc_s']]],
  ['up_5fint',['up_int',['../group__hard__constraints.html#a455f994af0ec892d84fee1bf60d14a81',1,'vrna_hc_s']]],
  ['up_5fml',['up_ml',['../group__hard__constraints.html#aa318079c2e3cfaca8dc589cc478d3b29',1,'vrna_hc_s']]]
];
