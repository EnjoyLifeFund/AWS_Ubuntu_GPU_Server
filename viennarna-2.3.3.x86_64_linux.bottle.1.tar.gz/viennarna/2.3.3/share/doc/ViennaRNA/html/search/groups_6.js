var searchData=
[
  ['incorporating_20ligands_20binding_20to_20specific_20sequence_2fstructure_20motifs_20using_20soft_20constraints',['Incorporating ligands binding to specific sequence/structure motifs using soft constraints',['../group__constraints__ligand.html',1,'']]],
  ['inverse_20folding_20_28design_29',['Inverse Folding (Design)',['../group__inverse__fold.html',1,'']]]
];
