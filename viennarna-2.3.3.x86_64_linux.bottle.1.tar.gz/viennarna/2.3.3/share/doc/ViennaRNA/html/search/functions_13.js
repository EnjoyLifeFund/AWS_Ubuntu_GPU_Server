var searchData=
[
  ['xrealloc',['xrealloc',['../utils_8h.html#a9037ada838835b1b9db41581a021b0c8',1,'utils.h']]],
  ['xrna_5fplot',['xrna_plot',['../group__plotting__utils.html#ga2f6d5953e6a323df898896b8d6614483',1,'plot_structure.h']]]
];
