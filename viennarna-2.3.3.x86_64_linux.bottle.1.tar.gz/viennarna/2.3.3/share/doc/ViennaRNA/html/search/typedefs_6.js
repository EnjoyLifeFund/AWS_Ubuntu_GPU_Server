var searchData=
[
  ['sect',['sect',['../group__data__structures.html#gaaacedee1f05d3d45aa6764eca51a8876',1,'data_structures.h']]],
  ['solution',['SOLUTION',['../subopt_8h.html#aa0f46ff02e1017469cf902d02ecd7f9a',1,'subopt.h']]]
];
