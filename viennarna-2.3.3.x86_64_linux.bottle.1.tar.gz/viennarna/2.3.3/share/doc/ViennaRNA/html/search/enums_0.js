var searchData=
[
  ['vrna_5fcommand_5fe',['vrna_command_e',['../commands_8h.html#a2ea3e452bf3b3f3ca513b3b081a86137',1,'commands.h']]],
  ['vrna_5ffc_5ftype_5fe',['vrna_fc_type_e',['../group__fold__compound.html#ga01a4ff86fa71deaaa5d1abbd95a1447d',1,'data_structures.h']]],
  ['vrna_5fmx_5ftype_5fe',['vrna_mx_type_e',['../group__dp__matrices.html#ga6042ea1d58d01931e959791be6d89343',1,'dp_matrices.h']]],
  ['vrna_5funit_5fenergy_5fe',['vrna_unit_energy_e',['../group__units.html#ga1d2fd1e73caf995e4dc69072b33e6ba5',1,'units.h']]],
  ['vrna_5funit_5ftemperature_5fe',['vrna_unit_temperature_e',['../group__units.html#gadeca8d9e91ef85f1b652cc8aef63d7e4',1,'units.h']]]
];
