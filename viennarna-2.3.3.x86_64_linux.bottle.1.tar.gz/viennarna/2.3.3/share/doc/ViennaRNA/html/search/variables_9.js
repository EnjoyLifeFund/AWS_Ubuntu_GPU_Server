var searchData=
[
  ['j',['j',['../structvrna__pinfo__s.html#a4142e38d6ba127acccdf680300a88e1f',1,'vrna_pinfo_s::j()'],['../group__data__structures.html#a7555cb6363d1479341eb72b9c087aa34',1,'interact::j()']]],
  ['james_5frule',['james_rule',['../fold__vars_8h.html#af349001ad3b4d008d0051d935b1b6261',1,'fold_vars.h']]],
  ['jindx',['jindx',['../structTwoDpfold__vars.html#a0699e194a797532c91b284ab10272384',1,'TwoDpfold_vars::jindx()'],['../group__fold__compound.html#a5037235dee512efd85ca543780bbca1a',1,'vrna_fc_s::jindx()']]]
];
