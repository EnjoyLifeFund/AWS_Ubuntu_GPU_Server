var indexSectionsWithContent =
{
  0: "12_abcdefghijklmnopqrstuvwxz",
  1: "_cdinpstv",
  2: "12abcdefghilmnprstu",
  3: "abcdefghilmnprstuvwxz",
  4: "abcdefghijklmnopqrstuwx",
  5: "bcdfipstv",
  6: "v",
  7: "v",
  8: "bfgikmntv",
  9: "cdefghilmprstu",
  10: "bdeiprsuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

