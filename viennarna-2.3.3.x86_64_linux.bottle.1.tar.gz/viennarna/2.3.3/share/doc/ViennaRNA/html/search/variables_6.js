var searchData=
[
  ['ggg',['ggg',['../group__dp__matrices.html#a0b7b86a5c75c96eabb89eb53a13e7164',1,'vrna_mx_mfe_s']]],
  ['ggg_5flocal',['ggg_local',['../group__dp__matrices.html#afd3ea65bc8f06559f7f1ea79072fa385',1,'vrna_mx_mfe_s']]],
  ['gi',['Gi',['../group__data__structures.html#a54f8183542fff4c32ab7ace49a16c02c',1,'interact']]],
  ['gikjl',['Gikjl',['../group__data__structures.html#ad58303190f9e085c3ab59890cbf61223',1,'interact']]],
  ['gikjl_5fwo',['Gikjl_wo',['../group__data__structures.html#a41793812abae560805414761fec398fe',1,'interact']]],
  ['give_5fup',['give_up',['../group__inverse__fold.html#ga7ec4ba51f86e1717a1e174264e4a75ce',1,'inverse.h']]],
  ['gquad',['gquad',['../structvrna__md__s.html#af88a511a2b1f526b4c6213de6cb8fd6e',1,'vrna_md_s::gquad()'],['../group__model__details.html#ga25f2bdcdf56e813d288845484a13d704',1,'gquad():&#160;model.h']]]
];
