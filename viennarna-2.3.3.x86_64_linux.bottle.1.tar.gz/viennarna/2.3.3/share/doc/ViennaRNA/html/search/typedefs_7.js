var searchData=
[
  ['twodfold_5fvars',['TwoDfold_vars',['../group__kl__neighborhood__mfe.html#gaf4f514010a14f9d59d850742b3e96954',1,'2Dfold.h']]]
];
