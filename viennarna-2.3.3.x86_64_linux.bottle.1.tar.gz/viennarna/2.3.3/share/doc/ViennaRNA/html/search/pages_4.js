var searchData=
[
  ['parsing_20and_20comparing_20_2d_20functions_20to_20manipulate_20structures',['Parsing and Comparing - Functions to Manipulate Structures',['../mp_parse.html',1,'']]]
];
