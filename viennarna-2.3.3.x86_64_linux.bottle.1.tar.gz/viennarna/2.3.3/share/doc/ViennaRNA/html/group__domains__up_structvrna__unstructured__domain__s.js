var group__domains__up_structvrna__unstructured__domain__s =
[
    [ "uniq_motif_count", "group__domains__up.html#ae17005ef8043aca2fc3864804cd5def6", null ],
    [ "uniq_motif_size", "group__domains__up.html#a2b484b0e19a47145db7055ada8b14159", null ],
    [ "motif_count", "group__domains__up.html#a5ad34148ea1d2e501f3e02029449546e", null ],
    [ "motif", "group__domains__up.html#af285436bbdea4436ad2cedec65d48c75", null ],
    [ "motif_size", "group__domains__up.html#a6a9f89ab7d147eb0ffd6cf8d77d178c0", null ],
    [ "motif_en", "group__domains__up.html#aae4f0a45419784fb7c244bce2781403d", null ],
    [ "motif_type", "group__domains__up.html#a3f0c026cced369ff176a66b2820f2057", null ],
    [ "prod_cb", "group__domains__up.html#ac2656d57130ac56e85212836482cbe80", null ],
    [ "exp_prod_cb", "group__domains__up.html#a181ae6ec67f77e68899ec6a0780f3e01", null ],
    [ "energy_cb", "group__domains__up.html#a1efba765dd4ea893dc8bd7362761f99b", null ],
    [ "exp_energy_cb", "group__domains__up.html#ad5aaa2530557880ae89e297f8f09aa55", null ],
    [ "data", "group__domains__up.html#a8802b1b0512999a9f35202031811ce17", null ],
    [ "free_data", "group__domains__up.html#a21b3084846902172858bc53f113d05a4", null ],
    [ "probs_add", "group__domains__up.html#a457b43dfab7f4321b5d7a84e5deea5d7", null ],
    [ "probs_get", "group__domains__up.html#a0b155283bccf65c5253f31e0211ae8ff", null ]
];