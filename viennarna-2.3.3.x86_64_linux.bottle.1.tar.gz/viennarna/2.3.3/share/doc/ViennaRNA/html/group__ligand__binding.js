var group__ligand__binding =
[
    [ "Ligands binding to unstructured domains", "group__ligands__up.html", null ],
    [ "Incorporating ligands binding to specific sequence/structure motifs using soft constraints", "group__constraints__ligand.html", "group__constraints__ligand" ],
    [ "constraints_ligand.h", "constraints__ligand_8h.html", null ]
];