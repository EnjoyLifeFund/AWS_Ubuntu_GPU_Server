var group__hard__constraints_structvrna__hc__up__s =
[
    [ "position", "group__hard__constraints.html#a67a98def263c534a8c57298098da16e8", null ],
    [ "options", "group__hard__constraints.html#a8bdeffbacefaa77d2d1c8ff0a7f52157", null ]
];