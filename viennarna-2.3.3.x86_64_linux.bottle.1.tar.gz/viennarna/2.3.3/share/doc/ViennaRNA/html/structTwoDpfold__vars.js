var structTwoDpfold__vars =
[
    [ "ptype", "structTwoDpfold__vars.html#a67f37b8901b8d0a049c216d4c6241b07", null ],
    [ "sequence", "structTwoDpfold__vars.html#a32c15a1e31856588259556c9020f32c6", null ],
    [ "S1", "structTwoDpfold__vars.html#a240311ae1e8e121441651d6101e187ac", null ],
    [ "maxD1", "structTwoDpfold__vars.html#a7292b6cbc1ee5bacf55e842f316c4bef", null ],
    [ "maxD2", "structTwoDpfold__vars.html#a8900622d91454d2d037242e290e42834", null ],
    [ "my_iindx", "structTwoDpfold__vars.html#ac2d3e6abf0cb0e1df363904fc938076e", null ],
    [ "jindx", "structTwoDpfold__vars.html#a0699e194a797532c91b284ab10272384", null ],
    [ "referenceBPs1", "structTwoDpfold__vars.html#aea15706d27b6b0fc19f5773919f43a8a", null ],
    [ "referenceBPs2", "structTwoDpfold__vars.html#a1221396d712bf76b7f35297f2ab35a9f", null ],
    [ "bpdist", "structTwoDpfold__vars.html#accef8eaa05fa57ca33aa22cbc7b7aaff", null ],
    [ "mm1", "structTwoDpfold__vars.html#a7c9e9af6224d4696118e05835441863d", null ],
    [ "mm2", "structTwoDpfold__vars.html#affb913470783f9edb12a0bfc22466269", null ]
];