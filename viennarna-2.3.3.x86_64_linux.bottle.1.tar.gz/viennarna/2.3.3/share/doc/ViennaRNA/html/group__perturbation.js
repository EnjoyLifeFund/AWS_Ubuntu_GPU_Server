var group__perturbation =
[
    [ "perturbation_fold.h", "perturbation__fold_8h.html", null ],
    [ "VRNA_OBJECTIVE_FUNCTION_QUADRATIC", "group__perturbation.html#ga81e10993d1ae728e4e02022b33155a12", null ],
    [ "VRNA_OBJECTIVE_FUNCTION_ABSOLUTE", "group__perturbation.html#gac070dfb9cafaeb14d5652bd9adf0f6b1", null ],
    [ "VRNA_MINIMIZER_DEFAULT", "group__perturbation.html#gae5126200d80dbb282f46083fffc606bf", null ],
    [ "VRNA_MINIMIZER_CONJUGATE_FR", "group__perturbation.html#gab1d89db58e8c497795a5005f5dbc8c4a", null ],
    [ "VRNA_MINIMIZER_CONJUGATE_PR", "group__perturbation.html#ga5aaeafe1b0aa77a5cda18943ff94b02f", null ],
    [ "VRNA_MINIMIZER_VECTOR_BFGS", "group__perturbation.html#ga9be8a702cddf58235571ace11cc41b22", null ],
    [ "VRNA_MINIMIZER_VECTOR_BFGS2", "group__perturbation.html#ga7b0a65c6c92fa1d8012383ba9d3dcb4f", null ],
    [ "VRNA_MINIMIZER_STEEPEST_DESCENT", "group__perturbation.html#ga9ecd2144c2ebed7533233da3986521b0", null ],
    [ "progress_callback", "group__perturbation.html#gaa715397c7afd2d2955c315512a3d571a", null ],
    [ "vrna_sc_minimize_pertubation", "group__perturbation.html#gaa124bdc20d88001c38ade590c4bcc3c4", null ]
];