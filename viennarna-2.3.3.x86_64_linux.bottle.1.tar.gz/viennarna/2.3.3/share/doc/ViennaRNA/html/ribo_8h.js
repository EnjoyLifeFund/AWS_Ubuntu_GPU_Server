var ribo_8h =
[
    [ "get_ribosum", "group__consensus__fold.html#ga1116aed4b2dab5252cd23946d47d52c3", null ],
    [ "readribosum", "group__consensus__fold.html#ga5e125c9586fcd4e2e1559fe76f7289cc", null ]
];