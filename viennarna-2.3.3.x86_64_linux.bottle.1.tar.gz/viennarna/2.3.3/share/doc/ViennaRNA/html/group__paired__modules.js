var group__paired__modules =
[
    [ "G-quadruplexes", "group__gquads.html", "group__gquads" ],
    [ "gquad.h", "gquad_8h.html", null ]
];