class Astyle < Formula
  desc "Source code beautifier for C, C++, C#, and Java"
  homepage "https://astyle.sourceforge.io/"
  if OS.mac?
    url "https://downloads.sourceforge.net/project/astyle/astyle/astyle%203.0/astyle_3.0_macos.tar.gz"
    sha256 "d113aa5942219699262ceddd1dde35c66b20bf6cc5eac04d27d398ca7a460eb3"
  elsif OS.linux?
    url "https://downloads.sourceforge.net/project/astyle/astyle/astyle%203.0/astyle_3.0_linux.tar.gz"
    sha256 "983e4fe87f20427ddf0d06fa5ba046b5ee95347f9ada33a681af3892426a4ff3"
  end
  head "https://svn.code.sf.net/p/astyle/code/trunk/AStyle"

  def install
    cd "src" do
      dir = OS.mac? ? "mac" : "gcc"
      system "make", "CXX=#{ENV.cxx}", "-f", "../build/#{dir}/Makefile"
      bin.install "bin/astyle"
    end
  end

  test do
    (testpath/"test.c").write("int main(){return 0;}\n")
    system "#{bin}/astyle", "--style=gnu", "--indent=spaces=4",
           "--lineend=linux", "#{testpath}/test.c"
    assert_equal File.read("test.c"), <<~EOS
      int main()
      {
          return 0;
      }
    EOS
  end
end
