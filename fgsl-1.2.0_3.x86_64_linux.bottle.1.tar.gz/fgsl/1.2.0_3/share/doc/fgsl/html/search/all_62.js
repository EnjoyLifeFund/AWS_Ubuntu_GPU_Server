var searchData=
[
  ['bind',['bind',['../classfgsl.html#a64406a5e119fa92e47b1adcddb152e91',1,'fgsl']]],
  ['bspline_2efinc',['bspline.finc',['../bspline_8finc.html',1,'']]]
];
