var searchData=
[
  ['adj_5frsq',['adj_rsq',['../structfgsl_1_1fgsl__multifit__robust__stats.html#af6f5dc1d1021acfc01d428e4b9be7635',1,'fgsl::fgsl_multifit_robust_stats']]]
];
