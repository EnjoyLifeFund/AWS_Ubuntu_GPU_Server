var searchData=
[
  ['linalg_2efinc',['linalg.finc',['../linalg_8finc.html',1,'']]]
];
