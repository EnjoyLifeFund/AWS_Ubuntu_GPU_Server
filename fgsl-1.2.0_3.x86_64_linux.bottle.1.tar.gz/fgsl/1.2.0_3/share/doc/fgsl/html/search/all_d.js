var searchData=
[
  ['permutation_2efinc',['permutation.finc',['../permutation_8finc.html',1,'']]],
  ['poly_2efinc',['poly.finc',['../poly_8finc.html',1,'']]]
];
