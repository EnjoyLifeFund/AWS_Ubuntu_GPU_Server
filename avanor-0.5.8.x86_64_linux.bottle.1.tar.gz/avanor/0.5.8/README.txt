=====================================================================
=                         USER SECTION
=====================================================================

Avanor can be compiled for playing:
1) for Linux, *NIX etc by GCC.
2) for DOS, Win* by DJGPP
3) It is recommended to compile by VC++ for debug purpose only.


=====================================================================
=                         DEVELOPERS SECTION
=====================================================================
If you woud like to join community of Avanor's developers do not
hinstance to visit http://www.avanor.com/forum/ developers section.
