class Kaiju < Formula
  desc "Fast taxonomic classification of metagenomic sequencing reads"
  homepage "http://kaiju.binf.ku.dk/"
  url "https://github.com/bioinformatics-centre/kaiju/archive/v1.5.0.tar.gz"
  sha256 "7a36b9eab08f2e0b288245fe1b34472168f856825962cbe74ac327eea872cb29"
  head "https://github.com/bioinformatics-centre/kaiju.git"
  # tag "bioinformatics"
  # doi "10.1038/ncomms11257"

  def install
    cd "src" do
      system "make"
    end
    rm "bin/taxonlist.tsv"
    bin.install Dir["bin/*"]
  end

  test do
    system "#{bin}/mkbwt", "-h"
  end
end
