declare var GraphTooltip: any;
export default GraphTooltip;
