class Qualimap < Formula
  desc "Facilitates the quality control of alignment sequencing data"
  homepage "http://qualimap.bioinfo.cipf.es/"
  url "https://bitbucket.org/kokonech/qualimap/downloads/qualimap-build-28-03-16.tar.gz"
  version "20160328"
  sha256 "12fd342a2ccc76ea09bbd5e9ae38c1ae9ae44aad5e6f0296298e584e55b0d8ae"

  depends_on "r" => :optional

  def install
    inreplace "qualimap", /-classpath [^ ]*/, "-classpath '#{libexec}/*'"
    bin.install "qualimap"
    libexec.install "scripts", "species", "qualimap.jar", *Dir["lib/*.jar"]
    doc.install "QualimapManual.pdf"
  end

  test do
    system "qualimap", "-h"
  end
end
