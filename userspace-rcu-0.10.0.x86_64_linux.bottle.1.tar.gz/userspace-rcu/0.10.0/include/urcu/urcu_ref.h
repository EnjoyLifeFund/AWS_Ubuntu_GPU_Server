#warning "urcu/urcu_ref.h is deprecated. Please include urcu/ref.h instead."
#include <urcu/ref.h>
