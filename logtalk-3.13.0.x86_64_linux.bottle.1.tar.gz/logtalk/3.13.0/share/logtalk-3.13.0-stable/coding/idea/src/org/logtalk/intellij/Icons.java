package org.logtalk.intellij;


import javax.swing.*;

import com.intellij.openapi.util.IconLoader;

public class Icons {

    public static final Icon LOGTALK = IconLoader.getIcon("/icons/logtalk.png");

    public static final Icon PROLOG = IconLoader.getIcon("/icons/prolog.png");

}
