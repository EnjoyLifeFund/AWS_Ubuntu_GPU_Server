# The namespace of the Cocoapods plugins plugin.
#
module CocoapodsPlugins
  VERSION = '1.0.0'.freeze
end
