module Pod
  # The version of the CocoaPods command line tool.
  #
  VERSION = '1.3.1'.freeze unless defined? Pod::VERSION
end
