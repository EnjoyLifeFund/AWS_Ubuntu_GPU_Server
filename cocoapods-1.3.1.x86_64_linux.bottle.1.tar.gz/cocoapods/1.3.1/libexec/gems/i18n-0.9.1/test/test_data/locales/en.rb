# encoding: utf-8

{ :en => { :fuh => { :bah => "bas" } } }