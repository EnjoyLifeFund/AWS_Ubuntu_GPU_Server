module I18n
  VERSION = "0.9.1"
end
