module CocoapodsDeintegrate
  VERSION = '1.0.1'.freeze
end
