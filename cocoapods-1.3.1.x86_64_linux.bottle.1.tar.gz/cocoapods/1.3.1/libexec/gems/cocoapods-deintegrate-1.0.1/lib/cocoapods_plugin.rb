module Pod
  require 'cocoapods_deintegrate'
  require 'cocoapods/command/deintegrate'
end
