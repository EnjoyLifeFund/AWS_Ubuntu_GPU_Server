module Nanaimo
  VERSION = '0.2.3'.freeze
end
