### Master

* Adds support for showing how to click on a link in terminal - 0xced

### 1.0.3

* Fixes for URLs with spaces - orta

### 1.0.0

* Initial major release - orta + krausefx 
