require 'gh_inspector/version'
require 'gh_inspector/inspector'
require 'gh_inspector/sidekick'
require 'gh_inspector/evidence'
require 'gh_inspector/exception_hound'

module GhInspector
end
