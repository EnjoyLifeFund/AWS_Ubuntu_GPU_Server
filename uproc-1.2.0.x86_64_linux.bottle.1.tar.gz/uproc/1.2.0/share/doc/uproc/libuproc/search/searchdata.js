var indexSectionsWithContent =
{
  0: "2abcdefghilmnopsuw",
  1: "u",
  2: "abcdefilmopsuw",
  3: "u",
  4: "dfhlopsuw",
  5: "u",
  6: "u",
  7: "u",
  8: "2abcdegilnopsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules"
};

