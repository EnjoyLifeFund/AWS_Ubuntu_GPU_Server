var searchData=
[
  ['2d_20double_20matrix',['2D double matrix',['../group__grp__datastructs__matrix.html',1,'']]]
];
