var searchData=
[
  ['protein_20classification',['Protein classification',['../group__grp__clf__prot.html',1,'']]]
];
