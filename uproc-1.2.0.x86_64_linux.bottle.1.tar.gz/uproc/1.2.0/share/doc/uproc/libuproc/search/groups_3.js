var searchData=
[
  ['common_20definitions',['Common definitions',['../group__grp__intern__common.html',1,'']]]
];
