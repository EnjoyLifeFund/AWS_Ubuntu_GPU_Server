var searchData=
[
  ['sequence_20classification',['Sequence classification',['../group__grp__clf.html',1,'']]],
  ['sequence_20io',['Sequence IO',['../group__grp__io__seqio.html',1,'']]],
  ['struct_20uproc_5fdnaresult',['struct uproc_dnaresult',['../group__struct__dnaresult.html',1,'']]],
  ['struct_20uproc_5forf',['struct uproc_orf',['../group__struct__orf.html',1,'']]],
  ['struct_20uproc_5fprotresult',['struct uproc_protresult',['../group__struct__protresult.html',1,'']]],
  ['struct_20uproc_5fsequence',['struct uproc_sequence',['../group__struct__sequence.html',1,'']]],
  ['struct_20uproc_5fword',['struct uproc_word',['../group__struct__word.html',1,'']]]
];
