var searchData=
[
  ['amino_20acid_20substitution_20matrix',['Amino acid substitution matrix',['../group__grp__datastructs__substmat.html',1,'']]],
  ['amino_20acid_20translation_20alphabets',['Amino acid translation alphabets',['../group__grp__intern__alpha.html',1,'']]],
  ['amino_20acid_20words',['Amino acid words',['../group__grp__intern__word.html',1,'']]]
];
