var searchData=
[
  ['wrapped_20standard_20io_20streams',['Wrapped standard IO streams',['../group__grp__io__io__stdstream.html',1,'']]],
  ['wrapped_20io_20streams_20with_20gz_20compression',['Wrapped IO streams with gz compression',['../group__grp__io__io__stdstream__gz.html',1,'']]]
];
