var searchData=
[
  ['offset',['offset',['../structuproc__sequence.html#a1f2c2db1043fb5addd4c4420cd9cb2fd',1,'uproc_sequence']]],
  ['orf',['orf',['../structuproc__dnaresult.html#a20c43c1dbc3c194d4a123f6249cea700',1,'uproc_dnaresult']]]
];
