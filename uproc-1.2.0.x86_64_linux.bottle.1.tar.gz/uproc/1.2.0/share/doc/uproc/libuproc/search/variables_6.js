var searchData=
[
  ['score',['score',['../structuproc__dnaresult.html#ab12fd8c0978c9bfcb12529bd5fc86ff8',1,'uproc_dnaresult::score()'],['../structuproc__orf.html#a392c407f23d67f6b12825591ef0f2323',1,'uproc_orf::score()'],['../structuproc__protresult.html#aaead4da22482fcdd7052c13960df3832',1,'uproc_protresult::score()']]],
  ['start',['start',['../structuproc__orf.html#aaafd490701f0feb22effe308d5d70da1',1,'uproc_orf']]],
  ['suffix',['suffix',['../structuproc__ecurve__suffixentry.html#a946962fac5345100c72a3c53b367e52f',1,'uproc_ecurve_suffixentry::suffix()'],['../structuproc__word.html#a6fc7b17c06099ae07f27745aca16d84e',1,'uproc_word::suffix()']]]
];
