var searchData=
[
  ['nucleotides_20and_20codons',['Nucleotides and codons',['../group__grp__intern__codon.html',1,'']]]
];
