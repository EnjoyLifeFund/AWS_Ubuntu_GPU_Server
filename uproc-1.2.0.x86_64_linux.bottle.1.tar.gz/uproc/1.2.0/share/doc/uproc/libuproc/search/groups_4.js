var searchData=
[
  ['dna_20classification',['DNA classification',['../group__grp__clf__dna.html',1,'']]],
  ['data_20structures',['Data structures',['../group__grp__datastructs.html',1,'']]]
];
