var searchData=
[
  ['uproc_5famino',['uproc_amino',['../group__grp__intern__common.html#ga679008adcf912af5b841b8737ba7cc90',1,'common.h']]],
  ['uproc_5fcodon',['uproc_codon',['../group__grp__intern__codon.html#gae4f9c91ac5048a1232c4cfdb0c36f28c',1,'codon.h']]],
  ['uproc_5ferror_5fhandler',['uproc_error_handler',['../group__grp__error.html#ga8d1625083423d90f8c294293992735a6',1,'error.h']]],
  ['uproc_5ffamily',['uproc_family',['../group__grp__intern__common.html#ga1f501be1cf10da1935c60191dfe19d79',1,'common.h']]],
  ['uproc_5fnt',['uproc_nt',['../group__grp__intern__codon.html#gab94def41721eea58268f135d72bbe6eb',1,'codon.h']]],
  ['uproc_5forffilter',['uproc_orffilter',['../group__grp__clf__orf.html#ga89754f039b542bb51e8a754075756f1e',1,'orf.h']]],
  ['uproc_5fprefix',['uproc_prefix',['../group__grp__intern__common.html#gad29991e7d08680c58c2b26956a4aef0b',1,'common.h']]],
  ['uproc_5fprotclass_5ftrace_5fcb',['uproc_protclass_trace_cb',['../group__obj__protclass.html#ga19df9244bdf5110f2e0a243f494dc43a',1,'protclass.h']]],
  ['uproc_5fprotfilter',['uproc_protfilter',['../group__obj__protclass.html#ga9bdd6584a9095df33967ffa31457e943',1,'protclass.h']]],
  ['uproc_5fsuffix',['uproc_suffix',['../group__grp__intern__common.html#gab8d93eb1d001d2fb199d2f50fcae8faf',1,'common.h']]],
  ['uproc_5fworditer',['uproc_worditer',['../group__obj__worditer.html#ga8865e766bc1503f93d4876cd29970e47',1,'word.h']]]
];
