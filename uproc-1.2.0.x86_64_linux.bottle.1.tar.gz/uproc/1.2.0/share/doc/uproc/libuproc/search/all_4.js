var searchData=
[
  ['data',['data',['../structuproc__orf.html#a62fa7bbfe35197021edca3c8f2f5c043',1,'uproc_orf::data()'],['../structuproc__sequence.html#a8fcae79473ca06bcf34bd10e6a1bfafe',1,'uproc_sequence::data()']]],
  ['database_2eh',['database.h',['../database_8h.html',1,'']]],
  ['dnaclass_2eh',['dnaclass.h',['../dnaclass_8h.html',1,'']]],
  ['dna_20classification',['DNA classification',['../group__grp__clf__dna.html',1,'']]],
  ['data_20structures',['Data structures',['../group__grp__datastructs.html',1,'']]]
];
