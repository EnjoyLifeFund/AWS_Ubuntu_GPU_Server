var searchData=
[
  ['family',['family',['../structuproc__dnaresult.html#af347725467457424c7e64368b76efdbe',1,'uproc_dnaresult::family()'],['../structuproc__ecurve__suffixentry.html#af190221d9f785424cfe7aa6210a89e54',1,'uproc_ecurve_suffixentry::family()'],['../structuproc__protresult.html#adf2e96f0df763d476423035bdb398558',1,'uproc_protresult::family()']]],
  ['frame',['frame',['../structuproc__orf.html#a900faf0591d72430b07778859f438e6b',1,'uproc_orf']]]
];
