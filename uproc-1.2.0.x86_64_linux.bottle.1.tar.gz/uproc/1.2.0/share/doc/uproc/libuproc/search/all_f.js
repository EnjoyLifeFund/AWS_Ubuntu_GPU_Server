var searchData=
[
  ['sequence_20classification',['Sequence classification',['../group__grp__clf.html',1,'']]],
  ['sequence_20io',['Sequence IO',['../group__grp__io__seqio.html',1,'']]],
  ['score',['score',['../structuproc__dnaresult.html#ab12fd8c0978c9bfcb12529bd5fc86ff8',1,'uproc_dnaresult::score()'],['../structuproc__orf.html#a392c407f23d67f6b12825591ef0f2323',1,'uproc_orf::score()'],['../structuproc__protresult.html#aaead4da22482fcdd7052c13960df3832',1,'uproc_protresult::score()']]],
  ['seqio_2eh',['seqio.h',['../seqio_8h.html',1,'']]],
  ['start',['start',['../structuproc__orf.html#aaafd490701f0feb22effe308d5d70da1',1,'uproc_orf']]],
  ['struct_20uproc_5fdnaresult',['struct uproc_dnaresult',['../group__struct__dnaresult.html',1,'']]],
  ['struct_20uproc_5forf',['struct uproc_orf',['../group__struct__orf.html',1,'']]],
  ['struct_20uproc_5fprotresult',['struct uproc_protresult',['../group__struct__protresult.html',1,'']]],
  ['struct_20uproc_5fsequence',['struct uproc_sequence',['../group__struct__sequence.html',1,'']]],
  ['struct_20uproc_5fword',['struct uproc_word',['../group__struct__word.html',1,'']]],
  ['substmat_2eh',['substmat.h',['../substmat_8h.html',1,'']]],
  ['suffix',['suffix',['../structuproc__ecurve__suffixentry.html#a946962fac5345100c72a3c53b367e52f',1,'uproc_ecurve_suffixentry::suffix()'],['../structuproc__word.html#a6fc7b17c06099ae07f27745aca16d84e',1,'uproc_word::suffix()']]]
];
