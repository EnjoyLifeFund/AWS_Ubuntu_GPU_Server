var searchData=
[
  ['codon_2eh',['codon.h',['../codon_8h.html',1,'']]],
  ['common_2eh',['common.h',['../common_8h.html',1,'']]],
  ['common_20definitions',['Common definitions',['../group__grp__intern__common.html',1,'']]]
];
