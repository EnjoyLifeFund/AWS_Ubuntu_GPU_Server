Credits
=========

``bandcamp-dl`` is written and maintained by:

- `Iheanyi Ekechukwu <https://github.com/iheanyi>`_
- `Anthony Forsberg <https://github.com/Evolution0>`_
- `John Titor <https://github.com/forsenonlhaimaisentito>`_
- `Alex Bouffard <https://github.com/Mixbo>`_
- `Pedro Lopes <https://github.com/PedroLopes>`_
- `Bendito999 <https://github.com/Bendito999>`_
- `Gabor Szabo <https://github.com/szabgab>`_
- `Vladde Nordholm <https://github.com/vladdeSV>`_
- `Simon W. Jackson <https://github.com/simonwjackson>`_
- `Yo'av Moshe <https://github.com/bjesus>`_
- `Mitchell Barron <https://github.com/mtchllbrrn>`_
- `Seppi <https://github.com/josefnpat>`_
- `Andrew Sampson <https://github.com/Codeusa>`_
- `Joseph Kahn <https://github.com/JBKahn>`_
- `Diego Costa <https://github.com/dgbc>`_
- `Gal Schlezinger <https://github.com/Schniz>`_
