README_hyda.TXT

HyDA 1.3.1 Source Code Package Released Under GNU GPL v3 License
See the accompanying file LICENSE.txt for the details of the license. 
Sep 17, 2014
Hamidreza Chitsaz
chitsaz@chitsazlab.org
Colorado State University
Fort Collins, CO

> SUMMARY
	* A/ Credits
	* B/ Installation
	* C/ Usage
		* C-1/ Importing read files
		* C-2/ Unitigging
		* C-3/ Finishing

----------------------------------------------------------------------------------
A/ Credits

See the accompanying file CREDIT_hyda.TXT.

References

Narjes S. Movahedi, Elmirasadat Forouzmand, Hamidreza Chitsaz, De Novo Co-assembly of Bacterial Genomes from Multiple Single Cells, IEEE International Conference on Bioinformatics and Biomedicine (BIBM), pp 561-565, 2012

Narjes S. Movahedi, Zeinab Taghavi, Mallory Embree, Harish Nagarajan, Karsten Zengler, Hamidreza Chitsaz. Efficient synergistic single-cell genome assembly, bioRxiv, under review

----------------------------------------------------------------------------------
B/ Installation

To clean up before a new compilation, issue the following command in the main hyda directory (next to Makefile):
$ make clean

For the default max kmer size [64 bps] and max colors [1], issue the following command in the main hyda directory (next to Makefile):
$ make clean; make

For max kmer size N, issue the following command in the main hyda directory (next to Makefile):
$ make clean; make MAXK=N

For max colors M, issue the following command in the main hyda directory (next to Makefile):
$ make clean; make MAXCOLORS=M

For both:
$ make clean; make MAXK=N MAXCOLORS=M


NOTE FOR ADVANCED USERS: Those source files that are only compiled into objects and go into libhyda are specified by symbolic links to the actual source file in src/lib. Those files that are compiled into executable binaries are specified by symbolic links to the actual source file in src/hyda.

----------------------------------------------------------------------------------
C/ Usage

Typical usage without minimizer-based slicing:

$ import [options] -O=reads-file
$ assemble-unitig [options] reads-file
$ assemble-finish [options] reads-file

Typical usage with minimizer-based slicing into S slices:

$ import [options] -O=reads-file
$ assemble-unitig [options] -m=S -s=0 reads-file
...
$ assemble-unitig [options] -m=S -s=S-1 reads-file
$ mergeunitigs [options] unitig_file0 unitig_file1 ...
$ assemble-finish [options] reads-file

----------------------------------------
C-1/ Importing read files

Usage: import [options]
       Output (FASTA by default) file name is identified by -O option.
       Input files are identified by -q and -f options.
       Example: import -f=lib1-1.fasta,lib1-2.fasta -q=lib2-1.fastq,lib2-2.fastq -f=lib3.fasta -O=reads.fasta
       Above, lib1-1.fasta and lib1-2.fasta are paired reads in library 0, lib2-1.fastq and lib2-2.fastq are paired reads in library 1, and lib3.fasta are single reads in library 2.


	-V,--version      prints the version
	-h,--help      shows this help
	-O,--output      =output file
	-q,--fastqlibrary      =comma separated list, without space, of FASTQ file names in the library
	-f,--fastalibrary      =comma separated list, without space, of FASTA file names in the library
	-t,--truncate      =bad quality flag, truncate trailing nucleotides with the bad quality value in FASTQ files
	-l,--minlen      =minimum length of a read (default 20)
	-n,--maxn      =maximum number of N's in the relevant part of a read (default 4)
	   --fastqout      fastq output

You always need to import your reads file, in FASTA or FASTQ format, into HyDA's FASTA/FASTQ format. Importing assigns a unique ID to each read and also removes those reads that contain too many 'N' nucleotides. That threshold is 4 by default but can be specified as a command line option, e.g. by '-n=10' for 10 Ns. A read ID contains the library number which will be linked to the colorings in the following step through the config file explained below. Libraries are 0-based, and numbered in the exact order they appear on the command line here. For example, import -f=file1 -f=file2 -q=file3,file4 will assign library number 0 to reads in file1, library number 1 to reads in file2, and library number 3 to the paired reads in file3 and file4.


----------------------------------------
C-2/ Unitigging

Usage: assemble-unitig [options] reads-file
       Output files prefix is identified by -O option.


	-V,--version      prints the version
	-h,--help      shows this help
	-O,--output      =output files prefix (mandatory)
	-C,--config      =coloring config file, if absent all libraries are colored 0
	-k,--kmer      =k as in kmer (mandatory)
	-p,--procs      =number of threads per processing node (default 1)
	-q,--fastq      input is in FASTQ format
	-m,--machines      =number of machines (only needed when distributing among multiple machines)
	-s,--slice      =0-base slice number (only needed when distributing among multiple machines)
	-S,--single      single strand
	   --exportkmers      export kmers with their multiplicities

For a simple example, if the output of import is named READS.FA and you would like to assemble with k=55 on 48 processing cores without any colorings, then issue
$ assemble-unitig -k=55 -p=48 -O=OUTPUT READS.FA  

For more than 1 color, you need to make a config file. Each tab separated line of the config file is like 'librarynumber	colornumber'. More precisely for advanced users, the config file is (libnum\tcolornum\n)^*. A line starting with '#' is considered just a comment and does not have any effect.

By default, the assembler assumes that the reads come from a double stranded DNA pool. You can override the default, for example for special RNA-seq protocols that differentiate between the two cDNA strands, by -S option.

For algorithmic reasons, k has to be odd, but if it is not odd, HyDA takes the liberty to make it odd. Optimal k depends on read length and error rates and profile. On one hand, k should be chosen so that every read has at least one perfectly error-free kmer, and on the other hand it has to be large enough to generate longer contigs. For Illumina 100 bp reads with 1% error, k=55 has been shown to perform well. 

You may distribute a large de Bruijn graph on multiple processing nodes through our minimizer-based hadoop-style hashing. The option '-m' specifies into how many different parts the graph should be sliced, and '-s' specifies which slice is run on the current processing node. Slices can be processed in any order and at any time, i.e. they do not need to be running at the same time in parallel. After completion of assemble-unitig on all of the slices, the output unitig files need to be merged into one unitig file by 'mergeunitigs'. The resulting unitig file can then be fed into the next step. For instance, if the graph needs to be divided into 3 slices, and slice i is run on NODE_i, then

NODE_0$ assemble-unitig -k=55 -p=48 -O=OUTPUT -m=3 -s=0 READS.FA
NODE_1$ assemble-unitig -k=55 -p=48 -O=OUTPUT -m=3 -s=1 READS.FA
NODE_2$ assemble-unitig -k=55 -p=48 -O=OUTPUT -m=3 -s=2 READS.FA
MASTERNODE$ mergeunitigs OUTPUT.slice0.unitigs OUTPUT.slice1.unitigs OUTPUT.slice2.unitigs -O=OUTPUT.unitigs

----------------------------------------
C-3/ Finishing

Usage: assemble-finish [options] reads-file
       Input unitigs file is identified by -U option.
       Output files prefix is identified by -O option.


	-V,--version      prints the version
	-h,--help      shows this help
	-U,--unitig      =input unitigs file ([collective] output of assemble-unitig [for multiple slices]) (mandatory)
	-O,--output      =output files prefix, may be the same as assemble-unitig output prefix (mandatory)
	-C,--config      =pairing config file
	-c,--cov      =minimum average coverage of a condensed node, as a multiple of the assembly coverage mean (default 1.0)
	-l,--lowcovlen      =maximum length of a low average coverage condensed node to be removed (default 1000nt)
	-p,--procs      =number of threads
	-q,--fastq      input is in FASTQ format
	-s,--single      single strand
	-a,--exportasm      export assembly graph for downstream applications, e.g. align-longreads
	   --mincontiglen      =minimum length of an output contig (default k)
	   --exportgraph      =max contig size, export those nodes of the condensed graph that are shorter than this value, in DOT format
	   --exportlowcov      export removed low coverage condensed nodes
	   --save      =file to save condensed graph into
	   --load      =file to load condensed graph from
	   --separatecolors      output contigs of each color into a separate file
	   --nolowcovunitigs      do not even initially load those unitigs that have coverage less than 2
	   --mincontigcov      =minimum coverage of an output contig [applicable only when --separatecolors used] (default 1.0)
	   --keepcolor0      keeps all nodes in color 0 no matter what their coverages are. That is the cut-off for color 0 is 0.

For the simple example, issue
$ assemble-finish -U=OUTPUT -O=OUTPUT READS.FA  

For the simple example with a coverage cutoff of 50% of the coverage mean, issue
$ assemble-finish -c=0.5 -U=OUTPUT -O=OUTPUT READS.FA

Coverage mean is the coverage of the entire assembly before any error removal. Many erroneous low coverage kmers exist in the assembly at that point, which pull the coverage mean down. That is why the default is 100% of the coverage mean. Optimal coverage cutoff depends on the quality of MDA, average coverage, and error rates. In the colored case, coverage mean is computed for each color individually and a normalization procedure makes the coverage of every color on the same scale.

Currently, the pairing information is always ignored.
 

