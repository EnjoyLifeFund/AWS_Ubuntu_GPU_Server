/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          distributor.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  12/25/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef _DISTRIBUTOR_H
#define _DISTRIBUTOR_H

#include "common.h"
#include "kmer.h"

typedef uint16_t Minimizer;

#define MINIMIZER_LEN  (sizeof(Minimizer)*4)
#define MINIMIZER_SHIFT  (2*MINIMIZER_LEN-2)

class Distributor {
public:
	void set(int _bins, int _k) {bins = _bins; kforge.reset(k=_k);};
	int bin(Kmer &);
private:
	int bins;
	int k;
	K kforge;
};

#endif
