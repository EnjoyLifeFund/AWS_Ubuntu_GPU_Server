/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          nuclist.h 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef NUCLIST_H
#define NUCLIST_H

#include "common_squeezambler.h"
#include "colorslist.h"
#include "colorsstat.h"
#include "logger.h"
#include <ostream>

using namespace std;


class NucList {
public:
	NucList(Logger *_logger, bool _debugMode, size_t _libNo, size_t nucs = 0, size_t _assemStepNum = 0);
  
	NucNum *getNucList(){return nucList;};
	NucNum countTotalNucs(size_t _assemStepNum);
	NucNum totalNucs(size_t _assemStepNum);
	NucNum totalNucsFromBegining(size_t _assemStepNum);
	void updateLastStepNucList(ColorsList & colorsList, ColorsStat & colorsStat, CovType newDesiredCoverage); 


private:
	size_t libNo;
	size_t assemStepNum;
	NucNum nucListArchive[MAXSTEPS][MAXLIBRARIES];
	NucNum nucList[MAXLIBRARIES];
	size_t totalNucList[MAXSTEPS];
	Logger *logger;
	bool debugMode;

	NucNum	estimateNewNucNum(NucNum oldNucNo, size_t oldPopulation, Stat oldStat, size_t newPopulation, Stat newStat);
	NucNum	estimateNewNucNum(size_t newPopulation, CovType newDesiredCoverage, AssemblySize newEstimatedAssemblySize);
	AssemblySize estimateNewAssemSize(Stat oldStat);
	NucNum findLastNonZeroNucLib(Lib lib);
};

#endif
