/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          implicitgraph.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/



#ifndef _IMPLICITGRAPH_H_
#define _IMPLICITGRAPH_H_

#include <iostream>
#include <fstream>
#include <list>
#include <stdint.h>

#include "common.h"
#include "distributor.h"
#include "compactstr.h"
#include "splaytree.h"
//#include "sortedlist.h"
#include "kmers.h"
#include "logger.h"
#include "unitig.h"

using namespace std;

enum ExitType {TR_NEXIST = 1, TR_LOOP = 2, TR_NULL = 3, TR_BREAK = 4, TR_ERROR = 5};


struct SemicompactNodeInfo {
	Mult mult; // multiplicity
	Edges edges;  // MSB -> A(in), C(in), G(in), T(in), T(out), G(out), C(out), A(out) <- LSB   (for the dual just exchange the two half bytes)
	bool vstd;

	SemicompactNodeInfo()
	{
		vstd = false;
	}

	inline bool isVisited()
	{
		return vstd;
	}

	inline void setVisited(bool v)
	{
		vstd = v;
	}
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct CompactNodeInfo {
	Mult mult; // multiplicity
	Edges edges;  // MSB -> A(in), C(in), G(in), T(in), T(out), G(out), C(out), A(out) <- LSB   (for the dual just exchange the two half bytes)

	inline bool isVisited()
	{
		return !mult;
	}

	inline void setVisited(bool v)
	{
		if(v)
			mult.init();
		else
			exitMsg((char*)"Error: CompactNodeInfo panic: oh dear!", INTERNAL_WOW_ERROR);
	}
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct EdgeInfo {
	int indeg, outdeg;
	Nucleotide innuc[NUCS];
	Nucleotide outnuc[NUCS];
};

template <class NodeInfo>
class ImplicitGraph
{
public:
	ImplicitGraph(int k, int _machines, int _slice, bool dbstrand, Logger *_logger);
	Kmer & smaller(Kmer & k1, Kmer & k2, bool & dual);
        void insertin(Kmer&, Nucleotide, Color, int thread = 0); 
	void insertout(Kmer&, Nucleotide, Color, int thread = 0); 
	void insertio(Kmer&, Nucleotide, Nucleotide, Color, int thread = 0);
	void insertin(Kmer&, Kmer&, Nucleotide, Color, int thread = 0);
	void insertout(Kmer&, Kmer&, Nucleotide, Color, int thread = 0);
	void insertio(Kmer&, Kmer&, Nucleotide, Nucleotide, Color, int thread = 0);
	int indegree(Edges e);
	int outdegree(Edges e);
	const Nucleotide *innuc(Edges e);
	const Nucleotide *outnuc(Edges e);
	int indegree(NodeInfo e);
	int outdegree(NodeInfo e);
	const Nucleotide *innuc(NodeInfo e);
	const Nucleotide *outnuc(NodeInfo e);
	Kmer dual(Kmer &kmer) {return kforge.dual(kmer);}

	Nucleotide getnuc(Kmer &kmer, int i) {return kforge.getnuc(kmer, i);}
	void push_end(Kmer &kmer, Nucleotide n) {kforge.push_end(kmer, n);}
	void push_begin(Kmer &kmer, Nucleotide n) {kforge.push_begin(kmer, n);}

	void transfer(Kmer &entrykmer, Direction direction, Unitig &, ExitType &exitType);

	size_t size() {return nodes.size();};

	void load(FILE *);
	void save(FILE *);
	void print(FILE *fp, bool binary);

	int rank(Kmer &kmer);

	void begin();
	bool hasNext();
	KmerData<NodeInfo> next();

	size_t initSave();
	bool moreSave(char *);
	size_t finalizeSave();

	void setThreadSafe(bool t) {nodes.setThreadSafe(t);}
	void setContainersThreadSafe(bool t) {nodes.setContainersThreadSafe(t);};
	int setThreadsNum(int _threadsnum) {int ret = threadsnum; threadsnum = _threadsnum; return ret;}

	void resetVisitations();

private:
	int machines, slice;
	Alloc alloc;
	Logger *logger;
	Distributor distributor;
//	Kmers<NodeInfo, SortedList> nodes;
	Kmers<NodeInfo, SplayTree> nodes;
	K kforge;
	int k;
	bool doublestrand;
	EdgeInfo edgeInfo[256];
	int threadsnum;

	size_t totaltips;
	size_t savesz;

	void insert(Kmer&, Edges mask, Color, int thread); 
	void insert(KmerData<NodeInfo>&);
};

#endif 
