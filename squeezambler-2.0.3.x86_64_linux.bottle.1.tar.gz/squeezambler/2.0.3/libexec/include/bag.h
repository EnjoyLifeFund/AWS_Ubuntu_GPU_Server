/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          bag.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef BAG_H
#define BAG_H

#include "alloc.h"

using namespace std;

#define __PAGESIZE 16

template<class T>
struct Page {
	T elements[__PAGESIZE];
	Page *next;
};

template<class T>
class Bag {
public:
	Bag();
	~Bag();
	void append(T data);
	void unappend();
	T& operator[](unsigned int idx);
	void clear();
	size_t size() { return num;}
	void begin();
	bool hasNext();
	T &next();
	T &first();
	T &last();

private:
	Alloc alloc;
	Page<T> *head, *current;
	unsigned int num;
	unsigned int itr;
	Page<T> *itrpage;

	Page<T> *newpage();
	void delpage(Page<T> *);
};


#endif
