/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          cgraph.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  11/09/2012
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef CGRAPH_H
#define CGRAPH_H

#include <algorithm>
#include <queue>
#include <vector>

#include "alloc.h"
#include "bag.h"
#include "common.h"
#include "heap.h"
#include "cnode.h"
#include "kmer.h"

#define SPS_CHUNK_NUM 128
#define MAX_SP_ROUNDS 100000

struct Locus {
	Locus(CNodeID cn) {cnodeid = cn; pos = 0;};
	Locus(){};
	Locus & operator++() {pos++; return *this;} //prefix
	Locus operator++(int) {Locus temp = *this; pos++; return temp;} //postfix

	CNodeID cnodeid;
	Coordinate pos;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;


class Path {
public:
	Locus begin, end;
	Bag<CNodeID> nodes; // not inclusive of begin and end
	Distance length; // in kmers, is not used everywhere and is viewed as an unreliable temporary value rather than a stable piece of information consistent everywhere

	Path & operator=(Path &rhs);
	void print(ostream &in);
	void save(FILE *);
	void load(FILE *);
}; 

typedef vector<CNode *> CNodes; 


class Graph {
public:
	Graph(int _k, int _procs);
	~Graph();
	CNode *newNode(UnitigSerial, Distance, Coverage);

	CNodeAuxSP *auxSP(CNodeID cnodeid, int thread); 
	CNodeAuxSP *auxSPNewIfNull(CNodeID cnodeid, int thread); 
	void deleteCNodeAuxSP(CNodeID cnodeid, int thread); 

	void append(CNode *cnode, CNodeID cnodeid) {cnode->append(cnodeid, k);} 

	void connect(CNodeID from, CNodeID to);
	void disconnect(CNodeID from, CNodeID to);

	bool transfer(CNodeID from);
	bool join(CNodeID from, CNodeID to);

	void remove(CNodeID cnodeid);
	void applyRemovals();

	Locus dual(Locus coord);
	void dual(Path &path, Path &ret);

	inline AvgCoverage avgCoverage(CNodeID cnodeid) {return ((AvgCoverage)cnodeid.coverage())/(cnodeid.length()-k+1);}

	size_t size() {return nodes.size();}

	void initPath(Locus, Locus, int);
	bool morePaths(Path &, int);

	void allpaths(CNodeID target, size_t maxdist, int thread);
	void cleanUp(int thread);
	void cleanUp();
	void prepareForDijkstra(int thisprocs);

	Coordinate NX(double x); //compute N50 with x = 0.5

	void save(FILE *fp);
	void load(FILE *fp);
	void exportGraph(Distance maxins, ostream &out); 

	inline void begin() {scratchNodes = nodes; it = scratchNodes.begin();}
	inline bool hasNext() {if(it != scratchNodes.end()) return true; else {scratchNodes.clear(); return false;}}
	inline CNode *next() {return *(it++);}
	inline CNode *node(size_t idx) {return nodes[idx];}

	int getk() {return k;}

private:
	Alloc alloc;
	int procs;
	int k;
	CNodes nodes;
	CNodes scratchNodes;
	CNodes::iterator it;

	Locus *pathbegin, *pathend;
	ShortestOrder *pathorder;
	CNodeAuxSP **pathaux;
	Bag<DijkstraTicket*> *cleanup;
	
	void dijkstra(CNodeID target, size_t maxdist, int thread);
	void higherOrderShortest(CNodeID target, size_t maxdist, int thread);
	void printedges(Distance maxins, CNodeID cnodeid, size_t, ostream &out);
	size_t findnode(CNodeID);
	CNode *newNode();
};

#endif
