/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          read.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef READ_H
#define READ_H

#include <ostream>

#include "id.h"

using namespace std;

class Read {
public:
	Read() {id.id = 0; quals = NULL; seq = NULL;};
	Read(ID i) {id.id = i.id; quals = NULL; seq = NULL;};
	Read(string &s, ID i = 0) {id.id = i.id; quals = NULL; seq = NULL; load(s);};
	Read(char *s, ID i = 0) {id.id = i.id; quals = NULL; seq = NULL; load(s);};
	~Read() {if(seq) delete[] seq; if(quals) delete[] quals;}
	void setID(ID i) {id.id = i.id;};
	void setID(char *c, bool dual = false);
	void setID(string s, bool dual = false);
	ID getID() const {return id;};
	Read operator~();
	Nucleotide &operator[](unsigned int i) {return seq[i];}
	char qual(unsigned int i) {return quals[i];}
	bool operator<(Read & rhs) const;
	void load(string &s, bool d = false);
	void loadqual(string &s, bool d = false);
	void load(char *s, bool d = false);
	void print(FILE *f);
	void print(ostream &f);
	void sprint(char *);
	size_t size() {return len;}
private:
	ID id;
	Nucleotide *seq;
	char *quals;
	size_t len; 
	void resize(size_t);
};

#endif
