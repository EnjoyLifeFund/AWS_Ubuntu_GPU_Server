/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          reads.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef READS_H
#define READS_H

#include <string>
#include <iostream>
#include <fstream>
#include <stdint.h>
#include <assert.h>

#include "read.h"
#include "sequence.h"

using namespace std;

class Reads {
public:
	Reads();
	~Reads();
	inline Read& operator[] (size_t n) {return reads[n];};
	void resize(size_t n);
	void sort();
	void sortbyID();
	size_t size() {return num;};
	void print(FILE *);
	void import(char *inputFilename, bool fasta = false, unsigned int trimb = 0, unsigned int trime = 0, bool includeDual = true, bool leastOfPrimDual = false);
	void import(string inputFilename, bool fasta = false, unsigned int trimb = 0, unsigned int trime = 0, bool includeDual = true, bool leastOfPrimDual = false);
	void initialize(char *inputFilename, bool fasta = false);
	void initialize(string inputFilename, bool fasta = false);
	void finalize();
	bool next(Read *read, unsigned int trimb = 0, unsigned int trime = 0, bool includeDual = true, bool leastOfPrimDual = false);
	bool next(string & name);
	void initialize();
	Read *find(ID &id);

private:
	Read *reads;
	size_t num;
	string filename;
	bool fasta;
	FILE *inputReads;
	ifstream *input;
	size_t readindex;
};

#endif
