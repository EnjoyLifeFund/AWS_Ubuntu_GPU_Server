/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          colorsstat.h 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef COLORSSTAT_H
#define COLORSSTAT_H

#include "common_squeezambler.h"
#include "colorslist.h"
#include "logger.h"
#include "finisher.h"
#include <ostream>
#include <vector>

using namespace std;


class ColorsStat {
public:
	ColorsStat(Logger *_logger, bool _debugMode); 
	~ColorsStat(){};

	void selectNextLevelActiveColors(vector<ContigMetadata> * _contigMetadataList, ColorsList * colorsList, double cutoffRatio, Lib _base_lib, size_t groupNum, CovType completeGenomeMinCoverage, int methodType = 0);
	AssemblySize get_assemblySize(Color c);
	Stat get_stat(Color c);
	void clear_stat();
	void clusterSequencedColors(vector<ContigMetadata> * _contigMetadataList, ColorsList * colorsList, double cutoffRatio, CList<int, MAXCOLORS> *_sequencedClusters, LibNamesList * inputLibNames);


private:
	CList<Stat, MAXPOWERBARCODE>	unionStat;
	CList<bool, MAXCONTIGNUM> sequencedPrecenceInUnion;
	CList<Stat, MAXCOLORS> colorListStat;
	Stat sequencedFinalStat[MAXCOLORS][MAXCOLORS];
	CList<int, MAXCOLORS> *sequencedClusters;
	int clustersNum;
	Stat totalStat;
	Colors_List *activeColors; 
	Colors_List *sequencedColors;
	vector<ContigMetadata> *contigMetadataList;
	Logger *logger;
	bool debugMode;

	void calcUnionStat(size_t uIndex);
	Stat calcStat(Color c);
	void extractUnionStats();
	void extractColorStats();
	Colors_List convertIndexToList(size_t index);
	size_t convertActiveColorIndexToUnionIndex(size_t activeColorIndex);
	void calcSequencedStat();
	Ratio assigncutoffPlot(Ratio cutoffRatio, Stat totalStat, Stat colorStat);
	void printListInf(Colors_List *list);
	void calcSequencedCommonStat();
	void clusterSequenced(double cutoffRatio);
	void printSequencedCommonStat();
	void printSequencedClusters();
	bool isSubset(int i,int j, double cutoffRatio);
	bool isSequenced(Color i, double cutoffRatio, CovType completeGenomeMinCoverage);
	void changeCluster(int i, int j);
	void cleanClusters();
	void printSequencedCommonStat(ColorsList * colorsList);
	void printSequencedClusters(ColorsList * colorsList, LibNamesList * inputLibNames);
};


#endif
