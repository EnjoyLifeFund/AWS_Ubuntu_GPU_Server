/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          colorslist.h 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef COLORSLIST_H
#define COLORSLIST_H

#include "common_squeezambler.h"
#include "logger.h"
#include <ostream>

using namespace std;


class ColorsList {
public:
	ColorsList(size_t initialGroupsNum, size_t _libNo, int _base_lib = 0);
	ColorsList(Logger* _logger, bool _debugMode, size_t initialGroupsNum, size_t _libNo, int _base_lib = 0);
	~ColorsList();
	
	Lib get_base_lib() { return base_lib;};
	size_t get_assemStepNo() { return assemStepNo;}; 

	CList<Color, MAXLIBCOLOR> *getColorsList() { return &colors;};
	Color *getColorsList_list() { return colors.list;};
	void getNewColorsList_list(Color *newList);
	Color getColors(size_t l); 
	LibraryList *getLibraryList(Color c) { return &(colorsLibList.list[c]);};
	size_t getColorPopulation(Color c) { return colorsLibList.list[c].listNo;};
	
	size_t activeListSize() { return activeColors.listNo;};
	bool isEmpty_activeColors() { return (activeColors.listNo == 0);};
	Color lastActiveColor();
	Color getActiveColors(int i);
	Colors_List *getActiveColorsList(){ return &activeColors;};
	void emptyActiveColors() { activeColors.listNo = 0;};


	size_t waitingListSize() { return waitingColors.listNo;};
	bool isEmpty_waitingColors() { return (waitingColors.listNo == 0);};
	Color lastWaitingColor();
	Color getWaitingColors(int i);
	Colors_List *getWaitingColorsList(){ return &waitingColors;};

	bool isEmpty_sequencedColors() { return (sequencedColors.listNo == 0);};
	Color lastSequencedColor();
	size_t sequencedListSize() { return sequencedColors.listNo;};
	Color getSequencedColors(int i);
	Lib getSequencedLibs(int i);
	Colors_List *getSequencedColorsList(){ return &sequencedColors;};

	Color moveSingleCellsFromActiveToSequencedList();
	void updateActiveList(Lib _base_lib, int searchMethodType, size_t groupNum, Colors_List nextRoundColorList);
  
	size_t countCellsinColors(Color c); 
	size_t countCellsinColors(Colors_List ListOfColors);

	bool allSequenced(){ return ((isEmpty_waitingColors() && isEmpty_activeColors()));};

	void printColorInf(Logger *_logger, bool _debugMode);
	void printColorInf();
	void printColorInf(Color c);
	void printActiveColorsInf();
	void printWaitingColorsInf();
	void printSequencedColorsInf();

	void initializeColorsList(size_t initialGroupsNum, size_t _libNo, int _base_lib);
	void divideColor(Color c, size_t groupNum);
	void divideColor(LibraryList libraryList, size_t groupNum);
	void divideLastWaitingColor(size_t groupNum);
	void divideAllWaitingColors(size_t groupNum);
	void divideAllActiveColors(size_t groupNum);
	void divideFirstActiveColor(size_t groupNum);

	void set_base_lib( Lib _base_lib);
	void set_assemStepNo(size_t _assemStepNo) { set_base_lib((Lib) (_assemStepNo * libNo));}; 

	Color moveLastActiveToSequencedList();
	Color moveLastActiveToWaitingList();
	Color moveLastWaitingToActiveList();

	void pushToActiveList(Color c);
	Color popFromActiveList();
	void pushToWaitingList(Color c);
	Color popFromWaitingList();
	void pushToSequencedList(Color c);
	Color popFromSequencedList();
	
	void  updateWaitingColorsIn_colors_list();
private:
	CList <Color, MAXLIBCOLOR>	colors; //colors.list[ i + stepsNo*inputLibNames.size() ]: color of ith library in the step number stepNo+1
	Colors_List	activeColors;
	Colors_List	waitingColors;
	Colors_List	sequencedColors;
	ColorsLibList	colorsLibList; //colorsLibList.list[i].list[:] : list of libraries in color i	
	Logger *logger;
	bool debugMode;
	size_t libNo;
	Lib base_lib;
	size_t assemStepNo;
	
};

#endif
