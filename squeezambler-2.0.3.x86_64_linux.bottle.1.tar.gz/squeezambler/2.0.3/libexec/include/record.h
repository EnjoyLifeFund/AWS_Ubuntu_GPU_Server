/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          record.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef RECORD_H
#define RECORD_H

#include "alloc.h"

using namespace std;

class Record {
public:
	Record();
	Record(char *s);
	Record(string s);
	~Record();
	inline const char *operator[](size_t n) {return fields[n];};
	const char *field(size_t n) {return (const char *)fields[n];};
	size_t size();
	void parse(char *);
	bool operator<(const Record& rhs) const;
	void setNumericSort() {numericSort = true;}
	void setLexicoSort() {numericSort = false;}
	void setSortField(int sf) {if (sf < size()) sortField = sf; else sortField = 0;};
	char  **fields;
private:
	char *line;
	Alloc alloc;
	int sortField;	
	bool numericSort;	
};

#endif
