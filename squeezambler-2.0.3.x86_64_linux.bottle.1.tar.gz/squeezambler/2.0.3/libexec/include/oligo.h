/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          oligo.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  11/16/2012
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "common.h"
#include <ostream>
#include <iostream>

using namespace std;

#ifndef OLIGO_H
#define OLIGO_H

struct Oligo {
	Oligomer oligomer;
	inline size_t hashMax() {return (Oligomer)(-1);}
	inline size_t hash() {return oligomer;}
	inline size_t maxSize() {return sizeof(Oligomer)*NUCS_PER_BYTE;}
	inline void push(Nucleotide nuc) {oligomer = (oligomer << BITS_PER_NUC) | nuc;}
	void show(ostream & out, Oligomer oligo, size_t level) {if(level != 0) show(out, oligo >> BITS_PER_NUC, level-1); out << nuc2char(oligo & 3);} 
};

ostream& operator<<(ostream & out, Oligo oligo);

#endif
