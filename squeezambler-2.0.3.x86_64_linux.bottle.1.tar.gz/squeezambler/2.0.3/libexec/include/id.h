/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          id.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef ID_H
#define ID_H

#include "common.h"

using namespace std;

class ID {
public:
	ID() {id = 0;}
	ID(Serial s, unsigned int c, unsigned int p, bool d); 
	ID(char *, bool d = false); 
	bool dual() {return id % 2;}
	unsigned int piece() {return (id & 0xfffeL) >> 1;}
	unsigned int library() {return (id & 0xffff0000L) >> 16;}
	Serial serial() {return (id & 0xffffffff00000000L) >> 32;}
	bool operator<(const ID & rhs) const {return id < rhs.id;};
	ID & operator=(const ID & rhs) {id = rhs.id; return *this;};
	bool operator==(const ID & rhs) const {return (id == rhs.id);};
	ID operator~() {ID ret = *this; if(dual()) ret.id &= 0xfffffffffffffffeL; else ret.id |= 0x1L; return ret;};

	IDBITS id; // bits 63-32: serial number, bits 31-16: library number, bits 15-1: in-library piece number, bit 0: primal or dual
};


#endif
