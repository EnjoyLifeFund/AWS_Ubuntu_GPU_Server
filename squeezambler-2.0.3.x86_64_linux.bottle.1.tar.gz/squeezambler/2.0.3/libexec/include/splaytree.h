/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          splaytree.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef SPLAYTREE_H
#define SPLAYTREE_H

#define _INITSIZE 4 

#include <iostream>
#include <iterator>
#include <stack>
#include "alloc.h"
#include "common.h"
#include "index.h"

using namespace std;

template<class Pair>
struct SplayNode {
	Pair pair;
	TreeIndex left; 
	TreeIndex right; 
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct SplayTreeIterator
{
	stack<TreeIndex> stck;
};

template<class Pair>
class SplayTree : public Index<Pair, TreeIndex> {
public:
	SplayTree();
	~SplayTree();
	bool insert(Pair &);
	TreeIndex add(Pair &);
	Pair *find(Pair &);
	Pair *find(TreeIndex);
	Pair& item(size_t);
	void setThreadSafe(bool t) {dosplay = !t;}
	size_t size() { return num; }
	void print();
	void printall();
	SplayTreeIterator* begin();
	Pair& next(SplayTreeIterator *); 
	bool hasNext(SplayTreeIterator * &);
	 
private:
	Alloc alloc;
	SplayNode<Pair> *sheet;
	TreeIndex root;
	TreeIndex maxNum;
	TreeIndex num;
	bool dosplay;

	void resize(TreeIndex s);
	TreeIndex newSlot();
	TreeIndex rotateLeft(TreeIndex i);
	TreeIndex rotateRight(TreeIndex i);
	void splay(Pair & pair);
	Pair *search(Pair &);
	void print(TreeIndex r);
	void pushLeft(SplayTreeIterator *it, TreeIndex x);
};

#endif

