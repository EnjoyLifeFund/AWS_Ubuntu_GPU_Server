/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          cnode.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  12/26/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef _CNODE_H
#define _CNODE_H

#include <map>
#include <vector>

#include "alloc.h"
#include "bag.h"
#include "common.h"
#include "compactstr.h"
#include "radixheap.h"

typedef Enum AuxType;
#define AUX_SP 1
#define AUX_NON 2

typedef Enum SPStatus; 
#define SP_NV 1
#define SP_EXP 2 
#define SP_FINAL 3

typedef Enum Duality; 
#define DUALITY_NEG -1
#define DUALITY_POS 1


using namespace std;

class CNode;
struct AuxSP;
class CNodeAuxSP;

class CNodeID {
public:	
	CNodeID(CNode *cn = NULL, Duality d = DUALITY_POS) : cnode(cn), duality(d) {};

	inline Coverage coverage();

	inline size_t size();
	inline Distance length();

	inline unsigned int indegree();
	inline unsigned int outdegree();

	inline CNodeID in(unsigned int i); 
	inline CNodeID out(unsigned int i);

	inline void setRemoval();
	inline bool removed();

	inline void connectin(CNodeID);
	inline void connectout(CNodeID);
	inline void disconnectin(CNodeID);
	inline void disconnectout(CNodeID);

	inline AuxSP *auxSP();
	inline AuxSP *newAuxSP(int procs); 
	inline CNodeAuxSP *newCNodeAuxSP(int prc, int deg); 
	inline CNodeAuxSP *cnodeAuxSP(int prc);
	inline void deleteCNodeAuxSP(int prc);
	inline void deleteAux();

	inline void save(FILE *);
	inline void load(FILE *);

	inline CNodeID operator-()
	{
		CNodeID ret;
		ret.cnode = cnode;
		ret.duality = -duality;
		return ret;
	}

	inline bool operator<(int rhs) const
	{
		return (duality < rhs);
	}

	inline bool operator>(int rhs) const
	{
		return (duality > rhs);
	}

	inline bool operator<(const CNodeID rhs) const //to be distinguished from (int) version
	{
		return (cnode < rhs.cnode || (cnode == rhs.cnode && duality < rhs.duality));
	}

	inline bool operator>(CNodeID rhs) const
	{
		return (cnode > rhs.cnode || (cnode == rhs.cnode && duality > rhs.duality));
	} 

	inline bool operator==(CNodeID rhs)
	{
		return (cnode == rhs.cnode && duality == rhs.duality);
	}

	inline bool operator!=(CNodeID rhs)
	{
		return (cnode != rhs.cnode || duality != rhs.duality);
	}
	
	inline operator bool() {return cnode;}

	inline UnitigSerial operator[] (unsigned int i); 

private:
	CNode *cnode;
	Duality duality;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

inline CNodeID abs(CNodeID i)
{
	if(i < 0)
		return -i;
	else
		return i;
}

struct SPInfo {
	Distance distance;
	CNodeID next;
	ShortestOrder nextindex;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct ShortestPaths {
	ShortestOrder ordersnum;
	SPInfo shortest[];
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct DijkstraTicket {
	unsigned int heapNode;
	Distance priority;
	CNodeID cnodeid;
	SPStatus status;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct FirstOrderList {
	int size;	
	int current;
	SPInfo items[];
};

class CNodeAuxSP {
public:
	CNodeAuxSP(int deg); 
	~CNodeAuxSP(); 

	void resize(int _sz);
	inline SPInfo & item(int itm) { return sorted1stOrder->items[itm]; }
	bool current(SPInfo &ret); 
	void inc();
	void sort();
	void insert(SPInfo a); 
	inline SPInfo & shortest(ShortestOrder order) {return shortests->shortest[order];}
	inline ShortestOrder orders() {return shortests->ordersnum;}

	DijkstraTicket ticket;

private:
	Alloc alloc;
	FirstOrderList *sorted1stOrder;
	ShortestPaths *shortests;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct HigherOrderTicket {
	Distance priority;
	ShortestOrder order;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct SPTreeNode {
	RadixHeap<HigherOrderTicket> *heap;
	size_t length;
	CNodeID cnodeid;
	ShortestOrder heapUpDateIdx;
	char active;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

struct AuxSP {
	CNodeAuxSP **cnodeAuxSP; //for each thread there will be one CNodeAuxSP
//	Bag<FixedArray<CNodeID, 3> > *copies;
	int procs;
//	char switchboardDisable;
//	Bag<CNodeID> *associates[2]; //rough mates for cnodeid and -cnodeid
	char *flag; // a general purpose flag, for each thread there will be a flag
};

inline bool operator<(HigherOrderTicket lhs, HigherOrderTicket rhs)
{
	return lhs.priority < rhs.priority;	
}

inline bool operator<=(HigherOrderTicket lhs, HigherOrderTicket rhs)
{
	return lhs.priority <= rhs.priority;	
}

inline bool operator<(DijkstraTicket lhs, DijkstraTicket rhs)
{
	return lhs.priority < rhs.priority;	
}

inline bool operator<=(DijkstraTicket lhs, DijkstraTicket rhs)
{
	return lhs.priority <= rhs.priority;	
}

class Contig {
public:
	Contig() {len = 0;}
	
	basic_string<UnitigSerial> seq; // sequence of 1-based Serial numbers of unitigs, minus means dual
	Distance len; // in nucleotides
	Coverage coverage; // in kmers

	void append(CNodeID from, int k);
};

class CNode {
public:
	CNode();
	CNode(UnitigSerial s, Distance l, Coverage c);
	~CNode();
	void connectin(CNodeID cnodeid);
	void connectout(CNodeID cnodeid);
	void disconnectin(CNodeID cnodeid);
	void disconnectout(CNodeID cnodeid);
	inline unsigned int indegree() {return indeg;}
	inline unsigned int outdegree() {return outdeg;}
	inline CNodeID out(unsigned int i) {return outedges[i];}
	inline CNodeID in(unsigned int i) {return inedges[i];} 
	inline size_t size() {return contig.seq.size();}
	inline Distance length() {return contig.len;}

	inline AuxSP *auxSP() {if(auxType == AUX_SP) return (AuxSP *)aux; else return NULL;}      
	AuxSP *newAuxSP(int procs); // twice the number of threads should be passed here as proc for the primal and dual
	CNodeAuxSP *newCNodeAuxSP(int prc, int deg); 
	CNodeAuxSP *cnodeAuxSP(int prc);
	void deleteCNodeAuxSP(int prc);
	void deleteAux();

	inline Coverage coverage() {return contig.coverage;}
	inline void append(CNodeID from, int k) {contig.append(from, k);}
	inline void append(UnitigSerial s) {contig.seq += s;}
	inline void setRemoval() {contig.len = 0;}
	inline bool removed() {return contig.len == 0;}
	inline UnitigSerial utg(unsigned int i) {return contig.seq[i];}

	void save(FILE *out);
	void load(FILE *in);

private:
	Alloc alloc;
	CNodeID *inedges; 
	unsigned int indeg;
	CNodeID *outedges;
	unsigned int outdeg;
        void *aux;
	AuxType auxType;
//	CompactString<CompactWord> seq;
	Contig contig;
};

inline Coverage CNodeID::coverage()
{
	return cnode->coverage();
}

inline size_t CNodeID::size()
{
	return cnode->size();
}

inline Distance CNodeID::length()
{
	return cnode->length();
}

inline unsigned int CNodeID::indegree() 
{
	return (duality < 0) ? cnode->outdegree() : cnode->indegree();
}

inline unsigned int CNodeID::outdegree() 
{
	return (duality < 0) ? cnode->indegree() : cnode->outdegree(); 
}

inline CNodeID CNodeID::in(unsigned int i) 
{
	return (duality < 0) ? -(cnode->out(i)) : cnode->in(i);
}

inline CNodeID CNodeID::out(unsigned int i) 
{
	return (duality < 0) ? -(cnode->in(i)) : cnode->out(i);
}

inline void CNodeID::setRemoval()
{
	cnode->setRemoval();
}

inline bool CNodeID::removed()
{
	return cnode->removed();
}

inline UnitigSerial CNodeID::operator[] (unsigned int i) 
{
	return (duality < 0) ? -cnode->utg(size() - i - 1) : cnode->utg(i);
} 

inline void CNodeID::connectin(CNodeID n)
{
	if(duality > 0)
		cnode->connectin(n);
	else
		cnode->connectout(-n);
}

inline void CNodeID::connectout(CNodeID n)
{
	if(duality > 0)
		cnode->connectout(n);
	else
		cnode->connectin(-n);
}

inline void CNodeID::disconnectin(CNodeID n)
{
	if(duality > 0)
		cnode->disconnectin(n);
	else
		cnode->disconnectout(-n);
}

inline void CNodeID::disconnectout(CNodeID n)
{
	if(duality > 0)
		cnode->disconnectout(n);
	else
		cnode->disconnectin(-n);
}

inline AuxSP *CNodeID::auxSP()
{
	return cnode->auxSP();
}

inline AuxSP *CNodeID::newAuxSP(int procs)
{
	return cnode->newAuxSP(2*procs); // twice the number of threads should be passed here as proc for the primal and dual
} 

inline CNodeAuxSP *CNodeID::newCNodeAuxSP(int prc, int deg)
{
	return cnode->newCNodeAuxSP(2*prc+((duality < 0) ? 1 : 0), deg);
} 

inline CNodeAuxSP *CNodeID::cnodeAuxSP(int prc)
{
	return cnode->cnodeAuxSP(2*prc+((duality < 0) ? 1 : 0));
}

inline void CNodeID::deleteCNodeAuxSP(int prc)
{
	return cnode->deleteCNodeAuxSP(2*prc+((duality < 0) ? 1 : 0));
}

inline void CNodeID::deleteAux()
{
	cnode->deleteAux();
}

inline void CNodeID::save(FILE *out)
{
	cnode->save(out);
}

inline void CNodeID::load(FILE *in)
{
	cnode->load(in);
}


#endif
