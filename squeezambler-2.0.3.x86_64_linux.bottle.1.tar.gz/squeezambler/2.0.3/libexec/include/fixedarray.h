/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          fixedarray.h 
 * Author:         Zeinab Taghavi
 * Created:        2012
 * Last modified:  10/08/2013
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef FIXEDARRAY_H
#define FIXEDARRAY_H


template <class T, int size>
struct FixedArray {
public:
	template <class S>
	FixedArray<T, size>(FixedArray<S, size> rightHandSide) 
	{	
		for(int n = 0; n < size; n++)
			elements[n] = (T)rightHandSide[n];
	} 

	FixedArray<T, size>(T val) 
	{
		*this = val;
	}

	FixedArray<T, size>() 
	{
		init();
	}

	inline void init() { *this = 0;} 

        inline void init(int i){elements[i] = 0;}
	
	inline T max() 
	{
		T ret = elements[0];
		for(int n = 1; n < size; n++)
		{
			if(elements[n] > ret) 
				ret = elements[n];
		}
		return ret;
	}
        
	inline T min() 
	{
		T ret = elements[0];
		for(int n = 1; n < size; n++)
		{
			if(elements[n] < ret) 
				ret = elements[n];
		}
		return ret;
	}
      
	inline T & operator[](unsigned int i) {return elements[i];}

	inline FixedArray<T, size> operator*(FixedArray val)
	{ 
		FixedArray<T, size> tmp;
		for(int n = 0; n < size; n++)
			tmp[n] = elements[n] * val[n];

		return tmp;
	}

	inline FixedArray<T, size> operator/(T val)
	{ 
		FixedArray<T, size> tmp;
		for(int n = 0; n < size; n++)
			tmp[n] = elements[n] / val;

		return tmp;
	}

	inline FixedArray<T, size> operator/(FixedArray rhs)
	{ 
		FixedArray<T, size> tmp;
		for(int n = 0; n < size; n++)
			if(rhs[n])
				tmp[n] = elements[n] / rhs[n];
			else
				tmp[n] = elements[n];

		return tmp;
	}

	inline FixedArray<T, size> & operator+=(FixedArray rhs) 
	{
		for(int n = 0; n < size; n++)
			elements[n] = elements[n] + rhs[n];

		return *this;
	}

	inline bool operator!() 
	{
		return *this == 0;
	}

	inline bool operator<=(FixedArray rhs)
	{ 
		for(int n = 0; n < size; n++)
			if(elements[n] > rhs[n]) return false;

		return true;
	}

	inline FixedArray<T, size> & operator=(T val)
	{ 
		for(int n = 0; n < size; n++)
			elements[n] = val;

		return *this;
	}

private:
	T elements[size];

	inline bool operator==(T val)
	{ 
		bool ret = true; 
		for(int n = 0; n < size; n++)
			if(elements[n] != val)
			{ 
				ret = false;
				break;
			}

		return ret;
	}
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

#endif
