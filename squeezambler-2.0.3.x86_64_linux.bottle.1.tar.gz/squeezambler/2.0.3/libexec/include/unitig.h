/*
Copyright 2012- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          unitig.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2012
 * Last modified:  03/15/2012
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/



#ifndef _UNITIG_H_
#define _UNITIG_H_

#include <list>
#include <iostream>

#include "common.h"

using namespace std;


class Unitig {
public:
	list<Nucleotide> seq;
        Edges begin_edges, end_edges, edges;
	Coverage coverage; // sum of the multiplicities of individual vertices

	inline Distance length() {return seq.size();}

	inline void getnucs(Nucleotide *nucs)
	{
		int cnt = 0;
		for(list<Nucleotide>::iterator it = seq.begin(); it != seq.end(); it++)
			nucs[cnt++] = *it;
	}

	void print(FILE *out, Serial number, int k)
	{
		fprintf(out, ">serial_%ld_length_%ld_edges_%d_k_%d", number, seq.size(), (int) edges, k);  
		for(int n = 0; n < MAXCOLORS; n++)
			fprintf(out, "_cnt%d_%ld", n, coverage[n]);  		
        	fprintf(out, "\n");  


		int cnt = 0;
		for(list<Nucleotide>::iterator it = seq.begin(); it != seq.end(); it++)
		{
			cnt++;
			fprintf(out, "%c", nuc2char(*it));
			if(cnt >= 60)
			{
				fprintf(out, "\n");
				cnt = 0;
			}
		}
		fprintf(out, "\n");
	}

	void print(ostream &out, Serial number, int k)
	{
		out << ">serial_"<< number << "_length_" << seq.size() << "_edges_" << (int) edges << "_k_" << k;
 		for(int n = 0; n < MAXCOLORS; n++)
			out << "_cnt" << n << "_" << coverage[n];  		
   		out << endl;

		int cnt = 0;
		for(list<Nucleotide>::iterator it = seq.begin(); it != seq.end(); it++)
		{
			cnt++;
			out << nuc2char(*it);
			if(cnt >= 60)
			{
				out << endl;
				cnt = 0;
			}
		}
		out << endl;
	}

/*	void scan(char *name, char *str, Serial *number, int *k)
	{
		size_t sz;
		int intedges;

		if(sscanf(name, "serial_%ld_length_%ld_edges_%d_k_%d", number, &sz, &intedges, k) < 4)
		{
			
			cerr << name << endl;
			exitMsg((char*)"Error: Unitig panic: unitigs file is corrupted: unitig name not in expected format.", UNITIGS_FILE_ERROR);
		}

		if(sz != strlen(str))
		{
			cerr << name << endl;
			cerr << "claimed length = " << sz << " whereas actual length = " << strlen(str) << endl;
			exitMsg((char*)"Error: Unitig panic: unitigs file is corrupted: inconsistent length.", UNITIGS_FILE_ERROR);
		}

		if(sz < *k)
		{
			cerr << name << endl;
			cerr << "length = " << sz << " < k = " << *k << endl;
			exitMsg((char*)"Error: Unitig panic: unitigs file is corrupted: inconsistent length and k.", UNITIGS_FILE_ERROR);
		}

		edges = (Edges) intedges;
		for(Coordinate i = 0; i < sz; i++)
			seq.push_back(char2nuc(str[i])); 
	} */

	void save(FILE *out)
	{
		size_t sz = seq.size();
		write_in_file(&edges, sizeof(Edges), 1, out);
		write_in_file(&coverage, sizeof(Coverage), 1, out);
		write_in_file(&sz, sizeof(size_t), 1, out);
		
		Nucleotide *sq = new Nucleotide[sz];
		Coordinate cnt = 0;
		for(list<Nucleotide>::iterator it = seq.begin(); it != seq.end(); it++)
			sq[cnt++] = *it;

		write_in_file(sq, sizeof(Nucleotide), sz, out);
		delete[] sq;
	}

	void load(FILE *in)
	{
		size_t sz;
		read_from_file(&edges, sizeof(Edges), 1, in);
		read_from_file(&coverage, sizeof(Coverage), 1, in);
		read_from_file(&sz, sizeof(size_t), 1, in);
		
		Nucleotide *sq = new Nucleotide[sz];
		read_from_file(sq, sizeof(Nucleotide), sz, in);

		for(Coordinate i = 0; i < sz;)
			seq.push_back(sq[i++]);
		delete[] sq;
	}
};

#endif
