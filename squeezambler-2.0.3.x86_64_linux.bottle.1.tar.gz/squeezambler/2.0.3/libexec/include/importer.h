/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          importer.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  03/07/2013
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/



#ifndef _IMPORTER_H_
#define _IMPORTER_H_

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <set>
#include <fstream>
#include <iostream>

#include "common.h"
#include "sequence.h"
#include "logger.h"
#include "id.h"

using namespace std;

template <class T>
struct Library {
	vector<T> files;
	bool fasta;
};

class Importer {
public:
	Importer(Logger *_logger, vector<Library<string> > _inputLibnames, string _outputFile,
	bool _truncate = false, bool _fastqout = false,
	int _maxN = 4,
	int _minLen = 0,
	int _BADQFLAG = 'B');
	~Importer();

	void import(size_t *maxnucs = NULL, int base_lib = 0);
	void openOutput(bool append = false) {if (append) output.open(outputFile.c_str(), ios::out | ios::app); else output.open(outputFile.c_str(), ios::out);}	
	void closeOutput() {output.close();}	
	bool iseof(int lib);

	static void tokenize(string & s, vector<string> & tokens, const string & del);

private:
	Logger *logger;
	vector<Library<ifstream *> > inputLibs;
	string outputFile;
	bool truncate, fastqout;
	int maxN;
	int minLen;
	int BADQFLAG;
	ofstream output;
	unsigned int libs;
	time_t now;
};

#endif
