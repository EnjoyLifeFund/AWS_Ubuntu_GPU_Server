/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          compactstr.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  01/24/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef COMPACTSTR_H
#define COMPACTSTR_H

#include <string>
#include <iostream>
#include <ostream>

#include "common.h"
#include "alloc.h"

#define CAN_SIZE (sizeof(Word)*NUCS_PER_BYTE)

using namespace std;

template<class Word>
class CompactString {
public:
	CompactString();
	~CompactString();
	CompactString & operator=(const CompactString & rhs);
	Nucleotide operator[](unsigned int);
	void append(Nucleotide);
	void append(Nucleotide *, size_t);
	void append(CompactString &, size_t begin, size_t end, bool orientation, bool dual = false); //inclusive of begin and exclusive of end

	void clear() {len = 0; if(str) alloc.xfree((void*&)str);}

	void save(FILE *);
	void load(FILE *);

	size_t size() const {return len;};
	Distance length() const {return len;};
	inline size_t compactsize() const {return len / CAN_SIZE  + ((len % CAN_SIZE) ? 1 : 0);};
	void copy(const Word *n, size_t sz) {resize(sz); memcpy(str, n, compactsize());}
	const Word *getStr() const {return str;};

	void print(FILE *out, Coordinate start, Coordinate end);
	void print(FILE *out);
	void print(ostream & out);

private:
	Word *str;
	size_t len;
	Alloc alloc;

	void sprint(char *s);
	void sprint(char *s, unsigned int, unsigned int);
	void resize(size_t s);
	void expand(size_t s);

	inline void address(size_t idx, size_t &word, size_t &offset)
	{
		word = idx / CAN_SIZE;
		offset = idx % CAN_SIZE;
	} 
};

#endif
