/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          common_squeezambler.h 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/
#ifndef COMMON_SQUEEZAMBLER_H
#define COMMON_SQUEEZAMBLER_H

using namespace std;
#include "common.h"
#include "importer.h"
#include <math.h> 
#include <vector> 

//#define FILE_STRING (char *)"squeezambler"
//#define FILE_VERSION (char *)"Squeezambler 2.0.3"
//#define MAXFILECHAR	2000
#define MAXSTEPS 1000
#define MAXLIBCOLOR (MAXSTEPS*MAXLIBRARIES)
#define MAXBARCODE 20
#define MAXPOWERBARCODE 1048576 //(pow(2, MAXBARCODE)) 
#define MAXCONTIGNUM 10000000
#define MINCONTIGCOVERAGE 1.0
typedef uint64_t Lib;
typedef double CovType;
typedef uint64_t AssemblySize;
typedef uint64_t NucNum;
typedef double Ratio;

template <class LISTTYPE, int LISTSIZE>
struct CList { 
LISTTYPE list[LISTSIZE];
size_t listNo;
};

typedef CList <Lib, MAXLIBRARIES> LibraryList;
typedef CList <LibraryList, MAXCOLORS> ColorsLibList;
typedef CList <Color, MAXCOLORS> Colors_List;
typedef vector<Library<string> > LibNamesList;

struct Stat {
	AssemblySize assemblySize;
	CovType	averageCoverage;
};

#endif

