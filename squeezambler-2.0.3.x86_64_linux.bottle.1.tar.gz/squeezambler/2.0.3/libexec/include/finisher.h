/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          finisher.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/



#ifndef _FINISHER_H_
#define _FINISHER_H_

#include <malloc.h>
#include <stdlib.h>

#include "asmengine.h"

using namespace std;

class Finisher {
public:
	Finisher(string _inputFilename, string _unitigFilename, string _configFilename,
	string _outputName,
	string _saveCGFilename, string _loadCGFilename,
	bool _fasta,
	int _procs,
	double _covThresh, // if -1 then consider per color normalized, if -2 then consider absolute.
	AvgCoverage _covThreshPerColorNormalized,
	Coverage _covThreshPerColorAbsolute,
	int _lowCovLenThresh,
	int _minContigLength,
	bool _doublestrand,
	int _exportGraph,
	bool _exportRemovedNodes,
	bool _exportAsm,
	bool _noLowCovUnitigs,
	bool _specificColors[MAXCOLORS],
	AvgCoverage _minOutputContigCoverage,
	bool _keepref,
	Logger *_logger);

	vector<ContigMetadata> metadata() {return contigmetadata;}

private:
	Logger *logger;
	string inputFilename, unitigFilename, configFilename;
	string outputName;
	string saveCGFilename, loadCGFilename;
	bool fasta;
	int procs;
	double covThresh;
	AvgCoverage covThreshPerColorNormalized;
	Coverage covThreshPerColorAbsolute;
	int lowCovLenThresh;
	int minContigLength;
	bool doublestrand;
	int exportGraph;
	bool exportRemovedNodes;
	bool exportAsm;
	bool noLowCovUnitigs;
	bool specificColors[MAXCOLORS];
	bool keepref;
	AvgCoverage minOutputContigCoverage;
	vector<ContigMetadata> contigmetadata;
};

#endif
