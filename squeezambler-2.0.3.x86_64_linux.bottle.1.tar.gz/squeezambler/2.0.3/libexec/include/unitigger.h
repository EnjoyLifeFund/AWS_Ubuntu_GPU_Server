/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          unitigger.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/



#ifndef _UNITIGGER_H_
#define _UNITIGGER_H_

#include <malloc.h>
#include <stdlib.h>

#include "implicitgraph.h"
#include "logger.h"
#include "reads.h"
#include "getopt.h"

using namespace std;

template <class NodeInfo>
class Unitigger {
public:
	Unitigger(string _inputFilename,
	string _outputName,
	string _configFilename,
	int _machines, int _slice,
	bool _fasta,
	int _procs,
	bool _doublestrand,
	int _k,
	bool _exportkmers,
	ImplicitGraph<NodeInfo> *g,
	Logger *_logger);

	Unitigger(string _inputFilename,
	string _outputName,
	Color _colors[MAXLIBRARIES],
	int _machines, int _slice,
	bool _fasta,
	int _procs,
	bool _doublestrand,
	int _k,
	bool _exportkmers,
	ImplicitGraph<NodeInfo> *g,
	Logger *_logger);


private:
	Logger *logger;
	ImplicitGraph<NodeInfo> *graph;
	K kforge;
	Color colors[MAXLIBRARIES];

	string inputFilename;
	string outputName;
	string configFilename;
	int machines, slice;
	bool fasta;
	int procs;
	bool doublestrand;
	int k;
	bool exportkmers;

	void index(Read & r, size_t & current);
	void exportKmers(string outputName, int slice);
	void index(Reads & reads);
	void makeGraph(string inputFilename);
	void condense(Kmer &kmer, Direction direction, Serial &number, size_t *kmersNum, FILE *out);
	void condenseGraph(string outputFilename);
	void loadConfigFile(FILE *cfgfile);
};

#endif
