/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          kmer.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#ifndef _KMER_H_
#define _KMER_H_

#include <iostream>
#include <ostream>
#include <stdint.h>
#include "common.h"

#define __QUOTIENT (MAXK / 4)
#define __REMAINDER (MAXK % 4)
#if __REMAINDER
#define __KMER_BYTES (__QUOTIENT + 1)
#else
#define __KMER_BYTES __QUOTIENT
#endif
#define __64S (__KMER_BYTES / 8)
#define __32S ((__KMER_BYTES % 8) / 4)
#define __16S ((__KMER_BYTES % 4) / 2)
#define __8S (__KMER_BYTES % 2)

using namespace std;

class Kmer {
public:
	#if __64S
	uint64_t toonies[__64S];
	#endif
	#if __32S
	uint32_t loonie;
	#endif
	#if __16S
	uint16_t half;
	#endif
	#if __8S
	uint8_t quarter;
	#endif

	Kmer() 
	{
	#if __64S
		for (int i = 0; i < __64S; i++)
			toonies[i] = 0;
	#endif
	#if __32S
		loonie = 0;
	#endif
	#if __16S
		half = 0;
	#endif
	#if __8S
		quarter = 0;
	#endif
	};

	void print(FILE *fout) 
	{
	#if __64S
		for (int i = 0; i < __64S; i++)
			fprintf(fout, "%llx\t", (long long) toonies[i]);
	#endif
	#if __32S
		fprintf(fout, "%x\t", loonie);
	#endif
	#if __16S
		fprintf(fout, "%x\t", half);
	#endif
	#if __8S
		fprintf(fout, "%hx\t", quarter);
	#endif
		fputs("", fout);
	}

	void print(ostream &out) 
	{
		char buffer[50000] = "";

	#if __64S
		for (int i = 0; i < __64S; i++)
			sprintf(buffer, "%s%llx\t", buffer, (long long) toonies[i]);
	#endif
	#if __32S
		sprintf(buffer, "%s%x\t", buffer, loonie);
	#endif
	#if __16S
		sprintf(buffer, "%s%x\t", buffer, half);
	#endif
	#if __8S
		sprintf(buffer, "%s%hx\t", buffer, quarter);
	#endif
		out << buffer << endl;
	}
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;


int kmercmp(const Kmer& k1, const Kmer& k2);
size_t kmerhash(const Kmer&);
size_t kmerhashmax();
ostream& operator<<(ostream & out, Kmer & kmer);
bool operator<(const Kmer& lhs, const Kmer& rhs);
bool operator==(const Kmer& lhs, const Kmer& rhs);
bool operator!=(const Kmer& lhs, const Kmer& rhs);


#define __TOONIES 4
#define __LOONIE 3
#define __HALF 2
#define __QUARTER 1

struct __Index
{
	int index;
	int offset;
	int type;
};

// developed in order to use in hashtable (example in align-longreads.c)
struct WrapperKmer{
	Kmer kmer;
	inline size_t hashMax() {return kmerhashmax();}
	inline size_t hash() {return kmerhash(kmer);}
};

class K {
private:
	static const uint64_t toonieMSN = (uint64_t) 3 << 62; 
	static const uint32_t loonieMSN = (uint32_t) 3 << 30; 
	static const uint16_t halfMSN = (uint16_t) 3 << 14; 
	static const uint8_t quarterMSN = (uint8_t) 3 << 6; 

	static const uint64_t nottoonieMSN = (uint64_t)~((uint64_t) 3 << 62); 
	static const uint32_t notloonieMSN = (uint32_t)~((uint32_t) 3 << 30); 
	static const uint16_t nothalfMSN = (uint16_t)~((uint16_t) 3 << 14); 
	static const uint8_t notquarterMSN = (uint8_t)~((uint8_t) 3 << 6); 

	static const uint64_t toonieLSN = (uint64_t) 3; 
	static const uint32_t loonieLSN = (uint32_t) 3; 
	static const uint16_t halfLSN = (uint16_t) 3; 
	static const uint8_t quarterLSN = (uint8_t) 3; 

	int maskIndex;
	int offset;
	int indexType;
	uint64_t toonieMask; 
	uint32_t loonieMask; 
	uint16_t halfMask; 
	uint8_t quarterMask; 
	
	__Index indices[MAXK];

	unsigned int _k; 
	void makeMasks();
	void makeIndices();

public:
	K(int k = MAXK);
	void reset(int k);
	Nucleotide push_end(Kmer & kmer, Nucleotide n);
	void push_begin(Kmer & kmer, Nucleotide n);
	Nucleotide replace(Kmer & kmer, int pos, Nucleotide n);
	Nucleotide getnuc(Kmer & kmer, int pos);
	Kmer dual(Kmer &);
	void print(Kmer &, FILE *);
	unsigned int k() {return _k;};
};


#endif 
