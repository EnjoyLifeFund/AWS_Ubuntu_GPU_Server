/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          common.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  09/17/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef COMMON_H
#define COMMON_H

//works only for gcc
#define PACK_MEMORY 1

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string>
#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream>

#include "fixedarray.h"

#ifndef NULL
#define NULL 0
#endif

#ifndef true
#define true 1
#define false 0
#endif

#define PACKAGE_STRING "HyDA 1.3.1"

#define NUCS 4
#define BITS_PER_NUC 2
#define NUCS_PER_BYTE 4
#define NUCS_MASK 0x3
#define WILDCARD_NUC 15
#define INT_INFINITY (0xffffffffffffffffL)


//ID constants
#define MAXPIECES 2
#define MAXLIBRARIES 1000

//The program handles all general cases. This is just a convenient constant.
#define LOW_COV_DISCRIMINANT 5
#define MIN_COV_THRESH 2

#ifndef MAXCOLORS
#define MAXCOLORS 1
#endif

typedef int64_t Coordinate; 
typedef uint64_t Distance;
typedef uint8_t Edges;
typedef int32_t HashIndex;
typedef uint64_t IDBITS;
typedef uint64_t CompactWord;
typedef uint8_t Nucleotide;
typedef uint16_t Oligomer;
typedef uint64_t Serial;
typedef int64_t UnitigSerial;
typedef int32_t ShortestOrder;
typedef uint16_t TreeIndex;
typedef int8_t Enum;


//Color handling department
typedef int8_t Color;    
typedef uint64_t CoverageType;
typedef uint16_t MultType;  
typedef FixedArray<CoverageType, MAXCOLORS> Coverage; 
typedef FixedArray<MultType, MAXCOLORS> Mult; 
typedef FixedArray<double, MAXCOLORS> AvgCoverage; 


enum Direction {DIR_FORWARD = 1, DIR_BACKWARD = 2};


#define NULLIDX ((TreeIndex)(-1))


#ifndef FIXEDPOINTPROB
typedef double Probability;
#define MAXPROB 1.0
#define NORMAL(X) (X)
#define REVNORMAL(X) (X)
#else
typedef unsigned short int Probability;
#define MAXPROB (USHRT_MAX)
#define NORMAL(X) ((X)*1.0/MAXPROB)
#define REVNORMAL(X) ((Probability)((X)*MAXPROB))
#endif

#define MIN(A, B)  (((A) < (B)) ? (A) : (B))
#define MAX(A, B)  (((A) < (B)) ? (B) : (A))
#define ADDRESS2D(A,B,L) ((A)*(L)+(B))

//#define TOSTR( x ) dynamic_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

void version(char* prog);
void version(std::ofstream &, char* prog);
Nucleotide char2nuc(char c);
char nuc2char(Nucleotide n);
char dual(char c);

inline Nucleotide dualnuc(Nucleotide c);
inline Edges setin(Edges e, Nucleotide n);
inline Edges setout(Edges e, Nucleotide n);
inline Edges unsetin(Edges e, Nucleotide n);
inline Edges unsetout(Edges e, Nucleotide n);
inline Edges dualedge(Edges e);


typedef enum {
	NO_ERROR = 0,
	FILE_OPEN_ERROR = 1, 
	UNITIGS_FILE_ERROR = 2, 
	CONFIG_FILE_ERROR = 3, 
	INTERNAL_DIJKSTRA_ERROR = 4, 
	INTERNAL_RADIXHEAP_ERROR = 5,
	INTERNAL_SPLAYTREE_ERROR = 6,
	INPUT_ARG_ERROR = 7,
	OUTPUT_ARG_ERROR = 8,
	INTERNAL_WOW_ERROR = 9
} Error;


FILE *open_file(char *fname, const char *mode);
FILE *open_file(std::string fname, const char *mode);
void write_in_file ( const void * ptr, size_t size, size_t count, FILE * stream );
void read_from_file ( void * ptr, size_t size, size_t count, FILE * stream );
void read_from_buf ( void * ptr, size_t size, size_t count, char *&buf );
void exitMsg(char *, Error);

// FixedArray is moved to fixedarray.h

inline Nucleotide dualnuc(Nucleotide c)
{
	return 3-c;
}

// MSB -> A(in), C(in), G(in), T(in), T(out), G(out), C(out), A(out) <- LSB   (for the dual just exchange the two half bytes)
inline Edges setin(Edges e, Nucleotide n)
{
	return e | ((Edges) 0x80 >> n);
}

inline Edges setout(Edges e, Nucleotide n)
{
	return e | ((Edges) 1 << n);
}

inline Edges setmix(Edges in, Edges out)
{
	return (out & 0x0F) | (in & 0xF0);
}

inline Edges unsetin(Edges e, Nucleotide n)
{
	return e & (~((Edges) 0x80 >> n));
}

inline Edges unsetout(Edges e, Nucleotide n)
{
	return e & (~((Edges) 1 << n));
}

inline Edges dualedge(Edges e)
{
	return ((Edges) e >> 4) | ((Edges) e << 4);
}

#endif

