/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          asmengine.h 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  03/12/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#ifndef ASMENGINE_H
#define ASMENGINE_H


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <algorithm>
#include <set>
#include <iostream>
#include <unistd.h>
#include <math.h>
#include <omp.h>

#include "bag.h"
#include "common.h"
#include "compactstr.h"
#include "hashtable.h"
#include "logger.h"
#include "kmers.h"
#include "getopt.h"
#include "cgraph.h"
#include "oligo.h"
#include "record.h"
#include "sequence.h"


//the algorithm that uses the following constants is flexible, therefore these are just some convenient guesses 
#define __MAXLINE 10000
#define __MAXCONFIGS 1000

using namespace std;

struct MatingInfo {
	int lib, maxlib;
	unsigned int pieces;
	Direction dirs[MAXPIECES];
	Distance insertMax, insertMin, insertMean, tolerance;
	int confignum;
};

struct UnitigConnection {
	UnitigSerial serial;
	Enum dir; // 0 means from kmer to the unitig and 1 means from unitig to the kmer
};

struct ContigMetadata {
	size_t length;
	AvgCoverage coverages;
};

#define KMER_TO_UNITIG 0
#define UNITIG_TO_KMER 1



class AsmEngine {
public:
	AsmEngine(string _inputFilename, string _unitigFilename, string _configFilename, string _outputName, bool _fasta, int _procs, bool _doublestrand, bool _loadLowCovKmers, Logger *_logger);
	~AsmEngine();

	void makeCGraph();
	void condenseGraph();
	void joinContigs();
	void exportLowCoverage(AvgCoverage avgcov, int lenthresh, FILE *);
	AvgCoverage getAvgCoverage(int lenthresh);
	void removeLowCoverage(AvgCoverage avgcov, int lenthresh);
	void mapReads();
	void doMating();
	vector<ContigMetadata> outputContigs(int minContigLen, bool exportAsm, bool specificColors[MAXCOLORS], AvgCoverage minOutputContigCoverage);

	void saveCG(string filename);
	void loadCG(string filename);
	void exportG(int version, int maxins);

	long int NX(double x) {return cgraph->NX(x);}

	int getk() {return k;}

private:
	Alloc alloc;
	Logger *logger;
	string inputFilename, unitigFilename, configFilename;
	string outputName;
	bool fasta;
	int procs;
	int k;
	size_t kmersNum[LOW_COV_DISCRIMINANT], effectiveKmersNum;
	Serial unitigsNum;
	bool doublestrand;
	bool loadLowCovKmers;
	MatingInfo matingInfo[__MAXCONFIGS];
	Bag<MatingInfo *> matingConfigs[MAXLIBRARIES];
	int configs;

	K kforge;

	Graph *cgraph;

	void loadConfig();
	void connectUnitigsBS(KmerData<UnitigConnection> *, size_t, KmerData<CNode *> *); // binary search implementation
	void connectUnitigsP(KmerData<UnitigConnection> *, size_t, KmerData<CNode *> *); // progressive implementation
	string getSeq(CNodeID cnodeid, map<UnitigSerial, CompactString<CompactWord> *> &unitigs);
	string getSeq(CNodeID cnodeid, map<UnitigSerial, CompactString<CompactWord> *> &unitigs, bool multiline);
	Serial findNobranchingPath(CNodeID cnodeid, Serial id, string seq, FILE *out, map<UnitigSerial, CompactString<CompactWord> *> &unitigs, map<CNodeID, Serial> &nodeNumber, map<CNodeID, bool> traversed, double minCov, Color c);
};

#endif


