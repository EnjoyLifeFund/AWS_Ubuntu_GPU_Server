/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          fibheap.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "fibheap.h"
#include <limits.h>
#include <stdlib.h>


static inline int64_t mylog2(int64_t x)
{
	int64_t old;
	int64_t ret;
	int64_t bits;
	int64_t cons;

	old = x;
	bits = sizeof(int64_t)*4;
	ret = 0;
	while (bits) 
	{
		ret = (ret << 1);
		cons = ((int64_t) 1) << bits;
		if (x >= cons) {
			x /= cons;
			ret = ret | 1;
		} else
			x &= cons - 1;
		bits /= 2;
	}
	if ((((int64_t) 1 << ret)) == old)
		return ret;
	else
		return ret + 1;
}

template <class Element>
FibHeap<Element>::FibHeap()
{
	N = 0;
	Dl = -1;
	cons = NULL;
	min = NULL;
	root = NULL;
}

template <class Element>
FibHeap<Element>::~FibHeap()
{
	while(size() > 0)
		extractMin();
	if(cons) free(cons);
}

template <class Element>
FibHeapNode<Element> *FibHeap<Element>::insert(Element *data)
{
	FibHeapNode<Element> *x = newElement();

	if (!x)	return NULL;

	x->data = data;

	insertRootList(x);

	if (min == NULL || *(x->data) < *(min->data))
		min = x;

	N++;
	return x;
}

template <class Element>
Element *FibHeap<Element>::extractMin()
{
	Element *ret = NULL;

	if (min != NULL) 
	{
		FibHeapNode<Element> *z;
		FibHeapNode<Element> *orig;

		z = min;

		orig = NULL;
		for (FibHeapNode<Element> *x = z->child; x != orig && x != NULL;) 
		{
			if (orig == NULL)
				orig = x;

			FibHeapNode<Element> *y = x->right;
			x->parent = NULL;
			insertRootList(x);
			x = y;
		}
		removeRootList(z);
		N--;

		if (N == 0)
			min = NULL;
		else 
		{
			min = z->right;
			consolidate();
		}
		ret = z->data;
		delete z;
	}

	return ret;
}

template <class Element>
void FibHeap<Element>::insertRootList(FibHeapNode<Element> *x)
{
	if (root == NULL) {
		root = x;
		x->left = x;
		x->right = x;
		return;
	}

	insertAfter(root, x);
}

template <class Element>
void FibHeap<Element>::removeRootList(FibHeapNode<Element> *x)
{
	if (x->left == x)
		root = NULL;
	else
		root = remove(x);
}

template <class Element>
void FibHeap<Element>::consolidate()
{
	FibHeapNode<Element> *w;
	FibHeapNode<Element> *y;
	FibHeapNode<Element> *x;

	checkcons();

	for (int i = 0; i < Dl + 1; i++)
		cons[i] = NULL;

	while ((w = root) != NULL) 
	{
		x = w;
		removeRootList(w);
		int d = x->degree;
		while (cons[d] != NULL) 
		{
			y = cons[d];
			if (*(x->data) > *(y->data))
			{
				FibHeapNode<Element> *temp = x;
				x = y;
				y = temp;
			}
			heaplink(y, x);
			cons[d] = NULL;
			d++;
		}
		cons[d] = x;
	}
	min = NULL;
	for (int i = 0; i < Dl + 1; i++)
		if (cons[i] != NULL) 
		{
			insertRootList(cons[i]);
			if (min == NULL || *(cons[i]->data) < *(min->data))
				min = cons[i];
		}
}

template <class Element>
void FibHeap<Element>::heaplink(FibHeapNode<Element> *y, FibHeapNode<Element> *x)
{
	if (x->child == NULL)
		x->child = y;
	else
		insertBefore(x->child, y);
	y->parent = x;
	x->degree++;
	y->mark = 0;
}


template <class Element>
FibHeapNode<Element> *FibHeap<Element>::newElement()
{
	FibHeapNode<Element> *e = new FibHeapNode<Element>;

	if (!e) return NULL;

	e->degree = 0;
	e->mark = 0;
	e->parent = NULL;
	e->child = NULL;
	e->left = e;
	e->right = e;
	e->data = NULL;

	return e;
}

template <class Element>
void FibHeap<Element>::insertAfter(FibHeapNode<Element> * a, FibHeapNode<Element> * b)
{
	if (a == a->right) {
		a->right = b;
		a->left = b;
		b->right = a;
		b->left = a;
	} else {
		b->right = a->right;
		a->right->left = b;
		a->right = b;
		b->left = a;
	}
}

template <class Element>
void FibHeap<Element>::insertBefore(FibHeapNode<Element> * a, FibHeapNode<Element> * b)
{
	insertAfter(a->left, b);
}

template <class Element>
FibHeapNode<Element> *FibHeap<Element>::remove(FibHeapNode<Element> * x)
{
	FibHeapNode<Element> *ret;

	if (x == x->left)
		ret = NULL;
	else
		ret = x->left;

	if (x->parent != NULL && x->parent->child == x)
		x->parent->child = ret;

	x->right->left = x->left;
	x->left->right = x->right;

	x->parent = NULL;
	x->left = x;
	x->right = x;

	return ret;
}

template <class Element>
void FibHeap<Element>::checkcons()
{
	int64_t oldDl;

	if (Dl == -1 || N > (1 << Dl)) 
	{
		oldDl = Dl;
		if ((Dl = mylog2(N) + 1) < 8)
			Dl = 8;
		if (oldDl != Dl)
			cons = (FibHeapNode<Element> **) realloc(cons, sizeof(FibHeapNode<Element> *) * (Dl + 1));
		if (cons == NULL)
			abort();
	}
}

