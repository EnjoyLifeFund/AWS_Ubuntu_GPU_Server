/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          compactstr.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "compactstr.h"

template<class Word>
CompactString<Word>::CompactString()
{
	len = 0;
	str = NULL;
}

template<class Word>
CompactString<Word>::~CompactString()
{
	if(str) alloc.xfree((void * &)str);
}

template<class Word>
void CompactString<Word>::expand(size_t s) 
{
	size_t newsize = (s / CAN_SIZE) + ((s % CAN_SIZE) ? 1 : 0);
	size_t oldsize = compactsize();
	if(newsize > oldsize)
	{
		str = (Word *)alloc.xrealloc(str, newsize*sizeof(Word));
		memset(str+oldsize, 0, (newsize-oldsize)*sizeof(Word));
	} 

	len = s;
}

template<class Word>
void CompactString<Word>::resize(size_t s) 
{
	if(str) alloc.xfree((void*&)str);
	len = s; 
	str = (Word *)alloc.xmalloc(compactsize()*sizeof(Word));
} 

template<class Word>
CompactString<Word> & CompactString<Word>::operator=(const CompactString & rh)
{
	copy(rh.getStr(), rh.size());

	return *this;
}

template<class Word>
Nucleotide CompactString<Word>::operator[](unsigned int position)
{
	register Word c = str[position / CAN_SIZE];

	register int off = position % CAN_SIZE;

	return (Nucleotide)((c >> (BITS_PER_NUC*(CAN_SIZE-off-1))) & NUCS_MASK); 
}

template<class Word>
void CompactString<Word>::append(Nucleotide n)
{
	expand(len+1);
	register Word *c = & str[(len-1) / CAN_SIZE];

	register int off = (len-1) % CAN_SIZE;
	register Word tmp = n;

	*c |= (tmp << (BITS_PER_NUC*(CAN_SIZE-off-1))); 
}

template<class Word>
void CompactString<Word>::append(Nucleotide *nucs, size_t l)
{
	register size_t word, offset;

	address(len, word, offset);

	expand(len+l);

	register Word *c = & str[word];

	for(Coordinate i = 0; i < l; i++)
	{
		if(offset >= CAN_SIZE)
		{
			offset -= CAN_SIZE;
			c++;
			*c = 0;
		}

		*c |= (((Word)nucs[i]) << (BITS_PER_NUC*(CAN_SIZE-offset-1)));

		offset++;
	} 
}

template<class Word>
void CompactString<Word>::append(CompactString<Word> &st, size_t begin, size_t end, bool orientation, bool dual) // inclusive of begin and exclusive of end
{
//	register size_t oldlen = len;
//	register Nucleotide *c;
//	size_t stlen = st.size();

//	expand(len+(end-begin));

	if(orientation && dual)
		for(register long int idx = begin; idx < end; idx++)
			append(dualnuc(st[idx]));
	else if(orientation && !dual)
		for(register long int idx = begin; idx < end; idx++)
			append(st[idx]);
	else if(!orientation && dual)
		for(register long int idx = (((long int)end)-1); idx >= ((long int)begin); idx--)
			append(dualnuc(st[idx]));
	else
		for(register long int idx = (((long int)end)-1); idx >= ((long int)begin); idx--)
			append(st[idx]);
}


template<class Word>
void CompactString<Word>::print(FILE *out, Coordinate start, Coordinate end)
{
	char *buff = (char *)alloc.xmalloc(len+1);

	sprint(buff, start, end);
	fprintf(out, "%s", buff);
	alloc.xfree((void *&)buff);
}


template<class Word>
void CompactString<Word>::print(FILE *out)
{
	char *buff = (char *)alloc.xmalloc(len+1);

	sprint(buff);
	fprintf(out, "%s\n", buff);
	alloc.xfree((void *&)buff);
}

template<class Word>
void CompactString<Word>::print(ostream & out)
{
	char *buff = (char *)alloc.xmalloc(len+1);

	sprint(buff);
	out << buff << endl;
	alloc.xfree((void *&)buff);
}


template<class Word>
void CompactString<Word>::sprint(char *s)
{
	sprint(s, 0, len);
}

template<class Word>
void CompactString<Word>::sprint(char *s, unsigned int begin, unsigned int end)  // inclusive of begin and exclusive of end
{
	int index = 0;

	if(end > len)
		end = len;
		
	for(int i = begin; i < end; i++)
		s[index++] = nuc2char((*this)[i]);

	s[index++] = '\0';
}

template<class Word>
void CompactString<Word>::save(FILE *out)
{
	write_in_file((void*)&len, sizeof(size_t), 1, out);
	if(len)
		write_in_file((void*)str, sizeof(Word), compactsize(), out);
}

template<class Word>
void CompactString<Word>::load(FILE *in)
{
	if(str) alloc.xfree((void*&)str);
	read_from_file((void*)&len, sizeof(size_t), 1, in);

	if(len)
	{
		str = (Word *)alloc.xmalloc(compactsize()*sizeof(Word));
		read_from_file((void*)str, sizeof(Word), compactsize(), in);
	} 
} 

