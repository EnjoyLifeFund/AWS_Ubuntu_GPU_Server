/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          splaytree.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include "splaytree.h"

template<class Pair>
SplayTree<Pair>::SplayTree()
{
	sheet = NULL;
	num = 0;
	dosplay = true;
	resize(_INITSIZE);
}

template<class Pair>
SplayTree<Pair>::~SplayTree()
{
	if(sheet)
		alloc.xfree((void*&)sheet);
// use if(sheet) delete[] sheet for a real c++ implementation. we chose above for speed.
}

template<class Pair>
void SplayTree<Pair>::resize(TreeIndex s)
{
	if(s > (TreeIndex)(-1) - 5)
		exitMsg((char*)"Error: SplayTree is choking. Make TreeIndex bigger and recompile. \n", INTERNAL_SPLAYTREE_ERROR);

	sheet = (SplayNode<Pair> *)alloc.xrealloc(sheet, sizeof(SplayNode<Pair>)*s);
// use sheet = new SplayNode<Pair>[s] for a real c++ implementation. in that case, the existing elements have to be copied to the new sheet one by one. we chose above for speed.
	maxNum = s;
}

template<class Pair>
TreeIndex SplayTree<Pair>::newSlot()
{
	if(num >= maxNum)
//		resize(maxNum + ((maxNum < 16*_INITSIZE) ? maxNum : 16*_INITSIZE));
		resize(maxNum + _INITSIZE);

	num++;
	return num-1;
}

template<class Pair>
bool SplayTree<Pair>::insert(Pair & pair)
{
	if (num == 0) {
		root = newSlot();
		sheet[root].pair.first = pair.first;
		sheet[root].pair.second = pair.second;
		sheet[root].left = sheet[root].right = NULLIDX;
		return true;
	}

	splay(pair);

	if (pair.first < sheet[root].pair.first) 
	{
		TreeIndex newidx = newSlot();
		sheet[newidx].pair.first = pair.first;
		sheet[newidx].pair.second = pair.second;
		sheet[newidx].left = sheet[root].left;
		sheet[newidx].right = root;
		sheet[root].left = NULLIDX;
		root = newidx;
	} else if (sheet[root].pair.first < pair.first) 
	{
		TreeIndex newidx = newSlot();
		sheet[newidx].pair.first = pair.first;
		sheet[newidx].pair.second = pair.second;
		sheet[newidx].right = sheet[root].right;
		sheet[newidx].left = root;
		sheet[root].right = NULLIDX;
		root = newidx;
	} else
		return false;

	return true;
}


template<class Pair>
TreeIndex SplayTree<Pair>::add(Pair & pair)
{
	if (num == 0) {
		root = newSlot();
		sheet[root].pair.first = pair.first;
		sheet[root].pair.second = pair.second;
		sheet[root].left = sheet[root].right = NULLIDX;
		return root;
	}

	splay(pair);

	if (pair.first < sheet[root].pair.first) 
	{
		TreeIndex newidx = newSlot();
		sheet[newidx].pair.first = pair.first;
		sheet[newidx].pair.second = pair.second;
		sheet[newidx].left = sheet[root].left;
		sheet[newidx].right = root;
		sheet[root].left = NULLIDX;
		root = newidx;
	} else if (sheet[root].pair.first < pair.first) 
	{
		TreeIndex newidx = newSlot();
		sheet[newidx].pair.first = pair.first;
		sheet[newidx].pair.second = pair.second;
		sheet[newidx].right = sheet[root].right;
		sheet[newidx].left = root;
		sheet[root].right = NULLIDX;
		root = newidx;
	} else
		return NULLIDX;

	return root;
}

template<class Pair>
void SplayTree<Pair>::splay(Pair & pair)
{
	if (num == 0)
		return;

	SplayNode<Pair> header;
	TreeIndex leftTreeMax = NULLIDX, rightTreeMin = NULLIDX;


	header.left = header.right = NULLIDX;

	TreeIndex current = root;	
	while (pair.first != sheet[current].pair.first) 
	{
		SplayNode<Pair> *cur = &(sheet[current]); 
		if (pair.first < cur->pair.first) 
		{
			if (cur->left == NULLIDX)
				break;
			if (pair.first < sheet[cur->left].pair.first)
				current = rotateLeft(current);
			if (sheet[current].left == NULLIDX)
				break;

			if(rightTreeMin != NULLIDX) 
				sheet[rightTreeMin].left = current;
			else
				header.left = current;
			rightTreeMin = current;
			current = sheet[current].left;
		} else 
		{
			if (cur->right == NULLIDX)
				break;
			if (sheet[cur->right].pair.first < pair.first)
				current = rotateRight(current);
			if (sheet[current].right == NULLIDX)
				break;

			if(leftTreeMax != NULLIDX) 
				sheet[leftTreeMax].right = current;
			else
				header.right = current;
			leftTreeMax = current;
			current = sheet[current].right;
		}
	}	

	if(leftTreeMax != NULLIDX) 
		sheet[leftTreeMax].right = sheet[current].left;
	else
		header.right = sheet[current].left;
		

	if(rightTreeMin != NULLIDX) 
		sheet[rightTreeMin].left = sheet[current].right;
	else
		header.left = sheet[current].right;

	sheet[current].left = header.right;
	sheet[current].right = header.left;

	root = current;
}

template<class Pair>
TreeIndex SplayTree<Pair>::rotateLeft(TreeIndex i)
{
	TreeIndex j;

	j = sheet[i].left;
	sheet[i].left = sheet[j].right;
	sheet[j].right = i;

	return j;		
}

template<class Pair>
TreeIndex SplayTree<Pair>::rotateRight(TreeIndex i)
{
	TreeIndex j;

	j = sheet[i].right;
	sheet[i].right = sheet[j].left;
	sheet[j].left = i;

	return j;
}


template<class Pair>
Pair *SplayTree<Pair>::find(Pair & pair)
{
	if(num == 0)
		return NULL;

	if(dosplay)
	{
		splay(pair);

		if(pair.first == sheet[root].pair.first)
			return &(sheet[root].pair);
		else
			return NULL;
	} else
		return search(pair);
}

template<class Pair>
Pair *SplayTree<Pair>::search(Pair & pair)
{
	if(num == 0)
		return NULL;

	TreeIndex current = root;
	while(current != NULLIDX)
	{
		if(pair.first == sheet[current].pair.first)
			return &(sheet[current].pair);
		else
			if(pair.first < sheet[current].pair.first)
				current = sheet[current].left;
			else
				current = sheet[current].right;
	}

	return NULL;
}

template<class Pair>
Pair *SplayTree<Pair>::find(TreeIndex bstIndex)
{
	if(bstIndex >= num)
		return NULL;

	return &(sheet[bstIndex].pair);
}

template<class Pair>
void SplayTree<Pair>::printall()
{
	for(TreeIndex r = 0; r < num; r++)
	{
		cout << "Node " << r << ": " << sheet[r].pair.first << endl;
		cout << "Left:" << sheet[r].left << endl;
		cout << "Right:" << sheet[r].right << endl;
	}
}

template<class Pair>
void SplayTree<Pair>::print(TreeIndex r)
{
	if(r == NULLIDX || num == 0)
		return;

	cout << sheet[r].pair.first;
	cout << "Left:" << endl;
	print(sheet[r].left);
	cout << "Right:" << endl;
	print(sheet[r].right);
}

template<class Pair>
void SplayTree<Pair>::print()
{
	print(root);
}

 template<class Pair>
SplayTreeIterator *SplayTree<Pair>::begin() 
{ 
	SplayTreeIterator *it = new SplayTreeIterator; 
	pushLeft(it, root);
	return it;
} 

template<class Pair>
Pair& SplayTree<Pair>::next(SplayTreeIterator *it) 
{
	TreeIndex x = it->stck.top();
	it->stck.pop();	
	pushLeft(it, sheet[x].right);
	return sheet[x].pair;
}

template<class Pair>
void SplayTree<Pair>::pushLeft(SplayTreeIterator *it, TreeIndex x)
{
	if(!sheet || !it)
		return;
	while (x != NULLIDX)
	{ 
		it->stck.push(x); 
		x = sheet[x].left;
	}
}

template<class Pair>
bool SplayTree<Pair>::hasNext(SplayTreeIterator *& it) 
{
	if(!it)
		return false;
	if(it->stck.empty())
	{
		delete it;
		it = NULL;
		return false;
	}
	return true;
}

template<class Pair>
Pair& SplayTree<Pair>::item(size_t i) 
{
	return sheet[i].pair;
}





