/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          read.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "read.h"

void Read::setID(string s, bool dual)
{
	ID temp((char *)s.c_str(), dual);
	id.id = temp.id;
}

void Read::setID(char *c, bool dual)
{
	ID temp(c, dual);
	id.id = temp.id;
}

void Read::resize(size_t sz)
{
	len = sz;
	if(seq) delete[] seq;
	seq = new Nucleotide[len];
}

bool Read::operator<(Read & rhs) const
{
	register Nucleotide n1, n2;
	register size_t rs = rhs.size();

	for(register int i = 0; i < len && i < rs; i++)
	{
		n1 = seq[i];
		n2 = rhs[i];
		if(n1 < n2)
			return true;
		else if(n1 > n2)
			return false;
	}

	if(len < rs)
		return true;
	else
		return false;
}

Read Read::operator~()
{
	Read ret = *this;

	size_t len = size();

	for(int i = 0; i < len; i++)
		ret[i] = dualnuc(seq[len-i-1]);

	ret.setID(~id);
	return ret;
}

void Read::load(string &s, bool d)
{
	resize(s.size());
	if(!d)
		for(int i = 0; i < s.size(); i++)
			seq[i] = char2nuc(s[i]);
	else
		for(int i = s.size()-1, j = 0; i >=0; i--)
			seq[i] = char2nuc(dual(s[j++]));
}

void Read::loadqual(string &s, bool d)
{
	if(quals) delete quals;

	quals = new char[len+1];

	if(!d)
		strncpy(quals, s.c_str(), len+1); 
	else
		for(int i = MIN(s.size(), len)-1, j = 0; i >= 0; i--)
			quals[i] = s[j++];
}

void Read::load(char *s, bool d)
{
	resize(strlen(s));
	if(!d)
		for(int i = 0; i < size(); i++)
			seq[i] = char2nuc(s[i]);
	else
		for(int i = size()-1, j = 0; i >=0; i--)
			seq[i] = char2nuc(dual(s[j++]));
}

void Read::print(FILE *out)
{
	fprintf(out, ">%ld\n", id.id); 
	for(int i = 0; i < size(); i++)
		fprintf(out, "%c", nuc2char(seq[i]));
	fprintf(out, "\n");
}

void Read::print(ostream &out)
{
	out << ">" << id.id << endl; 
	for(int i = 0; i < size(); i++)
		out << nuc2char(seq[i]);
	out << endl;
}

void Read::sprint(char *s)
{
	for(int i = 0; i < size(); i++)
		s[i] = nuc2char(seq[i]);
	s[size()] = '\0';
}

