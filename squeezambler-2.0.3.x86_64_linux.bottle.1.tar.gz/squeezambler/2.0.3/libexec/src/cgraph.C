/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          cgraph.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  09/19/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include <omp.h>

#include "cgraph.h"

#include "bag.C"
#include "heap.C"
#include "radixheap.C"
#include "splaytree.C"

// template class Bag<Node*>;
// template class Bag<CNodeID>;
// template class Bag<DijkstraTicket*>;
// template class Bag<FixedArray<CNodeID, 3> >;
// template class Heap<DijkstraTicket>;
// template class RadixHeap<HigherOrderTicket>;


/* Path & Path::operator=(Path &rhs)
{
	begin = rhs.begin;
	end = rhs.end;
	nodes.clear();
	rhs.nodes.begin();
	while(rhs.nodes.hasNext())
		nodes.append(rhs.nodes.next());
	return *this;
}
	
void Path::save(FILE *out)
{
	write_in_file(&begin, sizeof(CoordMap), 1, out);
	write_in_file(&end, sizeof(CoordMap), 1, out);
	size_t midnodes = nodes.size();
	write_in_file(&midnodes, sizeof(size_t), 1, out);
	nodes.begin();
	while(nodes.hasNext())
		write_in_file(&(nodes.next()), sizeof(CNodeID), 1, out);
}

void Path::load(FILE *in)
{
	read_from_file(&begin, sizeof(CoordMap), 1, in);
	read_from_file(&end, sizeof(CoordMap), 1, in);
	size_t midnodes;
	CNodeID temp;
	read_from_file(&midnodes, sizeof(size_t), 1, in);
	for(int i = 0; i < midnodes; i++)
	{
		read_from_file(&temp, sizeof(CNodeID), 1, in);
		nodes.append(temp);
	}
}

void Path::print(ostream &in)
{
	in << "Begin: " << begin.cnodeid << "," << begin.pos << endl;
	in << "Intermediate nodes: ";	
	nodes.begin();
	while(nodes.hasNext())
		in << nodes.next() << "  ";
	in << endl;
	in << "End: " << end.cnodeid << "," << end.pos << endl;
} */


Graph::Graph(int _k, int _procs)
{
	k = _k;
	procs = _procs;
}

Graph::~Graph()
{
	for(CNodes::iterator it = nodes.begin(); it != nodes.end(); it++)
		delete *it;
}

CNode* Graph::newNode()
{
	CNode *ret = new CNode();
	nodes.push_back(ret);
	return ret;
}

CNode* Graph::newNode(UnitigSerial s, Distance l, Coverage c)
{
	CNode *ret = new CNode(s, l, c);
	nodes.push_back(ret);
	return ret;
}

void Graph::save(FILE *out)
{
	size_t nodesnum = nodes.size();

	write_in_file((void *)&k, sizeof(int), 1, out);
	write_in_file((void *)&nodesnum, sizeof(size_t), 1, out);

	sort(nodes.begin(), nodes.end());

	begin();
	while(hasNext())
	{
		CNodeID cnodeid(next());

		int outdeg = cnodeid.outdegree(), indeg = cnodeid.indegree();
		write_in_file((void *)&indeg, sizeof(int), 1, out);
		write_in_file((void *)&outdeg, sizeof(int), 1, out);

		for(int i = 0; i < indeg; i++)
		{
			UnitigSerial idx = (UnitigSerial)(findnode(abs(cnodeid.in(i)))) * (cnodeid.in(i) < 0 ? -1 : 1);
			write_in_file((void *)&idx, sizeof(UnitigSerial), 1, out);
		}

		for(int i = 0; i < outdeg; i++)
		{
			UnitigSerial idx = (UnitigSerial)(findnode(abs(cnodeid.out(i)))) * (cnodeid.out(i) < 0 ? -1 : 1);
			write_in_file((void *)&idx, sizeof(UnitigSerial), 1, out);
		}
		
		cnodeid.save(out);
	} 
}

void Graph::load(FILE *in)
{
	nodes.clear();

	size_t nodesnum;

	read_from_file((void *)&k, sizeof(int), 1, in);
	read_from_file((void *)&nodesnum, sizeof(size_t), 1, in);

	int *indegs = new int[nodesnum];
	int *outdegs = new int[nodesnum];

	UnitigSerial **ins = new UnitigSerial *[nodesnum];
	UnitigSerial **outs = new UnitigSerial *[nodesnum];
	
	for(size_t nodeidx = 0; nodeidx < nodesnum; nodeidx++)
	{
		CNodeID cnodeid(newNode());

		read_from_file((void *)(indegs+nodeidx), sizeof(int), 1, in);
		read_from_file((void *)(outdegs+nodeidx), sizeof(int), 1, in);

		ins[nodeidx] = new UnitigSerial[indegs[nodeidx]];
		outs[nodeidx] = new UnitigSerial[outdegs[nodeidx]];
		
		read_from_file((void *)ins[nodeidx], sizeof(UnitigSerial), indegs[nodeidx], in);
		read_from_file((void *)outs[nodeidx], sizeof(UnitigSerial), outdegs[nodeidx], in);

		cnodeid.load(in);
	}

	for(size_t nodeidx = 0; nodeidx < nodesnum; nodeidx++)
	{
		CNodeID cnodeid(nodes[nodeidx]);

		for(int i = 0; i < indegs[nodeidx]; i++)
		{
			UnitigSerial serial = ins[nodeidx][i];

			CNodeID from(nodes[abs(serial)]);

			if(serial < 0)
				from = -from;

			connect(from, cnodeid);
		}

		for(int i = 0; i < outdegs[nodeidx]; i++)
		{
			UnitigSerial serial = outs[nodeidx][i];

			CNodeID to(nodes[abs(serial)]);

			if(serial < 0)
				to = -to;

			connect(cnodeid, to);
		}

		delete[] ins[nodeidx], outs[nodeidx];
	}	

	delete[] ins, outs;
	delete[] indegs, outdegs;
}


// assuming nodes are sorted perform a binary search
size_t Graph::findnode(CNodeID cnodeid)
{
	long int up = 0, down = size();

	down--;

	while(up <= down)
	{
		long int mid = (up+down)/2;

		CNodeID midnode(nodes[mid]);
		
		if(cnodeid < midnode)
			down = mid - 1;
		else if(cnodeid > midnode)
			up = mid + 1;
		else
			return mid;
	}

	return 0;
}

void Graph::printedges(Distance maxins, CNodeID cnodeid, size_t idx, ostream &outst)
{
	for(unsigned int i = 0; i < cnodeid.indegree(); i++)
	{
		CNodeID innode = cnodeid.in(i);

		if(innode.length() < maxins)
		{
			size_t ndidx = findnode(abs(innode));

			if(innode < 0)
			{
				outst << "\tNN" << ndidx+1 << " -> N" << idx+1 << ";" << endl;
				outst << "\tNN" << idx+1 << " -> N" << ndidx+1 << ";" << endl;
			}
			else 
			{
				outst << "\tN" << ndidx+1 << " -> N" << idx+1 << ";" << endl;
				outst << "\tNN" << idx+1 << " -> NN" << ndidx+1 << ";" << endl;
			}
		}
	}

	for(unsigned int i = 0; i < cnodeid.outdegree(); i++)
	{
		CNodeID outnode = cnodeid.out(i);

		if(outnode.length() < maxins)
		{
			size_t ndidx = findnode(abs(outnode));

			if(outnode < 0)
			{
				outst << "\tN" << idx+1 << " -> NN" << ndidx+1 << ";" << endl;
				outst << "\tN" << ndidx+1 << " -> NN" << idx+1 << ";" << endl;
			}
			else 
			{
				outst << "\tN" << idx+1 << " -> N" << ndidx+1 << ";" << endl;
				outst << "\tNN" << ndidx+1 << " -> NN" << idx+1 << ";" << endl;
			}
		}
	}
}


void Graph::exportGraph(Distance maxins, ostream &out)
{
	out << "digraph g {" << endl;

	sort(nodes.begin(), nodes.end());

	for(size_t i = 0; i < size(); i++)
	{
		if(nodes[i]->length() < maxins)
		{
			out << "\tN" << i+1 << " [label = \"L" << nodes[i]->length() << "\"];" << endl;
			out << "\tNN" << i+1 << " [label = \"L" << nodes[i]->length() << "\"];" << endl;
			out.flush();
		}		
	}

	for(size_t i = 0; i < size(); i++)
	{
		if(nodes[i]->length() < maxins)
		{
			CNodeID tmp(nodes[i]);
			printedges(maxins, tmp, i, out);
			out.flush();
		}		
	}

	out << "}" << endl; 
}

void Graph::connect(CNodeID from, CNodeID to)
{
	from.connectout(to);
	to.connectin(from);
} 

void Graph::disconnect(CNodeID from, CNodeID to)
{
	from.disconnectout(to);
	to.disconnectin(from);
} 


CNodeAuxSP *Graph::auxSP(CNodeID cnodeid, int thread) 
{
	return cnodeid.cnodeAuxSP(thread);
}

CNodeAuxSP *Graph::auxSPNewIfNull(CNodeID cnodeid, int thread) 
{
	CNodeAuxSP *ret = cnodeid.cnodeAuxSP(thread);

	if(!ret)
		ret = cnodeid.newCNodeAuxSP(thread, cnodeid.outdegree());

	return ret;
}

void Graph::deleteCNodeAuxSP(CNodeID cnodeid, int thread) 
{
	cnodeid.deleteCNodeAuxSP(thread);
}

bool Graph::transfer(CNodeID from)
{
	if(from.indegree() != 1 || from.outdegree() != 1 || from.out(0).indegree() != 1 || from.out(0).outdegree() != 1 || from.out(0) == from)
		return false;

	CNode *newnode = newNode();

	vector<CNodeID> toBeDel;

	CNodeID current = from;
	append(newnode, current);
	toBeDel.push_back(current);

	current = current.out(0);

	while(current.indegree() == 1 && current.outdegree() == 1 && current != from)
	{
		append(newnode, current);
		toBeDel.push_back(current);

		current = current.out(0);
	}
	

	if(current != from)
	{
		connect(newnode, current);
		connect(from.in(0), newnode);
	}
	else
		connect(newnode, newnode);

	vector<CNodeID>::iterator it = toBeDel.begin();
	while(it < toBeDel.end())
		remove(*(it++));


	return true;
} 

bool Graph::join(CNodeID from, CNodeID to)
{
	if(from.outdegree() != 1 || to.indegree() != 1 || abs(from) == abs(to))
		return false;

	CNode *newnode = newNode();

	append(newnode, from);
	append(newnode, to);

	for(int i = 0; i < from.indegree(); i++)
	{
		CNodeID innode = from.in(i);

		if(innode == to)
			connect(newnode, newnode);
		else if(innode == -to)
			exitMsg((char*)"Error: Graph panic: oh dear in join-in!", INTERNAL_WOW_ERROR);
		else
			connect(innode, newnode);
	}

	for(int i = 0; i < to.outdegree(); i++)
	{
		CNodeID outnode = to.out(i);

		if(outnode == from)
			connect(newnode, newnode);
		else if(outnode == -from)
			exitMsg((char*)"Error: Graph panic: oh dear in join-out!", INTERNAL_WOW_ERROR);
		else
			connect(newnode, outnode);
	}

	remove(from);
	remove(to);

	return true;
} 

void Graph::remove(CNodeID cnodeid)
{
	while(cnodeid.outdegree())
		disconnect(cnodeid, cnodeid.out(cnodeid.outdegree()-1));

	while(cnodeid.indegree())
		disconnect(cnodeid.in(cnodeid.indegree()-1), cnodeid);

	cnodeid.setRemoval(); // which means it will be removed in applyRemovals
}

void Graph::applyRemovals()
{
	CNodes newnodes;

	begin();
	while(hasNext())
	{
		CNode *cnode = next();
		if(!cnode->removed())
			newnodes.push_back(cnode);
		else
			delete cnode;
	}

	nodes = newnodes;
}


void Graph::prepareForDijkstra(int thisprocs)
{
	begin();
	while(hasNext())
		next()->newAuxSP(2*thisprocs); // for primal and dual

	cleanup = new Bag<DijkstraTicket*>[thisprocs];
	pathbegin = new Locus[thisprocs];
	pathend = new Locus[thisprocs];
	pathorder = new ShortestOrder[thisprocs];
	pathaux = new CNodeAuxSP*[thisprocs];
}


void Graph::dijkstra(CNodeID target, size_t maxdist, int thread) // compute the 1st order shortest paths to the target
{
	Heap<DijkstraTicket> pqueue;

	CNodeAuxSP *aux = auxSPNewIfNull(target, thread);

	SPInfo targetinfo;

	targetinfo.next = NULL;
	targetinfo.nextindex = -1;
	targetinfo.distance = 0;

	aux->insert(targetinfo);

	aux->ticket.status = SP_EXP;
	aux->ticket.cnodeid = target;
	aux->ticket.priority = 0;

	pqueue.insert(&(aux->ticket));

	while(!pqueue.empty())
	{
		DijkstraTicket *ticket = pqueue.extractMin();
		ticket->status = SP_FINAL;
		cleanup[thread].append(ticket);

		if(ticket->priority <= maxdist)
			for(int i = 0; i < ticket->cnodeid.indegree(); i++)
			{
				CNodeID innode = ticket->cnodeid.in(i);
				aux = auxSPNewIfNull(innode, thread);
	
				if(aux->ticket.status == SP_NV)
				{
					targetinfo.next = ticket->cnodeid;
					targetinfo.nextindex = 0;
					aux->ticket.priority = targetinfo.distance = ticket->priority + innode.length() - k + 1;

					aux->insert(targetinfo);

					aux->ticket.status = SP_EXP;
					aux->ticket.cnodeid = innode;

					pqueue.insert(&(aux->ticket));
				}
				else if(aux->ticket.status == SP_EXP)
				{
					if(aux->shortest(0).distance > ticket->priority + innode.length() - k + 1)
					{
						aux->shortest(0).next = ticket->cnodeid;
						aux->shortest(0).nextindex = 0;
						aux->ticket.priority = aux->shortest(0).distance = ticket->priority + innode.length() - k + 1;
						pqueue.update(&(aux->ticket));
					}
				}
			}
	} 
	cleanup[thread].begin();
	while(cleanup[thread].hasNext())
		cleanup[thread].next()->status = SP_NV;
}


void Graph::higherOrderShortest(CNodeID target, size_t maxdist, int thread) 
{
	Heap<DijkstraTicket> pqueue;

	bool done = true;

	CNodeAuxSP *aux = auxSP(target, thread);

	aux->ticket.cnodeid = target;
	aux->ticket.status = SP_EXP;
	aux->ticket.priority = aux->shortest(0).distance; 
	
	pqueue.insert(&(aux->ticket));

	size_t treenodesnum = 0, maxtreenodesnum = SPS_CHUNK_NUM;
	SPTreeNode *treenodes = (SPTreeNode *)alloc.xmalloc(sizeof(SPTreeNode)*maxtreenodesnum);

	while(!pqueue.empty())
	{
		DijkstraTicket *ticket = pqueue.extractMin();
		ticket->status = SP_FINAL;

		aux = auxSP(ticket->cnodeid, thread);

		int actual = 0;
		for(int i = 0; i < ticket->cnodeid.outdegree(); i++)
		{
			CNodeID outnode = ticket->cnodeid.out(i);
			if(outnode != aux->shortest(0).next)
			{
				CNodeAuxSP *tempaux = auxSP(outnode, thread);

				if(tempaux && (tempaux->shortest(0).distance <= maxdist))
				{
					SPInfo *info = &(aux->item(actual));
					info->distance = tempaux->shortest(0).distance;
					info->next = outnode;
					info->nextindex = 0;
					actual++;
				}
			}
		}
		aux->resize(actual);
		aux->sort();
		if(actual > 0)	
			done = false;			

		if(aux->shortest(0).distance <= maxdist)
			for(int i = 0; i < ticket->cnodeid.indegree(); i++)
			{
				CNodeID innode = ticket->cnodeid.in(i);
				CNodeAuxSP *tempaux = auxSP(innode, thread);
				if(tempaux->ticket.status == SP_NV)
				{
					tempaux->ticket.status = SP_EXP;
					tempaux->ticket.priority = tempaux->shortest(0).distance;
					tempaux->ticket.cnodeid = innode;
					pqueue.insert(&(tempaux->ticket));
				}
			}

		if(treenodesnum >= maxtreenodesnum)
		{
			maxtreenodesnum += SPS_CHUNK_NUM;
			treenodes = (SPTreeNode *)alloc.xrealloc(treenodes, sizeof(SPTreeNode)*maxtreenodesnum);
		}

		treenodes[treenodesnum].length = ticket->cnodeid.length();
		treenodes[treenodesnum].cnodeid = ticket->cnodeid;
		treenodes[treenodesnum].heap = new RadixHeap<HigherOrderTicket>(maxdist);
		treenodes[treenodesnum].heapUpDateIdx = 0;
		treenodes[treenodesnum].active = 1;
		treenodesnum++;
	}

	long int round = 1;
	long int computedpathsnum = 0;
	while(!done && computedpathsnum < MAX_SP_ROUNDS)
	{
		bool keepgoing = false;

		for(size_t nd = 0; nd < treenodesnum; nd++)
		{
			if(treenodes[nd].active)
			{
				computedpathsnum++;
				aux = auxSP(treenodes[nd].cnodeid, thread);
				treenodes[nd].active = 0;

				if(aux->orders() == round) 
				{
					SPInfo sh1st;
					bool is1st = aux->current(sh1st);

					for(ShortestOrder i = treenodes[nd].heapUpDateIdx; i < aux->orders(); i++)
					{
						SPInfo temp = aux->shortest(i);
						if(temp.next)
						{
							ShortestOrder objective = temp.nextindex+1;
							CNodeAuxSP *tempaux = auxSP(temp.next, thread);

							if(tempaux->orders() > objective)
							{
								HigherOrderTicket newht;
								newht.priority  = tempaux->shortest(objective).distance;
								newht.order = i;
								if(newht.priority <= maxdist)
									treenodes[nd].heap->insert(newht);
							}
						}
					}

					treenodes[nd].heapUpDateIdx = aux->orders();

					size_t localmin = INT_INFINITY;
					ShortestOrder localidx = 0;
					if(!treenodes[nd].heap->empty())
					{
						HigherOrderTicket ht = treenodes[nd].heap->min();
						localmin = ht.priority;
						localidx = ht.order;
					}


					if(localmin <= maxdist || is1st) // sh1st has been checked above to have distance <= maxdist
					{
						SPInfo newinfo;

						if(!is1st || localmin < sh1st.distance)
						{
							SPInfo temp = aux->shortest(localidx);
							treenodes[nd].heap->extractMin();
							newinfo.next = temp.next;
							newinfo.nextindex = temp.nextindex + 1;
							newinfo.distance = localmin + treenodes[nd].length - k + 1;
						} else
						{
							newinfo = sh1st;
							newinfo.distance += treenodes[nd].length - k + 1;
							aux->inc();
						}
						aux->insert(newinfo);

						treenodes[nd].active = 1;
						keepgoing = true;
					}
				}
			}
		}
		done  = !keepgoing;
		round++;
	}

	for(size_t nd = 0; nd < treenodesnum; nd++)
		delete treenodes[nd].heap;

	alloc.xfree((void*&)treenodes);
}

void Graph::cleanUp(int thread)
{
	cleanup[thread].begin();
	while(cleanup[thread].hasNext())
		deleteCNodeAuxSP(cleanup[thread].next()->cnodeid, thread);

	cleanup[thread].clear();
}

void Graph::cleanUp()
{
	begin();
	while(hasNext())
		next()->deleteAux();

	delete[] cleanup;

	delete[] pathbegin;
	delete[] pathend;
	delete[] pathorder;
	delete[] pathaux;
}


void Graph::allpaths(CNodeID target, size_t maxdist, int thread)
{
	dijkstra(target, maxdist, thread);
	higherOrderShortest(target, maxdist, thread); 
}

void Graph::initPath(Locus begin, Locus end, int thread)
{
	pathbegin[thread] = begin;
	pathend[thread] = end;
	pathorder[thread] = 0;
	pathaux[thread] = auxSP(pathbegin[thread].cnodeid, thread);
}

bool Graph::morePaths(Path &path, int thread)
{
	if(!pathaux[thread] || pathorder[thread] >= pathaux[thread]->orders())
		return false;

	path.begin = pathbegin[thread];
	path.end = pathend[thread];
	path.nodes.clear();
	path.length = pathaux[thread]->shortest(pathorder[thread]).distance + pathend[thread].pos - pathbegin[thread].pos;

	CNodeID next = pathbegin[thread].cnodeid;
	ShortestOrder nextindex = pathorder[thread];
	CNodeAuxSP *current = pathaux[thread];

	do {
		path.nodes.append(next);
		if(nextindex < current->orders())
		{
			next = current->shortest(nextindex).next;
			nextindex = current->shortest(nextindex).nextindex;
			if(next)
				current = auxSP(next, thread);
		} else
		{
			cout << path.begin.cnodeid << "," << path.begin.pos << endl;
			cout << path.end.cnodeid << "," << path.end.pos << endl;
			path.nodes.begin();
			while(path.nodes.hasNext())
				cout << path.nodes.next() << "  ";
			cout << endl;
			cout << nextindex << "  " << current->orders() << endl;
			exitMsg((char*)"Error: Graph panic: corrupted dijkstra or higherOrderShortest.", INTERNAL_DIJKSTRA_ERROR);
		}
	} while(next);

	pathorder[thread]++;

	return true;
} 

Locus Graph::dual(Locus coord)
{
	Locus ret;
	ret.cnodeid = -coord.cnodeid;
	ret.pos = coord.cnodeid.length() - coord.pos - k;
	return ret;
}

void Graph::dual(Path &path, Path &ret)
{
	ret.begin = dual(path.end);
	ret.end = dual(path.begin);
	CNodeID *nodes = new CNodeID[path.nodes.size()];
	int idx = 0;
	path.nodes.begin();
	while(path.nodes.hasNext())
		nodes[idx++] = -path.nodes.next();

	ret.nodes.clear();
	while(idx > 0)
		ret.nodes.append(nodes[--idx]);

	delete[] nodes;
}

Coordinate Graph::NX(double x)
{
	Coordinate sum = 0;
	Coordinate *lens = new Coordinate[size()];
	Coordinate ret = 0;


	Serial number = 0;
	begin();
	while(hasNext())
		sum += - (lens[number++] = -next()->length());

	sort(lens, lens+size());

	Coordinate temp = 0;
	for(Serial nm = 0; nm < number; nm++)
	{
		temp += -lens[nm];

		if(temp >= x*sum)
		{
			ret = -lens[nm];
			break;
		}
	}

	delete[] lens;
	return ret;
}


