/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          colorslist.C 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "colorslist.h"


void ColorsList::initializeColorsList(size_t initialGroupsNum, size_t _libNo, int _base_lib) 
{
	size_t inputLibIndex = 0;
	size_t maxPopulation = 0;
	colors.listNo = 0;
	activeColors.listNo = 0;
	waitingColors.listNo = 0;
	sequencedColors.listNo = 0;
	colorsLibList.listNo = 0;
	libNo = _libNo;
	set_base_lib(_base_lib);
	LibraryList firstIterationLibraryList;
	firstIterationLibraryList.listNo = libNo;
	for (int i = 0; i < libNo; i++)
	{
		firstIterationLibraryList.list[i] = (Lib) i;
	}
	for(int i = 0; i < MAXLIBCOLOR; i++)
	{	
		colors.list[i] = -1; 
	}
	divideColor(firstIterationLibraryList, initialGroupsNum);
}

ColorsList::ColorsList(size_t initialGroupsNum, size_t _libNo, int _base_lib)
{                  
	logger = NULL; 
	debugMode = 0; 
	initializeColorsList(initialGroupsNum, _libNo, _base_lib);
}


ColorsList::ColorsList(Logger *_logger, bool _debugMode, size_t initialGroupsNum, size_t _libNo, int _base_lib)
{
	logger = _logger; 
	debugMode = _debugMode; 
	initializeColorsList(initialGroupsNum, _libNo, _base_lib);
	printColorInf();
	printActiveColorsInf();
}

ColorsList::~ColorsList() 
{
	colors.listNo = 0;
	activeColors.listNo = 0;
	waitingColors.listNo = 0;
	sequencedColors.listNo = 0;
}

void ColorsList::set_base_lib(Lib _base_lib)
{
	base_lib = _base_lib; 
	assemStepNo = (size_t) (base_lib / libNo);
	if (base_lib + libNo >= MAXLIBCOLOR)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::set_base_lib(): base_lib + libNo >= MAXLIBCOLOR, i.e.,"<< base_lib << "+" << libNo << " >= " << MAXLIBCOLOR << endl; 
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	};
	if (colors.listNo < base_lib + libNo)
	{
		colors.listNo = base_lib + libNo;
	} else
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::set_base_lib(): colors.listNo >= base_lib + libNo, i.e.,"<< colors.listNo << ">=" << base_lib << " + " << libNo << endl; 
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}	
};


Color ColorsList::getColors(size_t l)
{
	if (l > colors.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::getColors(): l > colors.listNo, i.e.," << l << " > " << colors.listNo << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);	
	}
	return colors.list[l];
};

void ColorsList::getNewColorsList_list(Color *newList)
{
	logger->out() << " colors.list: " << endl;
	for (int i = 0; i < libNo; i++)
	{
		newList[i] = colors.list[i + base_lib];
	}
	for (int i = libNo; i < MAXLIBRARIES ; i++)
	{
		newList[i] = 0;
	}

};


void  ColorsList::pushToActiveList(Color c) 
{
	if (activeColors.listNo == MAXCOLORS)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::pushToActiveList(): activeColor list has been overflowed.  activeColors.listNo = MAXCOLORS, i.e.," << activeColors.listNo + 1 << " = " << MAXCOLORS << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	activeColors.list[activeColors.listNo] = c;
	activeColors.listNo ++;
	printActiveColorsInf();
}

Color ColorsList::popFromActiveList() 
{
	if (isEmpty_activeColors())
	{
		return -1;
	}

	activeColors.listNo --;
	printActiveColorsInf();
	return activeColors.list[activeColors.listNo];
}

Color ColorsList::lastActiveColor()
{
	if (isEmpty_activeColors())
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::LastActiveColor(): activeColor list is empty." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}
	return activeColors.list[activeColors.listNo];
}

Color ColorsList::getActiveColors(int i)
{ 
	if (i > activeColors.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::getActiveColor(i): the index i is larger than the size of activeColors." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	
	}
	return activeColors.list[i];
};

void  ColorsList::pushToWaitingList(Color c)
{
	if (waitingColors.listNo == MAXCOLORS)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::pushToWaitingList(): waitingColor list has been overflowed.  waitingColors.listNo = MAXCOLORS, i.e.," << waitingColors.listNo + 1 << " = " << MAXCOLORS << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	waitingColors.list[waitingColors.listNo] = c;
	waitingColors.listNo ++;
}

Color ColorsList::popFromWaitingList()
{
	if (isEmpty_waitingColors())
	{
		return -1;
	}

	waitingColors.listNo --;
	return waitingColors.list[waitingColors.listNo];
}

Color ColorsList::lastWaitingColor()
{
	if (isEmpty_waitingColors())
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::LastWaitingColor(): waitingColor list is empty." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}

	return waitingColors.list[waitingColors.listNo];
}

Color ColorsList::getWaitingColors(int i)
{ 
	if (i > waitingColors.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::getWaitingColor(i): the index i is larger than the size of waitingColors." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	
	}
	return waitingColors.list[i];
};


Color ColorsList::moveLastActiveToWaitingList()
{
	Color c;
	c = popFromActiveList(); 
	pushToWaitingList(c);
	return c;
}


Color ColorsList::moveLastWaitingToActiveList()
{
	if (!(isEmpty_waitingColors()))
	{
		Color c;
		c = popFromWaitingList(); 
		if (c > -1)
			pushToActiveList(c);
		return c;
	} else 
		return -1; 
}

void  ColorsList::pushToSequencedList(Color c)
{
	if (sequencedColors.listNo == MAXCOLORS)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::pushToSequencedList(): sequencedColor list has been overflowed.  sequencedColors.listNo = MAXCOLORS, i.e.," << sequencedColors.listNo + 1 << " = " << MAXCOLORS << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	sequencedColors.list[sequencedColors.listNo] = c;
	sequencedColors.listNo ++;
}

Color ColorsList::popFromSequencedList() 
{
	if (isEmpty_sequencedColors())
	{
		return -1;
	}

	sequencedColors.listNo --;
	printSequencedColorsInf();
	return sequencedColors.list[sequencedColors.listNo];
}

Color ColorsList::lastSequencedColor()
{
	if (isEmpty_sequencedColors())
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::LastSequencedColor(): sequencedColor list is empty." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}

	return sequencedColors.list[sequencedColors.listNo];
}

Color ColorsList::getSequencedColors(int i)
{ 
	if (i > sequencedColors.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::getSequencedColor(i): the index i is larger than the size of sequencedColors." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	
	}
	return sequencedColors.list[i];
};

Lib ColorsList::getSequencedLibs(int i)
{ 
	if (i > sequencedColors.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::getSequencedColor(i): the index i is larger than the size of sequencedColors." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	
	}
	return colorsLibList.list[sequencedColors.list[i]].list[0];
};


Color ColorsList::moveLastActiveToSequencedList()
{
	Color c;
	c = popFromActiveList(); 
	if (c > -1)
		pushToSequencedList(c);
	return c;

};

Color ColorsList::moveSingleCellsFromActiveToSequencedList()
{
	size_t remainingActiveColors = 0;
	while (activeColors.listNo > 0)
	{
		Color c = popFromActiveList(); 
		if (c > -1)
		{
			if (colorsLibList.list[c].listNo == 1)
			{
				pushToSequencedList(c);
			}
			else if (colorsLibList.list[c].listNo > 1)
			{
				pushToWaitingList(c);
				remainingActiveColors ++;
			}
		}
	};
	for (size_t i = 0; i < remainingActiveColors; i++)
	{
		moveLastWaitingToActiveList();
	};
	printActiveColorsInf();
	printSequencedColorsInf();
	logger-> out() << " moveSingleCellsFromActiveToSequencedList ends ========= " << endl;
};

void ColorsList::divideLastWaitingColor(size_t groupNum)
{
	if (!(isEmpty_activeColors()))
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::divideLastWaitingColor(): activeColors list is not empty." << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}
	Color c;
	c = popFromWaitingList();
	if (c > -1)
		divideColor(c, groupNum);
}

void ColorsList::divideAllWaitingColors(size_t groupNum)
{
	while (!(isEmpty_waitingColors()))
	{
		Color c;
		c = popFromWaitingList();
		if (c > -1)
			divideColor(c, groupNum);
	};
}


void ColorsList::divideAllActiveColors(size_t groupNum)
{
	size_t activeSize = activeListSize();
	while (!(isEmpty_activeColors()))
	{
		Color c;
		c = moveLastActiveToWaitingList();
	};
	for (size_t i = 0; i < activeSize; i++)
	{
		Color c;
		c = popFromWaitingList();
		if (c > -1)
			divideColor(c, groupNum);
	}
}

void ColorsList::divideFirstActiveColor(size_t groupNum)
{
	size_t activeSize = activeListSize();
	while (!(isEmpty_activeColors()))
	{
		Color c;
		c = moveLastActiveToWaitingList();
	};
	Color c = popFromWaitingList();
	if (c > -1)
		divideColor(c, groupNum);
}


void  ColorsList::divideColor(Color c, size_t groupNum)
{
	divideColor(colorsLibList.list[c], groupNum);
}


void  ColorsList::divideColor(LibraryList libraryList, size_t groupNum)
{
	if ( libraryList.listNo < groupNum)
		groupNum = libraryList.listNo;

	if (groupNum + colorsLibList.listNo >= MAXCOLORS)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsList::divideColor(): groupNum + colorsLibList.listNo >= MAXCOLORS, i.e.,"<< groupNum << "+" << colorsLibList.listNo << " >= " << MAXCOLORS << endl; 
		logger->out().flush();
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	};
	size_t libIndex = 0;
	for (Color j = 0; j < groupNum; j++)
	{
		size_t groupPopulation = (int) (libraryList.listNo - libIndex) / (int) (groupNum - j);
		logger->out() << "groupPopulation = " << groupPopulation << endl;
		if (groupPopulation > 0)
		{
			colorsLibList.list[colorsLibList.listNo].listNo = 0;
			colorsLibList.listNo ++;
			logger->out() << "colorsLibList.listNo = " << colorsLibList.listNo << endl;
			for (int i = 0; ((i < groupPopulation) && (libIndex < libraryList.listNo)); i++)
			{
				colors.list[libraryList.list[libIndex] + base_lib] = colorsLibList.listNo - 1; 
				colorsLibList.list[colorsLibList.listNo - 1].list[i] = libraryList.list[libIndex];
				colorsLibList.list[colorsLibList.listNo - 1].listNo ++;
				libIndex ++;
				logger->out() << " colorsLibList.list[" << colorsLibList.listNo - 1 << "].list[ " << i << "] = " << (int) colorsLibList.list[colorsLibList.listNo - 1].list[i] << endl;
			}
			pushToActiveList(colorsLibList.listNo - 1);
		}
	}
}

void  ColorsList::updateWaitingColorsIn_colors_list()
{
	for (size_t i = 0; i < waitingColors.listNo; i++)
	{
		Color c = waitingColors.list[i];
		for (size_t j = 0; j < colorsLibList.list[c].listNo; j++)
		{
			colors.list[colorsLibList.list[c].list[j] + base_lib] = c;
		}
	}
}

void ColorsList::updateActiveList(Lib _base_lib, int searchMethodType, size_t groupNum, Colors_List nextRoundColorList)
{
	set_base_lib(_base_lib);
	if ((searchMethodType == 1) || (searchMethodType == 0))
	{
		emptyActiveColors();
		for (int i = 0; i < nextRoundColorList.listNo; i++)
			pushToActiveList(nextRoundColorList.list[i]);
		divideAllActiveColors(groupNum);
	};
	if (searchMethodType == 2)
	{
		emptyActiveColors();
		logger->out() << " nextRoundColorList.listNo = " << nextRoundColorList.listNo << endl; 
		for (int i = 0; i < nextRoundColorList.listNo; i++)
			pushToWaitingList(nextRoundColorList.list[i]);

		if (nextRoundColorList.listNo == 0)
		{
			logger->out() << " moveLastWaitingToActiveList " << endl;
			moveLastWaitingToActiveList();
			logger->out() << " moveLastWaitingToActiveList done" << endl;
		}
		else
		{
			pushToActiveList(nextRoundColorList.list[nextRoundColorList.listNo - 1]);
			nextRoundColorList.listNo -= 1;
		}
		divideAllActiveColors(groupNum);
	}
	logger->out() << " updateWaitingColorsIn_colors_list " << endl;
	updateWaitingColorsIn_colors_list();
	logger->out() << " updateWaitingColorsIn_colors_list done" << endl;

}

size_t ColorsList::countCellsinColors(Color c)
{
	if (c >= colorsLibList.listNo)
	{
		if (logger != NULL)
			logger->out() << "Error in ColorsList::countCellsinColors(): c >= colorsLibList.listNo, i.e.,"<< c << " >= " << colorsLibList.listNo << endl; 
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	}
	return colorsLibList.list[c].listNo;
};

size_t ColorsList::countCellsinColors(Colors_List ListOfColors)
{
	size_t cellCount = 0;
	for (int i = 0; i < ListOfColors.listNo; i++)
	{
		cellCount += countCellsinColors(ListOfColors.list[i]);
	};
	return cellCount;
}


void ColorsList::printColorInf(Logger *_logger, bool _debugMode)
{
	Logger * tempLogger;
	tempLogger = logger;
	logger = _logger;
	bool tempDebugMode;
	tempDebugMode = debugMode;
	debugMode = _debugMode;
	printColorInf();
	logger =  tempLogger;
	debugMode = tempDebugMode;
}

void ColorsList::printColorInf() 
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "==============================" << endl;
			logger->out() << "Color numbers = " << colorsLibList.listNo << endl;

			for (Color c = 0; c < colorsLibList.listNo; c++)
				printColorInf(c);
		}
}

void ColorsList::printColorInf(Color c)
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "Color " << (int) c << " includes " << (int) colorsLibList.list[c].listNo << " libraries. Libraries are:" << endl;
			for (size_t i = 0; i < colorsLibList.list[c].listNo; i ++)
				logger->out() << (int) colorsLibList.list[c].list[i] << ", ";
			logger->out() << endl;
		};
}

void ColorsList::printActiveColorsInf()
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "Number of active colors are " << activeColors.listNo << ". The colors are:" << endl;
			for (size_t i = 0; i < activeColors.listNo; i ++)
				logger->out() << (int) activeColors.list[i] << ", ";
			logger->out() << endl;
		};
}

void ColorsList::printWaitingColorsInf()
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "Number of waiting colors are " <<  waitingColors.listNo << ". The colors are:" << endl;
			for (size_t i = 0; i < waitingColors.listNo; i ++)
				logger->out() << (int) waitingColors.list[i] << ", ";
			logger->out() << endl;
		};
}

void ColorsList::printSequencedColorsInf()
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "Number of sequenced colors are " << sequencedColors.listNo << ". The colors are:" << endl;
			for (size_t i = 0; i < sequencedColors.listNo; i ++)
				logger->out() << (int) sequencedColors.list[i] << ", ";
			logger->out() << endl;
		};
}

