/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          align-longreads.C
 * Author:         Hamidreza Chitsaz
 * Created:        2012
 * Last modified:  11/21/2012
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <malloc.h>
#include <stdlib.h>
#include <limits>
#include <map>
#include <bitset>
#include <queue>
#include <vector>
#include <set>

#include "kmer.h"
#include "kmers.h"
#include "bag.C"
#include "cgraph.h"
#include "getopt.h"
#include "hashtable.C"
#include "logger.h"
#include "oligo.h"
#include "reads.h"

using namespace std;

#define FILE_STRING (char *)"align-longreads"
#define MATCHING_OLIGO_RATIO 1.0
#define EDGE_COEFF 0.03

#define MATCH      1
#define MISMATCH  -3
#define INDEL     -2
#define READ_LENGTH 	100
#define MAX_LEVEL_DEPTH 20

typedef pair<basic_string<Nucleotide>, int> my_pair;
bool sort_pred(const my_pair& left, const my_pair& right) {return left.second > right.second;}

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('A', (char *)"assembly", NEEDS_ARG, (char *)"=input assembly graph file (mandatory)"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output files prefix (mandatory)"),
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer (mandatory)"),
	Option('m', (char *)"output_mode", NEEDS_ARG, (char *)"=output N best (mode 1) matched or N percent (mode 2) matched (default m=1)"),
	Option('N', (char *)"best_matched", NEEDS_ARG, (char *)"=output N best matched (default N=10)"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input reads are in FASTQ format"),
	Option('s', (char *)"single", NO_ARG, (char *)"single strand"),
	Option(0, NULL, 0, NULL)
};

struct PosLocus {
	Locus locus;	// defined in cgraph.h
	Coordinate localpos;
}
#if PACK_MEMORY
__attribute__((__packed__))
#endif
;

bool operator<(PosLocus lhs, PosLocus rhs)
{
	if(lhs.locus.cnodeid < rhs.locus.cnodeid)
		return true;
	else if (lhs.locus.cnodeid > rhs.locus.cnodeid)
		return false;
	else if (lhs.locus.cnodeid == -rhs.locus.cnodeid && lhs.locus.cnodeid > 0)
		return true;
	else if (lhs.locus.cnodeid == -rhs.locus.cnodeid && lhs.locus.cnodeid < 0)
		return false;
	else if (lhs.localpos < rhs.localpos)
		return true;
	else if (lhs.localpos > rhs.localpos)
		return false;
	else if (lhs.locus.pos < rhs.locus.pos)
		return true;
	else
		return false;
}

bool fasta = true;
int procs = 2;
bool doublestrand = true;
int k = 0;		// kmer
int m = 1; 		// output mode
int N = 10;		// output N best items
K kforge;		// for kmers
HashTable<WrapperKmer, PosLocus> *kmerindex = NULL;
HashTable<Oligo, PosLocus> *oligoindex = NULL;
Graph *cgraph = NULL;
map<CNodeID, basic_string<Nucleotide> *> *ntstrs = NULL;
//map<CNodeID, basic_string<Nucleotide> *> *paths = new map<CNodeID, basic_string<Nucleotide> *>;


int globalAlignment(basic_string<Nucleotide> X, basic_string<Nucleotide> Y);
bool equal(basic_string<Nucleotide> *c1, basic_string<Nucleotide> *c2);

// print out all nucleotides in contig;
void print_out_contig(CNodeID cnodeid){
	//kmer.print(cout << endl);
	cout << "Contig: ";
	//if(!cnodeid){ cout << "cnoedid == null!" << endl; return; }
	//ntstrs->find(currNode);
	if((*ntstrs).count(cnodeid) == 0) cnodeid = -cnodeid;
	//if((*ntstrs)[cnodeid]) cnodeid = -cnodeid;
	//if((*ntstrs)[cnodeid] == NULL){ cout << "(*ntstrs)[-cnodeid] == null!" << endl; return; }
	cout << "Contig: ";
	basic_string<Nucleotide> *st = ntstrs->find(cnodeid)->second;
	size_t len = (*st).length();
	for(Coordinate i = 0; i < len; i++)
		{
			Nucleotide n;
			n = (*st)[i];
			cout << nuc2char(n);
		}
	cout << endl;
}

void printOutInsOfCNodeID(CNodeID cnodeid){
	cout << "CnodeId.indegree(): " << cnodeid.indegree() << "; ";
	
	for(int i=0; i<cnodeid.indegree(); i++)
		cout << cnodeid.in(i);
	//print_out_contig(cnodeid);
	//if(cnodeid.outdegree() != 0)
		//cnodeid.append(cnodeid.out(0),k);
		//cout << cnodeid.out(0);
	//cout << "; CnodeId.outdegree(): " << cnodeid.outdegree();
	cout << endl;
}

void printContig(basic_string<Nucleotide> *st){
	Nucleotide *nt = (Nucleotide *) st->data();	
	size_t len;
	len = st->length();
	cout << "Contig length: " << len << endl;
	
	cout << "Contig: ";
	for(int i = 0; i<len; i++)
		cout << nuc2char(*(nt++));
	cout << endl;
}

void printContig2(basic_string<Nucleotide> c){
	size_t len = c.length();
	cout << "Contig length: " << len << endl;
	cout << "Contig: ";
	for(Coordinate i = 0; i < len; i++)
		cout << nuc2char(c[i]);
	cout << endl;
}


string convertToString(basic_string<Nucleotide> c){
	size_t len = c.length();
	string str;
	for(Coordinate i = 0; i < len; i++)
		str += nuc2char(c[i]);
	return str;
}

// trancate given contig
// startFS:	true - start abbreviation process with the first symbol; fals - start with the end of the contig. 
basic_string<Nucleotide>* shorten(basic_string<Nucleotide> *input, size_t len, bool startFS, Coordinate shifting){
	size_t length;	
	size_t i;
	
	

	if(startFS){
		i = shifting;
		if((shifting + len - 1) > (input->length()-1)) length = input->length() - 1;
		else length = shifting + len - 1;		
	}
	else{
		if(input->length() - shifting - 1 <= 0){ delete input; return new basic_string<Nucleotide>(); }
		//kforge.k()
		length = input->length() - shifting - 2;
		if(length > len) i = length - len + 1;
		/*length = input->length() - shifting - 1 + kforge.k() - 1;
		if(length > (len + kforge.k() -1)) i = length - len + 1 - kforge.k();*/
		//length = input->length() - shifting - 1 + k - 1;		
		////if(length > len) i = length - len + 1 - k;
		//if(length > (len + k -1)) i = length - len + 1 - k;
		else i = 0;
		
		//cout << "input->length(): " << input->length() << ", " << "len: " << len << ", " << "shifting: " << shifting << ", " << "kforge.k(): " << kforge.k() << endl;
		//cout << "i: " << i << ", " << "length: " << length << endl;
		//cin.get();
	}
	
	//cout << i << ", " << length << endl;
	//cout << "i: " << i << ", " << "length: " << length << endl;
	//basic_string<Nucleotide> *buf2 = new basic_string<Nucleotide>();
	//result->append(cTo->begin()+k-1, cTo->end());
	//buf->append(input->begin()+i, input->begin()+(length-i+1));
	basic_string<Nucleotide> *buf = new basic_string<Nucleotide>(input->substr(i,length-i+1));
	//*buf = ;	
	
	//for(; i<=length;)
	//	(*buf) += (*input)[i++];
	
	/*cout << "buf2: " << endl;
	printContig(buf2);
	
	cout << "BF: " << endl;
	printContig(buf);
	cout << "Equal?: " << equal(buf, buf2) << endl;
	cin.get();*/
	/*if(!startFS){
		length = input->length() - shifting - 2;		
		if(length > len) i = length - len + 1;
		else i = 0;
		for(; i<=length;)
			(*buf2) += (*input)[i++];
	}*/
	
	//printContig(buf);
	
	//printContig2(input->substr(i,length-i));
	//cin.get();
	
	/*cout << "len: " << len << endl;
	cout << "shifting: " << shifting << endl;
	//if(!startFS)
	//	printContig(buf2);
	cout << "Before: " << endl;
	printContig(input);
	cout << "After: " << endl;
	printContig(buf);
	cin.get();*/
	
	
	/*if(buf->length() == 0){
		cout << "Print out null contig!" << endl;
		printContig(buf);
		printContig(input);
	}*/
	
	delete input;
	//return buf2;
	return buf;
}

bool checkingCorrectnessOfIntersection(basic_string<Nucleotide> *left, basic_string<Nucleotide> *right){
	Coordinate i = left->length()-1;
	//Coordinate j = k-2; // for glueing
	//Coordinate j = k-1;
	Coordinate j = kforge.k()-1;
	while(j>=0){
		if((*left)[i] != (*right)[j]) return false;
		//cout << nuc2char((*left)[i]) << ", " << nuc2char((*right)[j])	 << endl;
		i--;
		j--;
	}
	return true;
}

// reverse complement of the contig
basic_string<Nucleotide>* reverseComplement(basic_string<Nucleotide> *c){
	basic_string<Nucleotide> *result = new basic_string<Nucleotide>(c->rbegin(), c->rend());
	for(int i = 0; i<result->length(); i++) (*result)[i] = dualnuc((*result)[i]);
	return result;
}

bool equal(basic_string<Nucleotide> *c1, basic_string<Nucleotide> *c2){
	if(c1->length() != c2->length()) return false;
	for(Coordinate i = 0; i<c1->length(); i++)
		if((*c1)[i] != (*c2)[i]) return false;
	return true;
}

// glue two contigs
basic_string<Nucleotide>* glueTwoContigs(basic_string<Nucleotide> *cFrom, basic_string<Nucleotide> *cTo){
	basic_string<Nucleotide> *result = new basic_string<Nucleotide>(*cFrom);
	//basic_string<Nucleotide> *resultCTo = new basic_string<Nucleotide>(*cTo);
	/*basic_string<Nucleotide> *result = new basic_string<Nucleotide>();
	Nucleotide n;
	
	// copying cFrom contig to result contig
	for(Coordinate i = 0; i<cFrom->length(); i++){		
		n = (*cFrom)[i];
		(*result) += n;
	}
	// copying toFrom contig to result contig
	for(Coordinate i = 0; (i+k-1)<cTo->length(); i++){
		n = (*cTo)[i+k-1];
		(*result) += n;
	}*/
	
	result->append(cTo->begin()+k-1, cTo->end());
	
	/*cout << "cFrom: " << endl;
	cFrom->append(cTo->begin()+k-1, cTo->end());
	printContig(cFrom);
	
	cout << "BF: " << endl;
	printContig(result);
	cout << "Equal?: " << equal(cFrom, result) << endl;;
	cin.get();*/
	
	//if(!checkingCorrectnessOfIntersection(cFrom, cTo)){
		/*cout << "Checking length of contigs:" << checkingCorrectnessOfIntersection(cFrom, cTo) << naysayersendl;
		cout << "cFrom contig. " << endl;
		printContig(cFrom);
		//cout << "Reverse contig. " << endl;
		//printContig(reverseComplement(cFrom));
		cout << "cTo contig. " << endl;
		printContig(cTo);
		cout << "result." << endl;
		printContig(result);
		cin.get();*/
	//}		
		
	//return result;
	return result;
}

// combine path
basic_string<Nucleotide>* combinePath(basic_string<Nucleotide> *prefix, basic_string<Nucleotide> *postfix){
	basic_string<Nucleotide> *result = new basic_string<Nucleotide>(*prefix);
	/*basic_string<Nucleotide> *result = new basic_string<Nucleotide>();
	
	for(Coordinate i = 0; i<prefix->length(); i++)
		(*result) += (*prefix)[i];

	for(Coordinate i = 0; i<postfix->length(); i++)
		(*result) += (*postfix)[i];*/
		
	result->append(*postfix);
	
	/*cout << "Prefix: " << endl;
	prefix->append(*postfix);
	printContig(prefix);
	
	cout << "BF: " << endl;
	printContig(result);
	cin.get();*/
	
	//result = prefix;
	//return result;
	return result;
}
	

// Breadth First Search Algorithms to traverse De Bruijn graph
// bool outDirection: true = traverse out edges, false = traverse in edges
vector<basic_string<Nucleotide> *> BFS(CNodeID cnodeid, int len, bool outDirection, Coordinate localpos){
	//bool signChanged = false;
	//int numberOfPaths = 1;
	int countLevels = 0;
	Coordinate shifting;
	int degree;
	queue<CNodeID> queueCnodeIDs;
	int cnodeIDsInCurrentLevel = 1;
  	int cnodeIDsNextLevel = 0;
	map<CNodeID, vector<basic_string<Nucleotide> *> > currMap, nextMap;
	//HashTable<CNodeID, basic_string<Nucleotide> *> *currHT = NULL; 
	//HashTable<CNodeID, basic_string<Nucleotide> *> *nextHT = NULL;
	vector<basic_string<Nucleotide> *> vector_buf;
	vector<basic_string<Nucleotide> *> currV;
	basic_string<Nucleotide> *buf;
	bool existance_key = false;
	//basic_string<Nucleotide> *curr;
	//bool building_paths_done = false;
	
	/*HashTable<WrapperKmer, PosLocus> *kmerindex = NULL;
	vector<PosLocus> **kmerLoci = new vector<PosLocus> *[read[job].size()-kforge.k()+1];
	kmerindex->add(wKmer, poslocus);
	kmerLoci[lc = 0] = kmerindex->get(wKmer);*/
	
	//int ml = 0;
	
	//cout << "start!" << endl;
	
	if (!cnodeid) return vector_buf;
	queueCnodeIDs.push(cnodeid);
	
	if(ntstrs->count(cnodeid) == 0){
		if(outDirection) shifting = localpos;
		else shifting = ntstrs->find(-cnodeid)->second->length() - localpos - 1; 	// delete k get rid of the coverage effect
		currMap[cnodeid].push_back(reverseComplement(ntstrs->find(-cnodeid)->second));
		//currHT->add(cnodeid, reverseComplement(ntstrs->find(-cnodeid)->second));
		//currMap[cnodeid].push_back(new basic_string<Nucleotide>(*(ntstrs->find(-cnodeid)->second)));
	}
	else{
		//currMap[cnodeid] = ntstrs->find(cnodeid)->second;
		if(outDirection) shifting = localpos;
		else shifting = ntstrs->find(cnodeid)->second->length() - localpos - 1; 	// delete k get rid of the coverage effect
		currMap[cnodeid].push_back(new basic_string<Nucleotide>(*(ntstrs->find(cnodeid)->second)));
		//currHT->add(cnodeid, new basic_string<Nucleotide>(*(ntstrs->find(cnodeid)->second)));
		//currMap[cnodeid] = 
		//int length = ;
		//currMap[cnodeid] = new basic_string<Nucleotide>();
		//*currMap[cnodeid] = ntstrs->find(cnodeid)->second->substr(0,ntstrs->find(cnodeid)->second->length());
		//ntstrs->find(cnodeid)->second->copy(buf,length,0);
	}
	//ml++;
		
	//if(outDirection) shifting = localpos;
	//else shifting = currMap[cnodeid]->length() - localpos - 1; 	// delete k get rid of the coverage effect	
	
	//while((countLevels < MAX_LEVEL_DEPTH) && !queueCnodeIDs.empty()){
	//cout << "Process!" << endl;
	//while((countLevels < MAX_LEVEL_DEPTH) && !queueCnodeIDs.empty()){
	while((countLevels < MAX_LEVEL_DEPTH) && !queueCnodeIDs.empty()){
		//bool len_enough = false;
		//bool len_not_enough = false;
		CNodeID currNode = queueCnodeIDs.front();
		queueCnodeIDs.pop();
		cnodeIDsInCurrentLevel--;
		
		//cout << "currMap[currNode]->length(): " << currMap[currNode]->length() << ", len + shifting + 1: " << len + shifting + 1 << endl;
		currV = currMap[currNode];
		for (vector<basic_string<Nucleotide> *>::iterator it=currV.begin(); it!=currV.end(); ++it){
			//if(currMap[currNode]->length() < len + shifting + 1){
			if((*it)->length() < len + shifting + 1){
				//cout << "Here!" << endl;
				if(outDirection) 
					//if(!signChanged) 
						degree = currNode.outdegree();
					//*else{
					//	degree = currNode.indegree();
					//	signChanged = false;
					//}/
				else 
					//if(!signChanged) 
						degree = currNode.indegree();
					//*else{
					//	degree = currNode.outdegree();
					//	signChanged = false;
					//}/
				//cout << "degree: " << degree << endl;
				for(int i=0; i<degree; i++){
					CNodeID nextNode;
					//len_not_enough = true;
					//cout << i << ", " << degree << (-currNode).outdegree() << endl;
					if(outDirection) nextNode = currNode.out(i);
					else nextNode = currNode.in(i);
				
					if(ntstrs->count(nextNode) == 0){
						//cout << "Changed sign!" << endl;
						//cout << "Out direction: " << outDirection << endl;
						//nextNode = -nextNode;
						//signChanged = true;		
						//cout << "Original:" << endl;
						//printContig(ntstrs->find(-nextNode)->second);			
						buf = reverseComplement(ntstrs->find(-nextNode)->second);
						//buf = new basic_string<Nucleotide>(*(ntstrs->find(-nextNode)->second));
						//cout << "Buf:" << endl;
						//printContig(buf);					
					}
					else{
						//buf = ntstrs->find(nextNode)->second;
						buf = new basic_string<Nucleotide>(*(ntstrs->find(nextNode)->second));
						//buf = new basic_string<Nucleotide>();
						//*buf = ntstrs->find(nextNode)->second->substr(0,ntstrs->find(nextNode)->second->length());
					}
					
					
					//cout << "Buf length: " << buf->length() << endl;
				
					existance_key = false;
					if(nextMap.count(nextNode) > 0)//{
						existance_key = true;
					//	delete nextMap[nextNode];
						//ml--;
					//}
				
					if(outDirection)
						nextMap[nextNode].push_back(glueTwoContigs(*it, buf));
						//nextHT->add(nextNode, glueTwoContigs(*it, buf));
					else
						nextMap[nextNode].push_back(glueTwoContigs(buf, *it));
						//nextHT->add(nextNode, glueTwoContigs(buf, *it));

					// print out currMap and nextMap:
					//*cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
					//cout << "currMap: " << endl;
					//for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it)
	  				//	printContig(it->second);
	  				
	  				//cout << "nextMap: " << endl;
					//for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=nextMap.begin(); it!=nextMap.end(); ++it)
	  				//	printContig(it->second);
	  					
	  				//cout << 2 << endl;
	  				//cin.get();
	  				//ml++;
	  				delete buf;
	  				if(!existance_key){
	  					queueCnodeIDs.push(nextNode);
						cnodeIDsNextLevel++;
					}
				}
			}
			else{
				/*existance_key = false;
				if(nextMap.count(currNode) > 0)//{
					existance_key = true;*/
				//	delete nextMap[currNode];
					//ml--;
				//}
				nextMap[currNode].push_back(new basic_string<Nucleotide>(**it));
				//nextHT->add(currNode, new basic_string<Nucleotide>(**it));
				/*if(!existance_key){
					queueCnodeIDs.push(currNode);
					cnodeIDsNextLevel++;
				}*/
				//len_enough = true;
				//ml++;
				//nextMap[currNode] = new basic_string<Nucleotide>();
				//nextMap[currNode] = currMap[currNode]->substr(0, currMap[currNode]->length());
			}
			//delete *it;
		}
		
		//for (vector<basic_string<Nucleotide> *>::iterator it=currV.begin(); it!=currV.end(); ++it)
		//	delete *it;
		//delete currMap[currNode];
		
		//cout << 1 << endl;
			
		if(cnodeIDsInCurrentLevel == 0 && !nextMap.empty()){
		//if(cnodeIDsInCurrentLevel == 0){
		
			//cout << "ml before: " << ml << endl;
			//cout << "nextMap.size() = " << nextMap.size() << endl;
			//cout << "currMap.size() = " << currMap.size() << endl;
			for (map<CNodeID, vector<basic_string<Nucleotide> *> >::iterator it=currMap.begin(); it!=currMap.end(); ++it){
				currV = it->second;
				for (vector<basic_string<Nucleotide> *>::iterator itV=currV.begin(); itV!=currV.end(); ++itV)
					delete *itV;
			}
			//currV = kmerindex->get(wKmer);
			//for (vector<basic_string<Nucleotide> *>::iterator it=currV.begin(); it!=currV.end(); ++it)
			//delete currHT;
			//currHT = nextHT;
			//nextHT = NULL;
			//}
			//cout << "ml after: " << ml << endl;
			//cout << "len_enough = " << len_enough << "; " << "len_not_enough = " << len_not_enough << endl << endl; 
			currMap.clear();
			swap(currMap, nextMap);
			cnodeIDsInCurrentLevel = cnodeIDsNextLevel;
			cnodeIDsNextLevel = 0;
			//if(len_enough && !len_not_enough)
			//	building_paths_done = true;
			countLevels++;
		}
	}
	
	/*cout << "shifting: " << shifting << endl;
	cout << "len: " << len << endl;
	cout << "????????????????Before shorten paths!" << endl;
	for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it)
  		printContig(it->second);*/
	// paths abbreviation
	
	//cout << endl << "************** SHIFTING! ******************" << endl;
  	/*for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it){
		if(outDirection) it->second = shorten(it->second, len, true, shifting);
		else it->second = shorten(it->second, len, false, shifting);
	}*/
	
	//cout << "end!" << endl;
	
	// ZAPPING MEMORY
	/*for (map<CNodeID, vector<basic_string<Nucleotide> *> >::iterator it=currMap.begin(); it!=currMap.end(); ++it){
  		currV = it->second;
  		for (vector<basic_string<Nucleotide> *>::iterator itV=currV.begin(); itV!=currV.end(); ++itV)
	  		delete *itV;
	}*/
	  		
	/*for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=nextMap.begin(); it!=nextMap.end(); ++it){
		delete it->second;
		//ml--;
	}*/
	//nextMap.clear();
	//cout << "began!" << endl;
	
  	for (map<CNodeID, vector<basic_string<Nucleotide> *> >::iterator it=currMap.begin(); it!=currMap.end(); ++it){
  		currV = it->second;
		for (vector<basic_string<Nucleotide> *>::iterator itV=currV.begin(); itV!=currV.end(); ++itV){
	  		if((*itV)->length() < len + shifting + 1){ delete *itV; continue; }	
			if(outDirection) {
				buf = shorten(*itV, len, true, shifting);
				if(buf->length() != 0)
					vector_buf.push_back(buf);
				else 
					delete buf;
			}
			else { 
				buf = shorten(*itV, len, false, shifting);
				if(buf->length() != 0) 
					vector_buf.push_back(buf);
				else
					delete buf;
			}
		}
	}
	
	//delete currHT;
	
	//for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it){
	

	
	//for (vector<basic_string<Nucleotide> *>::iterator it1=vector_buf.begin(); it1!=vector_buf.end(); ++it1)
	//	delete *it1;
	
	//currMap.clear();
	
	//cout << "end!" << endl << endl;
	
	// ZAPPING MEMORY
	/*for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it){
		delete it->second;
		//ml--;
	}*/
	
	/*if(ml != 0 ){
		cout << "ml: " << ml << endl;
		cin.get();
	}*/
	/*cout << "????????????????After shorten paths!" << endl;
	for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=currMap.begin(); it!=currMap.end(); ++it)
  		printContig(it->second);*/
  	//delete buf;
  	//return currMap;	
  	return vector_buf; 
}

pair<basic_string<Nucleotide>, int> getAllPossiblePaths	(
				CNodeID cnodeid, 
				int prefix_len, 
				int postfix_len, 
				Coordinate localpos,
				basic_string<Nucleotide> original	){
				
	basic_string<Nucleotide> buf;
	vector<basic_string<Nucleotide> *> prefixPaths, postfixPaths;
	my_pair p = pair<basic_string<Nucleotide>, int>();
	p.second = numeric_limits<int>::min();
	basic_string<Nucleotide> * prefixBest = NULL;
	basic_string<Nucleotide> * postfixBest = NULL;
	int maxPrefixBest = numeric_limits<int>::min();
	int maxPostfixBest = numeric_limits<int>::min();
	//int score_alignment = numeric_limits<int>::min();
	
	
	/*cout << "******CnodeId: " << ntstrs->find(cnodeid)->second << endl;
	if(ntstrs->count(cnodeid) == 0)
		cout << "-CnodeId length: " << ntstrs->find(-cnodeid)->second->length() << endl;
	else
		cout << "CnodeId length: " << ntstrs->find(cnodeid)->second->length() << endl;
	cout << "prefix_len: " << prefix_len << endl;
	cout << "postfix_len: " << postfix_len << endl;
	cout << "localpos: " << localpos << endl;*/
	//cin.get();
	//cout << "bfs begins" << endl;
	if(postfix_len != 0)//{
		postfixPaths = BFS(cnodeid, postfix_len, true, localpos);
		//cout << endl << endl << endl;
		//cout << "postfixMap length: " << postfixMap.size() << endl;
		//for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=postfixMap.begin(); it!=postfixMap.end(); ++it){
		//	postfix_paths.push_back(it->second);
	  		//printContig(it->second);
	  	//}
	//}
  	
  	//cout << endl << endl << endl << endl;

	if(prefix_len != 0)//{
  		prefixPaths = BFS(cnodeid, prefix_len, false, localpos);
	  	//cout << "prefixMap length: " << prefixMap.size() << endl;
		//for (map<CNodeID, basic_string<Nucleotide> *>::iterator it=prefixMap.begin(); it!=prefixMap.end(); ++it){
		//  	prefix_paths.push_back(it->second);
			//printContig(it->second);	
		//}
	//}
	//cout << "bfs ends" << endl;
	//if(postfix_len == 0) return postfix_paths;
	//else if(prefix_len == 0) return prefix_paths;
	
	//cout << "Checking ! " << endl;
	/*for (vector<basic_string<Nucleotide> *>::iterator it1=postfixPaths.begin(); it1!=postfixPaths.end(); ++it1)
		for (vector<basic_string<Nucleotide> *>::iterator it2=prefixPaths.begin(); it2!=prefixPaths.end(); ++it2){
			basic_string<Nucleotide> * bufP = combinePath(*it2, *it1);
			int alignment = globalAlignment(*bufP, original);
			if( alignment > score_alignment ){
				score_alignment = alignment;
				p = make_pair(*(bufP), score_alignment);
			}
			delete bufP;
		}*/
	
	
	//cout << "5" << endl;
	
	for (vector<basic_string<Nucleotide> *>::iterator it1=postfixPaths.begin(); it1!=postfixPaths.end(); ++it1){
		int alignment = globalAlignment(**it1, original);
		if( alignment > maxPostfixBest ){
			maxPostfixBest = alignment;
			postfixBest = *it1;
		}
	}
	
	/*for (map<CNodeID, basic_string<Nucleotide> *>::iterator it1=postfixMap.begin(); it1!=postfixMap.end(); ++it1){
		int alignment = globalAlignment(original, original);
		if( alignment > maxPrefixBest ){
			maxPrefixBest = alignment;
			postfixBest = it1->second;
		}
	}*/
	
	for (vector<basic_string<Nucleotide> *>::iterator it2=prefixPaths.begin(); it2!=prefixPaths.end(); ++it2){
		int alignment = globalAlignment(**it2, original);
		if( alignment > maxPrefixBest ){
			maxPrefixBest = alignment;
			prefixBest = *it2;
		}
	}
	
	//cout << "6" << endl;
	
	if((prefixBest != NULL) && (postfixBest != NULL)){
		basic_string<Nucleotide> * bufP = combinePath(prefixBest, postfixBest);
		p = make_pair(*(bufP), maxPrefixBest+maxPostfixBest);
		delete bufP;
	}
	
	//pair<basic_string<Nucleotide>, int> pr = make_pair(combinePath(prefixBest, postfixBest), maxPrefixBest+maxPostfixBest);
	
	// zapping memory
	//cout << "zapping memory begins" << endl;
	/*cout << 1 << endl;
	for (vector<basic_string<Nucleotide> *>::iterator it = prefix_paths.begin() ; it != prefix_paths.end(); ++it)
    	delete *it;
    cout << 2 << endl;	
    for (vector<basic_string<Nucleotide> *>::iterator it = postfix_paths.begin() ; it != postfix_paths.end(); ++it)
    	delete *it;
    cout << 3 << endl;	*/
	for (vector<basic_string<Nucleotide> *>::iterator it1=postfixPaths.begin(); it1!=postfixPaths.end(); ++it1)
		delete *it1;
	
	for (vector<basic_string<Nucleotide> *>::iterator it2=prefixPaths.begin(); it2!=prefixPaths.end(); ++it2)
		delete *it2;
	//cout << "zapping memory ends" << endl;	
			/*if(!checkingCorrectnessOfIntersection(it2->second, it1->second)){
				cout << "Not suited!	" << endl;
				printContig(it2->s	econd);
				printContig(it1->second);
				cin.get();
			}*/
	  		//cout << "Suit? " << checkingCorrectnessOfIntersection(it2->second, it1->second) << endl;	
	
	//cin.get();
	
	//cout << " 9 " << endl << endl;
	  	
	return p;
}

int globalAlignment(basic_string<Nucleotide> X, basic_string<Nucleotide> Y){
	size_t m = X.length();
	size_t n = Y.length();
	int tmp;
	int **C;
	
	C = new int *[m+1];
	for(int i = 0; i<=m; i++)
		C[i] = new int [n+1];
	
	// Global Alignment
	C[0][0] = 0;
	for(int i = 1; i<=m; i++)
		C[i][0] = i*INDEL;
		
	for(int j = 1; j<=n; j++)
		C[0][j] = j*INDEL;
		
	for(int i = 1; i <= m; i++)
		for( int j = 1; j <= n; j++){
			if(nuc2char(X[i]) == nuc2char(Y[j]))
				C[i][j] = C[i-1][j-1] + MATCH;
			else
				C[i][j] = C[i-1][j-1] + MISMATCH;
					
			tmp = C[i-1][j] + INDEL;
			if(tmp > C[i][j]) C[i][j] = tmp;
				
			tmp = C[i][j-1] + INDEL;
			if(tmp > C[i][j]) C[i][j] = tmp;
		}
			
	// Backtracking
	int i = m;
	int j = n;
	int k = 0;
	int bestSumAlignment = 0;
	while (i>0 || j>0){
		if (i > 0 && j > 0) {
			tmp = C[i-1][j-1];
			if (nuc2char(X[i]) == nuc2char(Y[j])) tmp += MATCH; else tmp += MISMATCH;
			if (tmp == C[i][j]) {
				bestSumAlignment += C[i][j];
				i--; 
				j--;
				continue; 
			} 
		}

		if (i > 0) {
			if (C[i-1][j] + INDEL == C[i][j]) {
				bestSumAlignment += C[i][j];
				i--;
				continue; 
			}
		}

		if (j > 0) {
			if (C[i][j-1] + INDEL == C[i][j]) { 
				bestSumAlignment += C[i][j];
				j--;
				continue;
			}
		}
	}
	
	for( int i=0 ; i<=m ; i++ )
		delete [] C[i] ;
	delete [] C ;
		
	return bestSumAlignment;
}

void loadAsm(string filename) //save is in AsmEngine::outputContigs
{
	FILE *inf = open_file((char*)filename.c_str(), "rb");

	cgraph = new Graph(0, procs);
	cgraph->load(inf);
	k = cgraph->getk();

	// k = 45;
	//cout << "k: " << k << endl;
	// size = 686;
	cout << "size: " << cgraph->size() << endl;
	cout << "k: " << k << endl;

	ntstrs = new map<CNodeID, basic_string<Nucleotide> *>;

	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());
		//print_out_contig(cnodeid);

		basic_string<Nucleotide> *st = new basic_string<Nucleotide>();
		(*ntstrs)[cnodeid] = st;

		size_t len = cnodeid.length();
		for(Coordinate i = 0; i < len; i++)
		{
			Nucleotide n;
			read_from_file((void *)&n, sizeof(Nucleotide), 1, inf);
			//cout << nuc2char(n);
			// nothing
			(*st) += n;
		}

		//printOutInsOfCNodeID(cnodeid);
		//cout << endl;

		//cout << "Nucleotide: " << st->length() << endl;
		//for(size_t t = 0; t < (*st).length(); t++)
		//	cout << nuc2char((*st)[t]);
	}
	fclose(inf);
}

void indexKmerInNtStr(CNodeID cnodeid, basic_string<Nucleotide> *st){
	size_t len = cnodeid.length();
	Coordinate i;
	
	Locus locus(cnodeid);
	PosLocus poslocus;
	poslocus.locus = locus;
	poslocus.localpos = 0;
	
	WrapperKmer wKmer;
	
	if(kforge.k() > len){ 
		cout <<  "The length of the contig is less that the length of kmer!";
		return;
	}
	
	register Nucleotide *nt = (Nucleotide *) st->data();
	
	for(i = 0; i < kforge.k(); i++)
		kforge.push_end(wKmer.kmer, *(nt++));
		
	kmerindex->add(wKmer, poslocus);
	
	for(; i<len; i++){
		kforge.push_end(wKmer.kmer, *(nt++));
		poslocus.locus++;
		kmerindex->add(wKmer, poslocus);
	}
	
	if(doublestrand){
		Locus neglocus(-cnodeid);
		poslocus.locus = neglocus;
		poslocus.localpos = 0;
		
		register Nucleotide *nt = (Nucleotide *) st-> data() + (len-1);
		
		for(i = 0; i < kforge.k(); i++)
			kforge.push_end(wKmer.kmer, dualnuc(*(nt--)));
			
		kmerindex->add(wKmer, poslocus);
		
		for(; i<len; i++){
			kforge.push_end(wKmer.kmer, dualnuc(*(nt--)));
			poslocus.locus++;
			kmerindex->add(wKmer, poslocus);
		}
	
	}
}

void indexOligosInNtStr(CNodeID cnodeid, basic_string<Nucleotide> *st)
{
	size_t len = cnodeid.length();
	Coordinate i;

	Locus locus(cnodeid);
	PosLocus poslocus;
	poslocus.locus = locus;
	poslocus.localpos = 0;

	Oligo oligo;

	if(oligo.maxSize() > len)
		return;

	register Nucleotide *nt = (Nucleotide *) st->data();

	for(i = 0; i < oligo.maxSize(); i++)
		oligo.push(*(nt++));

	oligoindex->add(oligo, poslocus);

	for(; i < len; i++)
	{
		oligo.push(*(nt++));
		poslocus.locus++;
		oligoindex->add(oligo, poslocus);
	}

	if(doublestrand)
	{
		Locus neglocus(-cnodeid);
		poslocus.locus = neglocus;
		poslocus.localpos = 0;

		register Nucleotide *nt = (Nucleotide *) st->data() + (len-1);

		for(i = 0; i < oligo.maxSize(); i++)
			oligo.push(dualnuc(*(nt--)));

		oligoindex->add(oligo, poslocus);

		for(; i < len; i++)
		{
			oligo.push(dualnuc(*(nt--)));
			poslocus.locus++;
			oligoindex->add(oligo, poslocus);
		}
	}
}

void indexKmers()
{
	kmerindex = new HashTable<WrapperKmer, PosLocus>();
	map<CNodeID, basic_string<Nucleotide> *>::iterator it = ntstrs->begin();
	while(it != ntstrs->end())
	{
		//cout << "Number of Paths: " << BFS(it->first, 2) << endl;
		//getAllPossiblePaths(it->first, READ_LENGTH, READ_LENGTH, 0);
		indexKmerInNtStr(it->first, it->second);
		it++;
	}
}

void indexOligos()
{
	oligoindex = new HashTable<Oligo, PosLocus>();

	map<CNodeID, basic_string<Nucleotide> *>::iterator it = ntstrs->begin();
	while(it != ntstrs->end())
	{
		//cout << "Cnode: " << it->first << endl;
		//cout << "basic_string: " << it->second->data << endl;
		indexOligosInNtStr(it->first, it->second);
		it++;
	}
}

// print out all nucleotides in kmer;
void print_out_kmer(Kmer kmer){
	//kmer.print(cout << endl);
	cout << "Kmer: ";
	for(int t = 0; t<kforge.k(); t++){
		cout << nuc2char(kforge.getnuc(kmer, t));
	}
	cout << endl;
}


void alignReads(string inp, string out, Logger *logger)
{
	bool done = false;
	int edge;
	//int n = 30; // for kmers
	//kforge.reset(k);
	Reads reads;
	reads.initialize(inp, fasta);
	FILE *nucout = open_file((char*)(out+".nucs").c_str(), "wt");
	FILE *algnout = open_file((char*)(out+".algns").c_str(), "wt");
	FILE *corrected = open_file((char*)(out+".fa").c_str(), "wt");

	int thisprocs = MAX(1, procs);
	int jobs = (thisprocs > 1) ? 16 * thisprocs : 1;

	Read *read = new Read[jobs];
	bool *load = new bool[jobs];

	bool temp = true;

	size_t current = 0;

	while(!done)
	{
		int jb = 0;
		while(jb < jobs && !done)
		{
			load[jb] = reads.next(&read[jb], 0, 0, false);
			if(!load[jb])
				done = true;
			jb++;
		}

#pragma omp parallel for schedule(dynamic) num_threads(thisprocs)
		for(int job = 0; job < jobs; job++)
		{
			//Oligo oligo;	// size = 8; maxSize = 8;
			//cout << "Oligo: " << oligo.maxSize() << endl;

			//Replacing all oligos on Kmers.			
 			WrapperKmer wKmer;

			if(load[job])
				if(read[job].size() >= kforge.k())
				{
					Coordinate c, lc;
					int edge = EDGE_COEFF*read[job].size();
					if(edge == 0) edge = 1;
					// read[job].size() == 100
					//vector<PosLocus> **loci = new vector<PosLocus> *[read[job].size()-oligo.maxSize()+1];
					basic_string<Nucleotide> read_buf;
					vector<PosLocus> **kmerLoci = new vector<PosLocus> *[read[job].size()-kforge.k()+1];
					
					for(c = 0; c < kforge.k(); c++){
						Nucleotide nuc = read[job][c];
						kforge.push_end(wKmer.kmer, nuc);
						read_buf += nuc;
					}
					
					/*if(temp){
						cout << "Edge: " << edge << endl;
						cout << "Read: ";
						read[job].print(cout);
						cout << "Length read: " << read[job].size() << endl;
						print_out_kmer(wKmer.kmer);
						temp = false;
					}*/
					
					//cout << "Another try!" << endl;
					//cin.get();

					//for(c = 0; c < oligo.maxSize(); c++){
						//if(temp)
						//	oligo.show(cout << endl, oligo.oligomer, oligo.maxSize()-1);
					//	oligo.push(read[job][c]);
					//}
					
					//temp = false;
					
					//loci[lc = 0] = oligoindex->get(oligo);
					kmerLoci[lc = 0] = kmerindex->get(wKmer);

					//WrapperKmer temp;
					/*PosLocus poslocus;
					vector<PosLocus>::iterator it = kmerLoci[0]->begin();
					if(temp){
						while(it != kmerLoci[0]->end())
						{
							//cout << "Cnode: " << it->first << endl;
							//cout << "basic_string: " << it->second->data << endl;
							//indexOligosInNtStr(it->first, it->second);
							poslocus = *it;
							cout << "Cnode: " << poslocus.locus.cnodeid << endl;
							cout << "poslocus: " << poslocus.locus.pos << endl;
							//poslocus = it->second;
							it++;
						}
					}
					temp = false;

					for(int j=0; j<kmerLoci[c]->size(); j++){

					}*/

					// mine
					/*if(temp){
						read[job].print(cout);
						//cout << loci[0] << endl;
						//cout << read[job].size() <<endl;
						temp = false;
					}*/
					
					for(; c < read[job].size(); c++)
					{
						//cout << nuc2char(oligo[0]) << endl;
						//oligo.show(cout << endl, oligo.oligomer, oligo.maxSize()-1);
						Nucleotide nuc = read[job][c];
						kforge.push_end(wKmer.kmer, nuc);
						kmerLoci[++lc] = kmerindex->get(wKmer);
						read_buf += nuc;
						//loci[++lc] = oligoindex->get(oligo);
					}

					// we are looking for all indexies untill now.
					
					size_t total = 0, idx;
					for(c = 0; c <= lc; c++)
						total += kmerLoci[c]->size();

					// counting how many indexies

					PosLocus *posKmerLoci = new PosLocus[total];

					idx = 0;
					for(c = 0; c <= lc; c++)
					{
						copy(kmerLoci[c]->begin(), kmerLoci[c]->end(), posKmerLoci+idx);
						for(size_t i = 0; i < kmerLoci[c]->size(); i++)
							posKmerLoci[idx++].localpos = c;
					}

					if(idx != total) exitMsg((char*)"Error: align-longreads panic: there is an inherent bug in Bag.", INTERNAL_WOW_ERROR);

					//if(temp){
					//	cout << posloci << endl;
					//	cout << posloci+total <<endl;
					//	temp = false;
					//}

					//sort(posKmerLoci, posKmerLoci+total);

					CNodeID prev;
					size_t count = 0, alignmatches = 0;
					
					//vector<basic_string<Nucleotide> *> paths;
					set<basic_string<Nucleotide> > spaths;
					//map<int, basic_string<Nucleotide>> ntstrs = new map<int, basic_string<Nucleotide>>();
					
					vector<pair<basic_string<Nucleotide>, int> > items;
					
					for(idx = 0; idx < total; idx++)
					{
					
					
						/*if(ntstrs->count(posKmerLoci[idx].locus.cnodeid) == 0){
							if(ntstrs->count(-posKmerLoci[idx].locus.cnodeid) == 0)
								cout << "Something wrong!" << endl;
							else
								cout << "Everything is OK!" << endl;
						}
						else
							cout << "Everything is OK!" << endl;*/
						// BFS(CNodeID cnodeid, int len, bool outDirection, Coordinate localpos){
						//if(temp){
							//cout << (*ntstrs)[posloci[idx].locus.cnodeid] << " " << posloci[idx].locus.pos << " " << posloci[idx].localpos << endl;
							//cout << (*ntstrs)[posloci[idx].locus.cnodeid]
							//temp = false;
						//}

						//cout << posloci[idx].locus.cnodeid.size() << endl;
						//cout << posloci[idx].locus.cnodeid.length() << endl;
						//cout << (*ntstrs)[posloci[idx].locus.cnodeid] << endl;
						
						// getAllPossiblePaths(CNodeID cnodeid, int prefix_len, int postfix_len, Coordinate localpos){
						
						/*cout << "CnodeId: " << ntstrs->find(posKmerLoci[idx].locus.cnodeid)->second << endl;
						if(ntstrs->count(posKmerLoci[idx].locus.cnodeid) == 0)
							cout << "-CnodeId length: " << ntstrs->find(-posKmerLoci[idx].locus.cnodeid)->second->length() << endl;
						else
							cout << "CnodeId length: " << ntstrs->find(posKmerLoci[idx].locus.cnodeid)->second->length() << endl;
						cout << "prefix_len: " << posKmerLoci[idx].localpos << endl;
						cout << "postfix_len: " << read[job].size() - posKmerLoci[idx].localpos << endl;
						cout << "localpos: " << posKmerLoci[idx].locus.pos << endl;*/
						
						items.push_back(getAllPossiblePaths(posKmerLoci[idx].locus.cnodeid, posKmerLoci[idx].localpos + edge, read[job].size() - posKmerLoci[idx].localpos + edge, posKmerLoci[idx].locus.pos, read_buf));
						
						/*vector<basic_string<Nucleotide> *> buf;
						buf = getAllPossiblePaths(posKmerLoci[idx].locus.cnodeid, posKmerLoci[idx].localpos + edge, read[job].size() - posKmerLoci[idx].localpos + edge, posKmerLoci[idx].locus.pos);
						//paths.insert(paths.end(), buf.begin(), buf.end() );
						for (std::vector<basic_string<Nucleotide> *>::iterator it = buf.begin() ; it != buf.end(); ++it)
    						spaths.insert(**it);
    					
    					// ZAPPING MEMORY
    					for (std::vector<basic_string<Nucleotide> *>::iterator it = buf.begin() ; it != buf.end(); ++it)
    						delete *it;*/
    					
						//spaths.insert(buf.begin(), buf.end());
						
						//buf.clear();
						
						// show paths
						/*cout << "Paths:" << endl;
						for (std::vector<basic_string<Nucleotide> *>::iterator it = paths.begin() ; it != paths.end(); ++it)
    						printContig(*it);
    						
    					cin.get();*/
						
						/*if(idx == 0)
						{
							prev = posKmerLoci[idx].locus.cnodeid;
							count = 1;
						}
						else
							if(prev == posKmerLoci[idx].locus.cnodeid)
								count++;
							else
							{
								if(count > MATCHING_OLIGO_RATIO*(prev.size()-kforge.k()+1))
									alignmatches++;
								prev = posKmerLoci[idx].locus.cnodeid;
								count = 1;
							}*/
					
					}
					
					//map<CNodeID, basic_string<Nucleotide> *> *ntstrs = NULL;
					//map<basic_string<Nucleotide> *, int> mapPaths;
					//cout << "Paths:" << endl;
					//cout << "Paths length: " << paths.size() << endl;
					//cout << "sPaths length: " << spaths.size() << endl;
					
					/*************************************************************
					vector<pair<basic_string<Nucleotide>, int> > items;
					for (set<basic_string<Nucleotide> >::iterator it = spaths.begin() ; it != spaths.end(); ++it){
    					//printContig2(*it);
    					//printContig2(read_buf);
    					//globalAlignment(*it, read_buf);
    					items.push_back(make_pair(*it,globalAlignment(*it, read_buf)));
    					//cout << globalAlignment(it, read_buf) << endl;
    					//cin.get();
    				}
    				
    				// ***************************************************************** */
    				
    				
    				//for (set<basic_string<Nucleotide> >::iterator it = spaths.begin() ; it != spaths.end(); ++it){ delete *it;}
						
    				
    				
    				//vector<pair<basic_string<Nucleotide> *, int> > items;
					/*for (std::vector<basic_string<Nucleotide> *>::iterator it = paths.begin() ; it != paths.end(); ++it){
    					//printContig(*it);
    					//mapPaths[*it] = globalAlignment(*it, read_buf);
    					items.push_back(make_pair(*it,globalAlignment(*it, read_buf)));
    					//cout << globalAlignment(*it, read_buf) << endl;
    					//cin.get();
    				}*/
    				
    				/*struct sort_pred {
						bool operator()(const std::pair<basic_string<Nucleotide> *, int> &left, const std::pair<basic_string<Nucleotide> *, int> &right) {
							return left.second < right.second;
						}
					};*/
					
					
    				//********************************************
    				//cout << "Items: " << items.size() << endl;
    				sort(items.begin(), items.end(), sort_pred);
    				//		[](const pair<basic_string<Nucleotide> *, int>& lhs, const pair<basic_string<Nucleotide> *, int>& rhs) {
             		//			return lhs.second < rhs.second; } );
    				
    				//cout << "MapPaths: " << mapPaths.size() << endl;
    				
    				
    				//cout << "** Original read: ";
    				//printContig2(read_buf);
  					//cout << "Here!" << endl;
    				int i=0;
    				int max_number = 1;
    				//if(m == 1)
    				//	max_number = N;
    				//else 
    				//	max_number = items.size()*N/100;
    					
    				//for (vector<pair<basic_string<Nucleotide>, int> >::iterator it=items.begin(); it!=items.end() && i<max_number; ++it, i++){
    								//std::cout << it->first << " => " << it->second << '\n';
    					//printContig2(it->first);
    					//cout << "Score alignment: " << it->second;
    								//cin.get();	
    				//}
    				
    				string bufStr = convertToString(read_buf);

					
					//for (vector<pair<basic_string<Nucleotide>, int> >::iterator it=items.begin(); it!=items.end() && i<max_number; ++it, i++){
    					//std::cout << it->first << " => " << it->second << '\n';
    					//printContig2(it->first);
    					//cout << "Score alignment: " << it->second;
    					//string bufStr2 = convertToString(it->first);
    					//cout << bufStr << endl;
    					//fprintf(corrected, ">corrected_read_%s\n", bufStr.c_str());
    					//fprintf(corrected, ">corrected_read_%s\n%s\n", bufStr.c_str(), bufStr2.c_str());
    					//cin.get();	
    				//}   
    				if(!items.empty()){
    					vector<pair<basic_string<Nucleotide>, int> >::iterator it=items.begin();
    					string bufStr2 = convertToString(it->first);
    					fprintf(corrected, ">corrected_read_%s\n%s\n", bufStr.c_str(), bufStr2.c_str());
    				} 
    				else fprintf(corrected, ">corrected_read_%s\nnot_found_matches\n", bufStr.c_str());
					
					//cout << "done!" << endl;
    				
    				//************************************************ */
    				
    				//items.clear();
    				//spaths.clear();
    				
    				//cin.get();
    				
    				/*struct CompareByValue {
					  bool operator() (const MyPair& a, const MyPair& b) const {
						return a.second < b.second;
					  };
					};*/
    				//sort(items.begin(), items.end());

					/*if(count && count > MATCHING_OLIGO_RATIO*(prev.size()-kforge.k()+1))
						alignmatches++;
					
					if(alignmatches>1)
						cout << "total: " << total << "; alignmatches: " << alignmatches << endl;*/
					
					delete[] posKmerLoci;
					
					//for(c = 0; c <= lc; c++)
					//	delete kmerLoci[c] ;
					delete[] kmerLoci;
				}
		}

		for(int job = 0; job < jobs; job++)
		{
			if(load[job])
			{
				current++;
				if(!(current % 100)){
					//cout << current << " reads have been processed." << endl;
					logger->out() << current << " reads have been processed." << endl;
				}
			} else
				done = true;
		}
	}

	delete[] read;
	delete[] load;
	fclose(nucout);
	fclose(algnout);
	fclose(corrected);
	reads.finalize();
}

/*void alignReads(string inp, string out, Logger *logger)
{
	bool done = false;
	int n = 30; // for kmers
	kforge.reset(k);
	Reads reads;
	reads.initialize(inp, fasta);
	FILE *nucout = open_file((char*)(out+".nucs").c_str(), "wt");
	FILE *algnout = open_file((char*)(out+".algns").c_str(), "wt");

	int thisprocs = MAX(1, procs);
	int jobs = (thisprocs > 1) ? 16 * thisprocs : 1;

	Read *read = new Read[jobs];
	bool *load = new bool[jobs];

	bool temp = true;

	size_t current = 0;

	while(!done)
	{
		int jb = 0;
		while(jb < jobs && !done)
		{
			load[jb] = reads.next(&read[jb], 0, 0, false);
			if(!load[jb])
				done = true;
			jb++;
		}

#pragma omp parallel for schedule(dynamic) num_threads(thisprocs)
		for(int job = 0; job < jobs; job++)
		{
			Oligo oligo;	// size = 8; maxSize = 8;
			//cout << "Oligo: " << oligo.maxSize() << endl;

			//Replacing all oligos on Kmers.			
 			Kmer kmer;

			if(load[job])
				if(read[job].size() >= oligo.maxSize())
				{
					Coordinate c, lc, kc, klc;
					// read[job].size() == 100
					vector<PosLocus> **loci = new vector<PosLocus> *[read[job].size()-oligo.maxSize()+1];
					//vector<PosLocus> **kmerLoci = new vector<PosLocus> *[read[job].size()-kforge.k()+1];
					
					for(kc = 0; kc < kforge.k(); kc++){
						Nucleotide nuc = read[job][kc];
						kforge.push_end(kmer, nuc);
					}
					
					if(temp){
						cout << "Read: ";
						read[job].print(cout);
						print_out_kmer(kmer);
						temp = false;
					}

					for(c = 0; c < oligo.maxSize(); c++){
						//if(temp)
						//	oligo.show(cout << endl, oligo.oligomer, oligo.maxSize()-1);
						oligo.push(read[job][c]);
					}
					
					//temp = false;
					
					loci[lc = 0] = oligoindex->get(oligo);

					// mine
					if(temp){
						read[job].print(cout);
						//cout << loci[0] << endl;
						//cout << read[job].size() <<endl;
						temp = false;
					}

					for(; c < read[job].size(); c++)
					{
						//cout << nuc2char(oligo[0]) << endl;
						//oligo.show(cout << endl, oligo.oligomer, oligo.maxSize()-1);
						oligo.push(read[job][c]);
						loci[++lc] = oligoindex->get(oligo);
					}

					// we are looking for all indexies untill now.

					size_t total = 0, idx;
					for(c = 0; c <= lc; c++)
						total += loci[c]->size();

					// counting how many indexies

					PosLocus *posloci = new PosLocus[total];

					idx = 0;
					for(c = 0; c <= lc; c++)
					{
						copy(loci[c]->begin(), loci[c]->end(), posloci+idx);
						for(size_t i = 0; i < loci[c]->size(); i++)
							posloci[idx++].localpos = c;
					}

					if(idx != total) exitMsg((char*)"Error: align-longreads panic: there is an inherent bug in Bag.", INTERNAL_WOW_ERROR);

					if(temp){
						cout << posloci << endl;
						cout << posloci+total <<endl;
						temp = false;
					}

					sort(posloci, posloci+total);

					CNodeID prev;
					size_t count = 0, alignmatches = 0;

					for(idx = 0; idx < total; idx++)
					{
						//if(temp){
							//cout << (*ntstrs)[posloci[idx].locus.cnodeid] << " " << posloci[idx].locus.pos << " " << posloci[idx].localpos << endl;
							//cout << (*ntstrs)[posloci[idx].locus.cnodeid]
							//temp = false;
						//}

						//cout << posloci[idx].locus.cnodeid.size() << endl;
						//cout << posloci[idx].locus.cnodeid.length() << endl;
						//cout << (*ntstrs)[posloci[idx].locus.cnodeid] << endl;

						if(idx == 0)
						{
							prev = posloci[idx].locus.cnodeid;
							count = 1;
						}
						else
							if(prev == posloci[idx].locus.cnodeid)
								count++;
							else
							{
								if(count > MATCHING_OLIGO_RATIO*(prev.size()-oligo.maxSize()+1))
									alignmatches++;
								prev = posloci[idx].locus.cnodeid;
								count = 1;
							}
					}

					if(count && count > MATCHING_OLIGO_RATIO*(prev.size()-oligo.maxSize()+1))
						alignmatches++;

					//cout << total << " " << alignmatches << endl;

					delete[] posloci;
					delete[] loci;
				}
		}

		for(int job = 0; job < jobs; job++)
		{
			if(load[job])
			{
				current++;
				if(!(current % 100))
					logger->out() << current << " reads have been processed." << endl;
			} else
				done = true;
		}
	}

	delete[] read;
	delete[] load;
	fclose(nucout);
	fclose(algnout);
	reads.finalize();
}*/




int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);

	int files = 0;
	string inputReadsFilename, inputAssemblyFilename;
	string outputName;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputReadsFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] longreads-file\n");
			printf("       Input assembly graph file is identified by -A option.\n");
			printf("       Output files prefix is identified by -O option.\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
      		else if (count == 'A')
			inputAssemblyFilename = current->getArg();
      		else if (count == 'O')
			outputName = current->getArg();
      		else if (count == 'q')
			fasta = false;
			else if (count == 'k')
			k = atoi(current->getArg());
			else if (count == 'm')
			m = atoi(current->getArg());
			else if (count == 'N')
			N = atoi(current->getArg());
      		else if (count == 'p')
			procs = atoi(current->getArg());
      		else if (count == 's')
			doublestrand = false;
		
	}

	if(!files || inputReadsFilename == "" || inputAssemblyFilename == "")
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	if(outputName == "")
	{
		fputs("Error: output name not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, OUTPUT_ARG_ERROR);
	}

	kforge.reset(k);

	Logger logger(outputName+".log");

	cout << "Logging in " << outputName+".log" << " file. Follow the status of the program there." << endl;
	cout.flush();

	time_t now;
	time(&now);
	logger.out() << "================================================" << endl;
	logger.report(string(FILE_STRING)+ " has been executed on " + string(ctime(&now)));
	for(int i = 0; i < argc; i++)
		logger.out() << argv[i] << " ";
	logger.out() << endl << endl;
	
	logger.out().flush();


	logger.setSection("loading assembly");
	loadAsm(inputAssemblyFilename);
	
	/*cout << "Begin checking!" << endl;
	
	if(ntstrs)
     {
         for(Serial idx = 0; idx < cgraph->size(); idx++)
         {
             CNodeID cnodeid(cgraph->node(idx));
             if(cnodeid.outdegree() == 0) cout << "idx: " << idx << ". Outdegree is empty!" << endl;
             else if(cnodeid.indegree() == 0) cout << "idx: " << idx << ". Indegree is empty!" << endl;
         }

     }
     
     cout << "End!" << endl;
     cin.get();*/

	//logger.setSection("indexing oligos in the assembly");
	//indexOligos();
	
	logger.setSection("indexing kmers in the assembly");
	indexKmers();



	logger.setSection("aligning reads to the assembly");
	alignReads(inputReadsFilename, outputName, &logger);

	//if(oligoindex) delete oligoindex;
	if(kmerindex) delete kmerindex;

	if(ntstrs)
	{
		map<CNodeID, basic_string<Nucleotide> *>::iterator it = ntstrs->begin();
		while(it != ntstrs->end())
		{
			delete it->second;
			it++;
		}
		delete ntstrs;
	}

	if(cgraph) delete cgraph;

	logger.report(string(FILE_STRING)+ " successfully concluded.");

	return NO_ERROR;
}
