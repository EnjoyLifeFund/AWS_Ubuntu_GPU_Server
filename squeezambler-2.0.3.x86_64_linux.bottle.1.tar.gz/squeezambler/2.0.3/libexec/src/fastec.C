/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          fastec.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <math.h>
//#ifdef OPENMP
//	#include <omp.h>
//#endif

#include "kmers.C"
#include "splaytree.C"
#include "getopt.h"
#include "reads.h"

#define PE 0.4

using namespace std;

#define FILE_STRING (char *)"fastec"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output file prefix"),
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input is in FASTQ format"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads"),
	Option(0, NULL, 0, NULL)
};

struct KmerInfo {
	Probability outedgesprob[NUCS];  //A, C, G, T
	Probability inedgesprob[NUCS];  //A, C, G, T
	Probability prob;
};

Kmer &smaller(Kmer &kmer, Kmer &dualkmer, bool &dual)
{
	if(kmer < dualkmer)
	{
		dual = false;
		return kmer;
	} else
	{
		dual = true;
		return dualkmer;
	}
}

void index(Kmers<KmerInfo, SplayTree> & kmers, Reads & reads, unsigned int k)
{
	KmerData<KmerInfo> pair;
	KmerData<KmerInfo> *node;
	Kmer searchedkmer;
	K kforge(k);
	
	Read r;

	size_t current = 0;

	while(reads.next(&r, 0, 0, false))
	{
		Kmer kmer, dualkmer;
			
		int len = r.size();

		for(int i = 0; i < len; i++)
		{
			Nucleotide nuc = r[i];
			kforge.push_end(kmer, nuc);
			kforge.push_begin(dualkmer, dualnuc(nuc));

			if(i >= k-1)
			{
				bool dual;
				
				kmers.fetch(searchedkmer = smaller(kmer, dualkmer, dual), node);
				if(node)
					pair.second = node->second;
				else
				{
					pair.second.prob = 0;
					for(int i = 0; i < NUCS; i++)
						pair.second.outedgesprob[i] = pair.second.inedgesprob[i] = 0;
				}

				pair.second.prob = (Probability)(MAXPROB - PE*(MAXPROB - pair.second.prob));
				if(dual)
				{
					if(i > k-1)
						pair.second.outedgesprob[nuc = dualnuc(r[i-k])] = (Probability)(MAXPROB - PE*(MAXPROB - pair.second.outedgesprob[nuc]));
					if(i < len-1)
						pair.second.inedgesprob[nuc = dualnuc(r[i+1])] = (Probability)(MAXPROB - PE*(MAXPROB - pair.second.inedgesprob[nuc]));
				} else
				{
					if(i < len-1)
						pair.second.outedgesprob[nuc = r[i+1]] = (Probability)(MAXPROB - PE*(MAXPROB - pair.second.outedgesprob[nuc]));
					if(i > k-1)
						pair.second.inedgesprob[nuc = r[i-k]] = (Probability)(MAXPROB - PE*(MAXPROB - pair.second.inedgesprob[nuc]));
				}

				if(node)
					node->second = pair.second;
				else
				{
					pair.first = searchedkmer;
					kmers.insert(pair);
				}
			}
		}
		current++;

		if(!(kmers.size() % 10000))
			cout << k << "-mers so far: " << kmers.size() << " in " << current << " reads." << endl;
	} 
}


int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;
	string inputFilename;
	string outputName;
	bool fasta = true;
	int procs = 8;
	int k = 0;
	Reads reads;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] reads-file\n");
			printf("       Output files prefix is identified by -O option (default reads-file).\n");
			printf("%s\n", opts.help());
			exit(0);
		}
      		else if (count == 'O')
			outputName = current->getArg();
      		else if (count == 'k')
			k = atoi(current->getArg());
      		else if (count == 'q')
			fasta = false;
      		else if (count == 'p')
			procs = atoi(current->getArg());
	}

	if(!files || k == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}

	if(outputName == "")
		outputName = inputFilename + ".corrected";

	time_t now;
	
	time(&now);
	printf("%s\n", ctime(&now));

	Kmers<KmerInfo, SplayTree> kmers;	
	reads.initialize(inputFilename, fasta);
	index(kmers, reads, k); 
	reads.finalize();

	long int counts[1010];

	for(int i = 0; i < 1010; i++)
		counts[i] = 0; 

	K kforge(k);

	ofstream output;
	output.open((outputName+".fasta").c_str(), ios::out);

	reads.initialize(inputFilename, fasta);

	long int current = 0;
	bool done = false;
//	kmers.setThreadSafe(true);
	kmers.setContainersThreadSafe(true);

#pragma omp parallel num_threads(procs) shared(done) 
	while(!done)
	{
		Read read;

#pragma omp critical
		done = !reads.next(&read, 0, 0, false);

		Nucleotide *nucs[2];
		Nucleotide nuc, dnuc;
		Kmer *kmer, *dualkmer, searchedkmer;
		KmerInfo info;

		if(!done)
		{		
			long int sz = read.size();

			for(int i = 0; i < 2; i++)
				nucs[i] = (Nucleotide *)malloc(sizeof(Nucleotide)*(sz+1));

			for(int i = 0; i < sz; i++)
				nucs[1][i] = dualnuc(nucs[0][i] = read[i]);

			kmer = new Kmer[sz-k+1];
			dualkmer = new Kmer[sz-k+1];

			for(int i = 0; i < k; i++)
			{
				nuc = nucs[0][i];
				dnuc = nucs[1][i];
				kforge.push_end(kmer[0], nuc);
				kforge.push_begin(dualkmer[0], dnuc);
			}

			bool searchdual;
			bool kmerNotFound = false;
			double p = 1.0;

			for(int i = 1; i < sz-k+1; i++)
			{
				kmer[i] = kmer[i-1];
				dualkmer[i] = dualkmer[i-1];
				
				nuc = nucs[0][i+k-1];
				dnuc = nucs[1][i+k-1];

				if(!kmers.fetch(smaller(kmer[i], dualkmer[i], searchdual), info))
					exitMsg((char*)"Woooowwww\n", INTERNAL_WOW_ERROR);
				
				p *= NORMAL((searchdual) ? info.inedgesprob[dnuc] : info.outedgesprob[nuc]) / NORMAL(info.prob);

				kforge.push_end(kmer[i], nuc);
				kforge.push_begin(dualkmer[i], dnuc);
			}


			double maxProb = p;
			int bestpos1 = -1;
			Nucleotide bestn1; 
//			int bestpos2 = -1;
//			Nucleotide bestn2; 
			for(int pos1 = sz-1; pos1 >= 0; pos1--)
//			for(int pos2 = pos1-1; pos2 >= 0; pos2--) 
			{
				for(Nucleotide n1 = 0; n1 < 4; n1++)
//				for(Nucleotide n2 = 0; n2 < 4; n2++) 
				{
/*					if(nucs[0][pos1] == n1 && nucs[0][pos2] == n2)
						continue; */ 

					if(nucs[0][pos1] == n1)
						continue; 

					Kmer localkmer, localdualkmer;
					double localmax = 0.0;
					kmerNotFound = false;
					searchdual = false;
					p = 1.0;

					for(int i = 0; i < sz-k; i++)
					{
						if(p < maxProb)
							break;
	
						localkmer = kmer[i];
						localdualkmer = dualkmer[i];
						int inkmerpos1 = pos1-i;
//						int inkmerpos2 = pos2-i;
					
						if(0 <= inkmerpos1 && inkmerpos1 < k)
						{
							kforge.replace(localkmer, inkmerpos1, n1);
							kforge.replace(localdualkmer, k-inkmerpos1-1, dualnuc(n1));
						}

/*						if(0 <= inkmerpos2 && inkmerpos2 < k)
						{
							kforge.replace(localkmer, inkmerpos2, n2);
							kforge.replace(localdualkmer, k-inkmerpos2-1, dualnuc(n2));
						} */

						if(!kmers.fetch(smaller(localkmer, localdualkmer, searchdual), info))
						{
							kmerNotFound = true;
							break;
						}

						nuc = nucs[0][i+k];
						dnuc = nucs[1][i+k];

						if(inkmerpos1 == k)
						{
							nuc = n1;
							dnuc = dualnuc(n1);
						}
/*						if(inkmerpos2 == k)
						{
							nuc = n2;
							dnuc = dualnuc(n2);
						} */
	
						p *= NORMAL((searchdual) ? info.inedgesprob[dnuc] : info.outedgesprob[nuc]) / NORMAL(info.prob);

						if(i == 0)
							p *= NORMAL(info.prob);
					}

						
					if(!kmerNotFound)
						localmax = p;

					if(localmax > maxProb)
					{
						maxProb = localmax;
						bestpos1 = pos1;
						bestn1 = n1;
//						bestpos2 = pos2;
//						bestn2 = n2;
					}
				}

			}	
		
#pragma omp atomic
			counts[min((int)(maxProb*1000), 1000)]++;


#pragma omp critical
			if(maxProb >= 0.0)
			{
				if(bestpos1 >= 0)
					read[bestpos1] = bestn1;
/*				if(bestpos2 >= 0)
					read[bestpos2] = bestn2;*/
				read.print(output);
				output.flush();
			}
#pragma omp atomic
			current++;

			if(!(current % 10000))
			{
				cout << "Done with " << current << " reads." << endl; 
				cout.flush();
			}
			
			for(int i = 0; i < 2; i++)
				free(nucs[i]);
			delete kmer; 
			delete dualkmer;
		}
	}

	reads.finalize();
	output.close();

	cout << "Finished correcting reads." << endl;

	time(&now);
	printf("%s\n", ctime(&now));
	
	ofstream countsout;
	countsout.open((outputName+".counts").c_str(), ios::out);

	for(int i = 0; i <= 1000; i++)
		countsout <<  counts[i]*1.0/current << endl;

	countsout.close();
	return 0;
}
