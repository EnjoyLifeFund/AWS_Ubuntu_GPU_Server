/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          squeezambler.C 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <iostream>


#include "logger.h"
#include "common.h"
#include "getopt.h"
#include "importer.h"
#include "unitigger.C"
#include "finisher.h"

#define FILE_STRING (char *)"squeezambler"
#define FILE_VERSION (char *)"Squeezambler 1.1.0"
#define MAXFILECHAR	2000
using namespace std;

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output files prefix (default sqzout)"),
	Option('g', (char *)"groups", NEEDS_ARG, (char *)"=the number of division groups (default 2)"),
	Option('b', (char *)"nucs", NEEDS_ARG, (char *)"=number of sampled nucleotides per cell in the first iteration (default 5,000,000nt)"),
	Option('c', (char *)"genomecoverage", NEEDS_ARG, (char *)"=estimated coverage of each distinct genome in each iteration (default 15)"),
	Option('t', (char *)"inclusionthreshold", NEEDS_ARG, (char *)"=tau, the cutoff for the individual assembly size / total assembly size ratio to detect assembly inclusion (default 0.2)"),
	Option('e', (char *)"inclusionexception", NEEDS_ARG, (char *)"=minimum individual assembly size to override tau-based inclusion (default 500,000nt)\n\t\tif the individual assembly size is minimum e, then no matter what the result of D_tau, the inclusion does not hold."),
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer (default 55) [ASSEMBLY RELATED]"),
	Option('f', (char *)"covcutoff", NEEDS_ARG, (char *)"=minimum average coverage of a condensed node as a multiple of mean coverage in the first condensation (default 1.0) [ASSEMBLY RELATED]"),
	Option('l', (char *)"lowcovlen", NEEDS_ARG, (char *)"=maximum length of a low average coverage condensed node to be removed (default 1000nt) [ASSEMBLY RELATED]"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads per processing node (default 1) [ASSEMBLY RELATED]"),
	Option(1, (char *)"mincontiglen", NEEDS_ARG, (char *)"=minimum length of an output contig (default 100) [ASSEMBLY RELATED]"),
	Option(0, NULL, 0, NULL)
};

Logger *logger;
int procs = 1;
int k = 55;
size_t nucsList[MAXLIBRARIES];
size_t nucs = 5000000;
double averageCoverage = 15.0;
AvgCoverage covThresh = 1.0;
int lowCovLenThresh = 1000;
int minContigLength = 100;
double relationshipCutoff;
double relationshipCutoffMain = 0.20;

int sequencingLaneNums = 0;
int assemblyLaneNums = 0;
size_t sequencingBasesNums = 0;
int initialColorNum = 2;
int base_lib = 0;

vector<Library<string> > inputLibNames;
string inputFilename, outputName = "sqzout", logFilename;
struct ColorsList{
	Color	colors[MAXLIBRARIES];
	Color	totalNumberOfColors;	
	Color	numberOfNewColors;
	Color 	base_color;	
	size_t colorsPopulation[MAXLIBRARIES];
} colorsList;

uint8_t isSequenced[MAXLIBRARIES]; 
//isSequenced[i]= 1 --> some other cell similar to this one is going to be sequenced; 
//		= 2 --> has been sequenced; 
//		= 0 --> has not been sequenced yet
vector<ContigMetadata> contigMetadataList;
Coordinate commonAssemblySize[MAXLIBRARIES][MAXLIBRARIES];
double averageCoverageList[MAXLIBRARIES];
bool colorsRelationships[MAXLIBRARIES][MAXLIBRARIES];
Coordinate relationshipCutoffNucsNo; 
Coordinate relationshipCutoffNucsNoMain = 500000; 
bool specificColors[MAXCOLORS];

void loadSetupFile(string setupFilename)
{
	FILE *inp = open_file(setupFilename, "rt");
	logger->out() << "Input files list:" << endl;
	int counter = 0;
	while (!feof(inp))
	{
		char fileformat;
		char fileNameChar[MAXFILECHAR];
		fscanf(inp, ">%c\t%s\n", &fileformat, fileNameChar);
		string fileName(fileNameChar);
		logger->out() << (int) counter << ") " << fileName;

		Library<string>	libName;
		if (fileformat == 'f')
		{	
			libName.fasta = true;
			logger->out() << "\t fasta" << endl;
		}
		else	if (fileformat == 'q')
		{
			libName.fasta = false;
			logger->out() << "\t fastq" << endl;
		}
		else
		{
			logger->out() << "\tInput file format error. Format should be either fasta (f) or fastq (q)." << endl;
			exitMsg(NULL, INPUT_ARG_ERROR);
		}
		libName.files.push_back(fileName);
		inputLibNames.push_back(libName);
		counter ++;
	}
	if (inputLibNames.size() > MAXLIBRARIES)
	{
		logger->out() << "The number of input files is more than MAXLIBRARIES. Increase MAXLIBRARIES and run the program again." << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}
	if (inp)
		fclose(inp);
}

void divideColor(Color colorTag, int newbase_lib, Color newColorTag)
{
	int counter = 0;
	int halfNumber = colorsList.colorsPopulation[colorTag] / 2;
	logger->out() << "newColorTag = " << (int) newColorTag << endl;
	logger->out() << "halfNumber = "  << (int) halfNumber << endl;
	logger->out() << "newbase_lib = " << (int) newbase_lib << endl;
	for (int i = newbase_lib; i < newbase_lib + inputLibNames.size(); i++)
	{
		if (colorsList.colors[i] == colorTag)
		{
			logger->out() <<  "Color of lib [" << i << "] is " << (int) colorTag << endl; 
			counter ++;
			if (counter > halfNumber)
			{
				colorsList.colors[i]  = newColorTag;
				logger->out() <<  "Changing color of lib [" << i << "] from " << (int) colorTag << " to " << (int) newColorTag << endl; 
			}
		}
	}	
	colorsList.numberOfNewColors ++;
	colorsList.colorsPopulation[newColorTag] = colorsList.colorsPopulation[colorTag] - halfNumber;
	colorsList.colorsPopulation[colorTag] =  halfNumber;
}

void removeColor(Color colorTag, int newbase_lib)
{
	int counter = 0;
	for (int i = newbase_lib; i < newbase_lib + inputLibNames.size(); i++)
		if (colorsList.colors[i] == colorTag)
		{
			colorsList.colors[i] = -1;
			counter++;
		}
	colorsList.colorsPopulation[colorTag] = 0;
	if (counter == 0)
	{
		logger->out() << "Color " << (int) colorTag << " has already been removed." << endl;
	}
}

void writeColors()
{
	logger->out() << "COLORS: [number of cells: color (isSequenced)]" << endl;

	for(int i = 0; i < base_lib + inputLibNames.size(); i++)
		logger->out() << i <<": " << (int) colorsList.colors[i] <<" (" << (int) isSequenced[i % inputLibNames.size()] << ") \t";		

	logger->out() << "\nTotal number of colors = " << (int) colorsList.totalNumberOfColors << endl; 
	logger->out() << "Population of old colors is: " << endl;
	for (Color i = 0; i < colorsList.base_color; i++)
		logger->out() << (int) i << ": " << (int) colorsList.colorsPopulation[i] << "\t";
	logger->out() << endl;
	logger->out() << "\nTotal number of new colors = " << (int) colorsList.numberOfNewColors << endl; 
	logger->out() << "Population of new colors is: " << endl;
	for (Color i = colorsList.base_color; i < colorsList.base_color + colorsList.numberOfNewColors; i++)
		logger->out() << (int) i << ": " << (int) colorsList.colorsPopulation[i] << "\t";
	logger->out() << endl;
	logger->out() << "Total number of sequencing lanes so far is "<< (int) sequencingLaneNums << endl; 
	logger->out() << "Total number of assembly lanes so far is "<< (int) assemblyLaneNums << endl; 
	logger->out() << "Total number of sequencing bases so far is "<< (int) sequencingBasesNums << " k" << endl; 

}

void initializeColorsList()
{
	int inputLibIndex = 0;
	size_t maxPopulation = 0;
	base_lib = 0;
	colorsList.base_color = 0;
	for (Color j = 0; j < initialColorNum; j++)
	{
		colorsList.colorsPopulation[j] = 0;
		size_t population = (int) (inputLibNames.size() - inputLibIndex) / (int) (initialColorNum - j );
		for(int i = 0; (i < population) & (inputLibIndex < inputLibNames.size()); i++)
		{
			colorsList.colorsPopulation[j] ++;
			colorsList.colors[inputLibIndex] = j;
			if (nucs > 0)
				nucsList[inputLibIndex] = nucs;
			isSequenced[inputLibIndex] = 0;
			inputLibIndex ++;
		}
		if (colorsList.colorsPopulation[j] > maxPopulation)
			maxPopulation = colorsList.colorsPopulation[j];
	}
	if (inputLibIndex < inputLibNames.size())
		logger->out() << "Error in  initializeColorsList(): inputLibIndex < inputLibNames.size(), i.e.,"<< (int) inputLibIndex << " < " << (int) inputLibNames.size() << endl; 
	for(int i = inputLibIndex; i < MAXLIBRARIES; i++)
	{	
		colorsList.colors[i] = -1;
		if (nucs > 0)
			nucsList[i] = 0;
		isSequenced[i] = 0;
	}
	colorsList.numberOfNewColors = initialColorNum; 
	colorsList.totalNumberOfColors = initialColorNum; 
	relationshipCutoff = relationshipCutoffMain / maxPopulation;
	relationshipCutoffNucsNo = relationshipCutoffNucsNoMain;
	writeColors();
}

void assignNucsList(size_t nucs)
{ 
	size_t basesNum = 0;
	for(int i = 0; i < inputLibNames.size(); i++)
		if (nucs > 0)
			if (colorsList.colors[i + base_lib] > -1)
			{
				nucsList[i] = nucs;
				basesNum = basesNum + nucsList[i];
			}			
			else 
				nucsList[i] = 0;
		
	for(int i = inputLibNames.size(); i < MAXLIBRARIES; i++)
		if (nucs > 0)
			nucsList[i] = 0;
	basesNum = basesNum / 1000;
	sequencingBasesNums = sequencingBasesNums + basesNum;
}

Coordinate estimateNewAssemSize(double oldAverageCoverage, Coordinate oldAssemblySize)
{
	Coordinate assemTemp;
	double assemRatio = 0;
	if (oldAverageCoverage > 20)
	{
		assemRatio = 1;
	} else if (oldAverageCoverage > 15)
	{
		assemRatio = 1.2 * 0.001/5.0 * (oldAverageCoverage - 15) + 0.99; //(1 - 0.99)/(20 - 15)(ac - 15) + 0.99
	}else if (oldAverageCoverage > 10)
	{
		assemRatio = 1.2 * 0.11/5.0 * (oldAverageCoverage - 10) + 0.88; //(0.99 - 0.88)/(15 - 10)(ac - 10) + 0.88
	}else if (oldAverageCoverage > 5)
 	{
		assemRatio = 1.2 * 0.63/5.0 * (oldAverageCoverage - 5) + 0.25; //(0.88 - 0.25)/(10 - 5)(ac - 5) + 0.25
	}else if (oldAverageCoverage > 1)
 	{
		assemRatio = 1.2 * 0.20/4.0 * (oldAverageCoverage - 1) + 0.05; //(0.25 - 0.05)/(5 - 1)(ac - 1) + 0.05
	}else if (oldAverageCoverage > 0)
	{
		assemRatio = 1.2 * 0.05/1.0 * (oldAverageCoverage - 0.0) + 0.0; //(0.05 - 0.0)/(1 - 0)(ac - 0.0) + 0.0
 	}
	assemTemp = (Coordinate) (oldAssemblySize / assemRatio);
	return assemTemp;
}

void assignNucsListCov(double newAverageCoverage, Color oldbase_color, int oldbase_lib)
{ 
	size_t basesNum = 0;
	logger->out() << "averageCoverage = " << (double) averageCoverage << endl << " oldbase_color = " << (int) oldbase_color <<" oldbase_lib = " <<(int) oldbase_lib << endl;
	logger->out() << "Library number (old color - new color): NucsList " << endl;
	for(int i = 0; i < inputLibNames.size(); i++)
		if (nucs > 0)
		{
			Color colorNum, oldColorNum;
			if (colorsList.colors[i + base_lib] > -1)
			{
				colorNum = colorsList.colors[i + base_lib];
				oldColorNum = colorsList.colors[i + oldbase_lib];
				Coordinate oldAssemblySize = commonAssemblySize[oldColorNum - oldbase_color][oldColorNum - oldbase_color];
				double oldAverageCoverage = averageCoverageList[oldColorNum - oldbase_color];
				Coordinate newAssemblySize = estimateNewAssemSize(oldAverageCoverage, oldAssemblySize);
				size_t nucsNum = nucsList[i] * ((double) colorsList.colorsPopulation[oldColorNum]  / (double) colorsList.colorsPopulation[colorNum]) * ( (double) newAssemblySize / (double) oldAssemblySize) * ( (double) newAverageCoverage / (double) oldAverageCoverage);
				nucsList[i] = nucsNum;
				basesNum = basesNum + nucsList[i];
			}			
			else 
				nucsList[i] = 0;
			logger->out() << (int) i << "(" << (int) oldColorNum << " - " << (int)  colorNum << "): " << (int) nucsList[i] << "\t"; 
		};
	logger->out() << endl;
	for(int i = inputLibNames.size(); i < MAXLIBRARIES; i++)
		if (nucs > 0)
			nucsList[i] = 0;
	basesNum = basesNum / 1000;
	sequencingBasesNums = sequencingBasesNums + basesNum;
}


void writeAssemblySize(Coordinate commonAssemblySize[MAXLIBRARIES][MAXLIBRARIES])
{
	logger->out() << "Statistics: " << endl;
	logger->out() << "\t \t";

	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
		logger->out() << (int) i + colorsList.base_color << "\t \t";
	logger->out() << "\n";

	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
	{
		logger->out() << (int) i + colorsList.base_color <<": \t";
		for (Color j = 0; j < colorsList.numberOfNewColors; j++)
			logger->out() << commonAssemblySize[i][j] << " (" << (double)(commonAssemblySize[i][i] - commonAssemblySize[i][j]) / (double)commonAssemblySize[i][i] << ")\t";
		logger->out() << endl;		
	}
	logger->out() << "Average Coverage: " << endl;

	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
	{
		logger->out() << (int) i + colorsList.base_color <<": \t" << averageCoverageList[i] << endl;
	}
}

void writeRelationships(bool colorsRelationships[MAXLIBRARIES][MAXLIBRARIES])
{
	logger->out() << "Inclusion: " << endl;
	logger->out() << "Inclusion ratio threshold (tau) = " << relationshipCutoff << endl;
	logger->out() << "Inclusion exception nucs threshold = " << relationshipCutoffNucsNo << endl;

	logger->out() << "\t ";

	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
		logger->out() << i + colorsList.base_color << "\t ";
	logger->out() << "\n";

	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
	{
		logger->out() << i + colorsList.base_color <<": \t";
		for (Color j = 0; j < colorsList.numberOfNewColors; j++)
		{
			if (colorsRelationships[i][j])
				logger->out() << "n \t";
			else	
				logger->out() << "s \t";
		}
		logger->out() << endl;		
	}
	
}
void extractStatictis()
{
	for (int i = 0; i < colorsList.numberOfNewColors; i++)
	{
		averageCoverageList[i] = 0;
		for (int j = 0; j < colorsList.numberOfNewColors; j++)
			commonAssemblySize[i][j] = 0;
	};
	
	for (int i = 0; i < contigMetadataList.size(); i++)
	{
		for (Color j = 0; j < colorsList.numberOfNewColors; j++)
		{
			if (contigMetadataList[i].coverages[j + colorsList.base_color] > 1.0) 
			{
				commonAssemblySize[j][j] += contigMetadataList[i].length;
				averageCoverageList[j] += contigMetadataList[i].coverages[j + colorsList.base_color] * contigMetadataList[i].length;
				for (Color l = j + 1; l < colorsList.numberOfNewColors; l++)
				{
					if (contigMetadataList[i].coverages[l + colorsList.base_color] > 1.0) 
					{
						commonAssemblySize[j][l] += contigMetadataList[i].length;
						commonAssemblySize[l][j] += contigMetadataList[i].length;
					};
				};
			};
		};
	};
	for (int j = 0; j < colorsList.numberOfNewColors; j++)
	{
		averageCoverageList[j] = averageCoverageList[j] / (double) commonAssemblySize[j][j];
	}
	writeAssemblySize(commonAssemblySize);
};

void	decideRelationships(double relationshipCutoff)
{
	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
	{
		colorsRelationships[i][i] = 0;
		for (Color j = i; j < colorsList.numberOfNewColors; j++)
		{
			double ratio = (double)(commonAssemblySize[i][i] - commonAssemblySize[i][j]) / (double)commonAssemblySize[i][i];
			Coordinate individualSize = commonAssemblySize[i][i] - commonAssemblySize[i][j]; 
			if ((ratio < relationshipCutoff) & (individualSize < relationshipCutoffNucsNo))
				colorsRelationships[i][j] = 0;
			else
				colorsRelationships[i][j] = 1;
			ratio = (double)(commonAssemblySize[j][j] - commonAssemblySize[j][i]) / (double)commonAssemblySize[j][j];
			individualSize = commonAssemblySize[j][j] - commonAssemblySize[j][i]; 
			if ((ratio < relationshipCutoff) & (individualSize < relationshipCutoffNucsNo))
				colorsRelationships[j][i] = 0;
			else
				colorsRelationships[j][i] = 1;		
		}
	}
	writeRelationships(colorsRelationships);
}

bool allSequenced()
{
	bool result = true; //all terms of isSequenced are -1 or 1
	for (int i = 0; i < inputLibNames.size(); i++)
	{
		if (isSequenced[i] == 0)
		{
			result = false;
		}
	}
	return result;
}

void writeFinishedSpecies()
{
	int counter = 0;
	logger->out() << "The following cells are sequenced and assembled:" << endl;
	for (int i = 0; i < inputLibNames.size(); i++)
	{
		if (isSequenced[i] == 2 )
		{
			logger->out() << (int) counter <<" - cell number " << (int) i << " - " << inputLibNames[i].files[0] << endl; 
			logger->out() << "\t\t from color " << (int) colorsList.colors[i + base_lib];
			if (colorsList.colors[i + base_lib] > -1)
			{
				Color color_tmp = colorsList.colors[i + base_lib] - colorsList.base_color;
				logger->out() << " -- NEW SPECIES -- assembly size = " << (int) commonAssemblySize[color_tmp][color_tmp];
				logger->out() <<" -- contig file: " << outputName << ".color" << (int) colorsList.colors[i + base_lib] <<".contigs" << endl;
				specificColors[colorsList.colors[i + base_lib]] = true;
				counter ++;
			}
			else
				logger->out() << endl;
		}
	}
	logger->out() << "Total number of sequenced speices is "<< (int) counter << endl; 
	logger->out() << "Total number of sequencing lanes is "<< (int) sequencingLaneNums << endl; 
	logger->out() << "Total number of assembly lanes is "<< (int) assemblyLaneNums << endl; 
	logger->out() << "Total number of sequencing bases is "<< (int) sequencingBasesNums << " k" << endl; 


}
void updateColors()
{
	for (int i = 0; i < inputLibNames.size(); i++)
	{
		if (colorsList.colors[i + base_lib] == -1)
			isSequenced[i] = 1;
		else if (colorsList.colorsPopulation[colorsList.colors[i + base_lib]] == 1)
			isSequenced[i] = 2;
		else
			isSequenced[i] = 0;
	}
	sequencingLaneNums = sequencingLaneNums + colorsList.numberOfNewColors;
	Color newbase_color, oldbase_color;
	int newbase_lib, oldbase_lib;
	bool allSequencedL = allSequenced();
	if (allSequencedL)
	{
		newbase_color = colorsList.base_color;
		newbase_lib = base_lib;
	}
	else
	{
		newbase_color = colorsList.base_color + colorsList.numberOfNewColors;
		newbase_lib = base_lib + inputLibNames.size();
		logger->out() <<"newbase_color = " << (int) newbase_color << endl;
		logger->out() <<"newbase_lib = " << (int) newbase_lib << endl;
		for (int i = 0; i < inputLibNames.size(); i++)
		{
			if (colorsList.colors[i + base_lib] > -1)
				colorsList.colors[i + newbase_lib] = colorsList.colors[i + base_lib] + (newbase_color - colorsList.base_color);		
			else
				colorsList.colors[i + newbase_lib] = -1;
		}
		for (Color i = 0; i < colorsList.numberOfNewColors; i++)
			colorsList.colorsPopulation[i + newbase_color] = colorsList.colorsPopulation[i + colorsList.base_color];
	}
	for (Color i = 0; i < colorsList.numberOfNewColors; i++)
	{
		for (Color j = i + 1; j < colorsList.numberOfNewColors; j++)
		{
			if (colorsRelationships[i][j] == 0)
			{
				removeColor(i + newbase_color, newbase_lib);
				break;
			}
			else if (colorsRelationships[j][i] == 0)
			{
				removeColor(j + newbase_color, newbase_lib);
				break;
			}
		}
	}
	if (!(allSequencedL))
	{
		Color numberOfOldColors = colorsList.numberOfNewColors;

		for (Color i = newbase_color; i < newbase_color + numberOfOldColors; i++)
			if (colorsList.colorsPopulation[i] > 1)
			{
				divideColor(i, newbase_lib, newbase_color + colorsList.numberOfNewColors);
			}
		ColorsList newColorsList = colorsList;
		newColorsList.numberOfNewColors = 0;
		newColorsList.base_color = newbase_color;
		for (int i = newbase_lib; i < newbase_lib + inputLibNames.size(); i++)
		{
			if (colorsList.colors[i] == -1) 
				newColorsList.colors[i] = colorsList.colors[i];
			else if	(colorsList.colors[i] > -1) 
			{
				Color colorTag = colorsList.colors[i];
				Color newColorTag = newbase_color + newColorsList.numberOfNewColors;
				newColorsList.numberOfNewColors ++;
				newColorsList.colorsPopulation[newColorTag] = 0;
				for (int j = i; j < newbase_lib + inputLibNames.size(); j++)
					if (colorsList.colors[j] == colorTag)
					{
						colorsList.colors[j] = -2;
						newColorsList.colors[j] = newColorTag;
						newColorsList.colorsPopulation[newColorTag] ++;
					}
			}
		}
		newColorsList.totalNumberOfColors = newColorsList.totalNumberOfColors + newColorsList.numberOfNewColors;	
		oldbase_color = colorsList.base_color;		
		colorsList = newColorsList;
		oldbase_lib = base_lib;
		base_lib = newbase_lib;
		colorsList.base_color = newbase_color;
		assignNucsListCov(averageCoverage, oldbase_color, oldbase_lib);
		size_t maxPopulation = 0;
		for (int i = colorsList.base_color; i < colorsList.base_color + colorsList.numberOfNewColors; i++)
			if (colorsList.colorsPopulation[i] > maxPopulation)
				maxPopulation = colorsList.colorsPopulation[i];

		relationshipCutoff = relationshipCutoffMain / maxPopulation;
	}
	writeColors();
}
 
void divideAndConquer()
{
	string outputFilename = outputName+".fasta";
	string outputUnitigsName = outputName+".unitigs";
	string outputContigsName = outputName+".contigs";
	bool done = false;
	
	logger->out() << "Loading setup file"<< endl;
	loadSetupFile(inputFilename);

	logger->out() << "Importing" << endl;
	Importer importer(logger, inputLibNames, outputFilename);
	// initialize color list
	initializeColorsList();
	importer.openOutput(false);
	importer.closeOutput();
	for (int i = 0; i < MAXCOLORS; i++)
	{
		specificColors[i] = false;
	} 
	logger->out() << "nucs = " << nucs << endl;
	assignNucsList(nucs); 

	while (!done)
	{
		assemblyLaneNums ++;
		logger->setSection("NEW LEVEL");
		logger->out() << "LEVEL "<< assemblyLaneNums << endl;
		logger->out() << "Importing a set of data" << endl;
		importer.openOutput(true);
		importer.import(nucsList, base_lib);
		importer.closeOutput();
		logger->out() << "Creating unitigs" << endl;
		Unitigger<CompactNodeInfo> unitigger(outputFilename, outputName, colorsList.colors, 1, 0, true, procs, true, k, false, NULL, logger);
		logger->out() << "Creating contigs" << endl;
		Finisher finisher(outputFilename, outputUnitigsName, "", outputName, "", "", true, procs, -1, covThresh, 0, lowCovLenThresh, minContigLength, true, false, false, false, false, specificColors, 1.0, false, logger);
		logger->out() << "Assembly finished" << endl;
		contigMetadataList = finisher.metadata();
		extractStatictis();
		decideRelationships(relationshipCutoff);
		updateColors(); 
		if (allSequenced())
			done = true;
		
	}
	writeFinishedSpecies();
	Finisher finisher(outputFilename, outputUnitigsName, "", outputName, "", "", true, procs, -1, covThresh, 0, lowCovLenThresh, minContigLength, true, false, false, false, false, specificColors, 1.0, false, logger);
	logger->out() << "Assembly finished" << endl;
}



int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_VERSION);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] input-setup-file\n");
			printf("input-setup-file format:\n");
			printf("       Each TAB separated line of input setup file is either\n");
			printf("       >f\tFASTAFilename\n");
			printf("       or\n");
			printf("       >q\tFASTQFilename\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
      		else if (count == 1)
			minContigLength = atoi(current->getArg());
		else if (count == 'O')
			outputName = current->getArg();
		else if (count == 'k')
			k = atoi(current->getArg());
		else if (count == 'g')
			initialColorNum = atoi(current->getArg());
		else if (count == 't')
			relationshipCutoffMain = atof(current->getArg());
		else if (count == 'e')
			relationshipCutoffNucsNoMain = atoi(current->getArg());
		else if (count == 'b')
			nucs = atol(current->getArg());
		else if (count == 'c')
			averageCoverage = atof(current->getArg());
		else if (count == 'p')
			procs = atoi(current->getArg());
      		else if (count == 'f')
			covThresh = atof(current->getArg());
      		else if (count == 'l')
			lowCovLenThresh = atoi(current->getArg());
	}

	if(!files || k == 0 || nucs == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	if(outputName == "")
	{
		fputs("Error: output name not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, OUTPUT_ARG_ERROR);
	}

	if(k % 2 == 0)
	{
		k++;
		cerr << "k should be odd, therefore we use k=" << k << " instead." << endl;
	}

	string executedcommand; 
	for(int i = 0; i < argc; i++)
	{
		executedcommand += argv[i];
		executedcommand += " ";
	}
	executedcommand += "\n";
	
	logFilename = outputName+".log";
	logger = new Logger(logFilename);

	cout << "Logging in " << logFilename << " file. Follow the status of the program there." << endl;
	cout.flush();

	time_t now;
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " has been executed on " + string(ctime(&now)));
	logger->out() << executedcommand << endl;

	logger->setSection("Divide and conquer");
	divideAndConquer();
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " successfully concluded on " + string(ctime(&now)));

	delete logger;

	return NO_ERROR;
}
