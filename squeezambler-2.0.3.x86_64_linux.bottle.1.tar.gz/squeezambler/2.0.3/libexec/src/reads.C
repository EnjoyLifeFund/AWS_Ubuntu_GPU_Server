/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          reads.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  02/05/2013
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <stdlib.h>
#include <algorithm>
#include "reads.h"

#define MAXFILENAMELENGTH 100000

struct compareIDs {
	bool operator() (Read & i, Read & j) const { return (i.getID().id < j.getID().id); }; 
} comparator;

Reads::Reads()
{
	reads = NULL;
	num = 0;
	inputReads = NULL;
}

Reads::~Reads()
{
	if(reads) delete[] reads;
}

void Reads::resize(size_t n)
{
	if(reads) delete[] reads;
	reads = new Read[num = n];
}

void Reads::sort()
{
	make_heap(reads, reads+num);
	sort_heap(reads, reads+num);
}

void Reads::sortbyID()
{
	make_heap(reads, reads+num, comparator);
	sort_heap(reads, reads+num, comparator);
}

Read *Reads::find(ID &id)
{
	size_t begin = 0, end = num;
	size_t middle;

	while(begin < end)
	{
		middle = (begin + end) / 2;
		if(reads[middle].getID().id < id.id)
			begin = middle+1;
		else if(reads[middle].getID().id > id.id)
			end = middle;
		else return &reads[middle];
	}
	return NULL;
}

void Reads::print(FILE *out)
{
	for(size_t i = 0; i < num; i++)
		reads[i].print(out);	
}

void Reads::import(string inputFilename, bool fasta, unsigned int trimb, unsigned int trime, bool includeDual, bool leastOfPrimDual)
{
	char fname[MAXFILENAMELENGTH];
	strncpy(fname, inputFilename.c_str(), MAXFILENAMELENGTH);
	import(fname, fasta, trimb, trime, includeDual, leastOfPrimDual);
}

void Reads::import(char *inputFilename, bool _fasta, unsigned int trimb, unsigned int trime, bool includeDual, bool leastOfPrimDual)
{
	int state = 0;

	while(state < 2)
	{
		initialize(inputFilename, _fasta);

		Read r[2];
		Read *buf = (state == 1) ? reads : r;
		while(next(buf, trimb, trime, includeDual && (state == 1), leastOfPrimDual))
		{
			if(state == 1)
			{
				if(includeDual && !leastOfPrimDual)
					buf += 2;
				else
					buf++;
			}
		}

		if(state == 0)
			resize((includeDual && !leastOfPrimDual) ? readindex*2 : readindex);
		else
			printf("Read %ld reads...\n", (includeDual && !leastOfPrimDual) ? readindex / 2 : readindex);

		state++;
	}
}

void Reads::initialize(string inputFilename, bool _fasta)
{
	char fname[MAXFILENAMELENGTH];
	strncpy(fname, inputFilename.c_str(), MAXFILENAMELENGTH);
	initialize(fname, _fasta);
}

void Reads::initialize(char *inputFilename, bool _fasta)
{
	fasta = _fasta;
	filename = inputFilename;
	readindex = 0;

	if(fasta)
		inputReads = open_file(inputFilename, "rt");
	else
	{
		input = new ifstream();
		input->open(inputFilename, ios::in);
	}
}

bool Reads::next(Read *r, unsigned int trimb, unsigned int trime, bool includeDual, bool leastOfPrimDual)
{
	if(fasta)
	{
		if(!inputReads) return false;

		Sequence motherseq(inputReads);
		if(trimb + trime != 0)
			motherseq.subsequence(trimb, motherseq.getLen() - trimb - trime);
		if(motherseq.isLoaded())
		{
			r[0].load(motherseq.getString());
			r[0].setID(motherseq.getName());
			if(includeDual)
			{
				if(!leastOfPrimDual)
				{
					r[1].load(motherseq.getString(), true);
					r[1].setID(motherseq.getName(), true);
				} else
				{
					Read temp;
					temp.load(motherseq.getString(), true);
					temp.setID(motherseq.getName(), true);
					if(temp < r[0])
						r[0] = temp;
				}
			}
		} else
			return false;

		if(includeDual && !leastOfPrimDual)
			readindex += 2;
		else
			readindex++;

		return true;
	}
	else
	{
		string line, name;
		bool chosedual = false;
		
		if(!(*input)) return false;
	
		getline(*input, name);
		if (name.size() == 0)
			return false;
		
		getline(*input, line);
		line = line.substr(trimb, line.size()-trimb-trime);
		name = name.substr(1, name.size()-1);	
		r[0].load(line);
		r[0].setID(name);
		if(includeDual)
		{						
			if(!leastOfPrimDual)
			{
				r[1].load(line, true);
				r[1].setID(name, true);
			} else
			{
				Read temp;
				temp.load(line, true);
				temp.setID(name, true);
				if(temp < r[0])
				{
					r[0] = temp;
					chosedual = true;
				}
			}
		}
		if(includeDual && !leastOfPrimDual)
			readindex += 2;
		else
			readindex++;

		getline(*input, line);
		getline(*input, line);
		line = line.substr(trimb, line.size()-trimb-trime);
		r[0].loadqual(line, chosedual);
		if(includeDual && !leastOfPrimDual)
			r[1].loadqual(line, !chosedual);
	
		return true;
	} 
}

void Reads::finalize()
{
	if(fasta)
	{
		if(inputReads) fclose(inputReads);
		inputReads = NULL;
	} else
		delete input;
}





