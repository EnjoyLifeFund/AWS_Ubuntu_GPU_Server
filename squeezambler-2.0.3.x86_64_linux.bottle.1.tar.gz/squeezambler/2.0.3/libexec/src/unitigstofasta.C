/*
Copyright 2012- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          unitigstofasta.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2012
 * Last modified:  04/14/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <stdlib.h>

#include "unitig.h"
#include "sequence.h"
#include "getopt.h"

using namespace std;

#define FILE_STRING (char *)"unitigstofasta"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output file (mandatory)"),
	Option('U', (char *)"unitigs", NEEDS_ARG, (char *)"=unitigs file (mandatory)"),
//	Option('r', (char *)"reverse", NO_ARG, (char *)"convert fasta to unitigs"),
	Option(0, NULL, 0, NULL)
};


int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);

	string outputFilename, unitigsFilename;
	Serial unitigsNum;
	int k;
	bool reverse = false;
	
	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
			cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options]\n");
			printf("       Output file is identified by -O option.\n");
			printf("       Input unitigs file is identified by -U option.\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
		else if (count == 'O')
			outputFilename = current->getArg();
		else if (count == 'U')
			unitigsFilename = current->getArg();
//		else if (count == 'r')
//			reverse = true;
// fix Unitig::scan first then activate this option
	}

	if(reverse)
	{
/*		FILE *unitigs = open_file(unitigsFilename, (const char *)"rt");
		FILE *output = open_file(outputFilename, (const char *)"wb");

		size_t kmersNum[LOW_COV_DISCRIMINANT];
		for(int i = 0; i < LOW_COV_DISCRIMINANT; i++)
			kmersNum[i] = 0;

		bool first = true;

		bool more_seq = true;
		while(more_seq)
		{
			Sequence *seq = new Sequence(unitigs);
			if(seq->isLoaded())
			{
				Distance l;
				int thisk;
				Coverage kmercount;
				int edges;
				Serial number;

				Unitig unitig;

				unitig.scan(seq->getName(), seq->getString(), &number, &thisk);


				if(first)
				{
					k = thisk;
					first = false;
				}
				else if(k != thisk)
				{
					cerr << seq->getName() << endl;
					cerr << "k = " << k << " whereas this k = " << thisk << endl;
					exitMsg((char*)"Error: unitigs file is corrupted: inconsistent k throughout the file.", UNITIGS_FILE_ERROR);
				}
			
				unitig.save(output);

				int pntr = LOW_COV_DISCRIMINANT-1;
				for(int i = 0; i < LOW_COV_DISCRIMINANT-1; i++)
				{
					if(unitig.coverage < (i+2)*(unitig.length()-k+1))
					{
						pntr = i;
						break;
					}
				}

				if(unitig.length() == k)
					kmersNum[pntr]++;
				else
					kmersNum[pntr] += 2;

				unitigsNum++;

				delete seq;
			}
			else
				more_seq = false;
		}

		write_in_file(kmersNum, sizeof(size_t), LOW_COV_DISCRIMINANT, output); 
		write_in_file(&unitigsNum, sizeof(Serial), 1, output); 
		write_in_file(&k, sizeof(int), 1, output); 

		fclose(unitigs);
		fclose(output); */
	}
	else
	{
		FILE *unitigs = open_file(unitigsFilename, (const char *)"rb");
		ofstream output;
		output.open(outputFilename.c_str());
		if(!output.good())
			exitMsg((char*)"Error: cannot open output file.", FILE_OPEN_ERROR);

		fseek(unitigs, -(long int)(sizeof(Serial)+sizeof(int)), SEEK_END);

		read_from_file(&unitigsNum, sizeof(Serial), 1, unitigs); 
		read_from_file(&k, sizeof(int), 1, unitigs); 

		rewind(unitigs);

		for(Serial number = 0; number < unitigsNum; number++)
		{
			Unitig unitig;

			unitig.load(unitigs);
			unitig.print(output, number+1, k);
		}

		fclose(unitigs);
		output.close();
	}

	return 0;
}
