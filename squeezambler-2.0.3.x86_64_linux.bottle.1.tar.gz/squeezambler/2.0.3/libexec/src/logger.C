/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          logger.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  02/26/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "logger.h"
#include <time.h>

Logger::Logger(string fname)
{
	start = clock();
	clock_gettime(CLOCK_REALTIME, &then);

	filename = fname;
	output.open(filename.c_str(), ios_base::app);
	if(!output.good())
		exitMsg((char*)"Logger error: cannot open log file.", FILE_OPEN_ERROR);
}

void Logger::doReport(string pre, string s, string post)
{
	output << pre << s << post;
	output.flush();
}

void Logger::reportTime()
{
	timespec now;
	clock_gettime(CLOCK_REALTIME, &now);

	output << "(wallc " << ((now.tv_nsec-then.tv_nsec)/1000000000.0 + now.tv_sec-then.tv_sec) << " s)";
	output << "(" << ((clock()-start)*1000)/CLOCKS_PER_SEC << " ms)";
	output.flush();
}

void Logger::report(string s)
{
	reportTime();
	doReport(" ", s, "\n");
}

