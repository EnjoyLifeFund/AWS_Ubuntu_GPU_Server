/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          errcorr.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <map>
#include <unistd.h>
#include <math.h>


#include "kmers.C"
#include "splaytree.C"
#include "getopt.h"
#include "reads.h"
#include "alloc.h"

using namespace std;

#define FILE_STRING (char *)"errcorr"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output prefix"),
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer"),
	Option('m', (char *)"maxsubs", NEEDS_ARG, (char *)"=max number of substitutions to correct a read (default 3)"),
	Option('n', (char *)"notusequality", NO_ARG, (char *)"do not use quality values"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input is in FASTQ format"),
	Option('s', (char *)"single", NO_ARG, (char *)"single strand"),
	Option('t', (char *)"thresh", NEEDS_ARG, (char *)"=error probability (derived from qualities) threshold above which a nucleotide is considered erroneous (default 0.3)"),
	Option(1, (char *)"phred33-quals", NO_ARG, (char *)"ASCII offset = 33, ASCII range 33 .. 126"),
	Option(2, (char *)"phred64-quals", NO_ARG, (char *)"ASCII offset = 64, ASCII range 64 .. 126"),
	Option(3, (char *)"solexa-quals", NO_ARG, (char *)"ASCII offset = 64, ASCII range 59 .. 126"),
	Option(0, NULL, 0, NULL)
};

enum QType {PHRED33 = 1, PHRED64 = 2, SOLEXA = 3};

struct KmerInfo {
	Probability outedgesprob[NUCS];  //A, C, G, T
	Probability inedgesprob[NUCS];  //A, C, G, T
	Probability prob;
};

bool doublestrand;
QType qtype;
bool usequality;
int procs = 8;


Kmer & smaller(Kmer & k1, Kmer & k2, bool & dual)
{
	if(!doublestrand)
	{
		dual = false;
		return k1;
	}

	if(k1 < k2)
	{
		dual = false;
		return k1;
	} else
	{
		dual = true;
		return k2;
	}
}

double perr(char qual)
{
	int q = 0;


	if(qtype == PHRED33)
		q = (int)(qual - 33);

	if(qtype == PHRED64 || qtype == SOLEXA)
		q = (int)(qual - 64);

	double ret = pow(10.0, -q/10.0);

	if(qtype == SOLEXA)
		return ret / (1.0 + ret); 
	else
		return MIN(ret, 0.99999);
}

void index(Kmers<KmerInfo, SplayTree> & kmers, Reads & reads, unsigned int k)
{
	K kforge(k);
	
	size_t current = 0;
	bool done = false;
	int jobs = (procs > 1) ? 64 * procs : 1;

	Read *read = new Read[jobs];
	bool *load = new bool[jobs];
	size_t *sizes = new size_t[jobs];
	Kmer **akmer = new Kmer*[jobs];
	Kmer **adualkmer = new Kmer*[jobs];
	Nucleotide **anucs[2];
	anucs[0] = new Nucleotide*[jobs];
	anucs[1] = new Nucleotide*[jobs];

	for(int i = 0; i < jobs; i++)
	{
		sizes[i] = 1000;
		akmer[i] = new Kmer[sizes[i]];
		adualkmer[i] = new Kmer[sizes[i]];
		anucs[0][i] = new Nucleotide[sizes[i]];
		anucs[1][i] = new Nucleotide[sizes[i]];
	}

	while(!done)
	{

		for(int jb = 0; jb < jobs; jb++)
			load[jb] = reads.next(&read[jb], 0, 0, false);

#pragma omp parallel for schedule(dynamic) num_threads(procs) 
		for(int job = 0; job < jobs; job++)
		{
			Nucleotide *nucs[2];
			Kmer *kmer, *dualkmer, localkmer, localdualkmer;
			size_t sz;

			if(load[job] && (sz = read[job].size()) > k)
			{
				if(sz > sizes[job])
				{
					sizes[job] = sz+1;
					delete akmer[job];
					akmer[job] = new Kmer[sizes[job]];
					delete adualkmer[job];
					adualkmer[job] = new Kmer[sizes[job]];
					delete anucs[0][job];
					anucs[0][job] = new Nucleotide[sizes[job]];
					delete anucs[1][job];
					anucs[1][job] = new Nucleotide[sizes[job]];
				}
	
				kmer = akmer[job];
				dualkmer = adualkmer[job];
				nucs[0] = anucs[0][job];
				nucs[1] = anucs[1][job];

				for(int i = 0; i < sz; i++)
					nucs[1][i] = dualnuc(nucs[0][i] = read[job][i]);

				for(int i = 0; i < k; i++)
				{
					kforge.push_end(kmer[0], nucs[0][i]);
					if(doublestrand)
						kforge.push_begin(dualkmer[0], nucs[1][i]);
				}
				localkmer = kmer[0];
				localdualkmer = dualkmer[0];

				for(int i = 1, idx = k; i < sz-k+1; i++, idx++)
				{
					kforge.push_end(localkmer, nucs[0][idx]);
					kmer[i] = localkmer;
					if(doublestrand)
					{
						kforge.push_begin(localdualkmer, nucs[1][idx]);
						dualkmer[i] = localdualkmer;
					}
				}
			}
		}

#pragma omp parallel for schedule(static) num_threads(procs)
		for(int prc = 0; prc < procs; prc++)
			for(int job = 0; job < jobs; job++)
			{
				Nucleotide *nucs[2];
				Kmer *kmer, *dualkmer, searchedkmer;
				KmerData<KmerInfo> pair;
				KmerData<KmerInfo> *node;
				size_t sz;
				if(load[job] && (sz = read[job].size()) > k)
				{
					kmer = akmer[job];
					dualkmer = adualkmer[job];
					nucs[0] = anucs[0][job];
					nucs[1] = anucs[1][job];


					double pcorr = 1.0;

					for(int i = 0; i < sz; i++)
					{
						pcorr *= (1 - (usequality ? perr(read[job].qual(i)) : 0.3));

						if(i > k-1)
							pcorr /= (1 - (usequality ? perr(read[job].qual(i-k)) : 0.3));

						if(i >= k-1)
						{
							bool dual;
				
							if(kmerhash(searchedkmer = smaller(kmer[i-k+1], dualkmer[i-k+1], dual)) % procs == prc)
							{
								kmers.fetch(searchedkmer, node);
								if(node)
									pair.second = node->second;
								else
								{
									pair.second.prob = 0;
									for(int i = 0; i < NUCS; i++)
										pair.second.outedgesprob[i] = pair.second.inedgesprob[i] = 0;
								}

								pair.second.prob = (Probability)(MAXPROB - (1 - pcorr)*(MAXPROB - pair.second.prob));
								if(dual)
								{
									if(i > k-1)
										pair.second.outedgesprob[nucs[1][i-k]] = (Probability)(MAXPROB - (usequality ? perr(read[job].qual(i-k)) : 0.3)*(MAXPROB - pair.second.outedgesprob[nucs[1][i-k]]));
									if(i < sz-1)
										pair.second.inedgesprob[nucs[1][i+1]] = (Probability)(MAXPROB - (usequality ? perr(read[job].qual(i+1)) : 0.3)*(MAXPROB - pair.second.inedgesprob[nucs[1][i+1]]));
								} else
								{
									if(i < sz-1)
										pair.second.outedgesprob[nucs[0][i+1]] = (Probability)(MAXPROB - (usequality ? perr(read[job].qual(i+1)) : 0.3)*(MAXPROB - pair.second.outedgesprob[nucs[0][i+1]]));
									if(i > k-1)
										pair.second.inedgesprob[nucs[0][i-k]] = (Probability)(MAXPROB - (usequality ? perr(read[job].qual(i-k)) : 0.3)*(MAXPROB - pair.second.inedgesprob[nucs[0][i-k]]));
								}

								if(node)
									node->second = pair.second;
								else
								{
									pair.first = searchedkmer;
									kmers.insert(pair);
								}
							}
						}
					}

				}
			}

		for(int job = 0; job < jobs; job++)
		{
			if(load[job])
			{
				current++;
				if(!(current % 10000))
					cout << "Distinct vertices so far: " << kmers.size() << " in " << current << " reads." << endl;
			} else
				done = true;
		}
	}

	for(int i = 0; i < jobs; i++)
	{
		delete akmer[i];
		delete adualkmer[i];
		delete anucs[0][i];
		delete anucs[1][i];
	}
	delete[] read;
	delete load;
	delete sizes;
	delete akmer;
	delete adualkmer;
	delete anucs[0];
	delete anucs[1];
}


int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;
	string inputFilename;
	string outputName;
	bool fasta = true;
	int k = 0;
	int maxsubs = 3;
	double pthresh = 0.3;
	Reads reads;
	doublestrand = true;
	qtype = PHRED33;
	usequality = true;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 1)
			qtype = PHRED33;
      		else if (count == 2)
			qtype = PHRED64;
      		else if (count == 3)
			qtype = SOLEXA;
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] reads-file\n");
			printf("       Output files prefix is identified by -O option (default reads-file).\n");
			printf("%s\n", opts.help());
			exit(0);
		}
      		else if (count == 'O')
			outputName = current->getArg();
      		else if (count == 'k')
			k = atoi(current->getArg());
      		else if (count == 'n')
			usequality = false;
      		else if (count == 'q')
			fasta = false;
      		else if (count == 'p')
			procs = atoi(current->getArg());
      		else if (count == 'm')
			maxsubs = atoi(current->getArg());
      		else if (count == 's')
			doublestrand = false;
      		else if (count == 't')
			pthresh = atof(current->getArg());
	}

	if(!files || k == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}

	if(outputName == "")
		outputName = inputFilename + ".corrected";

	time_t now;
	
	time(&now);
	printf("%s\n", ctime(&now));
	printf("Indexing %d-mers...\n", k);

	Kmers<KmerInfo, SplayTree> kmers;	
	reads.initialize(inputFilename, fasta);
	index(kmers, reads, k); 
	reads.finalize();

	cout << "Finished indexing." << endl;
	time(&now);
	printf("%s\n", ctime(&now));
	cout << "Correcting reads..." << endl;

	long int counts[1010];

	for(int i = 0; i < 1010; i++)
		counts[i] = 0; 

	K kforge(k);

	ofstream output;
	output.open((outputName+".fasta").c_str(), ios::out);

	reads.initialize(inputFilename, fasta);

	long int current = 0;
	bool done = false;
//	kmers.setThreadSafe(true);
	kmers.setContainersThreadSafe(true);

	long int jobs = 8*procs;

	Read *read = new Read[jobs];
	bool *load = new bool[jobs];
	int **bestsubs = new int*[jobs];
	Nucleotide **bestsubnucs = new Nucleotide*[jobs];
	int **asubs = new int*[jobs];
	Nucleotide **asubnucs = new Nucleotide*[jobs];
	int **aindices = new int*[jobs];
	Kmer **akmer = new Kmer*[jobs];
	Kmer **adualkmer = new Kmer*[jobs];
	Nucleotide **anucs[2];
	anucs[0] = new Nucleotide*[jobs];
	anucs[1] = new Nucleotide*[jobs];

	for(int i = 0; i < jobs; i++)
	{
		bestsubs[i] = new int[maxsubs];
		bestsubnucs[i] = new Nucleotide[maxsubs];
		asubs[i] = new int[maxsubs];
		asubnucs[i] = new Nucleotide[maxsubs];
		aindices[i] = new int[100000];
		akmer[i] = new Kmer[100000];
		adualkmer[i] = new Kmer[100000];
		anucs[0][i] = new Nucleotide[100000];
		anucs[1][i] = new Nucleotide[100000];
	}
	double *maxProb = new double[jobs];

	while(!done)
	{

		for(int prc = 0; prc < jobs; prc++)
			load[prc] = reads.next(&read[prc], 0, 0, false);

#pragma omp parallel for schedule(dynamic) num_threads(procs) 
		for(int prc = 0; prc < jobs; prc++)
		{
			Nucleotide *nucs[2];
			Nucleotide nuc, dnuc;
			Kmer *kmer, *dualkmer, searchedkmer;
			KmerInfo info;
			int *subs = asubs[prc];
			Nucleotide *subnucs = asubnucs[prc];
			for(int i = 0; i < maxsubs; i++)
				bestsubs[prc][i] = -1;

			long int sz;

			if(load[prc] && (sz = read[prc].size()) > k)
			{		
				int *indices = aindices[prc];

				int indicesNum = 0;

				nucs[0] = anucs[0][prc];
				nucs[1] = anucs[1][prc];

				for(int i = 0; i < sz; i++)
				{
					nucs[1][i] = dualnuc(nucs[0][i] = read[prc][i]);
					if(perr(read[prc].qual(i)) > pthresh)
						indices[indicesNum++] = i;
				}

				kmer = akmer[prc];
				dualkmer = adualkmer[prc];

				for(int i = 0; i < k; i++)
				{
					nuc = nucs[0][i];
					dnuc = nucs[1][i];
					kforge.push_end(kmer[0], nuc);
					kforge.push_begin(dualkmer[0], dnuc);
				}

				bool searchdual;
				bool kmerNotFound = false;
				double p = 1.0;

				for(int i = 1; i < sz-k+1; i++)
				{
					kmer[i] = kmer[i-1];
					dualkmer[i] = dualkmer[i-1];
				
					nuc = nucs[0][i+k-1];
					dnuc = nucs[1][i+k-1];

					if(!kmers.fetch(smaller(kmer[i], dualkmer[i], searchdual), info))
						exitMsg((char*)"Woooowwww\n", INTERNAL_WOW_ERROR);
				
					p *= NORMAL((searchdual) ? info.inedgesprob[dnuc] : info.outedgesprob[nuc]);
					if(i == 1)
						p *= NORMAL(info.prob);

					kforge.push_end(kmer[i], nuc);
					kforge.push_begin(dualkmer[i], dnuc);
				}


				maxProb[prc] = p;

				size_t cases = 1;
				int thismaxsubs = MIN(maxsubs, indicesNum+1);

				for(int i = 0; i < thismaxsubs-1; i++)
					cases *= NUCS*(indicesNum-i);

				size_t totalcases = NUCS*sz*cases;

				for(size_t idx = 0; idx < totalcases; idx++)
				{
					subs[0] = (idx / cases) / NUCS;
					subnucs[0] = (idx / cases) % NUCS;
					for(int i = 0; i < thismaxsubs-1; i++)
					{
						size_t base = cases / (NUCS*(indicesNum-i));
						subs[i+1] = indices[((idx % cases) / base) / NUCS];
						subnucs[i+1] = ((idx % cases) / base) % NUCS;
					}  

					Kmer localkmer, localdualkmer;
					double localmax = 0.0;
					kmerNotFound = false;
					searchdual = false;
					p = 1.0;

					for(int i = 0; i < sz-k; i++)
					{
						if(p < maxProb[prc])
							break;
	
						localkmer = kmer[i];
						localdualkmer = dualkmer[i];
						nuc = nucs[0][i+k];
						dnuc = nucs[1][i+k];

						for(int j = 0; j < thismaxsubs; j++)
						{
							int inkmerpos = subs[j]-i;
					
							if(0 <= inkmerpos && inkmerpos < k)
							{
								kforge.replace(localkmer, inkmerpos, subnucs[j]);
								kforge.replace(localdualkmer, k-inkmerpos-1, dualnuc(subnucs[j]));
							}

							if(inkmerpos == k)
							{
								nuc = subnucs[j];
								dnuc = dualnuc(subnucs[j]);
							}
						}


						if(!kmers.fetch(smaller(localkmer, localdualkmer, searchdual), info))
						{
							kmerNotFound = true;
							break;
						}

						p *= NORMAL((searchdual) ? info.inedgesprob[dnuc] : info.outedgesprob[nuc]);

						if(i == 0)
							p *= NORMAL(info.prob);
					}
						
					if(!kmerNotFound)
						localmax = p;

					if(localmax > maxProb[prc])
					{
						maxProb[prc] = localmax;
						memcpy(bestsubs[prc], subs, sizeof(int)*thismaxsubs);
						memcpy(bestsubnucs[prc], subnucs, sizeof(Nucleotide)*thismaxsubs);
					}
				}
			}
		}

		for(int prc = 0; prc < jobs; prc++)
		{
			if(load[prc])
			{
				counts[min((int)(maxProb[prc]*1000), 1000)]++;
				for(int i = 0; i < maxsubs; i++)
					if(bestsubs[prc][i] >= 0)
						read[prc][bestsubs[prc][i]] = bestsubnucs[prc][i];
				read[prc].print(output);

				current++;
				if(!(current % 10000))
				{
					cout << "Done with " << current << " reads." << endl; 
					cout.flush();
				}
			}
			else 
				done = true;
		}
	}

	delete[] read;
	delete[] load;
	for(int i = 0; i < procs; i++)
	{
		delete bestsubs[i];
		delete bestsubnucs[i];
		delete asubs[i];
		delete asubnucs[i];
		delete aindices[i];
		delete akmer[i];
		delete adualkmer[i];
		delete anucs[0][i];
		delete anucs[1][i];
	}
	delete bestsubs;
	delete bestsubnucs;
	delete maxProb;
	delete aindices;
	delete akmer;
	delete adualkmer;
	delete anucs[0];
	delete anucs[1];

	reads.finalize();
	output.close();

	cout << "Finished correcting reads." << endl;

	time(&now);
	printf("%s\n", ctime(&now));
	
	ofstream countsout;
	countsout.open((outputName+".counts").c_str(), ios::out);

	for(int i = 0; i <= 1000; i++)
		countsout <<  counts[i]*1.0/current << endl;

	countsout.close();
	return 0;
}
