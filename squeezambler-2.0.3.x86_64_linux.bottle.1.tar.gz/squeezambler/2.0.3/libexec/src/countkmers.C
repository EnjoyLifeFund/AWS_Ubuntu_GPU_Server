/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          countkmers.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <map>
#include <unistd.h>
#include <math.h>


#include "kmers.C"
#include "splaytree.C"
#include "getopt.h"
#include "reads.h"
#include "alloc.h"
#include "common.h"

using namespace std;

#define FILE_STRING (char *)"countkmers"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output name"),
	Option('R', (char *)"reference", NEEDS_ARG, (char *)"=reference genome"),
	Option('i', (char *)"inck", NEEDS_ARG, (char *)"=increment k as in kmer"),
	Option('k', (char *)"startk", NEEDS_ARG, (char *)"=start k as in kmer"),
	Option('l', (char *)"endk", NEEDS_ARG, (char *)"=end k as in kmer"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input is in FASTQ format"),
	Option('s', (char *)"single", NO_ARG, (char *)"single strand"),
	Option(0, NULL, 0, NULL)
};

struct KmerInfo {
	size_t count;
};

bool doublestrand;


Kmer & smaller(Kmer & k1, Kmer & k2, bool & dual)
{
	if(!doublestrand)
	{
		dual = false;
		return k1;
	}

	if(k1 < k2)
	{
		dual = false;
		return k1;
	} else
	{
		dual = true;
		return k2;
	}
}

void index(Kmers<KmerInfo, SplayTree> & kmers, Kmers<KmerInfo, SplayTree> & ngkmers, Reads & reads, unsigned int k)
{
	KmerData<KmerInfo> pair;
	KmerData<KmerInfo> *node;
	Kmer searchedkmer;
	K kforge(k);
	
	Read r;

	size_t current = 0;

	while(reads.next(&r, 0, 0, false))
	{
		Kmer kmer, dualkmer;
			
		int len = r.size();

		for(int i = 0; i < len; i++)
		{
			Nucleotide nuc = r[i];
			kforge.push_end(kmer, nuc);
			kforge.push_begin(dualkmer, dualnuc(nuc));

			if(i >= k-1)
			{
				bool dual;
				
				kmers.fetch(searchedkmer = smaller(kmer, dualkmer, dual), node);
				if(node)
					node->second.count++;
				else
				{
					pair.first = searchedkmer;
					pair.second.count = 0;
					ngkmers.insert(pair);
				}
			}
		}
		current++;

		if(!(current % 100000))
			cout << "Done with " << current << " reads." << endl;
	} 
}


int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;
	string inputFilename;
	string referenceFilename, outputFilename;
	bool fasta = true;
	int startk = 0, endk = 0, inck = 1;
	Reads reads;
	doublestrand = true;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] reads-file\n");
			printf("%s\n", opts.help());
			exit(0);
		}
      		else if (count == 'O')
			outputFilename = current->getArg();
      		else if (count == 'R')
			referenceFilename = current->getArg();
      		else if (count == 'i')
			inck = atoi(current->getArg());
      		else if (count == 'k')
			startk = atoi(current->getArg());
      		else if (count == 'l')
			endk = atoi(current->getArg());
      		else if (count == 'q')
			fasta = false;
      		else if (count == 's')
			doublestrand = false;
	}

	if(!files || startk == 0 || endk == 0 || referenceFilename == "" || outputFilename == "")
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}

	time_t now;
	ofstream output;

	FILE *refFile = open_file((char*)referenceFilename.c_str(), "rt"); 

	Alloc alloc;
	Sequence **refs = NULL;
	int refsnum = 0;
	bool more_seq = true;

	while(more_seq)
	{
		Sequence *newseq = new Sequence(refFile);
		if(newseq->isLoaded())
		{
			refsnum++;
			refs = (Sequence **)alloc.xrealloc(refs, sizeof(Sequence *)*refsnum);
			refs[refsnum-1] = newseq;
		}
		else 
			more_seq = false;
	}

	fclose(refFile);	

	output.open(outputFilename.c_str(), ios::out);
	output << "#k\tGenomic kmers\tRead kmers\tGenomic read kmers\tSens(%)\tPPV(%)" << endl;
	
	for(int k = startk; k <= endk; k += inck)
	{
		time(&now);
		printf("%s\n", ctime(&now));
		printf("Counting %d-mers in the reference...\n", k);

		Kmers<KmerInfo, SplayTree> kmers, ngkmers;
		K kforge(k);


		for(int seqnum = 0; seqnum < refsnum; seqnum++)
		{
			Kmer kmer, dualkmer;
			bool isdual;
			unsigned long int i = 0;
			KmerData<KmerInfo> pair;
			char *refseq = refs[seqnum]->getString();

			while(refseq[i])
			{
				Nucleotide nuc = char2nuc(refseq[i]);
				kforge.push_end(kmer, nuc);
				kforge.push_begin(dualkmer, dualnuc(nuc));
				if(i >= k-1)
				{
					pair.first = smaller(kmer, dualkmer, isdual);
					pair.second.count = 0;
					kmers.insert(pair);
				}
				i++;
			}
		}
		printf("Counted %ld %d-mers in the reference\n", kmers.size(), k);
		
		time(&now);
		printf("%s\n", ctime(&now));
		printf("Counting %d-mers in reads...\n", k);

		reads.initialize(inputFilename, fasta);
		index(kmers, ngkmers, reads, k); 
		reads.finalize();

		cout << "Finished counting." << endl;
		time(&now);
		printf("%s\n", ctime(&now));

		size_t gks = kmers.size(), rks = 0, grks = 0;

		kmers.begin();
		while(kmers.hasNext())
		{
			KmerData<KmerInfo> pair = kmers.next();
			if(pair.second.count)
				grks++;
		}
		rks = grks + ngkmers.size();

		size_t TP = grks;
		size_t FP = rks - grks;
		size_t FN = gks - grks;

		output << k << "\t" << gks << "\t" << rks << "\t" << grks << "\t" << TP*100.0 / (TP+FN) << "\t" << TP*100.0 /(TP+FP) << endl;
	}

	output.close();

	for(int seqnum = 0; seqnum < refsnum; seqnum++)
		delete refs[seqnum];

	alloc.xfree((void*&)refs);

	return 0;
}
