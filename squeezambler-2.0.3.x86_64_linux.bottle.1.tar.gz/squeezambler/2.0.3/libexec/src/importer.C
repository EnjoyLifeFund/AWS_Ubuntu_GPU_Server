/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          importer.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  03/07/2013
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "importer.h"

void Importer::tokenize(string & s, vector<string> & tokens, const string & del)
{
	string current = s;
	size_t pos;
	while((pos = current.find(del)) != string::npos)
	{
		tokens.push_back(current.substr(0, pos));
		current = current.substr(pos+del.size(), current.size() - pos - del.size());
	}
	tokens.push_back(current);
}

Importer::Importer(Logger *_logger, vector<Library<string> > _inputLibnames, string _outputFile,
	bool _truncate, bool _fastqout,
	int _maxN,
	int _minLen,
	int _BADQFLAG)
{
	logger = _logger;
	outputFile = _outputFile;
	truncate = _truncate, fastqout = _fastqout;
	maxN = _maxN;
	minLen = _minLen;
	BADQFLAG = _BADQFLAG;

	libs = _inputLibnames.size();
	if(libs > MAXLIBRARIES)
	{
		logger->out() << "Warning: ignoring " << libs - MAXLIBRARIES << " additional categories (max is " << MAXLIBRARIES << ")" << endl;
		libs = MAXLIBRARIES;
	}


	for(int library = 0; library < libs; library++)
	{
		unsigned int pieces = _inputLibnames[library].files.size();
		if(pieces > MAXPIECES)
		{ 
			logger->out() << "Warning: ignoring " << pieces - MAXPIECES << " additional pieces in library " << library << " (max is " << MAXPIECES<< ")" << endl;
			pieces = MAXPIECES;
		}

		Library<ifstream *> lib;
		lib.fasta = _inputLibnames[library].fasta;

		for(int j = 0; j < pieces; j++)
		{
			ifstream *inp = new ifstream;
			inp->open((char*)_inputLibnames[library].files[j].c_str(), ifstream::in);
			if(!inp)
			{
				cerr << "Error opening input file " << _inputLibnames[library].files[j] << endl;
				exit(FILE_OPEN_ERROR);
			}
			lib.files.push_back(inp);
		}

		inputLibs.push_back(lib);
	}
}

Importer::~Importer()
{
	for(int library = 0; library < libs; library++)
	{
		unsigned int pieces = inputLibs[library].files.size();
		for(int j = 0; j < pieces; j++)
		{
			inputLibs[library].files[j]->close();
			delete inputLibs[library].files[j];
		}
	}
}

void Importer::import(size_t *maxnucs, int base_lib)
{
	logger->setSection("importing begins");

	for(int library = 0; library < libs; library++)
	{
		size_t nucs = 0;
		logger->out() << "Processing library " << library << "..." << endl;
		unsigned int pieces = inputLibs[library].files.size();

		if(inputLibs[library].fasta)
		{
			Sequence **seqs = new Sequence *[pieces];
			for(int j = 0; j < pieces; j++)
				seqs[j] = NULL;

			bool more_seq = true;
			size_t readnum = 0;

			while(more_seq && (maxnucs == NULL || nucs < maxnucs[library]))
			{
				bool included = true;
				for(int j = 0; j < pieces; j++)
				{
					Sequence *motherseq = new Sequence(*(inputLibs[library].files[j]));
					if(motherseq->isLoaded())
					{
						seqs[j] = motherseq;
						if(seqs[j]->countNs() > maxN || seqs[j]->getLen() < minLen)
							included = false;
					}
					else
					{
						more_seq = false;
						break;
					}
				}
				if(more_seq && included)
				{
					for(int piece = 0; piece < pieces; piece++)
					{
						ID id(readnum, library + base_lib, piece, false);
						if(fastqout)
						{
							output << "@" << id.id << endl;
							seqs[piece]-> printSequence(output);
							output << "+" << endl;
							for(int i = 0; i < seqs[piece]->getLen(); i++)
								output << '~';
							output << endl;
						} else
						{
							output << ">" << id.id << endl;
							seqs[piece]-> printSequence(output);
						}
						nucs += seqs[piece]->getLen();
					}
					readnum++;
				}
				for(int j = 0; j < pieces; j++)
					if(seqs[j])
					{
						delete seqs[j];
						seqs[j] = NULL;
					}
			}
			logger->out() << "Read " << readnum*pieces << " reads in library " << library << "." << endl;						
			delete[] seqs;
		}
		else
		{
			string line;
			string *seqs = new string[pieces];
			string *quals = new string[pieces];

			bool more_seq = true;
			size_t readnum = 0;
			while(more_seq && (maxnucs == NULL || nucs < maxnucs[library]))
			{
				bool include = true;
				for(int j = 0; j < pieces; j++)
				{
					if(!(*(inputLibs[library].files[j])))
					{
						more_seq = false;
						break;
					}

					getline(*(inputLibs[library].files[j]), line);
					if (line.size() == 0)
					{
						more_seq = false;
						break;
					}
		
					getline(*(inputLibs[library].files[j]), seqs[j]);
					int len = seqs[j].size();

					getline(*(inputLibs[library].files[j]), line);
					getline(*(inputLibs[library].files[j]), quals[j]);
					if(quals[j].size() != len)
					{
						cerr << "Error: quality values are not the same length as the read." << endl;
						exit(1);
					}
					if(truncate)
					{
						int tmp;
						for(tmp = len-1; tmp >= 0 && quals[j][tmp] == BADQFLAG; tmp--);
						seqs[j] = seqs[j].substr(0, tmp+1);
						quals[j] = quals[j].substr(0, tmp+1);
					}
					int Ns = 0;
					for(int tmp = 0; tmp < seqs[j].size(); tmp++)
					{
						seqs[j][tmp] = toupper(seqs[j][tmp]);
						if(seqs[j][tmp] != 'A' && seqs[j][tmp] != 'C' && seqs[j][tmp] != 'G' && seqs[j][tmp] != 'T' && seqs[j][tmp] != 'U')
						{ 
							seqs[j][tmp] = 'N'; 
							Ns++;
						}
					}

					if(Ns > maxN || seqs[j].size() < minLen)
						include = false;
				}
				if(include && more_seq)
				{
					for(int piece = 0; piece < pieces; piece++)
					{
						ID id(readnum, library + base_lib, piece, false);
						if(fastqout)
						{
							output << "@" << id.id << endl;
							output << seqs[piece] << endl;
							output << "+" << endl;
							output << quals[piece] << endl;
						}
						else
						{
							output << ">" << id.id << endl;
							output << seqs[piece] << endl;
						}

						nucs += seqs[piece].size();
					}
					readnum++;
				}
			}
			logger->out() << "Read " << readnum*pieces << " reads in library " << library << "." << endl;						

			delete[] seqs;
			delete[] quals;
		}

		if(maxnucs != NULL)
			maxnucs[library] = nucs;
	} 
}

bool Importer::iseof(int lib)
{
	unsigned int pieces = inputLibs[lib].files.size();
	for(int piece = 0; piece < pieces; piece++)
		if(!(*(inputLibs[lib].files[piece])))
			return true;
	
	return false;
}



