/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          squeezambler2.C 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <iostream>


#include "logger.h"
#include "common.h"
#include "common_squeezambler.h"
#include "colorslist.h"
#include "colorsstat.h"
#include "nuclist.h"
#include "getopt.h"
#include "importer.h"
#include "unitigger.C"
#include "finisher.h"
#include "implicitgraph.h"

#define FILE_STRING (char *)"squeezambler2"
#define FILE_VERSION (char *)"Squeezambler 2.0.3"
#define MAXFILECHAR	2000

using namespace std;

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output files prefix (default sqzout)"),
	Option('s', (char *)"searchmethod", NEEDS_ARG, (char *)"= method of search; 0: BFS; 1: DFS (default 1)"),
	Option('g', (char *)"groups", NEEDS_ARG, (char *)"=the number of division groups (default 2)"),
	Option('b', (char *)"nucs", NEEDS_ARG, (char *)"=number of sampled nucleotides per cell in the first iteration (default 5,000,000nt)"),
	Option('c', (char *)"completeGenomeMinCoverage", NEEDS_ARG, (char *)"=estimated minimum coverage needed to assemble a genome completely (default 15)"),
	Option('t', (char *)"inclusionthreshold", NEEDS_ARG, (char *)"=tau, the cutoff for the individual assembly size / total assembly size ratio to detect assembly inclusion (default 0.2)"),
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer (default 55) [ASSEMBLY RELATED]"),
	Option('f', (char *)"covcutoff", NEEDS_ARG, (char *)"=minimum average coverage of a condensed node as a multiple of mean coverage in the first condensation (default 1.0) [ASSEMBLY RELATED]"),
	Option('l', (char *)"lowcovlen", NEEDS_ARG, (char *)"=maximum length of a low average coverage condensed node to be removed (default 1000nt) [ASSEMBLY RELATED]"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads per processing node (default 1) [ASSEMBLY RELATED]"),
	Option(1, (char *)"mincontiglen", NEEDS_ARG, (char *)"=minimum length of an output contig (default 100) [ASSEMBLY RELATED]"),
	Option(0, NULL, 0, NULL)
};

Logger *logger;
int procs = 1;
int k = 55;
size_t nucs = 5000000;
CovType completeGenomeMinCoverage = 15;
double covThresh = 1.0;
int lowCovLenThresh = 1000;
int minContigLength = 100;
double cutoffRatio;
double cutoffRatioMain = 0.20;
int searchMethodType = 1;
// searchMethodType
//0: BFS (optimum method); 1: DFS

int initialGroupsNum = 2, divideGroupsNum = 2; 
LibNamesList inputLibNames;
string inputFilename, outputName = "sqzout", logFilename;
vector<ContigMetadata> contigMetadataList;
bool outputContigsSpecificColors[MAXCOLORS];

void loadSetupFile(string setupFilename)
{
	FILE *inp = open_file(setupFilename, "rt");
	logger->out() << "Input files list:" << endl;
	int counter = 0;
	while (!feof(inp))
	{
		char fileformat;
		char fileNameChar[MAXFILECHAR];
		fscanf(inp, ">%c\t%s\n", &fileformat, fileNameChar);
		string fileName(fileNameChar);
		logger->out() << (int) counter << ") " << fileName;

		Library<string>	libName;
		if (fileformat == 'f')
		{	
			libName.fasta = true;
			logger->out() << "\t fasta" << endl;
		}
		else	if (fileformat == 'q')
		{
			libName.fasta = false;
			logger->out() << "\t fastq" << endl;
		}
		else
		{
			logger->out() << "\tInput file format error. Format should be either fasta (f) or fastq (q)." << endl;
			exitMsg(NULL, INPUT_ARG_ERROR);
		}
		libName.files.push_back(fileName);
		inputLibNames.push_back(libName);
		counter ++;
	}
	if (inputLibNames.size() > MAXLIBRARIES)
	{
		logger->out() << "The number of input files is more than MAXLIBRARIES. Increase MAXLIBRARIES and run the program again." << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}
	if (inp)
		fclose(inp);
};

void divideAndConquer()
{
	string outputFilename = outputName+".fasta";
	string outputUnitigsName = outputName+".unitigs";
	string outputContigsName = outputName+".contigs";
	int assemblyLaneNo = 0;
	logger->out() << "Loading setup file"<< endl;
	loadSetupFile(inputFilename);
	logger->out() << "Importing" << endl;
	Lib base_lib = 0;
	Importer importer(logger, inputLibNames, outputFilename);
	bool debugMode = true;
	logger->out() << "colorsList initializing" << endl;
	logger->out().flush();
	ColorsList colorsList(logger, debugMode, initialGroupsNum, inputLibNames.size(), base_lib);
	logger->out() << "colorsStat initializing" << endl;
	logger->out().flush();
	ColorsStat * colorsStat = new ColorsStat(logger, debugMode);
	importer.openOutput(false);
	importer.closeOutput();
	for (int i = 0; i < MAXCOLORS; i++)
	{
		outputContigsSpecificColors[i] = false;
	} 
	logger->out() << "nucs = " << nucs << endl;
	NucList nucList(logger, debugMode, inputLibNames.size(), nucs);	
	ImplicitGraph<SemicompactNodeInfo> *graph = new ImplicitGraph<SemicompactNodeInfo>(k, 0, 1, true, logger);
	while (!colorsList.allSequenced())
	{
		logger->setSection("NEW LEVEL");
		logger->out() << "LEVEL "<< assemblyLaneNo << endl;
		nucList.updateLastStepNucList(colorsList, *colorsStat, completeGenomeMinCoverage);
		logger->out() << "Importing a set of data" << endl;
		importer.openOutput(false);
		importer.import(nucList.getNucList(), base_lib);
		importer.closeOutput();
		nucList.countTotalNucs(assemblyLaneNo); 
		logger->out() << "Creating unitigs" << endl;
		Color newList[MAXLIBRARIES];
		colorsList.getNewColorsList_list(newList);
		logger->out() << "newList: (size)" << inputLibNames.size() << endl;
		for (int i = 0; i < inputLibNames.size(); i ++)
			logger->out() << (int) newList[i] << endl;
		logger->out().flush();
		graph->resetVisitations();
		Unitigger<SemicompactNodeInfo> unitigger(outputFilename, outputName, colorsList.getColorsList_list(), 1, 0, true, procs, true, k, false, graph, logger);
		logger->out() << "Creating contigs" << endl;
		Finisher finisher(outputFilename, outputUnitigsName, "", outputName, "", "", true, procs, -1, covThresh, 0, lowCovLenThresh, minContigLength, true, false, false, false, false, outputContigsSpecificColors, MINCONTIGCOVERAGE, false, logger);
		logger->out() << "Assembly finished" << endl;
		contigMetadataList = finisher.metadata();
		logger->out() << "move Single Cells From Active To Sequenced List" << endl;
		colorsList.moveSingleCellsFromActiveToSequencedList();
		logger->out() << "select Next Level Active Colors" << endl;
		Colors_List NextRoundColorList;
		base_lib = base_lib + inputLibNames.size();
		logger->out() << "update ActiveList. base_lib = " << (int) base_lib << endl;
		colorsStat->selectNextLevelActiveColors(&contigMetadataList, &colorsList, cutoffRatioMain, base_lib, divideGroupsNum, completeGenomeMinCoverage, searchMethodType);
		assemblyLaneNo ++; 
		logger->out() << "assemblyLaneNo = " << (int) assemblyLaneNo << endl;
	}
	CList<int, MAXCOLORS> sequencedClusters;
	colorsStat->clusterSequencedColors(&contigMetadataList, &colorsList, cutoffRatioMain, &sequencedClusters, &inputLibNames);
	logger->out() << "clusterSequencedColors done " << endl; 
	NucNum nucNum = nucList.totalNucsFromBegining(colorsList.get_assemStepNo());
	logger->out() << "total sequencing nucleotides = " << (int) nucNum << endl;
	logger->out() << "Assembly finished" << endl;

	delete colorsStat;
	delete graph;
}



int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_VERSION);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] input-setup-file\n");
			printf("input-setup-file format:\n");
			printf("       Each TAB separated line of input setup file is either\n");
			printf("       >f\tFASTAFilename\n");
			printf("       or\n");
			printf("       >q\tFASTQFilename\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
      		else if (count == 1)
			minContigLength = atoi(current->getArg());
		else if (count == 'O')
			outputName = current->getArg();
		else if (count == 'k')
			k = atoi(current->getArg());
		else if (count == 'g')
			initialGroupsNum = atoi(current->getArg());
		else if (count == 's')
			searchMethodType = atoi(current->getArg());
		else if (count == 't')
			cutoffRatioMain = atof(current->getArg());
		else if (count == 'b')
			nucs = atol(current->getArg()); 
		else if (count == 'c')
			completeGenomeMinCoverage = atof(current->getArg());
		else if (count == 'p')
			procs = atoi(current->getArg());
      		else if (count == 'f')
			covThresh = atof(current->getArg());
      		else if (count == 'l')
			lowCovLenThresh = atoi(current->getArg());
	}

	if(!files || k == 0 || nucs == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	if(outputName == "")
	{
		fputs("Error: output name not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, OUTPUT_ARG_ERROR);
	}

	if(k % 2 == 0)
	{
		k++;
		cerr << "k should be odd, therefore we use k=" << k << " instead." << endl;
	}

	string executedcommand; 
	for(int i = 0; i < argc; i++)
	{
		executedcommand += argv[i];
		executedcommand += " ";
	}
	executedcommand += "\n";
	
	logFilename = outputName+".log";
	cout << "1 - Logging in " << logFilename << " file. Follow the status of the program there." << endl;
	cout.flush();

	logger = new Logger(logFilename);

	cout << "Logging in " << logFilename << " file. Follow the status of the program there." << endl;
	cout.flush();

	time_t now;
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_VERSION)+ "-" + string(PACKAGE_STRING) + " has been executed on " + string(ctime(&now)));
	logger->out() << executedcommand << endl;
	logger->out() << "0" << endl;
	divideGroupsNum = initialGroupsNum; 
	logger->setSection("Divide and conquer");
	logger->out() << "1" << endl;
	logger->out() << "2" << endl;
	logger->out() << "3" << endl;
	logger->out() << "4" << endl;
	logger->out() << "5 divide" << endl;

	divideAndConquer();
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " successfully concluded on " + string(ctime(&now)));

	delete logger;

	return NO_ERROR;
}
