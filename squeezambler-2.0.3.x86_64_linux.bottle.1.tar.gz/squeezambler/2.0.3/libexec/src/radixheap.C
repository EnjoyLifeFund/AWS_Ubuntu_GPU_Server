/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          radixheap.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include "radixheap.h"


template <class Element>
RadixHeap<Element>::RadixHeap(size_t maxKey)
{
	N = 0;
	maxkey = maxKey;
	buckets = new Bucket<Element>*[maxkey+1];

	for(unsigned int i = 0; i <= maxkey; i++)
		buckets[i] = NULL;

	minel = maxkey+1;
}

template <class Element>
RadixHeap<Element>::~RadixHeap()
{
	for(unsigned int i = 0; i <= maxkey; i++)
		if(buckets[i])
			alloc.xfree((void*&)buckets[i]);
	delete[] buckets;	
}

template <class Element>
void RadixHeap<Element>::insert(Element data)
{
	if(data.priority > maxkey)
		exitMsg((char*)"Error: RadixHeap is small.", INTERNAL_RADIXHEAP_ERROR);

	if(!buckets[data.priority])
	{
		buckets[data.priority] = (Bucket<Element>*) alloc.xmalloc(sizeof(Bucket<Element>)+sizeof(Element)*INIT_BUCKET_SIZE);
		buckets[data.priority]->maxsize = INIT_BUCKET_SIZE;
		buckets[data.priority]->size = 0;
	}

	if(buckets[data.priority]->size >= buckets[data.priority]->maxsize)
	{
		buckets[data.priority]->maxsize += INIT_BUCKET_SIZE;
		buckets[data.priority] = (Bucket<Element>*) alloc.xrealloc(buckets[data.priority], sizeof(Bucket<Element>)+sizeof(Element)*buckets[data.priority]->maxsize);
	}

	buckets[data.priority]->elements[buckets[data.priority]->size++] = data;
	if(data.priority < minel)
		minel = data.priority;
	N++;
}


template <class Element>
Element RadixHeap<Element>::extractMin()
{
	while(!buckets[minel] || buckets[minel]->size == 0) minel++;

	buckets[minel]->size--;
	N--;
	return buckets[minel]->elements[buckets[minel]->size];
}

template <class Element>
Element RadixHeap<Element>::min()
{
	while(!buckets[minel] || buckets[minel]->size == 0) minel++;

	return buckets[minel]->elements[buckets[minel]->size-1];
}

