/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          cnode.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  12/26/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "cnode.h"
#include "compactstr.C"

template class CompactString<CompactWord>;


CNodeAuxSP::CNodeAuxSP(int deg) 
{
	shortests = (ShortestPaths *)alloc.xmalloc(sizeof(ShortestPaths));
	shortests->ordersnum = 0;
	ticket.status = SP_NV;
	sorted1stOrder = (FirstOrderList *)alloc.xmalloc(sizeof(FirstOrderList) + deg*sizeof(SPInfo));
	sorted1stOrder->size = deg;
	sorted1stOrder->current = 0;
}

CNodeAuxSP::~CNodeAuxSP() 
{
	if(sorted1stOrder) 
		alloc.xfree((void*&)sorted1stOrder);
	if(shortests) 
		alloc.xfree((void*&)shortests);
}

void CNodeAuxSP::resize(int _sz) 
{
	sorted1stOrder->current = 0;
	sorted1stOrder->size = _sz;
}

bool CNodeAuxSP::current(SPInfo &ret) 
{
	register int cur = sorted1stOrder->current;

	if(cur >= sorted1stOrder->size) 
		return false; 
	else 
	{
		ret = item(cur);
		return true;
	}
}

void CNodeAuxSP::inc() 
{
	sorted1stOrder->current++;
}

void CNodeAuxSP::sort() 
{
	register int sz = sorted1stOrder->size;
	for(int i = 0; i < sz-1; i++)
	{
		int minidx;
		register size_t mindis = INT_INFINITY;
		for(int j = i; j < sz; j++)
		{
			register size_t temp = item(j).distance;
			if(temp < mindis)
			{
				mindis = temp;
				minidx = j;
			}
		}
		if(i != minidx)
		{
			SPInfo temp = item(i);
			item(i) = item(minidx);
			item(minidx) = temp;
		}
	}
}	

void CNodeAuxSP::insert(SPInfo a) 
{
	shortests->ordersnum++;
	shortests = (ShortestPaths *)alloc.xrealloc(shortests, sizeof(ShortestPaths) + sizeof(SPInfo)*shortests->ordersnum);
	shortests->shortest[shortests->ordersnum-1] = a;
}



void Contig::append(CNodeID from, int k)
{
	for(Coordinate i = 0; i < from.size(); i++)
		seq += from[i];

	coverage += from.coverage();

	if(len == 0)
		len = from.length();
	else
		len += from.length()-k+1;
}


CNode::CNode()
{
	inedges = outedges = NULL;
	indeg = outdeg = 0;
	aux = NULL;
	auxType = AUX_NON;
}

CNode::CNode(UnitigSerial s, Distance l, Coverage c)
{
	inedges = outedges = NULL;
	indeg = outdeg = 0;
	aux = NULL;
	auxType = AUX_NON;
	contig.seq += s;
	contig.len = l;
	contig.coverage = c;
}


CNode::~CNode()
{
	if(inedges) alloc.xfree((void*&)inedges);
	if(outedges) alloc.xfree((void*&)outedges);
	deleteAux();
}

AuxSP *CNode::newAuxSP(int procs) 
{
	deleteAux(); 

	aux = (AuxSP *) alloc.xmalloc(sizeof(AuxSP)); 
	((AuxSP *)aux)->procs = procs;

	if(procs > 0)
		((AuxSP *)aux)->cnodeAuxSP = new CNodeAuxSP*[procs];
	else
		((AuxSP *)aux)->cnodeAuxSP = NULL;
	
	for(int i = 0; i < procs; i++)
		((AuxSP *)aux)->cnodeAuxSP[i] = NULL;

	auxType = AUX_SP; 

	return (AuxSP *)aux;
}	

CNodeAuxSP *CNode::newCNodeAuxSP(int prc, int deg)
{
	return (((AuxSP *)aux)->cnodeAuxSP[prc] = new CNodeAuxSP(deg));
} 

void CNode::deleteCNodeAuxSP(int prc)
{
	if(((AuxSP *)aux)->cnodeAuxSP[prc])
		delete ((AuxSP *)aux)->cnodeAuxSP[prc];
	((AuxSP *)aux)->cnodeAuxSP[prc] = NULL;
} 

CNodeAuxSP *CNode::cnodeAuxSP(int prc)
{
	return ((AuxSP *)aux)->cnodeAuxSP[prc];
} 

void CNode::deleteAux() 
{
	if(auxType == AUX_SP) 
	{
		for(int i = 0; i < ((AuxSP *)aux)->procs; i++)
			deleteCNodeAuxSP(i);
		 
		if(((AuxSP *)aux)->cnodeAuxSP)
			delete[] ((AuxSP *)aux)->cnodeAuxSP;
	}  

	if(aux) 
		alloc.xfree(aux); 
	auxType = AUX_NON; 
	aux = NULL;
} 

void CNode::connectin(CNodeID cnodeid)
{
	if(!inedges)
	{
		inedges = (CNodeID *)alloc.xmalloc(sizeof(CNodeID));
		indeg = 1;
		inedges[0] = cnodeid;
	} else
	{
		bool insert = true;
		for(register int idx = 0; idx < indeg && insert; idx++)
			if(inedges[idx] == cnodeid) insert = false;

		if(insert)
		{
			indeg++;
			inedges = (CNodeID *)alloc.xrealloc(inedges, sizeof(CNodeID)*indeg);
			inedges[indeg-1] = cnodeid;
		}
	}
}

void CNode::connectout(CNodeID cnodeid)
{
	if(!outedges)
	{
		outedges = (CNodeID *)alloc.xmalloc(sizeof(CNodeID));
		outdeg = 1;
		outedges[0] = cnodeid;
	} else
	{
		bool insert = true;
		for(register int idx = 0; idx < outdeg && insert; idx++)
			if(outedges[idx] == cnodeid) insert = false;

		if(insert)
		{
			outdeg++;
			outedges = (CNodeID *)alloc.xrealloc(outedges, sizeof(CNodeID)*outdeg);
			outedges[outdeg-1] = cnodeid;
		}
	}
}

void CNode::disconnectin(CNodeID cnodeid)
{
	if(!indeg)
		return;

	register int foundidx = -1;
	
	for(register int idx = 0; idx < indeg && foundidx == -1; idx++)
		if(inedges[idx] == cnodeid)
			foundidx = idx;

	if(foundidx != -1)
	{
		indeg--;
		inedges[foundidx] = inedges[indeg];
		if(indeg > 0)
			inedges = (CNodeID *)alloc.xrealloc(inedges, sizeof(CNodeID)*indeg);
		else
		{
			alloc.xfree((void*&)inedges);
			inedges = NULL;
		}
	}
}

void CNode::disconnectout(CNodeID cnodeid)
{
	if(!outdeg)
		return;

	register int foundidx = -1;
	
	for(register int idx = 0; idx < outdeg && foundidx == -1; idx++)
		if(outedges[idx] == cnodeid)
			foundidx = idx;

	if(foundidx != -1)
	{
		outdeg--;
		outedges[foundidx] = outedges[outdeg];
		if(outdeg > 0)
			outedges = (CNodeID *)alloc.xrealloc(outedges, sizeof(CNodeID)*outdeg);
		else
		{
			alloc.xfree((void*&)outedges);
			outedges = NULL;
		}
	}
}

void CNode::save(FILE *out)
{
	size_t sz = size();
	UnitigSerial s;

	write_in_file((void*)&contig.len, sizeof(Distance), 1, out);
	write_in_file((void*)&contig.coverage, sizeof(Coverage), 1, out);
	write_in_file((void*)&sz, sizeof(size_t), 1, out);

	for(size_t i = 0; i < sz; i++)
	{
		s = contig.seq[i];
		write_in_file((void*)&s, sizeof(UnitigSerial), 1, out);
	}
}

void CNode::load(FILE *in)
{
	size_t sz;
	UnitigSerial s;

	read_from_file((void*)&contig.len, sizeof(Distance), 1, in);
	read_from_file((void*)&contig.coverage, sizeof(Coverage), 1, in);
	read_from_file((void*)&sz, sizeof(size_t), 1, in);

	for(size_t i = 0; i < sz; i++)
	{
		read_from_file((void*)&s, sizeof(UnitigSerial), 1, in);
		contig.seq += s;
	}

}





























