/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          sortedlist.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "sortedlist.h"

template<class Pair>
SortedList<Pair>::SortedList()
{
	sheet = NULL;
	num = 0;
	resize(_INITSIZE);
}

template<class Pair>
SortedList<Pair>::~SortedList()
{
	if(sheet)
		alloc.xfree((void*&)sheet);
// use if(sheet) delete[] sheet for a real c++ implementation. we chose above for speed.
}

template<class Pair>
void SortedList<Pair>::resize(TreeIndex s)
{
	if(s > (TreeIndex)(-1) - 5)
		exitMsg((char*)"Error: SplayTree is choking. Make TreeIndex bigger and recompile. \n", 178);

	sheet = (Pair *)alloc.xrealloc(sheet, sizeof(Pair)*s);
// use sheet = new SplayNode<Pair>[s] for a real c++ implementation. in that case, the existing elements have to be copied to the new sheet one by one. we chose above for speed.
	maxNum = s;
}

template<class Pair>
TreeIndex SortedList<Pair>::newSlot()
{
	if(num >= maxNum)
		resize(maxNum + _INITSIZE);

	num++;
	return num-1;
}

template<class Pair>
bool SortedList<Pair>::insert(Pair & pair)
{
	if (num == 0) {
		sheet[newSlot()] = pair;
		return true;
	}

	if(find(pair) == NULL)
	{
		TreeIndex ns = newSlot();
		sheet[ns] = pair;
		while(ns > 0 && sheet[ns].first < sheet[ns-1].first)
		{
			Pair temp = sheet[ns];
			sheet[ns] = sheet[ns-1];
			sheet[ns-1] = temp;
			ns--;
		} 

		return true;
	} else
		return false;
}

template<class Pair>
TreeIndex SortedList<Pair>::add(Pair & pair)
{
	if (num == 0) {
		TreeIndex ns = newSlot();
		sheet[ns] = pair;
		return ns;
	}

	TreeIndex p = search(pair);
	if(p == NULLIDX)
	{
		TreeIndex ns = newSlot();
		sheet[ns] = pair;
		while(ns > 0 && sheet[ns].first < sheet[ns-1].first)
		{
			Pair temp = sheet[ns];
			sheet[ns] = sheet[ns-1];
			sheet[ns-1] = temp;
			ns--;
		} 

		return ns;
	} else
		return p;
}


template<class Pair>
Pair *SortedList<Pair>::find(Pair & pair)
{
	if(num == 0)
		return NULL;

	TreeIndex ll = 0, ul = num;
	while(ll < ul)
	{
		TreeIndex ml = ll+(ul-ll)/2;
		if(pair.first < sheet[ml].first)
			ul = ml;
		else if(sheet[ml].first < pair.first)
			ll = ml+1;
		else
			return &(sheet[ml]); 
	}

	return NULL;
}


template<class Pair>
Pair *SortedList<Pair>::find(TreeIndex bstIndex)
{
	if(bstIndex >= num)
		return NULL;

	return &(sheet[bstIndex]);
}

template<class Pair>
TreeIndex SortedList<Pair>::search(Pair & pair)
{
	if(num == 0)
		return NULLIDX;

	TreeIndex ll = 0, ul = num;
	while(ll < ul)
	{
		TreeIndex ml = ll+(ul-ll)/2;
		if(pair.first < sheet[ml].first)
			ul = ml;
		else if(sheet[ml].first < pair.first)
			ll = ml+1;
		else
			return ml; 
	}

	return NULLIDX;
}


template<class Pair>
void SortedList<Pair>::printall()
{
	for(TreeIndex r = 0; r < num; r++)
		cout << "Node " << r << ": " << sheet[r].first << endl;
}

template<class Pair>
void SortedList<Pair>::print()
{
	printall();
}

template<class Pair>
Pair& SortedList<Pair>::item(size_t i) 
{
	return sheet[i];
}





