/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          bag.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include "bag.h"

template<class T>
Bag<T>::Bag()
{
	current = head = NULL;
	num = 0;
}

template<class T>
Bag<T>::~Bag()
{
	clear();
}

template<class T>
inline void Bag<T>::clear()
{
	Page<T> *c, *temp;
	c = head;
	while(c)
	{
		temp = c->next;
		delpage(c);
		c = temp;
	}
	current = head = NULL;
	num = 0;
}

template<class T>
inline void Bag<T>::append(T data)
{
	unsigned int idx = num % __PAGESIZE;
	if(!idx)
	{
		if(!current)
			current = head = newpage();
		else
		{
			current->next = newpage();
			current = current->next;
		}
	}
	current->elements[idx] = data;
	num++;
}

template<class T>
inline void Bag<T>::unappend()
{
	num--;
	unsigned int idx = num % __PAGESIZE;
	if(!idx)
	{
		Page<T> *temp = head;
		for(long int i = 0; i < (num-1) / __PAGESIZE; i++)
			temp = temp->next;
	
		delpage(current);
		current = temp;
		current->next = NULL;
	}
}

template<class T>
inline T& Bag<T>::operator[](unsigned int idx)
{
	Page<T> *temp = head;

	for(long int i = 0; i < idx / __PAGESIZE; i++)
		temp = temp->next;

	return temp->elements[idx % __PAGESIZE];
}

template<class T>
inline Page<T> *Bag<T>::newpage()
{
	Page<T> *ret = (Page<T> *)alloc.xmalloc(sizeof(Page<T>));
	ret->next = NULL;
	return ret;
}

template<class T>
inline void Bag<T>::delpage(Page<T> *p)
{
	alloc.xfree((void*&)p);
}

template<class T>
inline void Bag<T>::begin()
{
	itr = 0;
	itrpage = head;
}

template<class T>
inline bool Bag<T>::hasNext()
{
	if(!itrpage)
		return false;

	if(itr < num)
		return true;
	else
		return false;
}

template<class T>
inline T &Bag<T>::next()
{
	unsigned int idx = itr % __PAGESIZE;
	if(!idx && itr != 0)
		itrpage = itrpage->next;
	itr++;
	return itrpage->elements[idx];
}

template<class T>
T &Bag<T>::first()
{
	return head->elements[0];
}

template<class T>
T &Bag<T>::last()
{
	return current->elements[(num % __PAGESIZE)-1];
}



