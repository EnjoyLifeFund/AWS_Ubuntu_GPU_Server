/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          common.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  03/13/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <cctype>
#include <errno.h>

#include "common.h"

void version(char* prog)
{
	printf("%s (%s) \n", prog, PACKAGE_STRING);
	puts("Authors: Hamidreza Chitsaz and Zeinab Taghavi and Narges Movahedi");
	puts("Copyright (C) 2011-2014");
	puts("Colorado State University");
	puts("Fort Collins, CO");
	puts("chitsaz@chitsazlab.org");
	exit(EXIT_SUCCESS);
}

void version(std::ofstream & out, char* prog)
{
	out << prog << " (" << PACKAGE_STRING << ")" << std::endl;
	out << "Authors: Hamidreza Chitsaz and Zeinab Taghavi and Narges Movahedi" << std::endl;
	out << "Copyright (C) 2011-2014" << std::endl;
	out << "Colorado State University" << std::endl;
	out << "Fort Collins, CO" << std::endl;
	out << "chitsaz@chitsazlab.org" << std::endl;
}

Nucleotide char2nuc(char c)
{
	switch(toupper(c))
	{
		case 'C': return 1;
		case 'G': return 2;
		case 'T': 
		case 'U': return 3;
		default: return 0;
	}
}

char nuc2char(Nucleotide n)
{
	switch(n)
	{
		case 1: return 'C';
		case 2: return 'G';
		case 3: return 'T';
		default: return 'A';
	}
}

char dual(char c)
{
	switch(toupper(c))
	{
		case 'C': return 'G';
		case 'G': return 'C';
		case 'T': 
		case 'U': return 'A';
		default: return 'T';
	}
}

FILE *open_file(char *fname, const char *mode)
{
	FILE *ret = fopen(fname, mode);
	if(!ret)
	{
		char buf[10000] = "Error: failed to open file ";
		strncat(buf, fname, 9500);
		strcat(buf, " in mode ");
		strncat(buf, (char *)mode, 100);
		strcat(buf, ".\n");
		exitMsg(buf, FILE_OPEN_ERROR); 
	}
	return ret;
}

FILE *open_file(std::string fname, const char *mode)
{
	return open_file((char*)fname.c_str(), mode);
}


void write_in_file ( const void * ptr, size_t size, size_t count, FILE * stream )
{
	if(fwrite(ptr, size, count, stream) != count)
	{
		perror("Error writing in file");
		exit(-1);
	}
}

void read_from_file ( void * ptr, size_t size, size_t count, FILE * stream )
{
	if(fread(ptr, size, count, stream) != count)
	{
		perror("Error reading from file");
		exit(-1);
	}
}

void read_from_buf ( void * ptr, size_t size, size_t count, char *& buf)
{
	memcpy(ptr, buf, size*count);
	buf += size*count;
}

void exitMsg(char *msg, Error c)
{
	if(msg)
	{
		fputs(msg, stderr);
		fputc('\n', stderr);
	}
	exit(c);
}
