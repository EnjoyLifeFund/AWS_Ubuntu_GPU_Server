/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          assemble-unitig.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "unitigger.C"

#define FILE_STRING (char *)"assemble-unitig"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output files prefix (mandatory)"),
	Option('C', (char *)"config", NEEDS_ARG, (char *)"=coloring config file, if absent all libraries are colored 0"), 
	Option('k', (char *)"kmer", NEEDS_ARG, (char *)"=k as in kmer (mandatory)"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads per processing node (default 1)"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input is in FASTQ format"),
	Option('m', (char *)"machines", NEEDS_ARG, (char *)"=number of machines (only needed when distributing among multiple machines)"),
	Option('s', (char *)"slice", NEEDS_ARG, (char *)"=0-base slice number (only needed when distributing among multiple machines)"),
	Option('S', (char *)"single", NO_ARG, (char *)"single strand"),
 	Option(1, (char *)"exportkmers", NO_ARG, (char *)"export kmers with their multiplicities"),
	Option(0, NULL, 0, NULL)
};

int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	Logger *logger;
	int files = 0;
	string inputFilename;
	string outputName;
	string configFilename;
	int machines = 1, slice = 0;
	bool fasta = true;
	int procs = 2;
	bool doublestrand = true;
	int k = 0;
	bool exportkmers = false;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] reads-file\n");
			printf("       Output files prefix is identified by -O option.\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
		else if (count == 1)
			exportkmers = true;
		else if (count == 'O')
			outputName = current->getArg();
		else if (count == 'C')
			configFilename = current->getArg();
		else if (count == 'k')
			k = atoi(current->getArg());
		else if (count == 'q')
			fasta = false;
		else if (count == 'p')
			procs = atoi(current->getArg());
		else if (count == 'm')
			machines = atoi(current->getArg());
		else if (count == 's')
			slice = atoi(current->getArg());
		else if (count == 'S')
			doublestrand = false;
	}

	if(!files || k == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	if(outputName == "")
	{
		fputs("Error: output name not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, OUTPUT_ARG_ERROR);
	}

	if(k % 2 == 0)
	{
		k++;
		cerr << "k should be odd, therefore we use k=" << k << " instead." << endl;
	}


	if(machines <= 0 || slice < 0 || slice >= machines)
	{
		cerr << "Error: slice number " << slice << " is out of the range of machines " << machines << endl;
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	string executedcommand; 

	for(int i = 0; i < argc; i++)
	{
		executedcommand += argv[i];
		executedcommand += " ";
	}
	executedcommand += "\n";

	char buf[MAX_BUF_SIZE];
	sprintf(buf, ".slice%d", slice);
	string sliceName = buf;
	string logFilename = outputName+((machines > 1) ? sliceName : "")+".log";

	logger = new Logger(logFilename);

	cout << "Logging in " << logFilename << " file. Follow the status of the program there." << endl;
	cout.flush();

	time_t now;
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " has been executed on " + string(ctime(&now)));
	logger->out() << executedcommand << endl;
	version(logger->out(), FILE_STRING);
	logger->out() << "MAXK = " << MAXK << endl;
	logger->out() << "MAXCOLORS = " << MAXCOLORS << endl;
	logger->out().flush();


	Unitigger<CompactNodeInfo> unitigger(inputFilename, outputName, configFilename, machines, slice, fasta, procs, doublestrand, k, exportkmers, NULL, logger);

	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " successfully concluded on " + string(ctime(&now)));

	delete logger;

	return NO_ERROR;
}
