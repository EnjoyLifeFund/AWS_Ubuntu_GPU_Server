/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          assemble-finish.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  09/19/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "finisher.h"

#define FILE_STRING (char *)"assemble-finish"


Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('U', (char *)"unitig", NEEDS_ARG, (char *)"=input unitigs file ([collective] output of assemble-unitig [for multiple slices]) (mandatory)"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output files prefix, may be the same as assemble-unitig output prefix (mandatory)"),
	Option('C', (char *)"config", NEEDS_ARG, (char *)"=pairing config file"),
	Option('c', (char *)"cov", NEEDS_ARG, (char *)"=minimum average coverage of a condensed node, as a multiple of the assembly coverage mean (default 1.0)"),
	Option('l', (char *)"lowcovlen", NEEDS_ARG, (char *)"=maximum length of a low average coverage condensed node to be removed (default 1000nt)"),
	Option('p', (char *)"procs", NEEDS_ARG, (char *)"=number of threads"),
	Option('q', (char *)"fastq", NO_ARG, (char *)"input is in FASTQ format"),
	Option('S', (char *)"single", NO_ARG, (char *)"single strand"),
	Option('a', (char *)"exportasm", NO_ARG, (char *)"export assembly graph for downstream applications, e.g. align-longreads"),
	Option(1, (char *)"mincontiglen", NEEDS_ARG, (char *)"=minimum length of an output contig (default k)"),
	Option(2, (char *)"exportgraph", NEEDS_ARG, (char *)"=max contig size, export those nodes of the condensed graph that are shorter than this value, in DOT format"),
	Option(3, (char *)"exportlowcov", NO_ARG, (char *)"export removed low coverage condensed nodes"),
	Option(4, (char *)"save", NEEDS_ARG, (char *)"=file to save condensed graph into"),
	Option(5, (char *)"load", NEEDS_ARG, (char *)"=file to load condensed graph from"),
	Option(6, (char *)"separatecolors", NO_ARG, (char *)"output contigs of each color into a separate file"),
	Option(7, (char *)"nolowcovunitigs", NO_ARG, (char *)"do not even initially load those unitigs that have coverage less than 2"),
	Option(8, (char *)"mincontigcov", NEEDS_ARG, (char *)"=minimum coverage of an output contig [applicable only when --separatecolors used] (default 1.0)"),
	Option(9, (char *)"keepcolor0", NO_ARG, (char *)"keeps all nodes in color 0 no matter what their coverages are. That is the cut-off for color 0 is 0."),
	Option(0, NULL, 0, NULL)
};

int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	int files = 0;
	string inputFilename, unitigFilename, configFilename;
	string outputName;
	string saveCGFilename, loadCGFilename;
	bool fasta = true;
	int procs = 2;
	double covThresh = 1.0;
	int lowCovLenThresh = 1000;
	int minContigLength = 0;
	bool doublestrand = true;
	int exportGraph = 0;
	bool exportRemovedNodes = false;
	bool exportAsm = false;
	bool separateColors = false;
	bool noLowCovUnitigs = false;
	double minContigCov = 1.0;
	bool keepref = false;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(files == 0)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				cerr << "Warning: ignoring additional argument " <<  current->getArg() << endl;
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] reads-file\n");
			printf("       Input unitigs file is identified by -U option.\n");
			printf("       Output files prefix is identified by -O option.\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
      		else if (count == 1)
			minContigLength = atoi(current->getArg());
      		else if (count == 2)
			exportGraph = atoi(current->getArg());
      		else if (count == 3)
			exportRemovedNodes = true;
      		else if (count == 4)
			saveCGFilename = current->getArg();
      		else if (count == 5)
			loadCGFilename = current->getArg();
      		else if (count == 6)
			separateColors = true;
      		else if (count == 7)
			noLowCovUnitigs = true;
		else if (count == 8)
			 minContigCov = atol(current->getArg());
		else if (count == 9)
			 keepref = true;
      		else if (count == 'U')
			unitigFilename = current->getArg();
      		else if (count == 'O')
			outputName = current->getArg();
      		else if (count == 'C')
			configFilename = current->getArg();
      		else if (count == 'c')
			covThresh = atof(current->getArg());
      		else if (count == 'l')
			lowCovLenThresh = atoi(current->getArg());
      		else if (count == 'q')
			fasta = false;
      		else if (count == 'p')
			procs = atoi(current->getArg());
      		else if (count == 'S')
			doublestrand = false;
      		else if (count == 'a')
			exportAsm = true;
	}

	if(!files || unitigFilename == "")
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, INPUT_ARG_ERROR);
	}

	if(outputName == "")
	{
		fputs("Error: output name not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exitMsg(NULL, OUTPUT_ARG_ERROR);
	}

	if(configFilename == "")
		fputs("Warning: mating configurations file not specified, ignoring mating information.\n", stderr);

	if(covThresh < 0.0)
	{
		covThresh = 0.0;
		fputs("Warning: given coverage threshold was negative, made it 0.0 if you do not mind.\n", stderr);
	}

	string executedcommand; 

	for(int i = 0; i < argc; i++)
	{
		executedcommand += argv[i];
		executedcommand += " ";
	}
	executedcommand += "\n";

	Logger *logger = new Logger(outputName+".log");

	cout << "Logging in " << outputName+".log" << " file. Follow the status of the program there." << endl;
	cout.flush();

	time_t now;
	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " has been executed on " + string(ctime(&now)));
	logger->out() << executedcommand << endl;
	version(logger->out(), FILE_STRING);
	logger->out() << "MAXK = " << MAXK << endl;
	logger->out() << "MAXCOLORS = " << MAXCOLORS << endl;
	logger->out().flush();

	bool specificColors[MAXCOLORS];

	for(int i = 0; i < MAXCOLORS; i++)
		specificColors[i] = separateColors;

	Finisher finisher(inputFilename, unitigFilename, configFilename, outputName, saveCGFilename, loadCGFilename, fasta, procs, covThresh, AvgCoverage(0.0), Coverage(0), lowCovLenThresh, minContigLength, doublestrand, exportGraph, exportRemovedNodes, exportAsm, noLowCovUnitigs, specificColors, AvgCoverage(minContigCov), keepref, logger);

	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " successfully concluded on " + string(ctime(&now)));

	return NO_ERROR;
}
