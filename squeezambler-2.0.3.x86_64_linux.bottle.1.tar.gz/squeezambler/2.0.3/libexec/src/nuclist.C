/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          nuclist.h 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013 - Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "nuclist.h"

NucList::NucList(Logger *_logger, bool _debugMode, size_t _libNo, size_t nucs, size_t _assemStepNum)
{
	logger = _logger;
	debugMode = _debugMode;
	libNo = _libNo;
	assemStepNum = _assemStepNum;
	for (size_t i = 0; i < MAXSTEPS; i++)	
		totalNucList[i] = 0;
	for (int i = 0; i < libNo; i++)
		nucList[i] = nucs;
}

NucNum NucList::countTotalNucs(size_t _assemStepNum)
{
	NucNum totNucs = 0;
	for (int i = 0; i < libNo; i++)
	{
		if (assemStepNum == _assemStepNum)
		{
			totNucs += nucList[i] / 1000;
		}
		else
			totNucs += nucListArchive[_assemStepNum][i] / 1000;
	}
	if (totalNucList[_assemStepNum] > 0)
	{
		if (totalNucList[_assemStepNum] !=  totNucs);
			logger->out() << "NucList::countTotalNucs: descripancy in totalNuc count. totalNucList[ " << _assemStepNum << " ] != " << totNucs << endl;
	}	
	totalNucList[_assemStepNum] = totNucs;
	logger->out() << " totalNucList[" << (int) _assemStepNum << "] = " << (int) totalNucList[_assemStepNum] << " Mbps" << endl;
	return totalNucList[_assemStepNum];
}; 


NucNum NucList::totalNucs(size_t _assemStepNum)
{
	logger->out() << " totalNucList[" << (int) _assemStepNum << "] = " << (int) totalNucList[_assemStepNum] << " Mbps" << endl;
	if (totalNucList[_assemStepNum] == 0)
	{
		for (int i = 0; i < libNo; i++)
		{
			if (assemStepNum == _assemStepNum)
			{
				totalNucList[_assemStepNum] += nucList[i] / 1000;
				logger->out() << " totalNucList[" << (int) _assemStepNum << "] = " << (int) totalNucList[_assemStepNum] << " Mbps" << endl;
			} else
			{
				totalNucList[_assemStepNum] += nucListArchive[_assemStepNum][i] / 1000;
				logger->out() << " totalNucList[" << (int) _assemStepNum << "] = " << (int) totalNucList[_assemStepNum] << " Mbps" << endl;
			}
		}
	};
	return totalNucList[_assemStepNum];
}; 


NucNum NucList::totalNucsFromBegining(size_t _assemStepNum)
{
	NucNum nucNum = 0;
	assemStepNum =  _assemStepNum;
	logger->out() << " assemStepNum = " << (int) assemStepNum << endl;
	logger->out().flush();
	for (size_t i = 0; i < assemStepNum; i++) 
	{
		logger->out() << " i = " << i << endl;
		logger->out().flush();
		nucNum += totalNucs(i);
		logger->out() << " nucNum = " << (int) nucNum << " Mbps" << endl;
		logger->out().flush();
	};
	return nucNum;
};

NucNum NucList::findLastNonZeroNucLib(Lib lib)
{
	size_t aStepNum = assemStepNum - 1;
	while ((nucListArchive[aStepNum][lib] == 0 ) && (aStepNum > 0))
	{
		logger->out() << "nucListArchive[" << (int) aStepNum << " ][" << (int) lib << "] = " << nucListArchive[aStepNum][lib] << endl;
		aStepNum --;
	}
	if ((nucListArchive[aStepNum][lib] == 0 ) && (aStepNum == 0)) // if logger->out() == NULL
	{
		logger->out() << "NucList::findLastNonZeroNucLib: descripancy in totalNuc count. nucListArchive[.][ " << (int) lib << " ] = 0" << endl;
		exitMsg(NULL, INTERNAL_WOW_ERROR);	
	}
	return nucListArchive[aStepNum][lib];
}

void	NucList::updateLastStepNucList(ColorsList & colorsList, ColorsStat & colorsStat, CovType newDesiredCoverage)
{ 
	logger->out() << " updateLastStepNucList begins." << endl;
	assemStepNum = colorsList.get_assemStepNo();
	logger->out() << " assemStepNum = " << assemStepNum << endl;
	logger->out() << " newDesiredCoverage = " << newDesiredCoverage << endl;
	if (assemStepNum > 0)
	{
		for (size_t i = 0; i < libNo; i++)
		{
			nucListArchive[assemStepNum - 1][i] = nucList[i];
			nucList[i] = 0;
		}
		colorsStat.clear_stat();
		Colors_List *activeColorList = colorsList.getActiveColorsList();
		for (size_t i = 0; i < activeColorList->listNo; i++)
		{
			Color newc = activeColorList->list[i];
			logger->out() << "color " << (int) newc << "in active list." << endl;
			LibraryList *libraryList = colorsList.getLibraryList(newc);
			logger->out() << "libraryList->listNo =  " << libraryList->listNo << endl;
			for (int l = 0; l < libraryList->listNo; l++)
			{
				Lib lib = libraryList->list[l];
				logger->out() << " libraryList->list[" << (int) l << " ] = " << (int) lib << endl;
				Color oldc = colorsList.getColors(lib + (assemStepNum - 1) * libNo);
				logger->out() << " colorsList.getColors(" << lib + (assemStepNum - 1) * libNo<< ") = " << (int) oldc << endl;
				Stat oldStat = colorsStat.get_stat(oldc);
				oldStat.averageCoverage /= oldStat.assemblySize;
				logger->out() << " oldStat.assemblySize = " << oldStat.assemblySize << endl;
				logger->out() << " oldStat.averageCoverage = " << oldStat.averageCoverage  << endl;
				Stat newStat;
				newStat.assemblySize = estimateNewAssemSize(oldStat);
				newStat.averageCoverage = newDesiredCoverage;
				size_t oldPopulation = colorsList.getColorPopulation(oldc);
				size_t newPopulation = libraryList->listNo;
				NucNum oldNucNum = findLastNonZeroNucLib(lib); 
				logger->out() << " oldPopulation = " << (int) oldPopulation  << endl;
				logger->out() << " oldNucNum = " << oldNucNum  << endl;
				logger->out() << " newPopulation = " << (int) newPopulation  << endl;
				logger->out() << " newStat.assemblySize = " << newStat.assemblySize << endl;
				logger->out() << " newStat.averageCoverage  = " << newStat.averageCoverage  << endl;

				NucNum nucNum = estimateNewNucNum(oldNucNum, oldPopulation, oldStat, newPopulation, newStat);
				nucList[lib] = nucNum;
				logger->out() << " nucList[" << (int) lib << " ] = " << nucNum << endl;
			}
		}
	}
	logger->out() << " updateLastStepNucList ends." << endl;

}

AssemblySize NucList::estimateNewAssemSize(Stat oldStat)
{
	AssemblySize assemTemp;
	double assemRatio = 0;
	if (oldStat.averageCoverage > 20)
	{
		assemRatio = 1;
	} else if (oldStat.averageCoverage > 15)
	{
		assemRatio = 1.2 * 0.001/5.0 * (oldStat.averageCoverage - 15) + 0.99; //(1 - 0.99)/(20 - 15)(ac - 15) + 0.99
	}else if (oldStat.averageCoverage > 10)
	{
		assemRatio = 1.2 * 0.11/5.0 * (oldStat.averageCoverage - 10) + 0.88; //(0.99 - 0.88)/(15 - 10)(ac - 10) + 0.88
	}else if (oldStat.averageCoverage > 5)
 	{
		assemRatio = 1.2 * 0.63/5.0 * (oldStat.averageCoverage - 5) + 0.25; //(0.88 - 0.25)/(10 - 5)(ac - 5) + 0.25
	}else if (oldStat.averageCoverage > 1)
 	{
		assemRatio = 1.2 * 0.20/4.0 * (oldStat.averageCoverage - 1) + 0.05; //(0.25 - 0.05)/(5 - 1)(ac - 1) + 0.05
	}else if (oldStat.averageCoverage > 0)
	{
		assemRatio = 1.2 * 0.05/1.0 * (oldStat.averageCoverage - 0.0) + 0.0; //(0.05 - 0.0)/(1 - 0)(ac - 0.0) + 0.0
 	}
	assemTemp = oldStat.assemblySize / assemRatio;
	return assemTemp;
}
NucNum	NucList::estimateNewNucNum(NucNum oldNucNo, size_t oldPopulation, Stat oldStat, size_t newPopulation, Stat newStat)
{
	NucNum estimatedNucNum;
	if (newStat.assemblySize == 0)
		newStat.assemblySize = oldStat.assemblySize;
	oldNucNo /= 1000;
	oldStat.assemblySize /= 1000;
 	newStat.assemblySize /= 1000;
	logger->out() << " ((double) oldPopulation / (double) newPopulation) = " << (double) oldPopulation / (double) newPopulation  << endl;
	logger->out() << " ((double) oldStat.assemblySize / (double) newStat.assemblySize) = " << (double) oldStat.assemblySize / (double) newStat.assemblySize  << endl;
	logger->out() << " ((CovType) newStat.averageCoverage /(CovType) oldStat.averageCoverage ) = " << (CovType) newStat.averageCoverage / (CovType) oldStat.averageCoverage   << endl;
	logger->out() << " newStat.averageCoverage  = " << newStat.averageCoverage  << endl;

	estimatedNucNum = (NucNum) ((double) oldNucNo * ((double) oldPopulation / (double) newPopulation) *  ((double) newStat.assemblySize / (double) oldStat.assemblySize) * ( (CovType) newStat.averageCoverage / (CovType) oldStat.averageCoverage )); 
	if (newPopulation == 1)
	{
		//estimatedNucNum = //??
	}
	estimatedNucNum *= 1000;
	logger->out() << " estimatedNucNum = " << (NucNum) estimatedNucNum  << endl;

	return estimatedNucNum;
}


NucNum	NucList::estimateNewNucNum(size_t newPopulation, CovType newDesiredCoverage, AssemblySize newEstimatedAssemblySize)
{
	NucNum estimatedNucNum;
	estimatedNucNum = (NucNum) ( newDesiredCoverage * newEstimatedAssemblySize) / (newPopulation); 
	if (newPopulation == 1)
	{
		//estimatedNucNum = //??
	}
	return estimatedNucNum;
}


