/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          import.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  03/13/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "getopt.h"
#include "importer.h"

#define FILE_STRING (char *)"import"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output file"),
	Option('q', (char *)"fastqlibrary", NEEDS_ARG, (char *)"=comma separated list, without space, of FASTQ file names in the library"),
	Option('f', (char *)"fastalibrary", NEEDS_ARG, (char *)"=comma separated list, without space, of FASTA file names in the library"),
	Option('t', (char *)"truncate", NEEDS_ARG, (char *)"=bad quality flag, truncate trailing nucleotides with the bad quality value in FASTQ files"),
	Option('l', (char *)"minlen", NEEDS_ARG, (char *)"=minimum length of a read (default 20)"),
	Option('n', (char *)"maxn", NEEDS_ARG, (char *)"=maximum number of N's in the relevant part of a read (default 4)"),
	Option(1, (char *)"fastqout", NO_ARG, (char *)"fastq output"),
	Option(0, NULL, 0, NULL)
};

int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	vector<Library<string> > inputLibs;
	string outputFile;
	bool truncate = false, fastqout = false;
	int maxN = 4;
	int minLen = 20;
	int BADQFLAG = 'B';
	time_t now;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
			fprintf(stderr, "Warning: additional argument %s is ignored.\n", current->getArg());
		else if (count == 'V')
			version(FILE_STRING);
		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options]\n");
			printf("       Output (FASTA by default) file name is identified by -O option.\n");
			printf("       Input files are identified by -q and -f options.\n");
			printf("       Example: %s -f=lib1-1.fasta,lib1-2.fasta -q=lib2-1.fastq,lib2-2.fastq -f=lib3.fasta -O=reads.fasta\n", FILE_STRING);
			printf("       Above, lib1-1.fasta and lib1-2.fasta are paired reads in library 0, lib2-1.fastq and lib2-2.fastq are paired reads in library 1, and lib3.fasta are single reads in library 2.\n");
			printf("%s\n", opts.help());
			exit(0);
		}
		else if (count == 1)
			fastqout = true;
		else if (count == 'O')
			outputFile = current->getArg();
		else if (count == 'q')
		{
			Library<string> lib;
			string lst = current->getArg();
			Importer::tokenize(lst, lib.files, ",");
			lib.fasta = false;
			inputLibs.push_back(lib);
		}
		else if (count == 'f')
		{
			Library<string> lib;
			string lst = current->getArg();
			Importer::tokenize(lst, lib.files, ",");
			lib.fasta = true;
			inputLibs.push_back(lib);
		}
		else if (count == 't')
		{
			truncate = true;
			BADQFLAG = current->getArg()[0];
		}
		else if (count == 'l')
			minLen = atoi(current->getArg());
		else if (count == 'n')
			maxN = atoi(current->getArg());
	}

	if(inputLibs.size() == 0)
	{
		fputs("Error: inputs not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}

	if(outputFile == "")
	{
		fputs("Error: output not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}

	Logger *logger = new Logger(outputFile+".log");

	string executedcommand; 

	for(int i = 0; i < argc; i++)
	{
		executedcommand += argv[i];
		executedcommand += " ";
	}
	executedcommand += "\n";

	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " has been executed on " + string(ctime(&now)));
	logger->out() << executedcommand << endl;
	version(logger->out(), FILE_STRING);
	logger->out() << "MAXK = " << MAXK << endl;
	logger->out() << "MAXCOLORS = " << MAXCOLORS << endl;
	logger->out().flush();


	Importer importer(logger, inputLibs, outputFile, truncate, fastqout, maxN, minLen, BADQFLAG);
	importer.openOutput();
	importer.import();
	importer.closeOutput();

	time(&now);
	logger->out() << "================================================" << endl;
	logger->report(string(FILE_STRING)+ " successfully concluded on " + string(ctime(&now)));

	delete logger;

	return NO_ERROR;
}

