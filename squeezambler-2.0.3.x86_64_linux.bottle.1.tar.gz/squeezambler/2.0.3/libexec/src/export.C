/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          export.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <set>
#include <fstream>
#include <iostream>
#include <map>

#include "common.h"
#include "reads.h"
#include "sequence.h"
#include "id.h"
#include "getopt.h"

#define FILE_STRING (char *)"export"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output prefix"),
	Option(0, NULL, 0, NULL)
};

struct Library {
	vector<string> filenames;
	bool fasta;
};

void tokenize(string & s, vector<string> & tokens, const string & del)
{
	string current = s;
	size_t pos;
	while((pos = current.find(del)) != string::npos)
	{
		tokens.push_back(current.substr(0, pos));
		current = current.substr(pos+del.size(), current.size() - pos - del.size());
	}
	tokens.push_back(current);
}

int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);
	
	string outputPrefix;
	string inputFilename;
	int files = 0;
	time_t now;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			if(!files)
			{
				inputFilename = current->getArg();
				files++;
			}
			else
				fprintf(stderr, "Warning: additional argument %s is ignored.\n", current->getArg());
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options]\n");
			printf("       Output FASTA files prefix is identified by -O option.\n");
			printf("%s\n", opts.help());
			exit(0);
		}
      		else if (count == 'O')
			outputPrefix = current->getArg();
	}

	if(outputPrefix == "" || !files)
	{
		fputs("Error: data not specified, try '", stderr);
		fputs(FILE_STRING, stderr);
		fputs(" -h' for help.\n", stderr);
		exit(1);
	}


	time(&now);
	printf("%s\n", ctime(&now));
	Reads reads;
	reads.initialize(inputFilename, true);
	map<int, ofstream*> outputs;

	Read read;	
	char buffer[10000];

	while(reads.next(&read, 0, 0, false, false))
	{
		int lib = read.getID().library();
		if(outputs.find(lib) == outputs.end())
		{
			strcpy(buffer, outputPrefix.c_str());
			sprintf(buffer, "%s.lib%d.fasta", buffer, lib);
			outputs[lib] = new ofstream;
			outputs[lib]->open(buffer, ios::out);
		} 
		read.print(*(outputs[lib]));
	}
	reads.finalize();	
	
	for(map<int, ofstream*>::iterator it = outputs.begin(); it != outputs.end(); it++)
	{
		it->second->close();
		delete it->second;
	}
	time(&now);
	printf("%s\n", ctime(&now));
}

