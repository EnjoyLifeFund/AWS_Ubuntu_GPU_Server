/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          kmers.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "kmers.h"


template<class Data, template<class Pair> class Container>
Kmers<Data, Container>::Kmers()
{
	table = new Container<KmerData<Data> >  *[kmerhashmax()+1];
	for(int i = 0; i <= kmerhashmax(); i++)
		table[i] = NULL;

	kmersNum = 0;
	threadsafe = false;
	gmutex = NULL;
}

template<class Data, template<class Pair> class Container>
Kmers<Data, Container>::~Kmers()
{
	if(table)
	{ 
		for(int i = 0; i <= kmerhashmax(); i++)
			if(table[i]) delete table[i];

		delete[] table;
	}

	if(gmutex) delete[] gmutex;
}

template<class Data, template<class Pair> class Container>
void Kmers<Data, Container>::insert(KmerData<Data> &pair)
{
	size_t h = hash(pair.first);

	if(threadsafe)
		pthread_mutex_lock(&gmutex[h]);

	if(!table[h])
		table[h] = new Container<KmerData<Data> >;

	if(table[h]->insert(pair))
#pragma omp atomic
		kmersNum++;

	if(threadsafe)
		pthread_mutex_unlock(&gmutex[h]);
}

template<class Data, template<class Pair> class Container>
bool Kmers<Data, Container>::fetch(Kmer & kmer, Data & data)
{
	KmerData<Data> *pair;
	fetch(kmer, pair);

	if(!pair)
		return false;
	else
	{
		data = pair->second;
		return true;
	}
}

template<class Data, template<class Pair> class Container>
void Kmers<Data, Container>::fetch(Kmer & kmer, KmerData<Data> *&pr)
{
	size_t h = hash(kmer);

	if(threadsafe)
		pthread_mutex_lock(&gmutex[h]);

	if(!table[h])
		pr = NULL;
	else
	{
		KmerData<Data> pair;
		pair.first = kmer;
	
		pr = table[h]->find(pair);
	}
	if(threadsafe)
		pthread_mutex_unlock(&gmutex[h]);
}

template<class Data, template<class Pair> class Container>
void Kmers<Data, Container>::begin() 
{
	idx = 0;
	while(table[idx] == NULL && idx <= kmerhashmax()) idx++;
	if(idx > kmerhashmax())
		return;

	spIndex = 0;
}

template<class Data, template<class Pair> class Container>
KmerData<Data>& Kmers<Data, Container>::next() 
{
	return table[idx]->item(spIndex++);
}

template<class Data, template<class Pair> class Container>
bool Kmers<Data, Container>::hasNext() 
{
	if(idx > kmerhashmax())
		return false;

	if(spIndex < table[idx]->size())
		return true;

	idx++;
	while(idx <= kmerhashmax() && table[idx] == NULL) idx++;
	if(idx > kmerhashmax())
		return false;
	else
	{
		spIndex = 0;
		return true;
	}
}

template<class Data, template<class Pair> class Container>
size_t Kmers<Data, Container>::count()
{
	size_t ret = 0;
	for(int i = 0; i <= kmerhashmax(); i++)
		if(table[i]) ret += table[i]->size();

	return ret;
}

template<class Data, template<class Pair> class Container>
void Kmers<Data, Container>::setThreadSafe(bool t) 
{
	if(t) 
	{
		gmutex = new pthread_mutex_t[kmerhashmax()+1];
		for(long int i = 0; i <= kmerhashmax(); i++)
			pthread_mutex_init(&gmutex[i], NULL);
	} 
	else 
	{
		for(long int i = 0; i <= kmerhashmax(); i++)
			pthread_mutex_destroy(&gmutex[i]);
		if(gmutex) delete gmutex;
		gmutex = NULL;
	}

	threadsafe = t;
}

template<class Data, template<class Pair> class Container>
void Kmers<Data, Container>::setContainersThreadSafe(bool t) 
{
	for(long int i = 0; i <= kmerhashmax(); i++)
		if(table[i])
			table[i]->setThreadSafe(t);
}

