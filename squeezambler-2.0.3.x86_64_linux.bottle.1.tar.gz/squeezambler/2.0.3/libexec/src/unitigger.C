/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          unitigger.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  09/19/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "unitigger.h"
#include "implicitgraph.C"

// The program handles all lengths correctly. This is just a convenient constant.
#define LONG_READ_LENGTH 5000
#define MAX_BUF_SIZE 100000
#define DONTCARE_COLOR (-1)
#define JOBS_PER_PROC 64


template class ImplicitGraph<CompactNodeInfo>;
template class ImplicitGraph<SemicompactNodeInfo>;

template <class NodeInfo>
Unitigger<NodeInfo>::Unitigger(string _inputFilename,
	string _outputName,
	string _configFilename,
	int _machines, int _slice,
	bool _fasta,
	int _procs,
	bool _doublestrand,
	int _k,
	bool _exportkmers,
	ImplicitGraph<NodeInfo> *g,
	Logger *_logger)
{
	inputFilename = _inputFilename;
	outputName = _outputName;
	configFilename = _configFilename;
	machines = _machines, slice = _slice;
	fasta = _fasta;
	procs = _procs;
	doublestrand = _doublestrand;
	k = _k;
	exportkmers = _exportkmers;
	logger = _logger;
	graph = g;

	logger->setSection("loading colorings");
	FILE *cfgFile = NULL;

	if(configFilename != "")
		cfgFile = open_file(configFilename.c_str(), "rt");

	loadConfigFile(cfgFile);
	if(cfgFile)
		fclose(cfgFile);
		
	logger->setSection("indexing kmers");

	kforge.reset(k);

	makeGraph(inputFilename);

	logger->setSection("unitiging");

	if(exportkmers)
		exportKmers(outputName, slice);

	char buf[MAX_BUF_SIZE];
	sprintf(buf, ".slice%d", slice);
	string sliceName = buf;

	condenseGraph(outputName+((machines > 1) ? sliceName : "")+".unitigs");

	if(g == NULL)
		delete graph;
}

template <class NodeInfo>
Unitigger<NodeInfo>::Unitigger(string _inputFilename,
	string _outputName,
	Color _colors[MAXLIBRARIES],
	int _machines, int _slice,
	bool _fasta,
	int _procs,
	bool _doublestrand,
	int _k,
	bool _exportkmers,
	ImplicitGraph<NodeInfo> *g,
	Logger *_logger)
{
	inputFilename = _inputFilename;
	outputName = _outputName;
	machines = _machines, slice = _slice;
	fasta = _fasta;
	procs = _procs;
	doublestrand = _doublestrand;
	k = _k;
	exportkmers = _exportkmers;
	logger = _logger;
	graph = g;

	for(int i = 0; i < MAXLIBRARIES; i++)
	{
		colors[i] = _colors[i];
		if(colors[i] >= MAXCOLORS)
		{
			cerr << "MAXCOLORS = " << MAXCOLORS << " - colors[" << i <<"] = " << (int) colors[i] << endl;
			exitMsg((char*)"Error: color number in the input color configs is greater than MAXCOLORS. Recompile with larger MAXCOLORS.", CONFIG_FILE_ERROR);
		}
	}

	logger->setSection("indexing kmers");

	kforge.reset(k);

	makeGraph(inputFilename);

	logger->setSection("unitiging");

	if(exportkmers)
		exportKmers(outputName, slice);

	char buf[MAX_BUF_SIZE];
	sprintf(buf, ".slice%d", slice);
	string sliceName = buf;

	condenseGraph(outputName+((machines > 1) ? sliceName : "")+".unitigs");

	if(g == NULL)
		delete graph;
}

template <class NodeInfo>
void Unitigger<NodeInfo>::exportKmers(string outputName, int slice)
{
	KmerData<NodeInfo> node;
	
	char *buf = new char[outputName.length() + 20];
	sprintf(buf, "%s.s%d.kmers", (char *)outputName.c_str(), slice);
	FILE *out = open_file(buf, "wt");
	delete buf;

	logger->report("Writing kmers...");

	graph->print(out, false);

	fclose(out);

	logger->report("Done.");
}

template <class NodeInfo>
void Unitigger<NodeInfo>::index(Read & r, size_t & current)
{
	Kmer kmer;
	Kmer dualkmer;
			
	int len = r.size();
	
	if(len <= k || colors[r.getID().library()] == DONTCARE_COLOR)
		return;

	int threadsnum = graph->setThreadsNum(1);

	for(int i = 0; i < len; i++)
	{
		Nucleotide nuc = r[i];
		kforge.push_end(kmer, nuc);
		if(doublestrand)
			kforge.push_begin(dualkmer, dualnuc(nuc));
	
		if(i == k-1)
			graph->insertout(kmer, dualkmer, r[i+1], colors[r.getID().library()]);  
		else if(i == len-1)
			graph->insertin(kmer, dualkmer, r[i-k], colors[r.getID().library()]);  
		else if(i > k-1)
			graph->insertio(kmer, dualkmer, r[i-k], r[i+1], colors[r.getID().library()]); 

		
	}
	current++;

	if(!(current % 10000))
		logger->out() << "Distinct vertices so far: " << graph->size() << " in " << current << " reads." << endl; 

	graph->setThreadsNum(threadsnum);
}

template <class NodeInfo>
void Unitigger<NodeInfo>::index(Reads & reads)
{
	bool done = false;
	Coordinate maxReadLen = 0;

	size_t current = 0;
	int thisprocs = MAX(1, procs);
	int jobs = (thisprocs > 1) ? JOBS_PER_PROC * thisprocs : 1;

	Read *read = new Read[jobs];
	bool *load = new bool[jobs];
	size_t *sizes = new size_t[jobs];
	Kmer **akmer = new Kmer*[jobs];
	Kmer **adualkmer = new Kmer*[jobs];
	Nucleotide **anucs[2];
	anucs[0] = new Nucleotide*[jobs];
	anucs[1] = new Nucleotide*[jobs];

	for(int i = 0; i < jobs; i++)
	{
		sizes[i] = LONG_READ_LENGTH;
		akmer[i] = new Kmer[sizes[i]];
		adualkmer[i] = new Kmer[sizes[i]];
		anucs[0][i] = new Nucleotide[sizes[i]];
		anucs[1][i] = new Nucleotide[sizes[i]];
	}

	graph->setThreadsNum(thisprocs);

	while(!done)
	{

		int jb = 0;
		for(int i = 0; i < jobs; i++)
			load[i] = false;

		while(jb < jobs && !done)
		{
			load[jb] = reads.next(&read[jb], 0, 0, false);
			if(!load[jb])
				done = true;

			if(load[jb] && colors[read[jb].getID().library()] == DONTCARE_COLOR)
				continue;

			if(load[jb] && read[jb].size() > maxReadLen)
				maxReadLen = read[jb].size();

			if(load[jb] && read[jb].size() >= LONG_READ_LENGTH)
				index(read[jb], current);
			else
				jb++;
		}

#pragma omp parallel for schedule(dynamic) num_threads(thisprocs) 
		for(int job = 0; job < jobs; job++)
		{
			Nucleotide *nucs[2];
			Kmer *kmer, *dualkmer, localkmer, localdualkmer;
			size_t sz;

			if(load[job] && (sz = read[job].size()) > k)
			{
				if(sz > sizes[job])
				{
					sizes[job] = sz+1;
					delete akmer[job];
					akmer[job] = new Kmer[sizes[job]];
					delete adualkmer[job];
					adualkmer[job] = new Kmer[sizes[job]];
					delete anucs[0][job];
					anucs[0][job] = new Nucleotide[sizes[job]];
					delete anucs[1][job];
					anucs[1][job] = new Nucleotide[sizes[job]];
				}
	
				kmer = akmer[job];
				dualkmer = adualkmer[job];
				nucs[0] = anucs[0][job];
				nucs[1] = anucs[1][job];

				for(int i = 0; i < sz; i++)
					nucs[1][i] = dualnuc(nucs[0][i] = read[job][i]);

				for(int i = 0; i < k; i++)
				{
					kforge.push_end(kmer[0], nucs[0][i]);
					if(doublestrand)
						kforge.push_begin(dualkmer[0], nucs[1][i]);
				}
				localkmer = kmer[0];
				localdualkmer = dualkmer[0];

				for(int i = 1, idx = k; i < sz-k+1; i++, idx++)
				{
					kforge.push_end(localkmer, nucs[0][idx]);
					kmer[i] = localkmer;
					if(doublestrand)
					{
						kforge.push_begin(localdualkmer, nucs[1][idx]);
						dualkmer[i] = localdualkmer;
					}
				}
			}
		}

#pragma omp parallel for schedule(dynamic) num_threads(thisprocs)
		for(int prc = 0; prc < thisprocs; prc++)
			for(int job = 0; job < jobs; job++)
			{
				Nucleotide *nucs[2];
				Kmer *kmer, *dualkmer;
				size_t sz;
				if(load[job] && (sz = read[job].size()) > k)
				{
					kmer = akmer[job];
					dualkmer = adualkmer[job];
					nucs[0] = anucs[0][job];
					nucs[1] = anucs[1][job];

					graph->insertout(kmer[0], dualkmer[0], nucs[0][k], colors[read[job].getID().library()], prc);  
					
					int i = 1;
					for(; i < sz-k; i++)
						graph->insertio(kmer[i], dualkmer[i], nucs[0][i-1], nucs[0][i+k], colors[read[job].getID().library()], prc);  

					graph->insertin(kmer[i], dualkmer[i], nucs[0][i-1], colors[read[job].getID().library()], prc);  
				}
			}

		for(int job = 0; job < jobs; job++)
		{
			if(load[job])
			{
				current++;
				if(!(current % 10000))
					logger->out() << "Distinct vertices so far: " << graph->size() << " in " << current << " reads." << endl;
			} else
				done = true;
		}
	}

	for(int i = 0; i < jobs; i++)
	{
		delete[] akmer[i];
		delete[] adualkmer[i];
		delete[] anucs[0][i];
		delete[] anucs[1][i];
	}
	delete[] read;
	delete[] load;
	delete[] sizes;
	delete[] akmer;
	delete[] adualkmer;
	delete[] anucs[0];
	delete[] anucs[1];

}

template <class NodeInfo>
void Unitigger<NodeInfo>::makeGraph(string inputFilename)
{
	size_t kmersnum, totalkmersnum;

	if(!graph)
		graph = new ImplicitGraph<NodeInfo>(k, slice, machines, doublestrand, logger);

	Reads reads;

	reads.initialize(inputFilename, fasta);

	index(reads); 

	reads.finalize();

	kmersnum = graph->size();
	logger->out() << "Totally " << kmersnum << " distinct " << k << "-mers" << ((doublestrand) ? " modulo duality." : ".") << endl; 

	graph->setContainersThreadSafe(true);
}

template <class NodeInfo>
void Unitigger<NodeInfo>::condense(Kmer &kmer, Direction direction, Serial &number, size_t *kmersNum, FILE *out)
{
	Unitig unitig;
	ExitType exitType;

	if(!doublestrand && direction == DIR_BACKWARD)
		exitMsg((char*)"Error: single stranded assembly and traversing backwards.", INTERNAL_WOW_ERROR);
	

	graph->transfer(kmer, direction, unitig, exitType);

	if(exitType != TR_NULL)
	{
		if(direction == DIR_FORWARD)
			unitig.edges = setmix(unitig.begin_edges, unitig.end_edges);
		else
			unitig.edges = setmix(unitig.end_edges, unitig.begin_edges);

		unitig.save(out);
		number++;

		int pntr = LOW_COV_DISCRIMINANT-1;
		for(int i = 0; i < LOW_COV_DISCRIMINANT-1; i++)
		{
			if(unitig.coverage.max() < (i+MIN_COV_THRESH)*(unitig.length()-k+1))
			{
				pntr = i;
				break;
			}
		}

		if(unitig.length() == k)
			kmersNum[pntr]++;
		else
			kmersNum[pntr] += 2;
	}
}

template <class NodeInfo>
void Unitigger<NodeInfo>::condenseGraph(string outputFilename)
{
	KmerData<NodeInfo> node;
	
	FILE *out = open_file(outputFilename, (const char *)"wb");

	logger->report("Condensing graph...");

	Serial number = 0;
	size_t kmersNum[LOW_COV_DISCRIMINANT];

	for(int i = 0; i < LOW_COV_DISCRIMINANT; i++)
		kmersNum[i] = 0;

	graph->begin();

	while(graph->hasNext())
	{
		node = graph->next();
		if(graph->indegree(node.second) > 1 || graph->outdegree(node.second) == 0)
		{
			if(doublestrand)			
				for(int i = 0; i < graph->indegree(node.second); i++)
				{
					Kmer kmer = node.first;
					kforge.push_begin(kmer, graph->innuc(node.second)[i]);
					condense(kmer, DIR_BACKWARD, number, kmersNum, out);
				}
		}

		if(graph->outdegree(node.second) > 1 || graph->indegree(node.second) == 0)
		{
			for(int i = 0; i < graph->outdegree(node.second); i++)
			{
				Kmer kmer = node.first;
				kforge.push_end(kmer, graph->outnuc(node.second)[i]);
				condense(kmer, DIR_FORWARD, number, kmersNum, out);
			}
		}
	}

	graph->begin();
	while(graph->hasNext())
	{
		node = graph->next();
		if(!node.second.isVisited())
		{
			Direction direction;

			if(graph->indegree(node.second) == 1 && doublestrand)
				direction = DIR_BACKWARD;
			else
				direction = DIR_FORWARD;

			condense(node.first, direction, number, kmersNum, out);
		}
	}

	write_in_file(kmersNum, sizeof(size_t), LOW_COV_DISCRIMINANT, out); 
	write_in_file(&number, sizeof(Serial), 1, out); 
	write_in_file(&k, sizeof(int), 1, out); 

	fclose(out);

//	delete graph;

	logger->report("Done.");
}

template <class NodeInfo>
void Unitigger<NodeInfo>::loadConfigFile(FILE *cfgfile)
{
	char buf[MAX_BUF_SIZE];

	for(int i = 0; i < MAXLIBRARIES; i++)
		colors[i] = 0;

	if(!cfgfile)
		logger->out() << "No coloring config file given, hence, all libraries are by default colored 0." << endl;
	else
	{
		logger->out() << "All libraries are by default colored 0." << endl;

		while(!feof(cfgfile))
		{
			fgets(buf, MAX_BUF_SIZE, cfgfile);
			if(buf[0] != '#' && buf[0] != EOF && buf[0] != '\n')
			{
				int lib, c;

				sscanf(buf, "%d\t%d\n", &lib, &c);
				if(c >= MAXCOLORS)
				{
					cerr << "MAXCOLORS = " << MAXCOLORS << endl;
					exitMsg((char*)"Error: color number in the config file is greater than MAXCOLORS. Recompile with larger MAXCOLORS.", CONFIG_FILE_ERROR);
				}

				colors[lib] = (Color)c;

				if(c != DONTCARE_COLOR)
					logger->out() << "Library " << lib << " is colored " << c << "." << endl;
				else
					logger->out() << "Library " << lib << " is ignored, i.e. not included in the assembly." << endl;
			}
		}
	}
}

