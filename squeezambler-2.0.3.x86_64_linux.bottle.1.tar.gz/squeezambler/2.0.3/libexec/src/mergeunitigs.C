/*
Copyright 2012- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          mergeunitigs.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2012
 * Last modified:  04/14/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <stdlib.h>
#include <vector>

#include "unitig.h"
#include "getopt.h"

using namespace std;

#define FILE_STRING (char *)"mergeunitigs"

Option OPTIONS[] = {
	Option('V', (char *)"version", NO_ARG, (char *)"prints the version"),
	Option('h', (char *)"help", NO_ARG, (char *)"shows this help"),
	Option('O', (char *)"output", NEEDS_ARG, (char *)"=output file (mandatory)"),
	Option('i', (char *)"ignoremultik", NO_ARG, (char *)"ignore the case that input unitigs are assembled with different k-mer sizes"),
	Option(0, NULL, 0, NULL)
};


int main(int argc, char *argv[])
{
	GetOpt opts(argc, argv, OPTIONS);

	string outputFilename;
	vector<string> filenames;
	bool ignoremultik = false;

	while (opts.hasNext())
	{
		Option *current = opts.next();
		char count = current->getShortForm();

		if (count == FREE_ARG)
		{
			string fname = current->getArg();
			filenames.push_back(fname);			
		}
      		else if (count == 'V')
			version(FILE_STRING);
      		else if (count == 'h')
		{
			printf("Usage: ");
			printf(FILE_STRING);
			printf(" [options] unitigs_file1 unitigs_file2 unitigs_file3 ...\n");
			printf("       Output file is identified by -O option.\n");
			printf("%s\n", opts.help());
			exitMsg(NULL, NO_ERROR);
		}
		else if (count == 'O')
			outputFilename = current->getArg();
		else if (count == 'i')
			ignoremultik = true;
	}

	if(filenames.size() == 0)
		exitMsg((char *)"No input is given. Try '-h' option for help.", INPUT_ARG_ERROR);

	FILE *output = open_file(outputFilename, (const char *)"wb");;

	size_t gkmersNum[LOW_COV_DISCRIMINANT];
	Serial gunitigsNum = 0;
	int gk = 0;

	for(int i = 0; i < LOW_COV_DISCRIMINANT; i++)
		gkmersNum[i] = 0;

	for(int i = 0; i < filenames.size(); i++)
	{
		FILE *unitigs = open_file(filenames[i], (const char *)"rb");

		fseek(unitigs, -(long int)(LOW_COV_DISCRIMINANT*sizeof(size_t)+sizeof(Serial)+sizeof(int)), SEEK_END);

		size_t kmersNum[LOW_COV_DISCRIMINANT];
		Serial unitigsNum;
		int k;

		read_from_file(kmersNum, sizeof(size_t), LOW_COV_DISCRIMINANT, unitigs); 
		read_from_file(&unitigsNum, sizeof(Serial), 1, unitigs); 
		read_from_file(&k, sizeof(int), 1, unitigs); 
		
		if(gk == 0)
			gk = k;
		else if(gk != k && !ignoremultik)
			exitMsg((char*)"Error: these unitigs are assembled with different k-mer sizes.", UNITIGS_FILE_ERROR);

		for(int j = 0; j < LOW_COV_DISCRIMINANT; j++)
			gkmersNum[j] += kmersNum[j];

		gunitigsNum += unitigsNum;

		rewind(unitigs);

		for(Serial number = 0; number < unitigsNum; number++)
		{
			Unitig unitig;

			unitig.load(unitigs);
			unitig.save(output);

			if(ignoremultik && k != gk && unitig.length() == k)
			{
				int pntr = LOW_COV_DISCRIMINANT-1;
				for(int i = 0; i < LOW_COV_DISCRIMINANT-1; i++)
				{
					if(unitig.coverage.max() < (i+MIN_COV_THRESH)*(unitig.length()-k+1))
					{
						pntr = i;
						break;
					}
				}

				gkmersNum[pntr]++;
			}
		}
	
		fclose(unitigs);
	}

	write_in_file(gkmersNum, sizeof(size_t), LOW_COV_DISCRIMINANT, output); 
	write_in_file(&gunitigsNum, sizeof(Serial), 1, output); 
	write_in_file(&gk, sizeof(int), 1, output); 

	fclose(output);

	return 0;
}
