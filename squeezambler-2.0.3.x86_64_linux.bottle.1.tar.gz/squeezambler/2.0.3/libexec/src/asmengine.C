/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************************************
 * Title:          asmengine.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  09/19/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "asmengine.h"
#include "unitig.h"

#include "bag.C"

#define COLOR_STR_LENGTH 1024

AsmEngine::AsmEngine(string _inputFilename, string _unitigFilename, string _configFilename, string _outputName, bool _fasta, int _procs, bool _doublestrand, bool _loadLowCovKmers, Logger *_logger)
{
	logger = _logger;
	inputFilename = _inputFilename;
	unitigFilename = _unitigFilename;
	configFilename = _configFilename;
	outputName = _outputName;

	fasta = _fasta;
	procs = MAX(1, _procs);
	doublestrand = _doublestrand;
	loadLowCovKmers = _loadLowCovKmers;
	cgraph = NULL;
	memset(kmersNum, 0, sizeof(size_t)*LOW_COV_DISCRIMINANT);
	k = 0;

	loadConfig();
}

AsmEngine::~AsmEngine()
{
	if(cgraph) delete cgraph;
}

void AsmEngine::saveCG(string filename)
{
	FILE *outf = open_file((char*)filename.c_str(), "wb");

	write_in_file((void *)&k, sizeof(int), 1, outf);
	write_in_file((void *)&unitigsNum, sizeof(size_t), 1, outf);
 	
	cgraph->save(outf);

	fclose(outf);
}

void AsmEngine::loadCG(string filename)
{
	FILE *inf = open_file((char*)filename.c_str(), "rb");

	read_from_file((void *)&k, sizeof(int), 1, inf);
	read_from_file((void *)&unitigsNum, sizeof(size_t), 1, inf);

	cgraph = new Graph(k, procs);

	cgraph->load(inf);

	fclose(inf);
	kforge.reset(k);
}

void AsmEngine::exportG(int vrsn, int maxins)
{
	ofstream out;
	char *buf = new char[outputName.length() + 800];
	sprintf(buf, "%s.cgraph.v%d.dot", (char *)outputName.c_str(), vrsn);
	out.open(buf, ios::out);
	delete[] buf;

	cgraph->exportGraph(maxins, out);

	out.close();
}

void AsmEngine::loadConfig()
{
	logger->report("Loading configs...");

	for(int i = 0; i < __MAXCONFIGS; i++)
		matingInfo[i].pieces = 0;

	configs = 0;
	if(configFilename != "")
	{
		FILE *cf = open_file((char *)configFilename.c_str(), "rt");
		char line[__MAXLINE];
		int cfg = 0;
		int maxlib = 0;
		
		while(!feof(cf) && cfg < __MAXCONFIGS)
		{
			if(!fgets(line, __MAXLINE, cf))
				break;
			if(!strcmp(line, ""))
				break;
			if(line[0] != '#' && line[0] != '\n' && line[0] != '\t')
			{
				Record record(line);
				unsigned int lib = atoi(record[0]);
				if(lib >= MAXLIBRARIES)
					exitMsg((char*)"Error: AsmEngine panic: library number in the config file is greater than max.", CONFIG_FILE_ERROR);
				if(lib > maxlib)
					maxlib = lib;
				matingInfo[cfg].confignum = cfg;
				matingInfo[cfg].lib = lib;
				matingInfo[cfg].maxlib = maxlib;
				matingInfo[cfg].pieces = atoi(record[1]);
				if(matingInfo[cfg].pieces > MAXPIECES)
					exitMsg((char*)"Error: AsmEngine panic: number of pieces in the config file is greater than max.", CONFIG_FILE_ERROR);
				for(unsigned int i = 0; i < matingInfo[cfg].pieces; i++)
				{
					if(record[i+2][0] == '>')
						matingInfo[cfg].dirs[i] = DIR_FORWARD;
					else if(record[i+2][0] == '<') 
						matingInfo[cfg].dirs[i] = DIR_BACKWARD;
					else
						exitMsg((char*)"Error: AsmEngine panic: invalid direction in the config file.", CONFIG_FILE_ERROR);
				}
				matingInfo[cfg].insertMin = atoi(record[matingInfo[cfg].pieces+2]);
				matingInfo[cfg].insertMax = atoi(record[matingInfo[cfg].pieces+3]);
				matingInfo[cfg].insertMean = (matingInfo[cfg].insertMin + matingInfo[cfg].insertMax) / 2;
				matingInfo[cfg].tolerance = (matingInfo[cfg].insertMax - matingInfo[cfg].insertMin) / 2;
				matingConfigs[lib].append(&(matingInfo[cfg]));
				cfg++;
			}
		}
		configs = cfg;
		
		fclose(cf);
	}	

	logger->report("Done.");
}

void AsmEngine::makeCGraph()
{
	FILE *unitigs = open_file(unitigFilename, "rb");
	UnitigSerial unitigSerial = 1;
	size_t thiskmersNum = 0, checkKmersNum = 0;
	
	logger->report("Indexing kmers and creating nodes...");

	fseek(unitigs, -(long int)(sizeof(size_t)*LOW_COV_DISCRIMINANT+sizeof(Serial)+sizeof(int)), SEEK_END);

	read_from_file(kmersNum, sizeof(size_t), LOW_COV_DISCRIMINANT, unitigs); 
	read_from_file(&unitigsNum, sizeof(Serial), 1, unitigs); 
	read_from_file(&k, sizeof(int), 1, unitigs); 

	rewind(unitigs);

	for(int i = 0; i < LOW_COV_DISCRIMINANT; i++)
		thiskmersNum += kmersNum[i];

	if(!loadLowCovKmers)
		thiskmersNum -= kmersNum[0];
	
	logger->out() << "Totally " << unitigsNum << " unitigs containing " << thiskmersNum << " end kmers to be indexed, " << "k = " << k << "." << endl;
	kforge.reset(k);

	KmerData<CNode *> *index = new KmerData<CNode *>[thiskmersNum];
	cgraph = new Graph(k, procs);

	for(Serial number = 0; number < unitigsNum; number++)
	{
		Unitig unitig;

		unitig.load(unitigs);

		if(loadLowCovKmers || (unitig.coverage.max() >= MIN_COV_THRESH*(unitig.length()-k+1)))
		{
			if(checkKmersNum >= thiskmersNum)
				exitMsg((char *)"Error: AsmEngine panic: serious trouble.\n", INTERNAL_WOW_ERROR);


			CNode *cnode = cgraph->newNode(unitigSerial, unitig.length(), unitig.coverage);

			Nucleotide *nucs = new Nucleotide[unitig.length()];

			unitig.getnucs(nucs);

			for(Coordinate i = 0; i < k; i++)
				kforge.push_end(index[checkKmersNum].first, nucs[i]);

			index[checkKmersNum].second = cnode;
			checkKmersNum++;

			if(unitig.length() > k)
			{
				for(Coordinate i = unitig.length()-k; i < unitig.length(); i++)
					kforge.push_end(index[checkKmersNum].first, nucs[i]);

				index[checkKmersNum].second = cnode;
				checkKmersNum++;
			}

			unitigSerial++;

			delete[] nucs;
		}
	}

	if(checkKmersNum != thiskmersNum)
		exitMsg((char *)"Error: AsmEngine panic: imbalance sheet.\n", INTERNAL_WOW_ERROR);


	effectiveKmersNum = checkKmersNum;

	sort(index, index+effectiveKmersNum);

	logger->report("Done.");

	rewind(unitigs);

	unitigSerial = 1;

	logger->report("Connecting nodes...");

	size_t maxLocalSearchKmersNum = effectiveKmersNum / (log(effectiveKmersNum) + 1), localSearchKmersNum = 0;

	KmerData<UnitigConnection> *searchlist = new KmerData<UnitigConnection>[maxLocalSearchKmersNum + NUCS*8]; // Allow a little room to avoid partially processed unitigs

	for(Serial number = 0; number < unitigsNum; number++)
	{
		if(localSearchKmersNum >= maxLocalSearchKmersNum)
		{
//			sort(searchlist, searchlist+localSearchKmersNum);
//			connectUnitigsP(searchlist, localSearchKmersNum, index); // progressive
			connectUnitigsBS(searchlist, localSearchKmersNum, index); // binary search

			localSearchKmersNum = 0; 
		}

		Unitig unitig;

		unitig.load(unitigs);

		Edges maskin = 0x80, maskout = 0x01;

		if(loadLowCovKmers || (unitig.coverage.max() >= MIN_COV_THRESH*(unitig.length()-k+1))) 
		{
			Nucleotide *nucs = new Nucleotide[unitig.length()];

			unitig.getnucs(nucs);

			for(Nucleotide n = 0; n < NUCS; n++) 
			{
				if(maskin & unitig.edges)
				{
					kforge.push_end(searchlist[localSearchKmersNum].first, n);

					for(Coordinate i = 0; i < k-1; i++)
						kforge.push_end(searchlist[localSearchKmersNum].first, nucs[i]);

					searchlist[localSearchKmersNum].second.serial = unitigSerial;
					searchlist[localSearchKmersNum].second.dir = KMER_TO_UNITIG;
					localSearchKmersNum++;

					if(doublestrand)
					{
						searchlist[localSearchKmersNum].first = kforge.dual(searchlist[localSearchKmersNum-1].first);
						searchlist[localSearchKmersNum].second.serial = -unitigSerial;
						searchlist[localSearchKmersNum].second.dir = UNITIG_TO_KMER;
						localSearchKmersNum++;
					}
				}

				if(maskout & unitig.edges)
				{
					for(Coordinate i = unitig.length()-k+1; i < unitig.length(); i++)
						kforge.push_end(searchlist[localSearchKmersNum].first, nucs[i]);

					kforge.push_end(searchlist[localSearchKmersNum].first, n);
	
					searchlist[localSearchKmersNum].second.serial = unitigSerial;
					searchlist[localSearchKmersNum].second.dir = UNITIG_TO_KMER;
					localSearchKmersNum++;

					if(doublestrand)
					{
						searchlist[localSearchKmersNum].first = kforge.dual(searchlist[localSearchKmersNum-1].first);
						searchlist[localSearchKmersNum].second.serial = -unitigSerial;
						searchlist[localSearchKmersNum].second.dir = KMER_TO_UNITIG;
						localSearchKmersNum++;
					}
				}

				maskin = maskin >> 1;
				maskout = maskout << 1;
			}

			delete[] nucs;

			unitigSerial++;
		}
	}

	if(localSearchKmersNum > 0)
	{
//		sort(searchlist, searchlist+localSearchKmersNum); // O(mlog(m))
//		connectUnitigsP(searchlist, localSearchKmersNum, index); // progressive O(m+n) algorithm
		connectUnitigsBS(searchlist, localSearchKmersNum, index); // binary search O(mlog(n)) algorithm

		localSearchKmersNum = 0; 
	}


	logger->report("Done.");


	delete[] searchlist;
	delete[] index;

	fclose(unitigs);
}


void AsmEngine::connectUnitigsBS(KmerData<UnitigConnection> *searchlist, size_t num, KmerData<CNode *> *index)
{
//	size_t chunkSize = num / procs;

	CNodeID *froms = new CNodeID[num], *tos = new CNodeID[num];


#pragma omp parallel for schedule(dynamic) num_threads(procs)
	for(int p = 0; p < procs; p++)
	{
//		size_t start = p * chunkSize;
//		size_t end = MIN(num, (p+1) * chunkSize);
		
		size_t bindex = 0;
		size_t eindex = effectiveKmersNum-1;

		for(size_t searchindex = p; searchindex < num; searchindex += procs)
		{
			long int up = bindex, down = eindex;	
			while(up <= down)
			{
				long int mid = (up + down) / 2;
				int cmp = kmercmp(searchlist[searchindex].first, index[mid].first);
				if(cmp < 0)
					down = mid - 1;
				else if(cmp > 0)
					up = mid + 1;
				else
				{
					CNodeID from(index[mid].second), to(cgraph->node(abs(searchlist[searchindex].second.serial)-1));

					if(searchlist[searchindex].second.serial < 0)
						to = -to;

					if(searchlist[searchindex].second.dir == UNITIG_TO_KMER)
					{
						CNodeID temp = to;
						to = from;
						from = temp;
					}

					froms[searchindex] = from;
					tos[searchindex] = to;

					up = mid;
					down = mid;

					break;
				}				
			}

//			bindex = up;	// only if sorted
		}
	}

	for(size_t i = 0; i < num; i++)
		if(froms[i] && tos[i])
			cgraph->connect(froms[i], tos[i]);

	delete[] froms, tos;
}

void AsmEngine::connectUnitigsP(KmerData<UnitigConnection> *searchlist, size_t num, KmerData<CNode *> *index)
{
	int thisprocs = procs; // we need a better parallelization. for now let's do it on a single processor.

	size_t chunkSize = effectiveKmersNum / thisprocs;

	CNodeID **froms = new CNodeID*[thisprocs], **tos = new CNodeID*[thisprocs];
	size_t *connections = new size_t[thisprocs];



	for(int p = 0; p < thisprocs; p++)
	{
		froms[p] = (CNodeID *)alloc.xmalloc(sizeof(CNodeID)*num);
		tos[p] = (CNodeID *)alloc.xmalloc(sizeof(CNodeID)*num);
		connections[p] = 0;
	}


#pragma omp parallel for schedule(dynamic) num_threads(thisprocs)
	for(int p = 0; p < thisprocs; p++)
	{
		size_t start = p * chunkSize;
		size_t end = MIN(effectiveKmersNum, (p+1) * chunkSize);
		
		size_t searchindex = 0;
		size_t indexindex = start;

		CNodeID *fs = froms[p], *ts = tos[p];

		while(searchindex < num && indexindex < end)
		{
			int cmp = kmercmp(searchlist[searchindex].first, index[indexindex].first);

			if(cmp < 0)
				searchindex++;
			else if(cmp > 0)
				indexindex++;
			else
			{
				CNodeID from(index[indexindex].second), to(cgraph->node(abs(searchlist[searchindex].second.serial)-1));

				if(searchlist[searchindex].second.serial < 0)
					to = -to;

				if(searchlist[searchindex].second.dir == UNITIG_TO_KMER)
				{
					CNodeID temp = to;
					to = from;
					from = temp;
				}

				fs[connections[p]] = from;
				ts[connections[p]++] = to;

				searchindex++; // there may be multiple instances of the same kmer in the search list, so it is important to pass only over the search list. 
			}				
		}
	}

	for(int p = 0; p < thisprocs; p++)
	{
		for(size_t i = 0; i < connections[p]; i++)
			cgraph->connect(froms[p][i], tos[p][i]);
	}

	for(int p = 0; p < thisprocs; p++)
	{
		alloc.xfree((void*&)froms[p]);
		alloc.xfree((void*&)tos[p]);
	}
	

	delete[] froms, tos;
	delete[] connections;
}


void AsmEngine::joinContigs()
{
	logger->report("Joining contigs...");

	logger->out() << "Starting with " << cgraph->size() << " nodes." << endl;

	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		for(int i = 0; i < cnodeid.indegree(); i++)
		{
			CNodeID innode = cnodeid.in(i);
			if(innode.removed())
				exitMsg((char*)"Error: AsmEngine panic: a deleted ghost node!!!", INTERNAL_WOW_ERROR); 
		}		

		for(int i = 0; i < cnodeid.outdegree(); i++)
		{
			CNodeID outnode = cnodeid.out(i);
			if(outnode.removed())
				exitMsg((char*)"Error: AsmEngine panic: a deleted ghost node!!!", INTERNAL_WOW_ERROR); 
		}		

		if(cnodeid.indegree() == 1 && cnodeid.outdegree() == 1)
		{
			CNodeID outnode = cnodeid.out(0);

			if((outnode.indegree() == 1 && outnode.outdegree() == 1) || !doublestrand)
				cgraph->transfer(cnodeid);
			else
				cgraph->transfer(-cnodeid);
		}
	} 

	bool done = false;

	while(!done)
	{
		done = true;
		cgraph->begin();
		while(cgraph->hasNext())
		{
			CNodeID cnodeid(cgraph->next());

			for(int i = 0; i < cnodeid.indegree(); i++)
			{
				CNodeID innode = cnodeid.in(i);
				if(innode.removed())
					exitMsg((char*)"Error: AsmEngine panic: a deleted ghost node!!!", INTERNAL_WOW_ERROR); 
			}		

			for(int i = 0; i < cnodeid.outdegree(); i++)
			{
				CNodeID outnode = cnodeid.out(i);
				if(outnode.removed())
					exitMsg((char*)"Error: AsmEngine panic: a deleted ghost node!!!", INTERNAL_WOW_ERROR); 
			}		

			if(cnodeid.outdegree() == 1)
			{
				CNodeID outnode = cnodeid.out(0);
			
				if(abs(outnode) != abs(cnodeid) && outnode.indegree() == 1)
				{
					done  = false;
					cgraph->join(cnodeid, outnode);
				}
			}


			if(cnodeid.indegree() == 1)
			{
				CNodeID innode = cnodeid.in(0);
			
				if(abs(innode) != abs(cnodeid) && innode.outdegree() == 1)
				{
					done = false;
					cgraph->join(innode, cnodeid);
				}
			}
		}
	}

	cgraph->applyRemovals();

	logger->report("Done.");
} 


void AsmEngine::exportLowCoverage(AvgCoverage avgcov, int lenthresh, FILE *out)
{
/*	Serial number = 1;

	cgraph->begin();

	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		if(cgraph->avgCoverage(cnodeid) <= avgcov && cgraph->length(cnodeid) <= lenthresh)
		{
			size_t len = cgraph->length(cnodeid);
			fprintf(out, ">|PROC_%d|CONTIG_%d|COV_%g|LENGTH_%ld|\n", mpirank, number++, cgraph->avgCoverage(cnodeid), len);
			cgraph->print(cnodeid, out);
			fprintf(out, "\n");
		}
	} */
}

void AsmEngine::removeLowCoverage(AvgCoverage avgcov, int lenthresh)
{
	logger->report("Removing low coverage contigs...");

	cgraph->begin();

	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		if(cgraph->avgCoverage(cnodeid) <= avgcov && cnodeid.length() <= lenthresh)
			cgraph->remove(cnodeid);
	}

	cgraph->applyRemovals();

	logger->report("Done.");
}

AvgCoverage AsmEngine::getAvgCoverage(int lenthresh)
{
	AvgCoverage avgc;
	FixedArray<size_t, MAXCOLORS> lens;

	avgc = 0;
	lens = 0;

	cgraph->begin();

	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		for(int i = 0; i < MAXCOLORS; i++)
			if(cnodeid.coverage()[i])	
			{
				avgc[i] += cnodeid.coverage()[i];
				lens[i] += cnodeid.length()-k+1;
			}
	}

	avgc = avgc / lens;

	return avgc;
}


vector<ContigMetadata> AsmEngine::outputContigs(int minContigLength, bool exportAsm, bool specificColors[MAXCOLORS], AvgCoverage minOutputContigCoverage) //if you modify this method, update the load version in align-longreads.C accordingly.
{
	vector<ContigMetadata> result; 
	logger->report("Outputing contigs...");

	map<UnitigSerial, CompactString<CompactWord> *> unitigs;

	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		for(Coordinate i = 0; i < cnodeid.size(); i++)
			unitigs[abs(cnodeid[i])] = NULL;
	}
	
	UnitigSerial unitigSerial = 1;

	FILE *unitigsFile = open_file(unitigFilename, "rb");

	map<UnitigSerial, CompactString<CompactWord> *>::iterator it;

	for(Serial number = 0; number < unitigsNum; number++)
	{

		Unitig unitig;

		unitig.load(unitigsFile);

		if(loadLowCovKmers || (unitig.coverage.max() >= MIN_COV_THRESH*(unitig.length()-k+1))) 
		{
			if((it = unitigs.find(unitigSerial)) != unitigs.end())
			{
				it->second = new CompactString<CompactWord>();
				Nucleotide *nucs = new Nucleotide[unitig.length()];
				
				unitig.getnucs(nucs);

				it->second->append(nucs, unitig.length());

				delete[] nucs;
			}

			unitigSerial++;
		}
	}

	fclose(unitigsFile);

	FILE *out = open_file((char*)(outputName+".contigs").c_str(), "wt");
	FILE *multiout = open_file((char*)(outputName+".extcontigs").c_str(), "wt");
	FILE *asmout = exportAsm ? open_file((char*)(outputName+".asm").c_str(), "wb") : NULL;
	FILE *colorsout[MAXCOLORS];
	FILE *colorsmultiout[MAXCOLORS];

	for(Color i = 0; i < MAXCOLORS; i++)
	{
		char cstr[COLOR_STR_LENGTH];

		sprintf(cstr, "%d", i);

		if(specificColors[i])
		{
			colorsout[i] = open_file((char*)(outputName+".color"+cstr+".contigs").c_str(), "wt");
			colorsmultiout[i] = open_file((char*)(outputName+".color"+cstr+".extcontigs").c_str(), "wt");
		}
		else
			colorsmultiout[i] = colorsout[i] = NULL;
	}

	if(!out || (!asmout && exportAsm))
		exitMsg((char*)"Error: AsmEngine panic: impossible to create output contigs file.\n", FILE_OPEN_ERROR);

	Serial number = 1;

	/////////////////////////////////////////Set ID for nodes
	map<CNodeID, Serial> nodeNumber;

	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());
		nodeNumber[cnodeid] = number;
		if(doublestrand)
			nodeNumber[-cnodeid] = -number;
		number++;	
	}
	/////////////////////////////////////////


	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());

		size_t len = cnodeid.length();
		if(len >= minContigLength)
		{
			ContigMetadata metadata;

			metadata.coverages = cgraph->avgCoverage(cnodeid);			
			metadata.length = len;

			result.push_back(metadata); 
			
			string contigstr = getSeq(cnodeid, unitigs);

			fprintf(out, ">|CONTIG_%d|", nodeNumber[cnodeid]); 
			for(int n = 0; n < MAXCOLORS; n++)
				fprintf(out, "COV%d_%g|", n, metadata.coverages[n]); 
			fprintf(out, "LENGTH_%ld|\n", len);
			fprintf(out, "%s\n", contigstr.c_str());

			for(Color i = 0; i < MAXCOLORS; i++)
			{
				if(specificColors[i] && metadata.coverages[i] >= minOutputContigCoverage[i])
				{
					fprintf(colorsout[i], ">|CONTIG_%d|", nodeNumber[cnodeid]); 
					for(Color n = 0; n < MAXCOLORS; n++)
						fprintf(colorsout[i], "COV%d_%g|", n, metadata.coverages[n]); 
					fprintf(colorsout[i], "LENGTH_%ld|\n", len);
					fprintf(colorsout[i], "%s\n", contigstr.c_str());
				}
			} 

//			number++;
		}
	}


	number = 1;

	cgraph->begin();
	while(cgraph->hasNext())
	{
		CNodeID cnodeid(cgraph->next());
		number = findNobranchingPath(cnodeid, number, "", multiout, unitigs, nodeNumber, map<CNodeID, bool>(), 0, MAXCOLORS);
		if(doublestrand)
			number = findNobranchingPath(-cnodeid, number, "", multiout, unitigs, nodeNumber, map<CNodeID, bool>(), 0, MAXCOLORS);	
	}

	for(Color i = 0; i < MAXCOLORS; i++)
	{
		if(colorsmultiout[i])
		{
			number = 1;

			cgraph->begin();
			while(cgraph->hasNext())
			{
				CNodeID cnodeid(cgraph->next());
				if(cgraph->avgCoverage(cnodeid)[i] >= minOutputContigCoverage[i])
				{
					number = findNobranchingPath(cnodeid, number, "", colorsmultiout[i], unitigs, nodeNumber, map<CNodeID, bool>(), minOutputContigCoverage[i], i);
					if(doublestrand)					
						number = findNobranchingPath(-cnodeid, number, "", colorsmultiout[i], unitigs, nodeNumber, map<CNodeID, bool>(), minOutputContigCoverage[i], i);
				}
			}
		}
	}
	

	if(exportAsm)
	{
		cgraph->save(asmout);

		cgraph->begin();
		while(cgraph->hasNext())
		{
			CNodeID cnodeid(cgraph->next());

			size_t loc = 0;

			for(Coordinate i = 0; i < cnodeid.size(); i++)
			{
				Coordinate start;
				if(i == 0)
					start = 0;
				else
					start = k-1;

				map<UnitigSerial, CompactString<CompactWord> *>::iterator thisunitigit = unitigs.find(abs(cnodeid[i]));
				Distance l = thisunitigit->second->length();
	
				if(cnodeid[i] < 0)
				{
					for(Coordinate ni = start; ni < l; ni++)
					{
						loc++;
						Nucleotide n = dualnuc((*(thisunitigit->second))[l-ni-1]);
						write_in_file((void *)&n, sizeof(Nucleotide), 1, asmout);
					}
				} else
				{
					for(Coordinate ni = start; ni < l; ni++)
					{
						loc++;
						Nucleotide n = (*(thisunitigit->second))[ni];
						write_in_file((void *)&n, sizeof(Nucleotide), 1, asmout);
					}
				}
			}
		}
	}

	for(map<UnitigSerial, CompactString<CompactWord> *>::iterator it = unitigs.begin(); it != unitigs.end(); it++)
		delete it->second;
	
	fclose(out);
	fclose(multiout);
	if(exportAsm) 
		fclose(asmout);
	for(Color i = 0; i < MAXCOLORS; i++)
		if(colorsout[i])
			fclose(colorsout[i]);

	logger->report("Done writing the contigs."); 

	return result;
}

string AsmEngine::getSeq(CNodeID cnodeid, map<UnitigSerial, CompactString<CompactWord> *> &unitigs)
{
	return getSeq(cnodeid,unitigs,true);	
}

string AsmEngine::getSeq(CNodeID cnodeid, map<UnitigSerial, CompactString<CompactWord> *> &unitigs, bool multiline)
{
	string contigstr;
	size_t loc = 0;
	for(Coordinate i = 0; i < cnodeid.size(); i++)
	{
		Coordinate start;
		if(i == 0)
			start = 0;
		else
			start = k-1;

		map<UnitigSerial, CompactString<CompactWord> *>::iterator thisunitigit = unitigs.find(abs(cnodeid[i]));
		Distance l = thisunitigit->second->length();
	
		if(cnodeid[i] < 0)
		{
			for(Coordinate ni = start; ni < l; ni++)
			{
				loc++;
				contigstr += nuc2char(dualnuc((*(thisunitigit->second))[l-ni-1]));
				if(loc >= 60 & multiline)
				{
					loc = 0;
					contigstr += "\n";
				}	
			}
		} 
		else
		{
			for(Coordinate ni = start; ni < l; ni++)
			{
				loc++;
				contigstr += nuc2char((*(thisunitigit->second))[ni]);
				if(loc >= 60 & multiline)
				{
					loc = 0;
					contigstr += "\n";
				}	
			}
		}
	}

	return contigstr;
}

Serial AsmEngine::findNobranchingPath(CNodeID cnodeid, Serial id, string seq, FILE *out, map<UnitigSerial, CompactString<CompactWord> *> &unitigs, map<CNodeID, Serial> &nodeNumber, map<CNodeID, bool> traversed, double minCov, Color c)
{
	unsigned int outd = cnodeid.outdegree(), ind = cnodeid.indegree();

	if(c < MAXCOLORS)
	{
		outd = ind = 0;
		for(int i = 0; i < cnodeid.outdegree(); i++)
			if(cgraph->avgCoverage(cnodeid.out(i))[c] >= minCov)
				outd++;
		for(int i = 0; i < cnodeid.indegree(); i++)
			if(cgraph->avgCoverage(cnodeid.in(i))[c] >= minCov)
				ind++;
	}
	

	CNodeID *outs = new CNodeID[outd];	

	if(c < MAXCOLORS)
	{
		unsigned int j = 0;
		for(int i = 0; i < cnodeid.outdegree(); i++)
			if(cgraph->avgCoverage(cnodeid.out(i))[c] >= minCov)
				outs[j++] = cnodeid.out(i);
	} else
	{
		unsigned int j = 0;
		for(int i = 0; i < cnodeid.outdegree(); i++)
			outs[j++] = cnodeid.out(i);
	}

	

	if(traversed.find(cnodeid) != traversed.end())
	{
		fprintf(out, "NODEe_%d_%d|", nodeNumber[cnodeid], outd); 	
		seq += getSeq(cnodeid, unitigs, false).substr(k-1) ;
		fprintf(out, "MULTIKCONTIG_%d|", id); 
		fprintf(out, "LENGTH_%ld|\n", seq.size());
		for (int j = 0; j < seq.size() / 60; j++)
			fprintf(out, "%s\n", seq.substr(j*60, 60).c_str());				

		fprintf(out, "%s\n", seq.substr(seq.size() - (seq.size() % 60)).c_str());
		delete[] outs;
		return id;
	}
	else
		traversed[cnodeid] = true;


	if(outd == 0 && ind == 0)
	{
		seq = getSeq(cnodeid, unitigs);

		fprintf(out, ">|NODEi_%d_%d|NODEe_%d_%d|", nodeNumber[cnodeid], 0, nodeNumber[cnodeid], 0);
		fprintf(out, "MULTIKCONTIG_%d|", id); 
		fprintf(out, "LENGTH_%ld|\n", seq.size());
		fprintf(out, "%s\n", seq.c_str());

		id++;
		delete[] outs;
		return id; 
	}

	if(seq == "")
	{
		if(outd > 1 || ind == 0)
		{
			seq = getSeq(cnodeid, unitigs, false);

			for(int i = 0; i < outd; i++)
			{
				fprintf(out, ">|NODEi_%d_%d|", nodeNumber[cnodeid], outd);
				findNobranchingPath(outs[i], id, seq, out, unitigs, nodeNumber, traversed, minCov, c);
				id++;
			}
		}
	}
	else if(outd == 1)
	{
		fprintf(out, "NODEm_%d|", nodeNumber[cnodeid]); 
		seq += getSeq(cnodeid, unitigs, false).substr(k-1) ;
		findNobranchingPath(outs[0], id, seq, out, unitigs, nodeNumber, traversed, minCov, c);
	}	
	else
	{
		fprintf(out, "NODEe_%d_%d|", nodeNumber[cnodeid], outd); 	
		seq += getSeq(cnodeid, unitigs, false).substr(k-1) ;
		fprintf(out, "MULTIKCONTIG_%d|", id); 
		fprintf(out, "LENGTH_%ld|\n", seq.size());
		for (int j = 0; j < seq.size() / 60; j++)
			fprintf(out, "%s\n", seq.substr(j*60, 60).c_str());				

		fprintf(out, "%s\n", seq.substr(seq.size() - (seq.size() % 60)).c_str());	
	}
	
	delete[] outs;
	return id;
}

