/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          record.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include <list>
#include <string>
#include <math.h>

#include "common.h"
#include "record.h"
#include "alloc.h"

using namespace std;


Record::Record()
{
	line = NULL;
	fields = NULL;
	sortField = 0;
	numericSort = false;
}

Record::Record(char *l)
{
	line = NULL;
	fields = NULL;
	sortField = 0;
	numericSort = false;
	parse(l);
}

Record::Record(string l)
{
	char *buffer = (char *)alloc.xmalloc(l.size()+1);
	strcpy(buffer, l.c_str());
	line = NULL;
	fields = NULL;
	sortField = 0;
	numericSort = false;
	parse(buffer);
	alloc.xfree((void *&)buffer);
}

Record::~Record()
{
	if(line) alloc.xfree((void *&)line);
	if(fields) alloc.xfree((void *&)fields);
}

size_t Record::size()
{
	size_t ret = 0;
	while(fields[ret++]);
	return ret-1;
}

void Record::parse(char *l)
{
	if(line) alloc.xfree((void *&)line);
	if(fields) alloc.xfree((void *&)fields);
	
	line = (char *)alloc.xmalloc(strlen(l)+1);
	strcpy(line, l);
	list<char*> tokens;

	char *token = line;
	char *previous = line;

	while(*token)
	{
		if(*token == '\t' || *token == '\n')
		{
			*token = '\0';
			tokens.push_back(previous);
			token++;
			previous = token;
		} else
			token++;
	}

	if(previous != token)
		tokens.push_back(previous);
			
	fields = (char **)alloc.xmalloc((tokens.size()+1)*sizeof(char*));
	list<char*>::iterator it;
	int i;

	for(it = tokens.begin(), i = 0; it != tokens.end(); i++, it++)
		fields[i] = *it;
	fields[i] = NULL;
}

bool Record::operator<(const Record& rhs) const
{
	if(numericSort)
		return atoi(fields[sortField]) < atoi(rhs.fields[sortField]);
	else
		return (strcmp(fields[sortField], rhs.fields[sortField]) < 0);
}
