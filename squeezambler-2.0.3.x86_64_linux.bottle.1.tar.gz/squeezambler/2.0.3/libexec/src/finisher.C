/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          finisher.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2013
 * Last modified:  05/27/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "finisher.h"

Finisher::Finisher(string _inputFilename, string _unitigFilename, string _configFilename,
	string _outputName,
	string _saveCGFilename, string _loadCGFilename,
	bool _fasta,
	int _procs,
	double _covThresh, // if -1 then consider per color normalized, if -2 then consider absolute.
	AvgCoverage _covThreshPerColorNormalized,
	Coverage _covThreshPerColorAbsolute,
	int _lowCovLenThresh,
	int _minContigLength,
	bool _doublestrand,
	int _exportGraph,
	bool _exportRemovedNodes,
	bool _exportAsm,
	bool _noLowCovUnitigs,
	bool _specificColors[MAXCOLORS],
	AvgCoverage _minOutputContigCoverage,
	bool _keepref,
	Logger *_logger)
{
	inputFilename = _inputFilename, unitigFilename = _unitigFilename, configFilename = _configFilename;
	outputName = _outputName;
	saveCGFilename = _saveCGFilename, loadCGFilename = _loadCGFilename;
	fasta = _fasta;
	procs = _procs;
	covThresh = _covThresh;
	covThreshPerColorNormalized = _covThreshPerColorNormalized,
	covThreshPerColorAbsolute = _covThreshPerColorAbsolute,
	lowCovLenThresh = _lowCovLenThresh;
	minContigLength = _minContigLength;
	doublestrand = _doublestrand;
	exportGraph = _exportGraph;
	exportRemovedNodes = _exportRemovedNodes;
	exportAsm = _exportAsm;
	noLowCovUnitigs = _noLowCovUnitigs;
	for(int i = 0; i < MAXCOLORS; i++)
		specificColors[i] = _specificColors[i];
	minOutputContigCoverage = _minOutputContigCoverage,
	keepref = _keepref;
	logger = _logger;

	logger->setSection("loading configs and unitigs");
	AsmEngine engine(inputFilename, unitigFilename, configFilename, outputName, fasta, procs, doublestrand, !noLowCovUnitigs, logger);


	if(loadCGFilename != "")
	{
		logger->setSection("loading the condensed graph");
		engine.loadCG(loadCGFilename);
	}
	else
	{
		logger->setSection("building the condensed graph");
		engine.makeCGraph();
	}

	engine.joinContigs();

	if(saveCGFilename != "")
	{
		logger->setSection("saving the condensed graph");
		engine.saveCG(saveCGFilename);
	}

	if(exportGraph)
		engine.exportG(0, exportGraph);

	FILE *removedNodes = NULL;

	if(exportRemovedNodes)
		removedNodes = open_file((outputName+".removedunitigs").c_str(), "wt");

	AvgCoverage avgcovThresh = engine.getAvgCoverage(lowCovLenThresh);

	if(covThresh >= 0)
		// new iterative removal up to a percentage of the mean, i.e. normalized coverage cutoff
		avgcovThresh = avgcovThresh*covThresh;
	else if(covThresh == -1)
		avgcovThresh = avgcovThresh*covThreshPerColorNormalized;
	else if(covThresh == -2)
		avgcovThresh = (AvgCoverage)covThreshPerColorAbsolute;

	if(keepref)
		avgcovThresh[0] = 0;

	AvgCoverage step = (avgcovThresh.max() != 0) ? (avgcovThresh / avgcovThresh.max()) : AvgCoverage(0);
	AvgCoverage covcutoff = 0.0;

	for(int i = 0; i < MAXCOLORS; i++)
		logger->out() << "Computed coverage cutoff threshold for color " << i << " is " << avgcovThresh[i] << " and its step is " << step[i] << "." << endl;		

	for(int i = 0; i < avgcovThresh.max(); i++)
	{ 
		covcutoff += step;
		if(removedNodes)
			engine.exportLowCoverage(covcutoff, lowCovLenThresh, removedNodes);
		engine.removeLowCoverage(covcutoff, lowCovLenThresh);
		engine.joinContigs();
		logger->out() << "N50 = " << engine.NX(0.5) << ", N90 = " << engine.NX(0.9) << endl;
	}

	// original iterative removal of low coverage nodes
/*	for(double covcutoff = 1.0; covcutoff <= covThresh; covcutoff += 1.0)
	{ 
		AvgCoverage cv;
		cv = covcutoff;
		if(removedNodes)
			engine.exportLowCoverage(cv, lowCovLenThresh, removedNodes);
		engine.removeLowCoverage(cv, lowCovLenThresh);
		engine.joinContigs();
		logger->out() << "N50 = " << engine.NX(0.5) << ", N90 = " << engine.NX(0.9) << endl;
	} */

	engine.joinContigs();
	logger->out() << "N50 = " << engine.NX(0.5) << ", N90 = " << engine.NX(0.9) << endl;

	if(removedNodes)
		fclose(removedNodes);

	if(exportGraph)
		engine.exportG(1, exportGraph);

/*	if(configFilename != "")
	{
		engine.doMating();

		time(&now);
		if(mpirank == 0)
			printf("%s\n", ctime(&now));

		engine.outputContigs(minContigLength);

		if(exportGraph)
			engine.exportG(1, __MAX_INS_SIZE);
	} */

	contigmetadata = engine.outputContigs(minContigLength, exportAsm, specificColors, minOutputContigCoverage);
}
