/*
Copyright 2013- Zeinab Taghavi (ztaghavi@cs.colostate.edu)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          colorsstat.C 
 * Author:         Zeinab Taghavi
 * Created:        2013
 * Last modified:  04/22/2014
 *
 * Copyright (c) 2013- Zeinab Taghavi
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "colorsstat.h"

ColorsStat::ColorsStat(Logger *_logger, bool _debugMode)
{
	unionStat.listNo = 0; 
	totalStat.assemblySize = 0; 
	logger = _logger; 
	debugMode = _debugMode;
	logger->out() << "debugMode = " << debugMode << endl;
	logger->out().flush();
	clear_stat();
};
void ColorsStat::calcUnionStat(size_t uIndex)
{ 
	Colors_List cList = convertIndexToList(uIndex);	
	
	unionStat.list[uIndex].assemblySize = 0;
	for (int i = 0; i < contigMetadataList->size(); i++)
	{
		bool contigPresenceInUnion = false;
		contigPresenceInUnion = sequencedPrecenceInUnion.list[i];
		size_t colorIndex = 0;
		while ((!contigPresenceInUnion) && (colorIndex < cList.listNo))
		{
			if (contigMetadataList->at(i).coverages[cList.list[colorIndex]] > MINCONTIGCOVERAGE)
			{
				contigPresenceInUnion = true;
			};
			colorIndex ++;	
		};
		if (contigPresenceInUnion)
		{
			unionStat.list[uIndex].assemblySize += contigMetadataList->at(i).length;
		}
	}
	logger->out() << " unionStat.list[" << uIndex<< "].assemblySize = " << (int) unionStat.list[uIndex].assemblySize << endl;
}

Stat ColorsStat::calcStat(Color c)
{
	Stat tempStat;
	tempStat.assemblySize = 0;
	tempStat.averageCoverage = 0;
	for (int i = 0; i < contigMetadataList->size(); i++)
	{
		if (contigMetadataList->at(i).coverages[c] > MINCONTIGCOVERAGE)
		{
			tempStat.assemblySize += contigMetadataList->at(i).length;
			tempStat.averageCoverage += contigMetadataList->at(i).length * contigMetadataList->at(i).coverages[c];
		};
	};	
	return tempStat;
}


void ColorsStat::calcSequencedStat()
{
	logger->out() << " calcSequencedStat starts" << endl;
	logger->out() << "contigMetadataList->size() = " << (int) contigMetadataList->size() << endl;
	logger->out() << "sequencedColors->listNo = " << (int) sequencedColors->listNo << endl;
	logger->out().flush();
	for (int i = 0; i < contigMetadataList->size(); i++)
	{
		sequencedPrecenceInUnion.list[i] = false;
		size_t colorIndex = 0;
		while ((!sequencedPrecenceInUnion.list[i]) && (colorIndex < sequencedColors->listNo))
		{
			if (contigMetadataList->at(i).coverages[sequencedColors->list[colorIndex]] > MINCONTIGCOVERAGE)
			{
				sequencedPrecenceInUnion.list[i] = true;
			};
			colorIndex ++;
	
		};
		logger->out().flush();
	};
	logger->out() << " calcSequencedStat finishes" << endl;
	logger->out().flush();
}

void ColorsStat::extractUnionStats()
{
	if ( (activeColors->listNo)  > MAXBARCODE)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsStat::extractUnionStats(): (activeColors->listNo + 1) > MAXBARCODE, i.e., " << activeColors->listNo << "+ 1 > " << MAXBARCODE << endl; 
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	};
	unionStat.listNo = pow(2, activeColors->listNo);
	logger->out() << " unionStat.listNo = " << unionStat.listNo << endl;
	calcSequencedStat();
	for (size_t uIndex = 0; uIndex < unionStat.listNo; uIndex ++)
	{
		calcUnionStat(uIndex);
	}
	totalStat = unionStat.list[unionStat.listNo - 1] ;
}

void ColorsStat::extractColorStats()
{
	if ( (activeColors->listNo)  > MAXBARCODE)
	{
		if (logger != NULL)
			logger->out() << "Error in  ColorsStat::extractColorStats(): (activeColors->listNo + 1) > MAXBARCODE, i.e., " << activeColors->listNo << "+ 1 > " << MAXBARCODE << endl; 
		exitMsg(NULL, INTERNAL_WOW_ERROR);
	};
	unionStat.listNo = pow(2, activeColors->listNo);
	logger->out() << " activeColors->listNo = " << activeColors->listNo << endl;
	calcSequencedStat();
	for (size_t aIndex = 0; aIndex < activeColors->listNo; aIndex ++)
	{
		size_t uIndex = convertActiveColorIndexToUnionIndex(aIndex);
		calcUnionStat(uIndex);
	}
}

Colors_List ColorsStat::convertIndexToList(size_t index)
{
	Colors_List listOfColors;
	listOfColors.listNo = 0;
	int i = 2;
	size_t colorIndex = 0;
	while (index >= 1)
	{
		if (colorIndex >= activeColors->listNo)
		{
			if (logger != NULL)
				logger->out() << "Error in  ColorsStat::convertIndexToList(): index is more than size of activeColors" << endl; 
			exitMsg(NULL, INTERNAL_WOW_ERROR);
		};
		if (index % 2 == 1)
		{
			listOfColors.list[listOfColors.listNo] = activeColors->list[colorIndex];
			listOfColors.listNo ++;	
		};
		index /= 2;
		colorIndex ++;
	};
	return listOfColors;
};

size_t ColorsStat::convertActiveColorIndexToUnionIndex(size_t activeColorIndex)
{
	size_t index;
	index = pow(2,activeColorIndex); 
	return index;
};


Ratio ColorsStat::assigncutoffPlot(Ratio cutoffRatio, Stat totalStat, Stat colorStat)
{
return cutoffRatio * colorStat.assemblySize;
}

void ColorsStat::selectNextLevelActiveColors(vector<ContigMetadata> * _contigMetadataList, ColorsList * colorsList, double cutoffRatio, Lib _base_lib, size_t groupNum, CovType completeGenomeMinCoverage, int methodType)
{
	logger->out() << " optimum next round selection method starts" << endl;
	activeColors = colorsList->getActiveColorsList();
	logger->out() << " activeColors :" << endl;
	logger->out().flush();
	printListInf(activeColors);
	int lowCoverageColorsNo = 0;
	if (methodType == 0) // optimum method, BFS
	{
		Colors_List optimumColorsList;
		if (activeColors->listNo == 0)
		{
			optimumColorsList.listNo = 0;
		} else
		if (activeColors->listNo == 1) 
		{
			optimumColorsList.listNo = 1;
			optimumColorsList.list[0] = activeColors->list[0];
		} else
		{
			sequencedColors = colorsList->getSequencedColorsList();
			logger->out() << " sequencedColors :" << endl;
			logger->out().flush();		
			printListInf(sequencedColors);
			contigMetadataList =  _contigMetadataList;
			logger->out().flush();
			clear_stat();
			Colors_List tempActiveList;
			tempActiveList.listNo = 0;

			for (size_t i = 0; i < activeColors->listNo; i ++)
			{
				Stat tempStat = get_stat(activeColors->list[i]);
				logger->out() << "activeColors->list[" << i << "] = " << (int) activeColors->list[i] << ":: tempStat.averageCoverage = " << tempStat.averageCoverage /  (CovType) tempStat.assemblySize << " :: tempStat.assemblySize " << tempStat.assemblySize << endl;
				tempStat.averageCoverage /= (CovType) tempStat.assemblySize;
				if (tempStat.averageCoverage < completeGenomeMinCoverage)
				{
					colorsList->pushToSequencedList(activeColors->list[i]);
					lowCoverageColorsNo ++;
					logger->out() << "TO SEQUENCED LIST" << endl;
				}else
				{
					tempActiveList.list[tempActiveList.listNo] = activeColors->list[i];
					tempActiveList.listNo ++;
					logger->out() << "TO tempActiveList" << endl;
				}
			} 
			activeColors->listNo = tempActiveList.listNo;
			for (size_t i = 0; i < tempActiveList.listNo; i ++)
			{
				activeColors->list[i] = tempActiveList.list[i];	
			}
			logger->out() << "activeColors->listNo = " << (int) activeColors->listNo << endl;
			extractUnionStats();
			size_t optimumindex = unionStat.listNo - 1;
			optimumColorsList = convertIndexToList(optimumindex);
			Stat optimumStat = unionStat.list[optimumindex];
			size_t optimumCellNum = colorsList->countCellsinColors(optimumColorsList);
			logger->out() << " totalStat.assemblySize = " << totalStat.assemblySize << endl;
			logger->out() << " optimumindex = " << optimumindex << endl;
			logger->out() << " optimumStat.assemblySize = " << optimumStat.assemblySize << endl;
			logger->out() << " optimumCellNum = " << optimumCellNum << endl;
			logger->out() << " optimimColorsList: "<< endl;
			printListInf(&optimumColorsList);
			for (size_t i = 0; i < unionStat.listNo; i++)
			{
				if ((totalStat.assemblySize - unionStat.list[i].assemblySize) < assigncutoffPlot(cutoffRatio, totalStat, unionStat.list[i]))
				{
					Colors_List tempColorsList = convertIndexToList(i);
					size_t tempCellNum = colorsList->countCellsinColors(tempColorsList);
					if (optimumCellNum > tempCellNum)
					{
						optimumindex = i;
						optimumColorsList = tempColorsList;
						optimumStat = unionStat.list[i];
						optimumCellNum = tempCellNum;
						logger->out() << " optimumindex = " << optimumindex << endl;
						logger->out() << " optimumStat.assemblySize = " << optimumStat.assemblySize << endl;
						logger->out() << " optimumCellNum = " << optimumCellNum << endl;
						logger->out() <<" optimimColorsList: "<< endl;
						printListInf(&optimumColorsList);
					}
				}
			}
		}
		colorsList->set_base_lib(_base_lib);
		logger->out() <<" base_lib updated. " << endl;
		colorsList->emptyActiveColors();
		logger->out() <<" emptyActiveColors updated. " << endl;
		for (int i = 0; i < optimumColorsList.listNo; i++)
			colorsList->pushToActiveList(optimumColorsList.list[i]);
		for (int i = 0; i < lowCoverageColorsNo; i++)
		{
			Color tempc = colorsList->popFromSequencedList();
			colorsList->pushToActiveList(tempc);
		}
		colorsList->divideAllActiveColors(groupNum);
	}
	else if (methodType == 1) // DFS
	{
		sequencedColors = colorsList->getSequencedColorsList();
		logger->out() << " sequencedColors :" << endl;
		logger->out().flush();		
		printListInf(sequencedColors);
		contigMetadataList =  _contigMetadataList;
		extractColorStats();
		Colors_List NextRoundList;
		NextRoundList.listNo = activeColors->listNo;

		int *to_be_sorted_indices = new int[NextRoundList.listNo];

		for (int i = 0; i <  NextRoundList.listNo; i++)
			to_be_sorted_indices[i] = i;
		
		for (int i = 0; i <  NextRoundList.listNo; i++)
		{
			AssemblySize minsize = unionStat.list[convertActiveColorIndexToUnionIndex(to_be_sorted_indices[i])].assemblySize;
			int minidx = i;
			for(int j = i+1; j < NextRoundList.listNo; j++)
				if(unionStat.list[convertActiveColorIndexToUnionIndex(to_be_sorted_indices[j])].assemblySize <= minsize)
				{
					minsize = unionStat.list[convertActiveColorIndexToUnionIndex(to_be_sorted_indices[j])].assemblySize;
					minidx = j;
				}
			if(minidx != i)
			{
				int temp = to_be_sorted_indices[i];
				to_be_sorted_indices[i] = to_be_sorted_indices[minidx];
				to_be_sorted_indices[minidx] = temp;
			}
		}
		
		for (int i = 0; i <  NextRoundList.listNo; i++)
			NextRoundList.list[i] = activeColors->list[to_be_sorted_indices[i]];

		delete[] to_be_sorted_indices;
		logger->out() << " NextRoundList.listNo = " << NextRoundList.listNo << endl;	
		logger->out() << " sorted active colors based on assembly size is: " << endl;	
		printListInf(&NextRoundList);

		colorsList->set_base_lib(_base_lib);
		colorsList->emptyActiveColors();
		logger->out() << " nextRoundColorList.listNo = " << NextRoundList.listNo << endl; 
		for (int i = 0; i < NextRoundList.listNo; i++)
			colorsList->pushToWaitingList(NextRoundList.list[i]);
		while (!(colorsList->allSequenced()) && (colorsList->isEmpty_activeColors()))
		{  
			logger->out() << " moveLastWaitingToActiveList " << endl;
			Color newTempActiveColor = colorsList->popFromWaitingList();
			logger->out() << "newTempActiveColor = " << (int) newTempActiveColor << endl;
			if (newTempActiveColor > -1)
			{
				if (!(isSequenced(newTempActiveColor,cutoffRatio, completeGenomeMinCoverage)))
					colorsList->pushToActiveList(newTempActiveColor);	
			}
		}
		colorsList->divideAllActiveColors(groupNum);
		logger->out() << " moveLastWaitingToActiveList done" << endl;
	}
	logger->out() << " updateWaitingColorsIn_colors_list " << endl;
	colorsList->updateWaitingColorsIn_colors_list();
	logger->out() << " updateWaitingColorsIn_colors_list done" << endl;

}

void ColorsStat::clear_stat()
{
	for (Color c = 0; c < MAXCOLORS; c++)
	{
		colorListStat.list[c].assemblySize = 0;
		colorListStat.list[c].averageCoverage = 0;
	}
}

AssemblySize ColorsStat::get_assemblySize(Color c)
{
	logger->out() << " get_assemblySize" << endl;
	logger->out() << "color = " << (int) c << endl;
	if (colorListStat.list[c].assemblySize == 0)
	{
		colorListStat.list[c] = calcStat(c);
	};
	return colorListStat.list[c].assemblySize;
};


Stat ColorsStat::get_stat(Color c)
{
	if (colorListStat.list[c].assemblySize == 0)
	{
		colorListStat.list[c] = calcStat(c);
	};
	return colorListStat.list[c];
}
void ColorsStat::printListInf(Colors_List *list)
{
	if (logger != NULL)
		if (debugMode = true)
		{
			logger->out() << "List length is  " << list->listNo << endl;
			for (size_t i = 0; i < list->listNo; i ++)
				logger->out() << (int) list->list[i] << ", ";
			logger->out() << endl;
		};
}


void ColorsStat::calcSequencedCommonStat()
{
	for (int i = 0; i < sequencedColors->listNo; i++)
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			sequencedFinalStat[i][j].assemblySize = 0;
			sequencedFinalStat[i][j].averageCoverage = 0;
		}
	for (int i = 0; i < contigMetadataList->size(); i++)
	{
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			if (contigMetadataList->at(i).coverages[sequencedColors->list[j]] > MINCONTIGCOVERAGE)
			{
				sequencedFinalStat[j][j].assemblySize += contigMetadataList->at(i).length;
				sequencedFinalStat[j][j].averageCoverage += contigMetadataList->at(i).length *contigMetadataList->at(i).coverages[sequencedColors->list[j]];
				for (int l = j + 1; l < sequencedColors->listNo; l++)
				{
					if (contigMetadataList->at(i).coverages[sequencedColors->list[l]] > MINCONTIGCOVERAGE)
					{
						sequencedFinalStat[j][l].assemblySize += contigMetadataList->at(i).length;
						sequencedFinalStat[l][j].assemblySize += contigMetadataList->at(i).length;
						sequencedFinalStat[j][l].averageCoverage += contigMetadataList->at(i).length*contigMetadataList->at(i).coverages[sequencedColors->list[j]];
						sequencedFinalStat[l][j].averageCoverage += contigMetadataList->at(i).length*contigMetadataList->at(i).coverages[sequencedColors->list[l]];
					}
				}

			}
		}
		
	}

}

bool ColorsStat::isSubset(int i, int j, double cutoffRatio) 
{
	double exclusivityRatio = (double) (sequencedFinalStat[i][i].assemblySize - sequencedFinalStat[i][j].assemblySize) / (double) sequencedFinalStat[i][i].assemblySize;
	if (exclusivityRatio < cutoffRatio)
	{
		return true;
	} else
	{
		return false;
	}
}

bool ColorsStat::isSequenced(Color c, double cutoffRatio, CovType completeGenomeMinCoverage) 
{
	logger->out() << "isSequenced ..." << endl;
	logger->out() << "color = " << (int) c << ", cutoffRatio = " << cutoffRatio << endl;
	calcSequencedStat();
	logger->out() << " calcSequencedStat() done." << endl;
	AssemblySize assemSize = 0, commonAssemSize = 0;
	CovType	averageCoverage = 0; 
	for (int i = 0; i < contigMetadataList->size(); i++)
	{
		if (contigMetadataList->at(i).coverages[c] > MINCONTIGCOVERAGE) 
		{
			assemSize += contigMetadataList->at(i).length;
			averageCoverage += contigMetadataList->at(i).coverages[c] * contigMetadataList->at(i).length;
			if (sequencedPrecenceInUnion.list[i])
				commonAssemSize += contigMetadataList->at(i).length;
		}
	}
	averageCoverage = averageCoverage / (CovType) assemSize;
	logger->out() << "averageCoverage = " << averageCoverage << endl;
	if (averageCoverage < completeGenomeMinCoverage)
		return false;
	double exclusivityRatio = (double) (assemSize - commonAssemSize) / (double) assemSize;
	logger->out() << "exclusivityRatio = " << exclusivityRatio << endl;
	if (exclusivityRatio < cutoffRatio)
	{
		return true;
	} else
	{
		return false;
	}
}

void ColorsStat::changeCluster(int i, int j)
{
	for (int l = 0; sequencedClusters->listNo; l++)
	{
		if (sequencedClusters->list[l] == i)
			sequencedClusters->list[l] = j;
	}

}

void ColorsStat::cleanClusters()
{
	logger->out() << "cleanClusters starts 2" << endl;
	logger->out().flush();
	for (int l = 0; l < sequencedClusters->listNo; l++)
		sequencedClusters->list[l] = -sequencedClusters->list[l];
	int clustersMax = 0;
	for (int i = 0; i < sequencedClusters->listNo; i++)
	{
		if (sequencedClusters->list[i] < 0)
		{
			clustersMax ++;
			int oldCluster = sequencedClusters->list[i];
			for (int j = i; j < sequencedClusters->listNo; j++)
				if (sequencedClusters->list[j] == oldCluster)
					sequencedClusters->list[j] = clustersMax;
		}
	}
	clustersNum = clustersMax + 1;
}

void ColorsStat::clusterSequenced(double cutoffRatio)
{
	logger->out() << "clusterSequenced starts" << endl;
	logger->out().flush();
	int clustersMax = 0;
	clustersNum = 0;
	sequencedClusters->listNo = sequencedColors->listNo;
	logger->out() << "sequencedClusters->listNo = " << (int) sequencedClusters->listNo << endl;
	logger->out().flush();
	for (int i = 0; i < sequencedClusters->listNo; i++)
		sequencedClusters->list[i] = -1;
	for (int i = 0; i < sequencedClusters->listNo; i++)
	{
		if (sequencedClusters->list[i] == -1)
		{
			sequencedClusters->list[i] = clustersMax;
			logger->out() << "sequencedClusters->list[ " << (int) i << "] = " << sequencedClusters->list[i] << endl; 
			logger->out().flush();			
			clustersNum += 1;
			clustersMax += 1;
		}	
		for (int j = i + 1; j < sequencedColors->listNo; j++)
		{
			if (isSubset(i, j, cutoffRatio) || isSubset(j, i, cutoffRatio))
			{
				if (sequencedClusters->list[j] == -1)
				{
					sequencedClusters->list[j] = sequencedClusters->list[i];
					logger->out() << "sequencedClusters->list[ " << (int) j << "] = " << sequencedClusters->list[j] << endl; 
					logger->out().flush();
		
				} else if (sequencedClusters->list[j] != sequencedClusters->list[i])
				{
					changeCluster(sequencedClusters->list[j], sequencedClusters->list[i]);
					clustersNum -=1;
					logger->out() << "sequencedClusters->list[ " << (int) j << "] = " << sequencedClusters->list[j] << endl; 
					logger->out().flush();
				}
			}		
		}
	}
	logger->out() << "cleanClusters starts" << endl;
	logger->out().flush();	
	cleanClusters();
	logger->out() << "total number of clusters are " << (int) clustersNum << endl;
	logger->out() << "clusters: (cell color: cluster name)" << endl;
	logger->out().flush();
	for (int i = 0; i < sequencedClusters->listNo; i++)
		logger->out() << (int) sequencedColors->list[i] << " : " <<  (int) sequencedClusters->list[i] << " \t\t";
	logger->out() << endl; 
	logger->out().flush();
}
void ColorsStat::clusterSequencedColors(vector<ContigMetadata> * _contigMetadataList, ColorsList * colorsList, double cutoffRatio, CList<int, MAXCOLORS> *_sequencedClusters, LibNamesList * inputLibNames)
{
	sequencedColors = colorsList->getSequencedColorsList();
	contigMetadataList =  _contigMetadataList;

	calcSequencedCommonStat();
	sequencedClusters = _sequencedClusters;
	clusterSequenced(cutoffRatio);

	printSequencedCommonStat(colorsList);
	printSequencedClusters(colorsList, inputLibNames);
	
}


void ColorsStat::printSequencedCommonStat(ColorsList * colorsList)
{
	logger->out() << "=========================" << endl;
	logger->out().flush();
	logger->out() << "sequenced list" << endl;
	logger->out().flush();
	logger->out() << "=========================" << endl;
	logger->out() << "total " << sequencedColors->listNo << " cells sequenced"<< endl;
	logger->out() << "index:color:library" << endl;
	for (int i = 0; i < sequencedColors->listNo; i++)
	{
		logger->out() << i << ":" << (int) colorsList->getSequencedColors(i) << ":" << (int) colorsList->getSequencedLibs(i) << endl;
	}
	logger->out() << "=========================" << endl;
	logger->out() << "sequencedCommonStat" << endl;
	logger->out() << "assembly size" << endl;
	logger->out() << "=========================" << endl;

	logger->out() << "\t";
	for (int i = 0; i < sequencedColors->listNo; i++)
		logger->out() << (int) colorsList->getSequencedLibs(i) <<"\t";
	logger->out() << endl;
	for (int i = 0; i < sequencedColors->listNo; i++)
	{
		logger->out() <<(int) colorsList->getSequencedLibs(i) << ": \t";
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			AssemblySize assemblySize = sequencedFinalStat[i][j].assemblySize;
			logger->out() << (int) assemblySize <<"\t";
		}
		logger->out() << endl;
	}

	logger->out() << "=========================" << endl;
	logger->out() << "sequencedCommonStat" << endl;
	logger->out() << "exlusivityRatio (\%)" << endl;
	logger->out() << "=========================" << endl;

	logger->out() << "\t";
	for (int i = 0; i < sequencedColors->listNo; i++)
		logger->out() << (int) colorsList->getSequencedLibs(i) <<"\t";
	logger->out() << endl;
	for (int i = 0; i < sequencedColors->listNo; i++)
	{
		logger->out() << (int) colorsList->getSequencedLibs(i) << ": \t";
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			double exclusivityRatio = (double) (sequencedFinalStat[i][i].assemblySize - sequencedFinalStat[i][j].assemblySize) / (double) sequencedFinalStat[i][i].assemblySize;
			exclusivityRatio = exclusivityRatio * 100;
			logger->out() << (double) exclusivityRatio <<"\t";
		}
		logger->out() << endl;
	}

	logger->out() << "=========================" << endl;
	logger->out() << "sequencedCommonStat" << endl;
	logger->out() << "average coverage" << endl;
	logger->out() << "=========================" << endl;

	logger->out() << "\t";
	for (int i = 0; i < sequencedColors->listNo; i++)
		logger->out() << (int) colorsList->getSequencedLibs(i) <<"\t";
	logger->out() << endl;
	for (int i = 0; i < sequencedColors->listNo; i++)
	{
		logger->out() <<  (int) colorsList->getSequencedLibs(i) << ": \t";
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			double averageCoverage = (double) sequencedFinalStat[i][j].averageCoverage  / (double) sequencedFinalStat[i][j].assemblySize;
			logger->out() << (double) averageCoverage <<"\t";
		}
		logger->out() << endl;
	}

}

void ColorsStat::printSequencedClusters(ColorsList * colorsList, LibNamesList * inputLibNames)
{
	logger->out() << "=========================" << endl;
	logger->out() << "sequenced clusters" << endl;
	logger->out() << "=========================" << endl;
	logger->out() << "total " << (int) clustersNum << " clusters (species)" << endl;
	logger->out() << "index:color:library index:library name" << endl;
	for (int i = 0; i < clustersNum; i++)
	{	
		logger->out() << "cluster " << (int) i << ":" << endl;
		for (int j = 0; j < sequencedColors->listNo; j++)
		{
			if (sequencedClusters->list[j] == i)
				logger->out() << j << ":" << (int) colorsList->getSequencedColors(j) << ":" << (int) colorsList->getSequencedLibs(j) << ":" << (*inputLibNames)[colorsList->getSequencedLibs(j)].files[0] << endl;
		}
	}
}		

