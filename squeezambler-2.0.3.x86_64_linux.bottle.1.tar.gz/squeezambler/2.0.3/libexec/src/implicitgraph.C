/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          implicitgraph.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  04/23/2014
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/

#include "implicitgraph.h"
#include "kmers.C"
#include "splaytree.C"
//#include "sortedlist.C"

//template class Kmers<CompactNodeInfo, SortedList>;
//template class Kmers<SemicompactNodeInfo, SortedList>;
template class Kmers<CompactNodeInfo, SplayTree>;
template class Kmers<SemicompactNodeInfo, SplayTree>;

template <class NodeInfo>
ImplicitGraph<NodeInfo>::ImplicitGraph(int _k, int _slice, int _machines, bool dbstrand, Logger *_logger)
{
	logger = _logger;
	doublestrand = dbstrand;
	k = _k;
	kforge.reset(k);
	machines = _machines;
	slice = _slice;
	threadsnum = 1;
	distributor.set(machines, k);

	for(int edges = 0; edges < 256; edges++)
	{
		edgeInfo[edges].indeg = edgeInfo[edges].outdeg = 0;
		int mask = 0x80;
		for(int i = 0; i < 4; i++)
		{
			if(edges & mask)
			{
				edgeInfo[edges].innuc[edgeInfo[edges].indeg] = i;
				edgeInfo[edges].indeg++;
			}
			mask = mask >> 1;
		}
		for(int i = 3; i >= 0; i--)
		{
			if(edges & mask)
			{
				edgeInfo[edges].outnuc[edgeInfo[edges].outdeg] = i;
				edgeInfo[edges].outdeg++;
			}
			mask = mask >> 1;
		}
	}
}


template <class NodeInfo>
void ImplicitGraph<NodeInfo>::load(FILE *fp)
{
	size_t sz, orig;
	KmerData<NodeInfo> node;

	read_from_file(&sz, sizeof(size_t), 1, fp);
	logger->out() << "Loading " << sz << " nodes from file..." << endl;
	orig = sz;

	for(; sz > 0; sz--)
	{
		read_from_file(&node, sizeof(KmerData<NodeInfo>), 1, fp);
		insert(node);
	}
	logger->out() << "Done loading." << endl;
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::save(FILE *fp)
{
	size_t sz = size();
	KmerData<NodeInfo> node;
	
	if(sz != nodes.count())
		cerr << "Error: inconsistency in the kmers data structure. This is a grave bug: size = " << sz << " while count = " << nodes.count() << endl;

	logger->out() << "Saving " << sz << " nodes into file..." << endl;

	write_in_file(&sz, sizeof(size_t), 1, fp);

	nodes.begin();
	while(nodes.hasNext())
	{
		node = nodes.next();
		write_in_file(&node, sizeof(KmerData<NodeInfo>), 1, fp);
		sz--;
	}
	if(sz != 0)
	{
		cerr << "Error: saving implicit graph does not seem to have been done right." << endl;
		cerr << "Error: there remain " << sz << " nodes to be saved." << endl;
	}

	logger->out() << "Done saving." << endl;
}

template <class NodeInfo>
size_t ImplicitGraph<NodeInfo>::initSave()
{
	savesz = size();
	
	if(savesz != nodes.count())
		cerr << "Error: "<< "inconsistency in the kmers data structure. This is a grave bug: size = " << savesz << " while count = " << nodes.count() << endl;

	nodes.begin();
	return sizeof(KmerData<NodeInfo>);
}

template <class NodeInfo>
bool ImplicitGraph<NodeInfo>::moreSave(char *buf)
{
	if(nodes.hasNext())
	{
		*((KmerData<NodeInfo> *)buf) = nodes.next();
		savesz--;
		return true;
	}
	else
		return false;
}

template <class NodeInfo>
size_t ImplicitGraph<NodeInfo>::finalizeSave()
{
	return savesz;
}


template <class NodeInfo>
void ImplicitGraph<NodeInfo>::print(FILE *fp, bool binary)
{
	size_t sz = size();
	Kmer kmer;
	
	if(sz != nodes.count())
		cerr << "Error: inconsistency in the kmers data structure. This is a grave bug: size = " << sz << " while count = " << nodes.count() << endl;

	logger->out() << "Printing " << sz << " kmers into file..." << endl;

	nodes.begin();
	while(nodes.hasNext())
	{
		KmerData<NodeInfo> node = nodes.next();
		kmer = node.first;
		if(binary)
			write_in_file(&kmer, sizeof(Kmer), 1, fp);
		else
		{
			kforge.print(node.first, fp);
			for(int n = 0; n < MAXCOLORS; n++)
				fprintf(fp, "\t%d", node.second.mult[n]); 
			fprintf(fp, "\n"); 
 		}
		sz--;
	}
	if(sz != 0)
	{
		cerr << "Error: printing the implicit graph does not seem to have been done right." << endl;
		cerr << "Error: there remain " << sz << " kmers to be printed." << endl;
	}

	logger->out() << "Done printing." << endl;
}

template <class NodeInfo>
Kmer & ImplicitGraph<NodeInfo>::smaller(Kmer & k1, Kmer & k2, bool & dual)
{
	if(!doublestrand)
	{
		dual = false;
		return k1;
	}

	if(k1 < k2)
	{
		dual = false;
		return k1;
	} else
	{
		dual = true;
		return k2;
	}
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertin(Kmer & kmer, Nucleotide nucin, Color c, int thread) 
{
	insert(kmer, setin(0, nucin), c, thread); 
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertout(Kmer & kmer, Nucleotide nucout, Color c, int thread) 
{
	insert(kmer, setout(0, nucout), c, thread); 
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertio(Kmer & kmer, Nucleotide nucin, Nucleotide nucout, Color c, int thread) 
{
	insert(kmer, setout(setin(0, nucin), nucout), c, thread); 
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertin(Kmer & kmer, Kmer & dualkmer, Nucleotide nucin, Color c, int thread) 
{
	if(!doublestrand)
		insertin(kmer, nucin, c, thread); 

	bool isdual;

	Kmer insertedkmer = smaller(kmer, dualkmer, isdual);

	if(isdual)
		insertout(insertedkmer, dualnuc(nucin), c, thread); 
	else
		insertin(insertedkmer, nucin, c, thread); 
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertout(Kmer & kmer, Kmer & dualkmer, Nucleotide nucout, Color c, int thread) 
{
	if(!doublestrand)
		insertout(kmer, nucout, c, thread); 

	bool isdual;

	Kmer insertedkmer = smaller(kmer, dualkmer, isdual);

	if(isdual)
		insertin(insertedkmer, dualnuc(nucout), c, thread); 
	else
		insertout(insertedkmer, nucout, c, thread); 
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insertio(Kmer & kmer, Kmer & dualkmer, Nucleotide nucin, Nucleotide nucout, Color c, int thread) 
{
	if(!doublestrand)
		insertio(kmer, nucin, nucout, c, thread); 

	bool isdual;

	Kmer insertedkmer = smaller(kmer, dualkmer, isdual);

	if(isdual)
		insertio(insertedkmer, dualnuc(nucout), dualnuc(nucin), c, thread); 
	else
		insertio(insertedkmer, nucin, nucout, c, thread); 
}


template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insert(Kmer& kmer, Edges mask, Color c, int thread) 
{
	KmerData<NodeInfo> *node;
	NodeInfo e;

	// ignore kmer if it does not belong to this processor	
	if(((((long int) nodes.hash(kmer)) % threadsnum) != thread))
		return; 

	// ignore kmer if it does not belong to this processor	
	if(distributor.bin(kmer) != slice)
		return;
	
	nodes.fetch(kmer, node);
	if(!node)
	{
		KmerData<NodeInfo> pair;
		pair.first = kmer;
		pair.second.edges = mask;
		pair.second.mult[c] = 1;
		nodes.insert(pair);
	} else
	{
		node->second.edges |= mask;
		if(node->second.mult[c] != (MultType)(-1)) 
			node->second.mult[c]++; 
	}
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::insert(KmerData<NodeInfo> &pair)
{
	// ignore kmer if it does not belong to this processor	
	if(distributor.bin(pair.first) != slice)
		return;

	nodes.insert(pair);
}

template <class NodeInfo>
int ImplicitGraph<NodeInfo>::outdegree(NodeInfo e)
{
	return edgeInfo[e.edges].outdeg;
}

template <class NodeInfo>
int ImplicitGraph<NodeInfo>::indegree(NodeInfo e)
{
	return edgeInfo[e.edges].indeg;
}

template <class NodeInfo>
const Nucleotide *ImplicitGraph<NodeInfo>::innuc(NodeInfo e)
{
	return edgeInfo[e.edges].innuc;
}

template <class NodeInfo>
const Nucleotide *ImplicitGraph<NodeInfo>::outnuc(NodeInfo e)
{
	return edgeInfo[e.edges].outnuc;
}

template <class NodeInfo>
int ImplicitGraph<NodeInfo>::outdegree(Edges e)
{
	return edgeInfo[e].outdeg;
}

template <class NodeInfo>
int ImplicitGraph<NodeInfo>::indegree(Edges e)
{
	return edgeInfo[e].indeg;
}

template <class NodeInfo>
const Nucleotide *ImplicitGraph<NodeInfo>::innuc(Edges e)
{
	return edgeInfo[e].innuc;
}

template <class NodeInfo>
const Nucleotide *ImplicitGraph<NodeInfo>::outnuc(Edges e)
{
	return edgeInfo[e].outnuc;
}

template <class NodeInfo>
int ImplicitGraph<NodeInfo>::rank(Kmer &kmer) 
{
	bool dual;
	Kmer dualkmer;

	if(doublestrand)
		return distributor.bin(smaller(kmer, dualkmer = kforge.dual(kmer), dual));
	else
		return distributor.bin(kmer);
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::transfer(Kmer &entrykmer, Direction direction, Unitig &unitig, ExitType &exitType) 
{
	KmerData<NodeInfo> *node;
	Kmer kmer = entrykmer, dualkmer;
	NodeInfo cure;
	bool isdual, first_time = true;
	Nucleotide nuc;

	if(doublestrand)
		dualkmer = kforge.dual(kmer);

	while(true) 
	{
		nodes.fetch(smaller(kmer, dualkmer, isdual), node);
		if(!node)
		{
			exitType = TR_NEXIST;
			break;
		}
		
		cure = node->second;

		if(cure.isVisited())
		{
			if(first_time)
				exitType = TR_NULL;
			else
				exitType = TR_LOOP;
			break;
		}

		int ind = (isdual) ? outdegree(cure) : indegree(cure), outd = (isdual) ? indegree(cure) : outdegree(cure);

		if(first_time)
		{
			unitig.coverage.init();  

			for(Coordinate c = 0; c < k; c++)
				unitig.seq.push_back(kforge.getnuc(kmer, c));

			unitig.begin_edges = (isdual) ? dualedge(cure.edges) : cure.edges;
			unitig.end_edges = (isdual) ? dualedge(cure.edges) : cure.edges;

			unitig.coverage += (Coverage) cure.mult;
			node->second.setVisited(true); // to indicate that this kmer has been visited 

			if((outd != 1 && direction == DIR_FORWARD) || (ind != 1 && direction == DIR_BACKWARD))
			{
				exitType = TR_BREAK;
				break;
			}
		} else if(ind == 1 && outd == 1)
		{
			if(direction == DIR_FORWARD)
				unitig.seq.push_back(nuc);
			else
				unitig.seq.push_front(nuc);

			unitig.coverage += (Coverage) cure.mult;
			node->second.setVisited(true); // to indicate that this kmer has been visited 
		} else
		{
			if((ind == 1 && direction == DIR_FORWARD) || (outd == 1 && direction == DIR_BACKWARD))
			{
				if(direction == DIR_FORWARD)
					unitig.seq.push_back(nuc);
				else
					unitig.seq.push_front(nuc);

				unitig.coverage += (Coverage) cure.mult;
				node->second.setVisited(true); // to indicate that this kmer has been visited 
				unitig.end_edges = (isdual) ? dualedge(cure.edges) : cure.edges;
			}
			
			exitType = TR_BREAK;
			break;
		}		

		nuc = (direction == DIR_FORWARD) ? ((isdual) ? dualnuc(innuc(cure)[0]) : outnuc(cure)[0]) : ((isdual) ? dualnuc(outnuc(cure)[0]) : innuc(cure)[0]); 
		unitig.end_edges = (isdual) ? dualedge(cure.edges) : cure.edges;

		if(direction == DIR_FORWARD)
		{
			kforge.push_end(kmer, nuc);
			if(doublestrand)
				kforge.push_begin(dualkmer, dualnuc(nuc));
		} else
		{
			kforge.push_begin(kmer, nuc);
			if(doublestrand)
				kforge.push_end(dualkmer, dualnuc(nuc));
		}

		first_time = false;
	}
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::begin()
{
	nodes.begin();
}

template <class NodeInfo>
bool ImplicitGraph<NodeInfo>::hasNext()
{
	return nodes.hasNext();
}

template <class NodeInfo>
KmerData<NodeInfo> ImplicitGraph<NodeInfo>::next()
{
	return nodes.next();
}

template <class NodeInfo>
void ImplicitGraph<NodeInfo>::resetVisitations()
{
	begin();
	while(hasNext())
	{
		KmerData<NodeInfo> *node;
		KmerData<NodeInfo> t = next();
		Kmer d = kforge.dual(t.first);
		bool isdual;

		nodes.fetch(smaller(t.first, d, isdual), node);
		node->second.setVisited(false);
	}

}

