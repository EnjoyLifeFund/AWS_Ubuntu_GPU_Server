/*
Copyright 2011- Hamidreza Chitsaz (chitsaz@chitsazlab.org)

    This file is part of HyDA.

    HyDA is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    HyDA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with HyDA; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


/***************************************************************************
 * Title:          heap.C 
 * Author:         Hamidreza Chitsaz
 * Created:        2011
 * Last modified:  10/10/2011
 *
 * Copyright (c) 2011- Hamidreza Chitsaz
 * All Rights Reserved
 * See file LICENSE for details.
 ***************************************************************************/


#include "heap.h"


template <class Element>
Heap<Element>::Heap()
{
	N = 0;
	maxN = 0;
	list = NULL;
	expand();
}

template <class Element>
Heap<Element>::~Heap()
{
	if(list) alloc.xfree((void*&)list);
}

template <class Element>
void Heap<Element>::expand()
{
	maxN += HEAPINITSIZE;
	list = (Element **)alloc.xrealloc(list, maxN*sizeof(Element*));
}

template <class Element>
void Heap<Element>::insert(Element *data)
{
	if(N >= maxN)
		expand();

	data->heapNode = N;
	list[N++] = data;
	heapup(N-1);

//	verify();
}

template <class Element>
Element *Heap<Element>::extractMin()
{
	Element *ret;

	if(N == 0)
		ret = NULL;
	else
	{	
		ret = list[0];
		N--;
		swap(0, N);

		heapdown();
	}

//	verify();

	return ret;
}

template <class Element>
void Heap<Element>::update(Element *data)
{
	heapup(data->heapNode);

//	verify();
}

template <class Element>
void Heap<Element>::heapdown()
{
	register unsigned int node = 0;
	register bool done = (N == 0);
	register unsigned int left;
	register unsigned int right;
	register unsigned int minchild;

	while(!done)
	{
		left = (node << 1);
		right = (node << 1) + 1;
		minchild = node;

		if(left < N && *(list[left]) < *(list[node]))
			minchild = left;

		if(right < N && *(list[right]) < *(list[minchild]))
			minchild = right;

		if(minchild != node)
		{
			swap(minchild, node);
			node = minchild;
		} else
			done = true;
	}
}

template <class Element>
void Heap<Element>::heapup(unsigned int node)
{
	register unsigned int p;

	while(node && *(list[node]) < *(list[p = node >> 1]))
	{
		swap(p, node);		
		node = p;
	}
}

template <class Element>
inline void Heap<Element>::swap(unsigned int a, unsigned int b)
{
	register Element *temp = list[a];
	list[a] = list[b];
	list[b] = temp;
	list[a]->heapNode = a;
	list[b]->heapNode = b;
}

/*template <class Element>
void Heap<Element>::verify()
{
	if(N == 0)
		return;

	for(size_t i = 0; i <= (N / 2)+1; i++)
	{
		if(2*i < N && *(list[2*i]) < *(list[i]))
		{
			cout << i << "  " << 2*i << endl;
			cout << N << endl;
			cout << list[i]->distance << endl;
			cout.flush();
			exitMsg((char*)"Wooooow\n", 100);
		} 
		if(2*i+1 < N && *(list[2*i+1]) < *(list[i]))
		{
			cout << i << "  " << 2*i+1 << endl;
			cout << N << endl;
			cout << list[i]->distance << endl;
			cout.flush();
			exitMsg((char*)"Wooooow\n", 100);
		} 
	}	
}*/


