README_squeezambler.TXT

Squeezambler 1.1.0 and Squeezambler 2.0.3 are parts of HyDA 1.3.1 Source Code Package Released Under GNU GPL v3 License.
See the accompanying file LICENSE.txt for the details of the license. 
Sep 17, 2014
Zeinab Taghavi
ztaghavi@cs.colostate.edu
Colorado State University
Fort Collins, CO

> SUMMARY
	* A/ Credits
	* B/ Installation
	* C/ Usage
	* D/ Examples

----------------------------------------------------------------------------------
A/ Credits

See the accompanying file CREDIT_squeezambler.TXT.

References

Zeinab Taghavi, Ensemble Analysis of Adaptive Compressed Genome Sequencing Strategies. RECOMB-SEQ 2014 (arXiv:1310.6401 [q-bio.GN]).

Zeinab Taghavi, Narjes S. Movahedi, Sorin Draghici, Hamidreza Chitsaz, Distilled single-cell genome sequencing and de novo assembly for sparse microbial communities. Bioinformatics 29(19), 2395–2401 (2013) (arXiv:1305.0062 [q-bio.GN]).

----------------------------------------------------------------------------------
A/ Installation

Refer to HyDA installation in README_hyda.txt.

----------------------------------------------------------------------------------
C/ Usage

This package includes 2 versions of squeezambler: 
(1) squeezambler2 includes BFS and DFS methods based on algorithm given in [1], and 
(2) sqeezambler, which is the modified version of squeezambler 1.0.0, includs BFS method with search strategy based on [2] and resource allocation method based on [1]. 


C-1/ sqeezambler2

Usage: squeezambler2 [options] input-setup-file
input-setup-file format:
       Each TAB separated line of input setup file is either
       >f       FASTAFilename
       or
       >q       FASTQFilename


        -V,--version      prints the version
        -h,--help      shows this help
        -O,--output      =output files prefix (default sqzout)
        -s,--searchmethod      = method of search; 0: BFS; 1: DFS (default 1)
        -g,--groups      =the number of division groups (default 2)
        -b,--nucs      =number of sampled nucleotides per cell in the first iteration (default 5,000,000nt)
        -c,--completeGenomeMinCoverage      =estimated minimum coverage needed to assemble a genome completely (default 15)
        -t,--inclusionthreshold      =tau, the cutoff for the individual assembly size / total assembly size ratio to detect assembly inclusion (default 0.2)
        -k,--kmer      =k as in kmer (default 55) [ASSEMBLY RELATED]
        -f,--covcutoff      =minimum average coverage of a condensed node as a multiple of mean coverage in the first condensation (default 1.0) [ASSEMBLY RELATED]
        -l,--lowcovlen      =maximum length of a low average coverage condensed node to be removed (default 1000nt) [ASSEMBLY RELATED]
        -p,--procs      =number of threads per processing node (default 1) [ASSEMBLY RELATED]
           --mincontiglen      =minimum length of an output contig (default 100) [ASSEMBLY RELATED]

C-2/ sqeezambler

Usage: squeezambler [options] input-setup-file
input-setup-file format:
       Each TAB separated line of input setup file is either
       >f       FASTAFilename
       or
       >q       FASTQFilename


        -V,--version      prints the version
        -h,--help      shows this help
        -O,--output      =output files prefix (default sqzout)
        -g,--groups      =the number of division groups (default 2)
        -b,--nucs      =number of sampled nucleotides per cell in the first iteration (default 5,000,000nt)
        -c,--genomecoverage      =estimated coverage of each distinct genome in each iteration (default 15)
        -t,--inclusionthreshold      =tau, the cutoff for the individual assembly size / total assembly size ratio to detect assembly inclusion (default 0.2)
        -e,--inclusionexception      =minimum individual assembly size to override tau-based inclusion (default 500,000nt)
                if the individual assembly size is minimum e, then no matter what the result of D_tau, the inclusion does not hold.
        -k,--kmer      =k as in kmer (default 55) [ASSEMBLY RELATED]
        -f,--covcutoff      =minimum average coverage of a condensed node as a multiple of mean coverage in the first condensation (default 1.0) [ASSEMBLY RELATED]
        -l,--lowcovlen      =maximum length of a low average coverage condensed node to be removed (default 1000nt) [ASSEMBLY RELATED]
        -p,--procs      =number of threads per processing node (default 1) [ASSEMBLY RELATED]
           --mincontiglen      =minimum length of an output contig (default 100) [ASSEMBLY RELATED]



For more detailed description of the parameters refer to [1] and [2] and for the ones tagged with [ASSEMBLY RELATED] refer to README_hyda.txt.

----------------------------------------------------------------------------------
D/ Examples

D-1/ Results in [2]

For reproducing results in [2] use squeezambler 1.0.

D-2/Results in table 3 of [1]

The following commands will run the first 4 lines of table 3 of [1] for 31 cells and 6 distinc genomes setup.

1- Naive
$ squeezambler2 -O=31_6_g31n132M_Naive	-b=132000000	-s=0	-t=0.1	-g=31	inputFilesList31_6.txt

2- squeezambler 1.1, BFS
$ squeezambler -O=31_6_g2n05M_BFS_1_1	-b=500000	-t=0.1	inputFilesList31_6.txt

3- squeezambler 2.0, BFS
$ squeezambler2 -O=31_6_g2n05M_BFS_2_0 	-b=500000	-s=0	-t=0.1	inputFilesList31_6.txt

4- squeezambler 2.0, DFS
$ squeezambler2 -O=31_6_g2n05M_DFS_2_0 	-b=500000	-t=0.1	inputFilesList31_6.txt


The inputFilesList31_6.txt is the corresponding input setup file of the first simulation setup listed in Table 2 of [2]. The fasta files used are 31 independant instances of simulated illumina reads of DNA of 6 different species listed in Table 1 of [1]. The DNA strands are sequenced using simulator ART [4] software. The first few letters of each filename indicate the NCBI ID of the corresponding species. This file includes the following content:

inputFilesList31_6.txt

>f	NC_004663.fasta
>f	FP929051_3.fasta
>f	NC_008532_1.fasta
>f	NC_009615_3.fasta
>f	NC_016776_1.fasta
>f	NC_004663_5.fasta
>f	FP929051_1.fasta
>f	NC_004663_8.fasta
>f	FP929051_11.fasta
>f	NC_004663_10.fasta
>f	FP929051_4.fasta
>f	NC_009614_3.fasta
>f	NC_004663_9.fasta
>f	NC_009615_2.fasta
>f	FP929051_6.fasta
>f	NC_004663_2.fasta
>f	NC_004663_3.fasta
>f	FP929051_10.fasta
>f	NC_004663_4.fasta
>f	FP929051_9.fasta
>f	NC_009614_1.fasta
>f	NC_009614_4.fasta
>f	FP929051_7.fasta
>f	NC_004663_11.fasta
>f	FP929051_5.fasta
>f	NC_009614_2.fasta
>f	NC_004663_6.fasta
>f	FP929051_8.fasta
>f	NC_009615_1.fasta
>f	FP929051_2.fasta
>f	NC_004663_7.fasta



------------------------------------------------------------------------------------
E/ References

[1] Zeinab Taghavi, Ensemble Analysis of Adaptive Compressed Genome Sequencing Strategies. RECOMB-SEQ 2014 (arXiv:1310.6401 [q-bio.GN]).

[2] Zeinab Taghavi, Narjes S. Movahedi, Sorin Draghici, Hamidreza Chitsaz, Distilled single-cell genome sequencing and de novo assembly for sparse microbial communities. Bioinformatics 29(19), 2395–2401 (2013) (arXiv:1305.0062 [q-bio.GN]).

[3] Taghavi, Z. and Draghici, S. (2012). Mdasim: A multiple displacement amplification simulator. In IEEE Conference on Bioinformatics and Biomedicine, pages 575–578.

[4] Huang, W., et al. (2012). ART: a next-generation sequencing read simulator. Bioinformatics, 28(4), 593–594.


