/* Generated automatically. */
static const char configuration_arguments[] = "../configure --prefix=@@HOMEBREW_PREFIX@@/Cellar/gcc@6/6.4.0  --enable-languages=c,c++,objc,obj-c++,fortran --program-suffix=-6 --with-gmp=@@HOMEBREW_PREFIX@@/opt/gmp --with-mpfr=@@HOMEBREW_PREFIX@@/opt/mpfr --with-mpc=@@HOMEBREW_PREFIX@@/opt/libmpc --with-isl=@@HOMEBREW_PREFIX@@/opt/isl  --enable-stage1-checking --enable-checking=release --enable-lto --with-build-config=bootstrap-debug --disable-werror --with-pkgversion='Homebrew GCC 6.4.0' --with-bugurl=https://github.com/Homebrew/homebrew-core/issues --with-dwarf2 --disable-nls --disable-multilib";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
