class SnpSites < Formula
  desc "Find SNP sites in a multi FASTA alignment file"
  homepage "https://github.com/sanger-pathogens/snp-sites"
  # doi "10.1101/038190"
  # tag "bioinformatics"

  url "https://github.com/sanger-pathogens/snp-sites/archive/2.3.2.tar.gz"
  sha256 "7a77af914b0baa425ccacedf2e4fbb2cac984fe671f3d8c07d98d3596202ed89"
  head "https://github.com/sanger-pathogens/snp-sites.git"

  depends_on "autoconf" => :build
  depends_on "automake" => :build
  depends_on "libtool" => :build
  depends_on "pkg-config" => :build
  depends_on "check" => :build

  def install
    system "autoreconf", "-i"
    system "./configure",
           "--disable-debug",
           "--disable-dependency-tracking",
           "--prefix=#{prefix}"

    system "make", "install"

    ln_s "#{bin}/snp-sites", "#{bin}/snp_sites"
    pkgshare.install "tests/data"
  end

  test do
    assert_match "#{version}", shell_output("#{bin}/snp-sites -V 2>&1", 0)
  end
end
