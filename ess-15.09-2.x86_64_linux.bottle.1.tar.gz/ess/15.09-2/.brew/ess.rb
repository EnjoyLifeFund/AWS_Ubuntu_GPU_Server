class Ess < Formula
  desc "Emacs Speaks Statistics"
  homepage "https://ess.r-project.org/"
  url "https://ess.r-project.org/downloads/ess/ess-15.09-2.tgz"
  version "15.09-2"
  sha256 "706c41237e1edf33a369902f503bb25254b2bbb750b9ed1adee244e875264afb"

  depends_on :emacs => "23"

  def install
    system "make", "install", "PREFIX=#{prefix}"
  end

  test do
    (testpath/".emacs").write <<-EOS.undent
      (add-to-list 'load-path "#{elisp}")
      (require 'ess-site)
    EOS
    (testpath/"test.r").write <<-EOS.undent
      foo(a,
      b)
    EOS
    system "emacs", "-Q", "--batch", "-l", testpath/".emacs",
           "test.r", "--eval", "(ess-indent-exp)", "-f", "save-buffer"

    expected = <<-EOS.undent
      foo(a,
          b)
    EOS
    assert_equal expected, (testpath/"test.r").read
  end
end
