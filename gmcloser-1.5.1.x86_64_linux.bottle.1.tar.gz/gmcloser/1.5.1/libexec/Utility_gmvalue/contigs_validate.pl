#!/usr/bin/env perl
use warnings;
use strict;
use Getopt::Long;
use Pod::Usage;

# Generate a contig fasta file whose contigs are broken at misassembled positions
# The misassembled positions are obtained from 'out.1coords' file

my $contig_file = '';
my $align_pos_file = '';
my $ref_file = '';
my $min_identity = 97;
my $min_contig_len = 200;
my $min_coverage = 99;
my $prefix_out = 'out';
my $error_correct = 0;
my $max_indel_size = 100;
my $help;

GetOptions(
    'query|q=s' => \$contig_file,
    'align|a=s' => \$align_pos_file,
    'ref|r=s' => \$ref_file,
    'min_id|mi=i' => \$min_identity,
    'min_len|ml=i' => \$min_contig_len,
    'min_cov|mc=i' => \$min_coverage,
    'prefix|p=s' => \$prefix_out,
    'enable_out|e' => \$error_correct,
    'max_indel|xi=i' => \$max_indel_size,
    'help' => \$help
) or pod2usage(-verbose => 0);

pod2usage(-verbose => 0) if $help;
pod2usage(-verbose => 0) if ($contig_file eq '');
pod2usage(-verbose => 0) if ($align_pos_file eq '');
pod2usage(-verbose => 0) if ($ref_file eq '') and ($error_correct == 1);

=head1 SYNOPSIS

  Options:
   --query or -q <STR>      an input contig fasta file (e.g., contig1.fa)
   --align or -a <STR>      an input coordinate file (i.e., out.1coords from gage-paper-validation/getCorrectnessStats.sh)
   --ref or -r <STR>        an input reference file (e.g., ref.fa) [mandatory when --dis_out is false]
   --min_id or -mi <INT>    a minimum alignment identity (%) [default: 95]
   --min_len or -ml <INT>   a minimum contig length to be output [default: 200]
   --min_cov or -mc <INT>   a minimum coverage (%) of query (contig) aligned to a reference [default: 95]
   --prefix or -p <STR>     prefix name of outputs
   --enable_out or -e       enable output of a corrected contig file (only output stat file) [default: false]
   --max_indel or -xi <INT> a maximum indel size considered splitted assembly as right assembly 
   --help or -h             output help message
   
=cut

my %ref_seq;
my $chr_name = '-';
my $Rseq = '';
open (FILE, $ref_file) or die "$!";
while (my $line = <FILE>){
    $line =~ s/(\r\n|\n|\r)//g;
    if ($line =~ /^>(\S+)/){
        if ($chr_name ne '-'){
            $ref_seq{$chr_name} = uc $Rseq;
            $Rseq = '';
        }
        $chr_name = $1;
    }
    else{
        $Rseq .= $line;
    }
}
$ref_seq{$chr_name} = uc $Rseq;
$Rseq = '';
close (FILE);

my $query_name = '-';
my $Qseq = '';
my %query_seq;
my %query_length;
open (FILE, $contig_file) or die "$!";
while (my $line = <FILE>){
    chomp $line;
    if ($line =~ /^>(\S+)/){
        if ($query_name ne '-'){
            $query_seq{$query_name} = uc $Qseq;
            $query_length{$query_name} = length $Qseq;
            $Qseq = '';
        }
        $query_name = $1;
    }
    else{
        $Qseq .= $line;
    }
}
$query_seq{$query_name} = uc $Qseq;
$query_length{$query_name} = length $Qseq;
$Qseq = '';
close (FILE);

my %partial_match;
my %broken_query_seq;
my %misassemble_query;
my %assemble_query;

open (FILE, $align_pos_file) or die "$!";
while (my $line = <FILE>){
    chomp $line;
    next if ($line !~ /^\d+/);
    my @line = split (/\s+/, $line);
    my $qname = $line[12];
    if ($line[10] >= $min_coverage){
        $assemble_query{$qname} = 1;
        next;
    }
    my $tstart = $line[0];
    my $tend = $line[1];
    my $strand = 'Plus' if ($line[2] < $line[3]);
    $strand = 'Minus' if ($line[2] > $line[3]);
    my $qstart = $line[2] if ($strand eq 'Plus');
    $qstart = $line[3] if ($strand eq 'Minus');
    my $qend = $line[2] if ($strand eq 'Minus');
    $qend = $line[3] if ($strand eq 'Plus');
    my $identity = $line[6];
    my $overlen = $line[4];
    my $qlen = $line[8];
    my $tlen = $line[7];
    my $tname = $line[11];
    my $qrange = "$qstart=$qend";
    if (!exists $assemble_query{$qname}){
        ${${${$partial_match{$tname}}{$qname}}{$strand}}{$tstart} = "$tend==$qstart==$qend==$overlen==$identity";
    }
}
close (FILE);

foreach my $tname (keys %partial_match){
    my $tlen = length $ref_seq{$tname};
    foreach my $qname (keys %{$partial_match{$tname}}){
        next if (exists $assemble_query{$qname});
        my $qlen = length $query_seq{$qname};
        foreach my $strand (keys %{${$partial_match{$tname}}{$qname}}){
            my $pre_tend = 0;
            my $pre_tstart = 0;
            my $pre_qend = 0;
            my $pre_qstart = 0;
            my $count_align = 0;
            my $align_num = scalar keys %{${${$partial_match{$tname}}{$qname}}{$strand}};
            foreach my $tstart (sort {$a<=>$b} keys %{${${$partial_match{$tname}}{$qname}}{$strand}}){
                $count_align ++;
                my ($tend, $qstart, $qend, $overlen, $ident) = split (/==/, ${${${$partial_match{$tname}}{$qname}}{$strand}}{$tstart});
                if ($count_align == 1){                     # considerer the gap regions and the 5'-terminus of the reference
                    if ($strand eq 'Plus'){
                        if ($qstart > 10){
                            if ($tstart <= 2){
                                $qstart = 1;
                            }
                            elsif ($tstart > 10){
                                my $upstream_seq = substr ($ref_seq{$tname}, $tstart - $qstart, $qstart - 6) if ($tstart - $qstart >= 0);
                                $upstream_seq = substr ($ref_seq{$tname}, 0, $tstart - 6) if ($tstart - $qstart + 1 < 0);
                                if ($upstream_seq =~ /^N+$/){
                                    $qstart = 1;
                                }
                            }
                        }
                    }
                    else{
                        if ($qend <= $qlen - 10){
                            if ($tstart <= 2){
                                $qend = $qlen;
                            }
                            elsif ($tstart > 10){
                                my $upstream_seq = substr ($ref_seq{$tname}, $tstart - ($qlen - $qend + 1), $qlen - $qend - 5) if ($tstart - ($qlen - $qend + 1) >= 0);
                                $upstream_seq = substr ($ref_seq{$tname}, 0, $qlen - $qend - 5) if ($tstart - ($qlen - $qend + 1) < 0);
                                if ($upstream_seq =~ /^N+$/){
                                    $qend = $qlen;
                                }
                            }
                        }
                    }
                }
                if ($count_align == $align_num){            # considerer the gap regions and the 3'-terminus of the reference
                    if ($strand eq 'Plus'){
                        if ($qend <= $qlen - 10){
                            if ($tend >= $tlen - 2){
                                $qend = $qlen;
                            }
                            elsif ($tend <= $tlen - 10){
                                my $downstream_seq = substr ($ref_seq{$tname}, $tend + 4, $qlen - $qend - 5) if ($tend + $qlen - $qend <= $tlen);
                                $downstream_seq = substr ($ref_seq{$tname}, $tend + 4) if ($tend + $qlen - $qend > $tlen);
                                if ($downstream_seq =~ /^N+$/){
                                    $qend = $qlen;
                                }
                            }
                        }
                    }
                    else{
                        if ($qstart > 10){
                            if ($tend >= $tlen - 2){
                                $qstart = 1;
                            }
                            elsif ($tend <= $tlen - 10){
                                my $downstream_seq = substr ($ref_seq{$tname}, $tend + 4, $qstart - 5) if ($tend + $qstart <= $tlen);
                                $downstream_seq = substr ($ref_seq{$tname}, $tend + 4) if ($tend + $qstart > $tlen);
                                if ($downstream_seq =~ /^N+$/){
                                    $qstart = 1;
                                }
                            }
                        }
                    }
                }
                if ($pre_tend > 0){
                    if ($tend <= $pre_tend){
                        next;
                    }
                    if (($qend > $pre_qend) and ($qstart < $pre_qstart)){
                        $pre_tend = $tend;
                        $pre_tstart = $tstart;
                        $pre_qend = $qend;
                        $pre_qstart = $qstart;
                        next;
                    }
                    my $t_distance = abs ($tstart - $pre_tend);
                    my $q_distance = abs ($qstart - $pre_qend) if ($strand eq 'Plus');
                    $q_distance = abs ($qend - $pre_qstart) if ($strand eq 'Minus');
                    if (($q_distance <= $max_indel_size) and ($t_distance <= $max_indel_size)){
                        $pre_tend = $tend;
                        $pre_qend = $qend if ($strand eq 'Plus');
                        $pre_qstart = $qstart if ($strand eq 'Minus');
                        next;
                    }
                    else{
                        my $total_overlen = $pre_qend - $pre_qstart + 1;
                        if ($total_overlen / $qlen * 100 >= $min_coverage){
                            $assemble_query{$qname} = 1;
                        }
                        else{
                            if (!exists $assemble_query{$qname}){
                                if ($total_overlen >= $min_contig_len){
                                    if (!exists ${$broken_query_seq{$qname}}{$pre_qstart}){
                                        ${$broken_query_seq{$qname}}{$pre_qstart} = $total_overlen;
                                    }
                                    else{
                                        my $pre_overlen = ${$broken_query_seq{$qname}}{$pre_qstart};
                                        if ($total_overlen > $pre_overlen){
                                            ${$broken_query_seq{$qname}}{$pre_qstart} = $total_overlen;
                                        }
                                    }
                                }
                                else{
                                    $misassemble_query{$qname} = 1;
                                }
                            }
                        }
                    }
                }
                $pre_tend = $tend;
                $pre_tstart = $tstart;
                $pre_qend = $qend;
                $pre_qstart = $qstart;
            }
            my $total_overlen = $pre_qend - $pre_qstart + 1;
            if ($total_overlen / $qlen * 100 >= $min_coverage){
                $assemble_query{$qname} = 1;
            }
            else{
                if (!exists $assemble_query{$qname}){
                    if ($total_overlen >= $min_contig_len){
                        my $total_overlen = $pre_qend - $pre_qstart + 1;
                        if (!exists ${$broken_query_seq{$qname}}{$pre_qstart}){
                            ${$broken_query_seq{$qname}}{$pre_qstart} = $total_overlen;
                        }
                        else{
                            my $pre_overlen = ${$broken_query_seq{$qname}}{$pre_qstart};
                            if ($total_overlen > $pre_overlen){
                                ${$broken_query_seq{$qname}}{$pre_qstart} = $total_overlen;
                            }
                        }
                    }
                    else{
                        $misassemble_query{$qname} = 1;
                    }
                }
            }
        }
    }
}

my %broken_query_seq_2;
foreach my $qname (keys %broken_query_seq){
    next if (exists $assemble_query{$qname});
    my %selected;
    my $pre_qend = 0;
    my $sub_num = 0;
    foreach my $qstart (sort {${$broken_query_seq{$qname}}{$b} <=> ${$broken_query_seq{$qname}}{$a}} keys %{$broken_query_seq{$qname}}){
        my $qend = $qstart + ${$broken_query_seq{$qname}}{$qstart} - 1;
        my $overlap_flag = 0;
        if (scalar keys %selected >= 1){
            foreach my $start2 (keys %selected){
                my $end2 = $selected{$start2};
                if ($qstart eq $start2){
                    $overlap_flag = 1;
                    last;
                }
                elsif (($qstart > $start2) and ($qend < $end2)){
                    $overlap_flag = 1;
                    last;
                }
                elsif (($qstart < $start2) and ($qend > $start2) and (($qend - $start2 >= ($end2 - $start2) * 0.8) or ($qend - $start2 >= ($qend - $qstart) * 0.8))){
                    $overlap_flag = 1;
                    last;
                }
                elsif (($qstart < $end2) and ($qend > $end2) and (($end2 - $qstart >= ($end2 - $start2) * 0.8) or ($end2 - $qstart >= ($qend - $qstart) * 0.8))){
                    $overlap_flag = 1;
                    last;
                }
            }
            if ($overlap_flag == 0){
                $selected{$qstart} = $qend;
            }
        }
        else{
            $selected{$qstart} = $qend;
        }
    }
    foreach my $qstart (keys %selected){
        ${$broken_query_seq_2{$qname}}{$qstart} = $selected{$qstart};
    }
}

my $out_misassemble_query_list = $prefix_out . '.misassemble.subcontig.list.txt';

open (OUT2, "> $out_misassemble_query_list");
foreach my $qname (keys %broken_query_seq_2){
    next if (exists $assemble_query{$qname});
    my $qlen = length $query_seq{$qname};
    my $pre_qend = 0;
    my $sub_num = 0;
    my $broken_num = scalar keys %{$broken_query_seq_2{$qname}};
    foreach my $qstart (sort {$a <=> $b} keys %{$broken_query_seq_2{$qname}}){
        $qstart = 1 if ($qstart < 1);
        my $qend = ${$broken_query_seq_2{$qname}}{$qstart};
        $qend = $qlen if ($qend > $qlen);
        next if ($pre_qend >= $qend);
        if ($qstart <= $pre_qend){
            $qstart = $pre_qend + 1;
        }
        $sub_num ++;
        print OUT2 "$qname\t$qstart\t$qend\n";
        $pre_qend = $qend;
    }
}
close (OUT2);
