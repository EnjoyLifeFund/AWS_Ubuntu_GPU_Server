class Sound:
    has_sound = 0   # no sound
    has_music = 0   # no music
    def __init__(self):
        pass
