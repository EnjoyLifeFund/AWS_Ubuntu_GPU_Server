elseif
------

Starts the elseif portion of an if block.

::

  elseif(expression)

See the :command:`if` command.
