
# This will be automatically populated by git via export-subst.
# cf. ./.gitattributes

COMMIT='1ac1aa05017832ee731461aa382d89d0847c582c'
NAMES=' (tag: 0.29.1)'
DATE='2017-03-26 17:24:25 -0500'
