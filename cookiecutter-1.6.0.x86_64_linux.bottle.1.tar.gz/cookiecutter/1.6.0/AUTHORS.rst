=======
Credits
=======

Development Leads
-----------------

* Audrey Roy Greenfeld (`@audreyr`_)
* Daniel Roy Greenfeld (`@pydanny`_)

Core Committers
---------------

* Michael Joseph (`@michaeljoseph`_)
* Paul Moore (`@pfmoore`_)
* Raphael Pierzina (`@hackebrot`_)

Contributors
------------

* Steven Loria (`@sloria`_)
* Goran Peretin (`@gperetin`_)
* Hamish Downer (`@foobacca`_)
* Thomas Orozco (`@krallin`_)
* Jindrich Smitka (`@s-m-i-t-a`_)
* Benjamin Schwarze (`@benjixx`_)
* Raphi (`@raphigaziano`_)
* Thomas Chiroux (`@ThomasChiroux`_)
* Sergi Almacellas Abellana (`@pokoli`_)
* Alex Gaynor (`@alex`_)
* Rolo (`@rolo`_)
* Pablo (`@oubiga`_)
* Bruno Rocha (`@rochacbruno`_)
* Alexander Artemenko (`@svetlyak40wt`_)
* Mahmoud Abdelkader (`@mahmoudimus`_)
* Leonardo Borges Avelino (`@lborgav`_)
* Chris Trotman (`@solarnz`_)
* Rolf (`@relekang`_)
* Noah Kantrowitz (`@coderanger`_)
* Vincent Bernat (`@vincentbernat`_)
* Germán Moya (`@pbacterio`_)
* Ned Batchelder (`@nedbat`_)
* Dave Dash (`@davedash`_)
* Johan Charpentier (`@cyberj`_)
* Éric Araujo (`@merwok`_)
* saxix (`@saxix`_)
* Tzu-ping Chung (`@uranusjr`_)
* Caleb Hattingh (`@cjrh`_)
* Flavio Curella (`@fcurella`_)
* Adam Venturella (`@aventurella`_)
* Monty Taylor (`@emonty`_)
* schacki (`@schacki`_)
* Ryan Olson (`@ryanolson`_)
* Trey Hunner (`@treyhunner`_)
* Russell Keith-Magee (`@freakboy3742`_)
* Mishbah Razzaque (`@mishbahr`_)
* Robin Andeer (`@robinandeer`_)
* Rachel Sanders (`@trustrachel`_)
* Rémy Hubscher (`@Natim`_)
* Dino Petron3 (`@dinopetrone`_)
* Peter Inglesby (`@inglesp`_)
* Ramiro Batista da Luz (`@ramiroluz`_)
* Omer Katz (`@thedrow`_)
* lord63 (`@lord63`_)
* Randy Syring (`@rsyring`_)
* Mark Jones (`@mark0978`_)
* Marc Abramowitz (`@msabramo`_)
* Lucian Ursu (`@LucianU`_)
* Osvaldo Santana Neto (`@osantana`_)
* Matthias84 (`@Matthias84`_)
* Simeon Visser (`@svisser`_)
* Guruprasad (`@lgp171188`_)
* Charles-Axel Dein (`@charlax`_)
* Diego Garcia (`@drgarcia1986`_)
* maiksensi (`@maiksensi`_)
* Andrew Conti (`@agconti`_)
* Valentin Lab (`@vaab`_)
* Ilja Bauer (`@iljabauer`_)
* Elias Dorneles (`@eliasdorneles`_)
* Matias Saguir (`@mativs`_)
* Johannes (`@johtso`_)
* macrotim (`@macrotim`_)
* Will McGinnis (`@wdm0006`_)
* Cédric Krier (`@cedk`_)
* Tim Osborn (`@ptim`_)
* Aaron Gallagher (`@habnabit`_)
* Fábio C. Barrionuevo da Luz (`@luzfcb`_)
* mozillazg (`@mozillazg`_)
* Joachim Jablon (`@ewjoachim`_)
* Andrew Ittner (`@tephyr`_)
* Diane DeMers Chen (`@purplediane`_)
* zzzirk (`@zzzirk`_)
* Carol Willing (`@willingc`_)
* phoebebauer (`@phoebebauer`_)
* Adam Chainz (`@adamchainz`_)
* Sulé (`@suledev`_)
* Evan Palmer (`@palmerev`_)
* Bruce Eckel (`@BruceEckel`_)
* Robert Lyon (`@ivanlyon`_)
* Terry Bates (`@terryjbates`_)
* Brett Cannon (`@brettcannon`_)
* Michael Warkentin (`@mwarkentin`_)
* Bartłomiej Kurzeja (`@B3QL`_)
* Thomas O'Donnell (`@andytom`_)
* Jeremy Carbaugh (`@jcarbaugh`_)
* Nathan Cheung (`@cheungnj`_)
* Abdó Roig-Maranges (`@aroig`_)
* Steve Piercy (`@stevepiercy`_)
* Corey (`@coreysnyder04`_)
* Dmitry Evstratov (`@devstrat`_)
* Eyal Levin (`@eyalev`_)
* mathagician (`@mathagician`_)
* Guillaume Gelin (`@ramnes`_)
* @delirious-lettuce (`@delirious-lettuce`_)
* Gasper Vozel (`@karantan`_)
* Joshua Carp (`@jmcarp`_)
* @meahow (`@meahow`_)

.. _`@cedk`: https://github.com/cedk
.. _`@johtso`: https://github.com/johtso
.. _`@maiksensi`: https://github.com/maiksensi
.. _`@svisser`: https://github.com/svisser
.. _`@LucianU`: https://github.com/LucianU
.. _`@osantana`: https://github.com/osantana
.. _`@msabramo`: https://github.com/msabramo
.. _`@mark0978`: https://github.com/mark0978
.. _`@rsyring`: https://github.com/rsyring
.. _`@vincentbernat`: https://github.com/vincentbernat
.. _`@audreyr`: https://github.com/audreyr
.. _`@pydanny`: https://github.com/pydanny
.. _`@sloria`: https://github.com/sloria
.. _`@gperetin`: https://github.com/gperetin
.. _`@foobacca`: https://github.com/foobacca
.. _`@krallin`: https://github.com/krallin
.. _`@s-m-i-t-a`: https://github.com/s-m-i-t-a
.. _`@benjixx`: https://github.com/benjixx
.. _`@raphigaziano`: https://github.com/raphigaziano
.. _`@ThomasChiroux`: https://github.com/ThomasChiroux
.. _`@pokoli`: https://github.com/pokoli
.. _`@alex`: https://github.com/alex
.. _`@rolo`: https://github.com/rolo
.. _`@oubiga`: https://github.com/oubiga
.. _`@michaeljoseph`: https://github.com/michaeljoseph
.. _`@rochacbruno`: https://github.com/rochacbruno
.. _`@svetlyak40wt`: https://github.com/svetlyak40wt
.. _`@mahmoudimus`: https://github.com/mahmoudimus
.. _`@lborgav`: https://github.com/lborgav
.. _`@solarnz`: https://github.com/solarnz
.. _`@relekang`: https://github.com/relekang
.. _`@coderanger`: https://github.com/coderanger
.. _`@pbacterio`: https://github.com/pbacterio
.. _`@nedbat`: https://github.com/nedbat
.. _`@davedash`: https://github.com/davedash
.. _`@cyberj`: https://github.com/cyberj
.. _`@merwok`: https://github.com/merwok
.. _`@hackebrot`: https://github.com/hackebrot
.. _`@saxix`: https://github.com/saxix
.. _`@uranusjr`: https://github.com/uranusjr
.. _`@cjrh`: https://github.com/cjrh
.. _`@pfmoore`: https://github.com/pfmoore
.. _`@fcurella`: https://github.com/fcurella
.. _`@aventurella`: https://github.com/aventurella
.. _`@emonty`: https://github.com/emonty
.. _`@schacki`: https://github.com/schacki
.. _`@ryanolson`: https://github.com/ryanolson
.. _`@treyhunner`: https://github.com/treyhunner
.. _`@freakboy3742`: https://github.com/freakboy3742
.. _`@mishbahr`: https://github.com/mishbahr
.. _`@robinandeer`: https://github.com/robinandeer
.. _`@trustrachel`: https://github.com/trustrachel
.. _`@Natim`: https://github.com/Natim
.. _`@dinopetrone`: https://github.com/dinopetrone
.. _`@inglesp`: https://github.com/inglesp
.. _`@ramiroluz`: https://github.com/ramiroluz
.. _`@thedrow`: https://github.com/thedrow
.. _`@lord63`: https://github.com/lord63
.. _`@Matthias84`: https://github.com/Matthias84
.. _`@lgp171188`: https://github.com/lgp171188
.. _`@charlax`: https://github.com/charlax
.. _`@drgarcia1986`: https://github.com/drgarcia1986
.. _`@agconti`: https://github.com/agconti
.. _`@vaab`: https://github.com/vaab
.. _`@iljabauer`: https://github.com/iljabauer
.. _`@eliasdorneles`: https://github.com/eliasdorneles
.. _`@mativs`: https://github.com/mativs
.. _`@macrotim`: https://github.com/macrotim
.. _`@wdm0006`: https://github.com/wdm0006
.. _`@ptim`: https://github.com/ptim
.. _`@habnabit`: https://github.com/habnabit
.. _`@luzfcb`: https://github.com/luzfcb
.. _`@mozillazg`: https://github.com/mozillazg
.. _`@ewjoachim`: https://github.com/ewjoachim
.. _`@tephyr`: https://github.com/tephyr
.. _`@purplediane`: https://github.com/purplediane
.. _`@willingc`: https://github.com/willingc
.. _`@phoebebauer`: https://github.com/phoebebauer
.. _`@adamchainz`: https://github.com/adamchainz
.. _`@suledev`: https://github.com/suledev
.. _`@palmerev`: https://github.com/palmerev
.. _`@BruceEckel`: https://github.com/BruceEckel
.. _`@ivanlyon`: https://github.com/ivanlyon
.. _`@terryjbates`: https://github.com/terryjbates
.. _`@zzzirk`: https://github.com/zzzirk
.. _`@brettcannon`: https://github.com/brettcannon
.. _`@mwarkentin`: https://github.com/mwarkentin
.. _`@B3QL`: https://github.com/B3QL
.. _`@andytom`: https://github.com/andytom
.. _`@jcarbaugh`: https://github.com/jcarbaugh
.. _`@cheungnj`: https://github.com/cheungnj
.. _`@aroig`: https://github.com/aroig
.. _`@stevepiercy`: https://github.com/stevepiercy
.. _`@coreysnyder04`: https://github.com/coreysnyder04
.. _`@devstrat`: https://github.com/devstrat
.. _`@eyalev`: https://github.com/eyalev
.. _`@mathagician`: https://github.com/mathagician
.. _`@ramnes`: https://github.com/ramnes
.. _`@delirious-lettuce`: https://github.com/delirious-lettuce
.. _`@karantan`: https://github.com/karantan
.. _`@jmcarp`: https://github.com/jmcarp
.. _`@meahow`: https://github.com/meahow
