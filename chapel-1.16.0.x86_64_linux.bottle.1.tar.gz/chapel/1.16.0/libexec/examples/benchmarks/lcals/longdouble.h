typedef long double longdouble;
