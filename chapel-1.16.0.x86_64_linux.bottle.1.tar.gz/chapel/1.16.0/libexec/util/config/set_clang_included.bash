# This should be sourced
export CHPL_ORIG_TARGET_COMPILER=`$CHPL_MAKE_HOME/util/chplenv/chpl_compiler.py --target`
export CHPL_TARGET_COMPILER=clang-included

