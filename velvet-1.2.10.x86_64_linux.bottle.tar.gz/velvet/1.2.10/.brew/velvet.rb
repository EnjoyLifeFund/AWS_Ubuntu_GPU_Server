# velvet: Build a bottle for Linuxbrew
class Velvet < Formula
  desc "sequence assembler for very short reads"
  homepage "http://www.ebi.ac.uk/~zerbino/velvet/"
  url "http://www.ebi.ac.uk/~zerbino/velvet/velvet_1.2.10.tgz"
  sha256 "884dd488c2d12f1f89cdc530a266af5d3106965f21ab9149e8cb5c633c977640"

  # doi "10.1101/gr.074492.107"
  # tag "bioinformatics"
  head "https://github.com/dzerbino/velvet.git"

  option "with-maxkmerlength=", "Specify maximum k-mer length, any positive odd integer (default: 31)"
  option "with-categories=", "Specify number of categories, any positive integer (default: 2)"
  option "with-openmp", "Enable OpenMP multithreading"

  needs :openmp if build.with? "openmp"

  def install
    args = ["CFLAGS=-Wall -m64", "LONGSEQUENCES=1"]
    args << "OPENMP=1" if build.with? "openmp"
    maxkmerlength = ARGV.value("with-maxkmerlength") || "-1"
    categories = ARGV.value("with-categories") || "-1"
    args << "MAXKMERLENGTH=#{maxkmerlength}" if maxkmerlength.to_i > 0
    args << "CATEGORIES=#{categories}" if categories.to_i > 0

    system "make", "velveth", "velvetg", *args
    bin.install "velveth", "velvetg"

    # install additional contributed scripts
    (share / "velvet/contrib").install Dir["contrib/shuffleSequences_fasta/shuffleSequences_*"]
  end

  def caveats
    <<-EOS.undent
      Some additional user contributed scripts are installed here:
      #{share}/velvet/contrib
    EOS
  end

  test do
    system "velveth", "--help"
    system "velvetg", "--help"
  end
end
