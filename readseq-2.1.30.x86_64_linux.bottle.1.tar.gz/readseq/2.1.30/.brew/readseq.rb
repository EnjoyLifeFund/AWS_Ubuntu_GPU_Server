class Readseq < Formula
  desc "Read and reformat biosequences"
  homepage "http://iubio.bio.indiana.edu/soft/molbio/readseq/java/"
  # tag "bioinformatics"

  url "http://iubio.bio.indiana.edu/soft/molbio/readseq/java/readseq.jar"
  version "2.1.30"
  sha256 "830c79f5eba44c8862a30a03107fe65ad044b6b099b75f9638d7482e0375aab6"

  depends_on :java

  def install
    jar = "readseq.jar"
    java = share/"java"
    java.install jar
    bin.write_jar_script java/jar, "readseq"
  end

  test do
    system "#{bin}/readseq"
  end
end
