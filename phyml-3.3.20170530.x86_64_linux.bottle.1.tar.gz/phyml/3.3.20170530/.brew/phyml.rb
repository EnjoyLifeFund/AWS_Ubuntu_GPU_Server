class Phyml < Formula
  desc "Fast maximum likelihood-based phylogenetic inference"
  homepage "http://www.atgc-montpellier.fr/phyml/"
  url "https://github.com/stephaneguindon/phyml/archive/v3.3.20170530.tar.gz"
  sha256 "f826726cd56b755be75f923abdf29aca8a9951d6af948cddbab40739a8f99f74"
  # tag "bioinformatics"
  # doi "10.1093/sysbio/syq010"

  depends_on "autoconf" => :build
  depends_on "automake" => :build
  depends_on "libtool" => :build
  depends_on "pkg-config" => :build

  def install
    # fatal error: 'malloc.h' file not found
    # Upstream issue from 31 Jan 2017 https://github.com/stephaneguindon/phyml/issues/52
    inreplace "src/utilities.h", "#include <malloc.h>", "" if OS.mac?

    system "./autogen.sh"

    # separate steps required
    system "./configure", "--prefix=#{prefix}"
    system "make"

    bin.install "src/phyml"
    doc.install "doc/phyml-manual.pdf"
    pkgshare.install Dir["examples/*"]
  end

  def caveats; <<-EOS.undent
    Examples have been installed here:
      #{opt_pkgshare}

    See options for phyml by running:
      phmyl --help

    PhyML must be run with the "-i" option to specify an input or it will
    segfault. Example:
      phyml -i #{opt_pkgshare}/nucleic
    EOS
  end
end
