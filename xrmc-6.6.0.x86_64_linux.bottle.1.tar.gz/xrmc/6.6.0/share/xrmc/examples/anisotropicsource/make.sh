gcc -Wall -o intensityscreen_image intensityscreen_image.c -lm
