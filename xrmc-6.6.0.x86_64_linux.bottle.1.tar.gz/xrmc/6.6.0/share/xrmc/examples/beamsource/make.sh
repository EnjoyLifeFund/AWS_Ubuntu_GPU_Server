gcc -Wall -o beamscreen_image beamscreen_image.c -lm
