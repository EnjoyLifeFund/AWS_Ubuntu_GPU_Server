class Libcdio < Formula
  desc "Compact Disc Input and Control Library"
  homepage "https://www.gnu.org/software/libcdio/"
  url "https://ftp.gnu.org/gnu/libcdio/libcdio-1.1.0.tar.gz"
  mirror "https://ftpmirror.gnu.org/libcdio/libcdio-1.1.0.tar.gz"
  sha256 "785c32494e4770c38bef09b1a545ef3acec8ccfbf2b799cb7e70dc380cbcf164"

  depends_on "pkg-config" => :build

  def install
    system "./configure", "--disable-dependency-tracking", "--disable-silent-rules",
                          "--prefix=#{prefix}"
    system "make", "install"
  end

  test do
    assert_match /#{version}/, shell_output("#{bin}/cd-info -v", 1)
  end
end
