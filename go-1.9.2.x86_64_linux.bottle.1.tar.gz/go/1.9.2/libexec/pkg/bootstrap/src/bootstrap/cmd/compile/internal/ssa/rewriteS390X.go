package ssa

func rewriteValueS390X(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockS390X(b *Block) bool { panic("unused during bootstrap") }
