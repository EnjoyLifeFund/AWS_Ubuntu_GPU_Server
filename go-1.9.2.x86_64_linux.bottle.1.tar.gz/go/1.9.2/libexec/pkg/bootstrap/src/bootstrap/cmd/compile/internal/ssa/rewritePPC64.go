package ssa

func rewriteValuePPC64(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockPPC64(b *Block) bool { panic("unused during bootstrap") }
