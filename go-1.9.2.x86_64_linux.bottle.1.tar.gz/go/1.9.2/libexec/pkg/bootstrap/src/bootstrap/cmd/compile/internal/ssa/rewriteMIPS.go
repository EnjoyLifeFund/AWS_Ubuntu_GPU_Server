package ssa

func rewriteValueMIPS(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockMIPS(b *Block) bool { panic("unused during bootstrap") }
