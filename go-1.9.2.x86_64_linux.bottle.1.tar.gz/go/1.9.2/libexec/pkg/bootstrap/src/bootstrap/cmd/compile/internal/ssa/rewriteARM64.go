package ssa

func rewriteValueARM64(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockARM64(b *Block) bool { panic("unused during bootstrap") }
