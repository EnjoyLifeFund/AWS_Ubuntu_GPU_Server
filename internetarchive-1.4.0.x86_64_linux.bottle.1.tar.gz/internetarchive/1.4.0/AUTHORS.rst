Authors
=======
The Internet Archive Python library and command-line tool is written
and maintained by Jake Johnson and various contributors:

Development Lead
----------------

- Jake Johnson <jake@archive.org>

Contributors
------------

- Bryce Drennan <internetarchive@brycedrennan.com>

Patches and Suggestions
-----------------------

- VM Brasseur
