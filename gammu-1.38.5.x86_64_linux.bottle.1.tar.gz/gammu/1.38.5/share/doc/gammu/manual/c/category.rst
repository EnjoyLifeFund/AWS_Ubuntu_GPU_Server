Category
========

.. doxygenfunction:: GSM_GetCategory
.. doxygenfunction:: GSM_AddCategory
.. doxygenfunction:: GSM_GetCategoryStatus
.. doxygenenum:: GSM_CategoryType
.. doxygenstruct:: GSM_Category
    :members:
.. doxygenstruct:: GSM_CategoryStatus
    :members:
