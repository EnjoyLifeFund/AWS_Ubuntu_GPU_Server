Date and time
=============

.. doxygenfunction:: DayOfWeek
.. doxygenfunction:: GSM_GetCurrentDateTime
.. doxygenfunction:: Fill_Time_T
.. doxygenfunction:: GSM_GetLocalTimezoneOffset
.. doxygenfunction:: Fill_GSM_DateTime
.. doxygenfunction:: GSM_DateTimeFromTimestamp
.. doxygenfunction:: OSDateTime
.. doxygenfunction:: OSDate
.. doxygenfunction:: CheckDate
.. doxygenfunction:: CheckTime
.. doxygenfunction:: GSM_GetDateTime
.. doxygenfunction:: GSM_SetDateTime
.. doxygenstruct:: GSM_DateTime
    :members:
.. doxygenstruct:: GSM_DeltaTime
    :members:
