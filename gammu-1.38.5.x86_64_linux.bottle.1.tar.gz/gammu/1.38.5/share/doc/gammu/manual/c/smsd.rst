SMSD
====

.. doxygenfunction:: SMSD_InjectSMS
.. doxygenfunction:: SMSD_GetStatus
.. doxygenfunction:: SMSD_Shutdown
.. doxygenfunction:: SMSD_ReadConfig
.. doxygenfunction:: SMSD_MainLoop
.. doxygenfunction:: SMSD_NewConfig
.. doxygenfunction:: SMSD_FreeConfig
.. doxygenstruct:: GSM_SMSDStatus
    :members:
.. doxygentypedef:: GSM_SMSDConfig
