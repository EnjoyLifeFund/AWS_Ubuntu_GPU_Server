libGammu C API
==============

.. toctree::
    :maxdepth: 3

    backup
    bitmap
    calendar
    callback
    call
    category
    datetime
    debug
    error
    file
    info
    inifile
    keys
    limits
    memory
    message
    misc
    nokia
    ringtone
    security
    settings
    smsd
    statemachine
    types
    unicode
    wap
