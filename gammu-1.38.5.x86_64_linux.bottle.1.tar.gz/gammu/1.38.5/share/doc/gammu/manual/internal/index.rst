.. _internal:

Gammu internals
===============

Gammu project internals are a bit more complicated than required, mostly for
historical reasons. Before digging into source code, you should look at
:doc:`../project/directories` and  :doc:`../project/coding-style`.

.. toctree::
    :maxdepth: 2

    reply
    state-machine
    new-phone
