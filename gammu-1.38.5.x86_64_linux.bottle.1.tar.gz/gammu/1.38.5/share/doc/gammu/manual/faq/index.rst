.. _faq:

Frequently Asked Questions
==========================

.. toctree::
    :maxdepth: 2

    general
    config
    phone
    smsd
    python
