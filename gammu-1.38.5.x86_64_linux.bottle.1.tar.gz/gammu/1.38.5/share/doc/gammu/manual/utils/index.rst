.. _utils:

Miscellaneous utilities
=======================

.. toctree::
    :maxdepth: 2

    gammu-detect
    gammu-config
    jadmaker

