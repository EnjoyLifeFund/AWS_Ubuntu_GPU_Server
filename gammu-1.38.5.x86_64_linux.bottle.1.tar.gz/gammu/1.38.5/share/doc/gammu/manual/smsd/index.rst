.. _smsd:

SMS Daemon
==========

.. toctree::
    :maxdepth: 2

    overview
    usage
    manual
    config
    run
    backends
    code
