module Main
  class Program
    require File.dirname(__FILE__) + '/program/class_methods.rb'
    require File.dirname(__FILE__) + '/program/instance_methods.rb'
  end
end
