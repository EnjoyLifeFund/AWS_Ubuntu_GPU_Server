module Braid
  VERSION = '1.0.21'.freeze
end
