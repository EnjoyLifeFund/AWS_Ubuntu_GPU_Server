This is version 6.12.1 of the Inform Library,
Copyright Graham Nelson 1993-2004, David Griffith 2012-2016
Full release notes and instructions are available at
http://www.inform-fiction.org
and
http://www.ifarchive.org/indexes/if-archiveXinfocomXcompilersXinform6.html

The Git repository is at https://github.com/DavidGriffith/inform6lib

Bug reports may be filed at the above Github page, the Inform Bug
Tracker at http://inform7.com/mantis/, or directly with David Griffith
<dave@661.org>

Thanks go to:

Sarganar, David Kinder, Fredrik Ramsberg, Roger Firth, Marshall
Vandegrift, Nathan Summers, Emerick Rogul, Martin Bays, Cedrick Knight,
Jesse McGrew, Nathan Schwartzman, Andrew Plotkin, Vince Laviano
