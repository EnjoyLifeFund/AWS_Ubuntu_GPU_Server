
#define GLOBJECTS_PROJECT_NAME        "globjects"
#define GLOBJECTS_PROJECT_DESCRIPTION "Strict OpenGL objects wrapper."

#define GLOBJECTS_AUTHOR_ORGANIZATION "CG Internals GmbH"
#define GLOBJECTS_AUTHOR_DOMAIN       "https://github.com/cginternals/globjects/"
#define GLOBJECTS_AUTHOR_MAINTAINER   "opensource@cginternals.com"

#define GLOBJECTS_VERSION_MAJOR       "1"
#define GLOBJECTS_VERSION_MINOR       "0"
#define GLOBJECTS_VERSION_PATCH       "0"
#define GLOBJECTS_VERSION_REVISION    "000000000000"

#define GLOBJECTS_VERSION             "1.0.0"
#define GLOBJECTS_NAME_VERSION        "globjects v1.0.0 (000000000000)"
