#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl12/types.h>
#include <glbinding/gl12/boolean.h>
#include <glbinding/gl12/values.h>
#include <glbinding/gl12/bitfield.h>
#include <glbinding/gl12/enum.h>
#include <glbinding/gl12/functions.h>
