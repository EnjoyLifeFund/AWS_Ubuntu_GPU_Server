#pragma once

#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl42ext
{





} // namespace gl42ext
