#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl42/types.h>
#include <glbinding/gl42/boolean.h>
#include <glbinding/gl42/values.h>
#include <glbinding/gl42/bitfield.h>
#include <glbinding/gl42/enum.h>
#include <glbinding/gl42/functions.h>
