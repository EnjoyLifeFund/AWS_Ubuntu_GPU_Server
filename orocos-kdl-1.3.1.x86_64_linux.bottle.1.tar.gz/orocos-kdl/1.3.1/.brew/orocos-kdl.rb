class OrocosKdl < Formula
  desc "Orocos Kinematics and Dynamics C++ library"
  homepage "http://www.orocos.org/kdl"
  url "https://github.com/orocos/orocos_kinematics_dynamics/archive/v1.3.1.tar.gz"
  sha256 "aff361d2b4e2c6d30ae959308a124022eeef5dc5bea2ce779900f9b36b0537bd"
  head "https://github.com/orocos/orocos_kinematics_dynamics.git"

  option "without-test", "Disable build-time checking"
  deprecated_option "without-check" => "without-test"

  depends_on "cmake"   => :build
  depends_on "cppunit" => :build
  depends_on "boost"   => :build
  depends_on "eigen@3.2"

  def install
    cd "orocos_kdl" do
      mkdir "build" do
        eigen_include_dir = Formula["eigen@3.2"].opt_include/"eigen3"
        args = std_cmake_args << "-DEIGEN3_INCLUDE_DIR=#{eigen_include_dir}"
        args << "-DENABLE_TESTS=ON" if build.with? "test"
        system "cmake", "..", *args
        system "make"
        system "make", "check" if build.with? "test"
        system "make", "install"
      end
    end
  end
end
