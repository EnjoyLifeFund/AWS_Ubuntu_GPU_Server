* We need a way to work with block based data like the 'wo' cmd in r1
* Implement formatted structs with named arguments in p command
* getcurblock can manage its own memory.. all those free's can be removed
* Find a way to return original value if str2ut64 fails (2nd arg..)
* Add math support to '?' command
* w<- should write from stdin

Commands can:

 -1 - fail
  0 - quit
  1 - run fine
  2 - run with issues
