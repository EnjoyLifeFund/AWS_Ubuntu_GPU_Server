#!/bin/bash
#
# Well, speaks by itself
echo "G2 is based on" $("$GIT_EXE" version)
