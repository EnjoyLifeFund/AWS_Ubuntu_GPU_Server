LASTZ - pairwise DNA sequence aligner
=========

This repository contains the latest official release of LASTZ, version 1.04.00.
Additional LASTZ releases, including all releases prior to March 2017, can be
found at http://www.bx.psu.edu/~rsharris/lastz (in the form of tarballs).

For information about installation and use, see README.lastz.html.

Mar/12/2017 Bob Harris (the LASTZ guy)

