#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.11.1"
/* generated using gnu compiler gcc-6 (Homebrew GCC 6.4.0) 6.4.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
