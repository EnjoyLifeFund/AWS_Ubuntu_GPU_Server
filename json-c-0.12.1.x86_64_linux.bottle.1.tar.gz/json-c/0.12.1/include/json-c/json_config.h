/* json_config.h.  Generated from json_config.h.in by configure.  */

/* Define to 1 if you have the <inttypes.h> header file. */
#define JSON_C_HAVE_INTTYPES_H 1
