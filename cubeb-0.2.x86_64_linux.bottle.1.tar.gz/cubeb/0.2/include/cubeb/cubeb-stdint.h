#ifndef _LIBCUBEB_INCLUDE_CUBEB_CUBEB_STDINT_H
#define _LIBCUBEB_INCLUDE_CUBEB_CUBEB_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "libcubeb 0.2"
/* generated using gnu compiler gcc-5 (Homebrew gcc 5.4.0) 5.4.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
