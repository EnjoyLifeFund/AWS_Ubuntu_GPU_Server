/* geo_config.h.  Generated from geo_config.h.in by configure.  */
#ifndef GEO_CONFIG_H
#define GEO_CONFIG_H

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRINGS_H 1

#define HAVE_LIBPROJ 1
/* #undef HAVE_PROJECTS_H */

/* #undef GEO_NORMALIZE_DISABLE_TOWGS84 */

#endif /* ndef GEO_CONFIG_H */
