liblcf authors
==============

* Alejandro Marzini (vgvgf)
* Gabriel Kind (Ghabry)
* Glynn Clements (glynnc)
* Paulo "Zhek" Vizcaino (paulo_v)
