class Fasta < Formula
  homepage "http://faculty.virginia.edu/wrpearson/fasta/"
  # doi "10.1016/0076-6879(90)83007-V"
  # tag "bioinformatics"

  url "http://faculty.virginia.edu/wrpearson/fasta/fasta36/fasta-36.3.7.tar.gz"
  sha256 "95fe27b6055e6a4a5f16bb4f52b3d8f188c8e3447fc16c58ddab8e7548b1cac2"

  def install
    mkdir "bin"
    cd "src" do
      system "make", "-f",
        if OS.mac?
          "../make/Makefile.os_x86_64"
        elsif OS.linux?
          "../make/Makefile.linux64_sse2"
        else
          raise "Unknown operating system"
        end
    end
    bin.install Dir["bin/*"]
    doc.install Dir["doc/*"]
  end

  test do
    system "#{bin}/fasta36"
  end
end
