Release 0.0.1 (in development)
================================================================================

* Added Google Test and Google Benchmark (changes in .gitmodules).
* Sphinx documentation initialized. First two sections: Installation, Quickstart
* Git repository initialized. CMake skeleton and built environment.
