var searchData=
[
  ['width',['width',['../interface_chipmunk_bitmap_sampler.html#a67fee67a96db2a6d41a44558c5e41cde',1,'ChipmunkBitmapSampler']]],
  ['worldtolocal_3a',['worldToLocal:',['../interface_chipmunk_body.html#abaab505f6dfea590949af377099f1373',1,'ChipmunkBody']]]
];
