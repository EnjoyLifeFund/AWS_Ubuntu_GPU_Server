var searchData=
[
  ['normal',['normal',['../structcp_contact_point_set.html#a2fab2c7e343e14833185b2c97e9fd5b8',1,'cpContactPointSet::normal()'],['../structcp_segment_query_info.html#a453d113d757becaab1363e80c9a54e76',1,'cpSegmentQueryInfo::normal()'],['../interface_chipmunk_segment_query_info.html#a32e919b78a72c40b68045136c09816b2',1,'ChipmunkSegmentQueryInfo::normal()'],['../interface_chipmunk_segment_shape.html#a8ca8a1829ebeda87fbcf445a04132cec',1,'ChipmunkSegmentShape::normal()']]],
  ['nsarray_28chipmunkobject_29',['NSArray(ChipmunkObject)',['../category_n_s_array_07_chipmunk_object_08.html',1,'']]]
];
