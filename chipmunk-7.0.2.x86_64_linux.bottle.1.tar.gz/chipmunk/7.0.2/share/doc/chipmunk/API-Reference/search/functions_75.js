var searchData=
[
  ['updatelocation_3a',['updateLocation:',['../interface_chipmunk_multi_grab.html#ab3663a7c9a0590c9e5bb80410b0b5d30',1,'ChipmunkMultiGrab']]],
  ['updateposition_3a',['updatePosition:',['../interface_chipmunk_body.html#a5520fe5fa563f4dbd4a7d52cc7978c34',1,'ChipmunkBody']]],
  ['updatevelocity_3agravity_3adamping_3a',['updateVelocity:gravity:damping:',['../interface_chipmunk_body.html#a106b0890f58719adc809ffc536e0edde',1,'ChipmunkBody']]]
];
