var searchData=
[
  ['velocityatlocalpoint_3a',['velocityAtLocalPoint:',['../interface_chipmunk_body.html#afe0208c271b53af6c699d98e4e20c399',1,'ChipmunkBody']]],
  ['velocityatworldpoint_3a',['velocityAtWorldPoint:',['../interface_chipmunk_body.html#aec6566c62e3d3f590245e726ea014589',1,'ChipmunkBody']]]
];
