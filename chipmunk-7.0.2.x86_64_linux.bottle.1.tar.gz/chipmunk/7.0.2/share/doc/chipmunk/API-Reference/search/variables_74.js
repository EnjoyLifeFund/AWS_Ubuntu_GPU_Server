var searchData=
[
  ['typea',['typeA',['../structcp_collision_handler.html#a07bbc9d26af9d41cc87bae6514930d9f',1,'cpCollisionHandler']]],
  ['typeb',['typeB',['../structcp_collision_handler.html#a7f9def10b179d18de37bec5b3c6d8621',1,'cpCollisionHandler']]]
];
