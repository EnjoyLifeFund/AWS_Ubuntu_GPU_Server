var searchData=
[
  ['normal',['normal',['../interface_chipmunk_segment_query_info.html#a32e919b78a72c40b68045136c09816b2',1,'ChipmunkSegmentQueryInfo::normal()'],['../interface_chipmunk_segment_shape.html#a8ca8a1829ebeda87fbcf445a04132cec',1,'ChipmunkSegmentShape::normal()']]]
];
