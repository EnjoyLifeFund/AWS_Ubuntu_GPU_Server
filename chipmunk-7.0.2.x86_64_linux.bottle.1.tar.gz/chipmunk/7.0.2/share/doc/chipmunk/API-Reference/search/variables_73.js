var searchData=
[
  ['separatefunc',['separateFunc',['../structcp_collision_handler.html#a1823a67807ba11b1bae7f41024cd6ce0',1,'cpCollisionHandler']]],
  ['shape',['shape',['../structcp_point_query_info.html#ad27c172fcc5ca586f60c4e9fc15560da',1,'cpPointQueryInfo::shape()'],['../structcp_segment_query_info.html#a1644aedf3beee1c910f0361ff73e50eb',1,'cpSegmentQueryInfo::shape()']]],
  ['shapeoutlinecolor',['shapeOutlineColor',['../structcp_space_debug_draw_options.html#a5bc64c5754df1f4bc4b7a789e81555f8',1,'cpSpaceDebugDrawOptions']]]
];
