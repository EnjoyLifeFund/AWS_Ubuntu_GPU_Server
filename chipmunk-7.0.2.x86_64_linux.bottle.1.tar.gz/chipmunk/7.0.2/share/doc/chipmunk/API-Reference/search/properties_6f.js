var searchData=
[
  ['offset',['offset',['../interface_chipmunk_circle_shape.html#a3ae86d4d818f0f78d14bb9991ac93f5e',1,'ChipmunkCircleShape']]],
  ['outputrect',['outputRect',['../interface_chipmunk_bitmap_sampler.html#a7ed228f484f27ed1ae77e6fc3d7d4d09',1,'ChipmunkBitmapSampler']]]
];
