var searchData=
[
  ['idlespeedthreshold',['idleSpeedThreshold',['../interface_chipmunk_space.html#ad79276e72714d0e3d8025fb51efca906',1,'ChipmunkSpace']]],
  ['impulse',['impulse',['../interface_chipmunk_constraint.html#acfae278103bd74cc1a6ad6a2aad4f1fa',1,'ChipmunkConstraint']]],
  ['info',['info',['../interface_chipmunk_point_query_info.html#acfecefbea610b5b520a81b1b251bbb71',1,'ChipmunkPointQueryInfo::info()'],['../interface_chipmunk_segment_query_info.html#a7978e8423a50400626f1b0997a35ccee',1,'ChipmunkSegmentQueryInfo::info()']]],
  ['isclosed',['isClosed',['../interface_chipmunk_polyline.html#aa554c304a9c991350ac69c1ae4ce1adb',1,'ChipmunkPolyline']]],
  ['islocked',['isLocked',['../interface_chipmunk_space.html#aa6d66772a03214b8c28991301e47735b',1,'ChipmunkSpace']]],
  ['issleeping',['isSleeping',['../interface_chipmunk_body.html#aff377602948f0d6c9268342403ddf906',1,'ChipmunkBody']]],
  ['iterations',['iterations',['../interface_chipmunk_space.html#a14ae29e48719422333bc51ebfc292553',1,'ChipmunkSpace']]]
];
