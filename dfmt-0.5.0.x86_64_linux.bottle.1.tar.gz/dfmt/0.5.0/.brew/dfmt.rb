class Dfmt < Formula
  desc "Formatter for D source code"
  homepage "https://github.com/dlang-community/dfmt"
  url "https://github.com/dlang-community/dfmt.git",
      :tag => "v0.5.0",
      :revision => "fef85e388a41add75020675ab33ed7e55c3efe85"

  head "https://github.com/dlang-community/dfmt.git", :shallow => false

  devel do
    url "https://github.com/dlang-community/dfmt.git",
      :tag => "v0.6.0-alpha.1",
      :revision => "02a735cb0c10d711c5f08fc26572f98bc5fdf0ff"
    version "0.6.0-alpha.1"
  end

  depends_on "dmd" => :build

  def install
    system "make"
    bin.install "bin/dfmt"
  end

  test do
    (testpath/"test.d").write <<~EOS
      import std.stdio; void main() { writeln("Hello, world without explicit compilations!"); }
    EOS

    expected = <<~EOS
      import std.stdio;

      void main()
      {
          writeln("Hello, world without explicit compilations!");
      }
    EOS

    system "#{bin}/dfmt", "-i", "test.d"

    assert_equal expected, (testpath/"test.d").read
  end
end
