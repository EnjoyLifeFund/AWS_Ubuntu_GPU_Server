# MkDocs

Project documentation with Markdown.

---

[![PyPI Version][pypi-v-image]][pypi-v-link]
[![Build Status][travis-image]][travis-link]
[![Windows Build Status][appveyor-image]][appveyor-link]
[![Coverage Status][codecov-image]][codecov-link]
[![Landscale Code Health][landscape-image]][landscape-link]

- View the [MkDocs documentation][mkdocs].
- Project [release notes][release-notes].
- Visit the [MkDocs wiki](https://github.com/mkdocs/mkdocs/wiki) for community
  resources, including third party themes and a list of MkDocs users.
- IRC channel: `#mkdocs` on freenode.
- Discussions and support: <https://groups.google.com/forum/#!forum/mkdocs>

## Code of Conduct

Everyone interacting in the MkDocs project's codebases, issue trackers, chat
rooms, and mailing lists is expected to follow the [PyPA Code of Conduct].

[appveyor-image]: https://img.shields.io/appveyor/ci/d0ugal/mkdocs/master.png
[appveyor-link]: https://ci.appveyor.com/project/d0ugal/mkdocs
[codecov-image]: http://codecov.io/github/mkdocs/mkdocs/coverage.svg?branch=master
[codecov-link]: http://codecov.io/github/mkdocs/mkdocs?branch=master
[landscape-image]: https://landscape.io/github/mkdocs/mkdocs/master/landscape.svg?style=flat-square
[landscape-link]: https://landscape.io/github/mkdocs/mkdocs/master
[pypi-v-image]: https://img.shields.io/pypi/v/mkdocs.png
[pypi-v-link]: https://pypi.python.org/pypi/mkdocs
[travis-image]: https://img.shields.io/travis/mkdocs/mkdocs/master.png
[travis-link]: https://travis-ci.org/mkdocs/mkdocs

[mkdocs]: http://www.mkdocs.org
[release-notes]: http://www.mkdocs.org/about/release-notes/

[PyPA Code of Conduct]: https://www.pypa.io/en/latest/code-of-conduct/
