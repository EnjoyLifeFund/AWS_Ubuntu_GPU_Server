# NSIS

[![Build Status](https://travis-ci.org/kichik/nsis.svg?branch=master)](https://travis-ci.org/kichik/nsis)

NSIS (Nullsoft Scriptable Install System) is a professional open source system to create Windows installers. It is designed to be as small and flexible as possible and is therefore very suitable for internet distribution.

## External Links

   * [Simple tutorial](http://nsis.sourceforge.net/Simple_tutorials)
   * [NSIS Homepage](http://nsis.sourceforge.net/)
   * [User Manual](http://nsis.sourceforge.net/Docs/)
