
int main()
{
    static_assert(sizeof(int) > 1, "int too small");
    return 0;
}
