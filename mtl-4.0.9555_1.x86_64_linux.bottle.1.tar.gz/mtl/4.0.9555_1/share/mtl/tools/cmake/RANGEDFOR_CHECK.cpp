// #include <iostream>

int main()
{
    int array[]= {3, 7, 9, 4};

    int s= 0;
    for (int i : array)
	s+= i;
    // std::cout << "s = " << s << '\n';
    return 0;
}
