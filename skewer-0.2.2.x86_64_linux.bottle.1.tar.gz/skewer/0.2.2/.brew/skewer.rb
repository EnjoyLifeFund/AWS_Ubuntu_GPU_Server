class Skewer < Formula
  desc "Fast and accurate NGS adapter trimmer"
  homepage "https://github.com/relipmoc/skewer"
  url "https://github.com/relipmoc/skewer/archive/0.2.2.tar.gz"
  sha256 "bc37afccdf55de047502b87fe56d537cdf78674ccaec1a401b2d29552d6b2dfc"
  head "https://github.com/relipmoc/skewer.git"
  # doi "10.1186/1471-2105-15-182"
  # tag "bioinformatics"

  def install
    system "make", "CXX=#{ENV.cxx}", "CXXFLAGS=-c #{ENV.cxxflags}"
    bin.install "skewer"
    doc.install "README.md", "LICENSE"
  end

  test do
    assert_match "USAGE", shell_output("#{bin}/skewer --help 2>&1", 1)
  end
end
