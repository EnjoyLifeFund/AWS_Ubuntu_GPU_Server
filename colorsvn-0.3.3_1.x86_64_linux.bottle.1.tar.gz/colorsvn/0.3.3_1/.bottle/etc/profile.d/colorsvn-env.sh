# set alias for svn

alias svn=@@HOMEBREW_PREFIX@@/Cellar/colorsvn/0.3.3_1/bin/colorsvn
