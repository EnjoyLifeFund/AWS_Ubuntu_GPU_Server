void MVM_spesh_args(MVMThreadContext *tc, MVMSpeshGraph *g, MVMCallsite *cs,
    MVMSpeshStatsType *type_tuple);
