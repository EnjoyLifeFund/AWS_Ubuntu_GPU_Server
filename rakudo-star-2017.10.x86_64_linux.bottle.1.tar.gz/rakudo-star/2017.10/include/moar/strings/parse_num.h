MVMnum64 MVM_coerce_s_n(MVMThreadContext *tc, MVMString *s);
