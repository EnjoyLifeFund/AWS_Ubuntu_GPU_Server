#ifndef SPNAV_CONFIG_H_
#define SPNAV_CONFIG_H_

#endif	/* SPNAV_CONFIG_H_ */
