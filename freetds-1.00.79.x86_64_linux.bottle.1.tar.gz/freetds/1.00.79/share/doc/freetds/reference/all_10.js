var searchData=
[
  ['remote_20procedure_20functions',['Remote Procedure functions',['../a00519.html',1,'']]],
  ['read',['read',['../a01041.html#a2f0be7677a1bf9c730e3c697bfba21c9',1,'tds_input_stream']]],
  ['read_2ec',['read.c',['../a00311.html',1,'']]],
  ['read_5fand_5fconvert',['read_and_convert',['../a00534.html#ga676c4dee6522815b16fdc8e448e43590',1,'read.c']]],
  ['ref_5fcount',['ref_count',['../a00585.html#a812580afdfca53b6d54a7d09938c65c2',1,'dblib_context::ref_count()'],['../a01157.html#a692ccceff71d836df0d084ec26123c2d',1,'tds_cursor::ref_count()'],['../a01165.html#a2798c66fb3c8637c7fb29c6d1efebfa4',1,'tds_dynamic::ref_count()']]],
  ['res_5finfo',['res_info',['../a01165.html#ac736e163c0d4cdbca980a861214d99e7',1,'tds_dynamic']]],
  ['resinfo',['resinfo',['../a00581.html#ad49b82677ae277e5d5b0038f522da293',1,'dblib_buffer_row']]],
  ['ret_5fstatus',['ret_status',['../a01193.html#a355e0b8c6219908747f82cd7482c6efb',1,'tds_socket']]],
  ['row',['row',['../a00581.html#a015599345b266045d8bd3fac731e4675',1,'dblib_buffer_row']]],
  ['row_5fcount',['row_count',['../a00993.html#a8fd44f3c44ae4c83a1bdda0b73776ecd',1,'_hstmt']]],
  ['row_5fdata',['row_data',['../a00581.html#a5a057d6bbecfac1a85a9fbcd09eaf3a0',1,'dblib_buffer_row']]],
  ['row_5fstatus',['row_status',['../a00993.html#a41dd89b2dc41fe0e747580f6ea807063',1,'_hstmt']]],
  ['rows_5faffected',['rows_affected',['../a01193.html#a803e29dabc76d35227f5de2488f29877',1,'tds_socket']]],
  ['rsa_5fpublic_5fkey',['rsa_public_key',['../a00745.html',1,'']]],
  ['rtrim',['rtrim',['../a00521.html#ga4d5be57b25a0654e2170fd656dc35489',1,'bcp.c']]],
  ['results_20processing',['Results processing',['../a00536.html',1,'']]]
];
