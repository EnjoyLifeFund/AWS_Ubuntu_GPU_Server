var searchData=
[
  ['remote_20procedure_20functions',['Remote Procedure functions',['../a00519.html',1,'']]],
  ['results_20processing',['Results processing',['../a00536.html',1,'']]]
];
