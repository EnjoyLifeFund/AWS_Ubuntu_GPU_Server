var searchData=
[
  ['the_20db_2dlib_20api',['The db-lib API',['../a00517.html',1,'']]]
];
