var searchData=
[
  ['read_2ec',['read.c',['../a00311.html',1,'']]]
];
