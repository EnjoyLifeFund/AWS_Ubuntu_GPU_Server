var searchData=
[
  ['adjust_5fcharacter_5fcolumn_5fsize',['adjust_character_column_size',['../a00536.html#ga91770634ce8c0d6f1fe007b45da186fd',1,'token.c']]]
];
