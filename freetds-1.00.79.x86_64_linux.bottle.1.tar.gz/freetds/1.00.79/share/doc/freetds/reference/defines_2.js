var searchData=
[
  ['tds_5fis_5fmssql',['TDS_IS_MSSQL',['../a00434.html#a07e9371c3e72b9e319f4c14e6fc2c20f',1,'tds.h']]],
  ['tds_5fis_5fsybase',['TDS_IS_SYBASE',['../a00434.html#a4840433488d0c66601ff4002a54b41d7',1,'tds.h']]],
  ['tds_5fms_5fver',['TDS_MS_VER',['../a00434.html#a1f5fb9d2184949ed566c8ce308a4e91e',1,'tds.h']]],
  ['tds_5fput_5ftinyint',['tds_put_tinyint',['../a00434.html#adfc186758f4c1856c01746b5436aff74',1,'tds.h']]],
  ['tds_5fsyb_5fver',['TDS_SYB_VER',['../a00434.html#aca53a637849948c4b7a07f69e40c685c',1,'tds.h']]]
];
