var searchData=
[
  ['offset',['offset',['../a01077.html#a76f4cbcb3bc7c10b3616579ec7861f58',1,'TDS_DATETIMEALL::offset()'],['../a01265.html#a13159d738e1d0b582a3a731123feb5f3',1,'DBDATETIMEALL::offset()']]],
  ['options',['options',['../a01157.html#a1be9f69f84a6d83ce86380c33a2bf9f8',1,'tds_cursor']]],
  ['origdsn',['origdsn',['../a00637.html#a8127a82b8c4130820a4c44f88eda8bcf',1,'DSNINFO']]],
  ['out_5fbuf',['out_buf',['../a01193.html#ad6b5121e435d22d640a645b98833cb9d',1,'tds_socket']]],
  ['out_5fbuf_5fmax',['out_buf_max',['../a01193.html#ae6fc66be718f3211fac3b835557e330e',1,'tds_socket']]],
  ['out_5fflag',['out_flag',['../a01193.html#a9bb663ee7c71f56f1602cbfcd993018c',1,'tds_socket']]],
  ['out_5fpos',['out_pos',['../a01193.html#a426adbd80f29f477377e42e8f78d3ff0',1,'tds_socket']]]
];
