var searchData=
[
  ['s',['s',['../a01189.html#a4853be2466fd81c9463ac88f8da8b9c2',1,'tds_connection']]],
  ['second',['second',['../a01081.html#a8560717700de586f279af702bac86ad6',1,'tdsdaterec']]],
  ['send_5fpacket',['send_packet',['../a01193.html#a1c7c38af79f5845b90f19aaf5f63ce18',1,'tds_socket']]],
  ['server_5fcharset',['server_charset',['../a01101.html#a80dae8a766655c5c7365ba42d4d4d62c',1,'tds_login']]],
  ['server_5fname',['server_name',['../a01101.html#a69ed4cfded269727901bed2f95f1652e',1,'tds_login']]],
  ['server_5frealm_5fname',['server_realm_name',['../a01101.html#a1e5a5a13fa3cb0c5168d44187b52c814',1,'tds_login']]],
  ['server_5fspn',['server_spn',['../a01101.html#ad8d335a04cf09453a87a8e0b9118eaeb',1,'tds_login']]],
  ['size',['size',['../a01065.html#a9d221dd860f67d97daa71e107dce3470',1,'tds_dynamic_stream']]],
  ['sizes',['sizes',['../a00581.html#abe1aa9f8ea96dda1400654813e68130a',1,'dblib_buffer_row']]],
  ['status',['status',['../a01157.html#ab5d6a587ac5780f001d383d4b874852f',1,'tds_cursor']]],
  ['stmt_5flist',['stmt_list',['../a00985.html#a4a9f3e8f1eba573df79a1ed300d8fc91',1,'_hdbc']]],
  ['stream',['stream',['../a00693.html#abb6db59e849d11de92f4c55c61d51744',1,'tds_file_stream']]]
];
