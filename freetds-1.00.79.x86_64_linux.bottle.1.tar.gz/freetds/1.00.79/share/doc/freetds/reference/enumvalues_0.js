var searchData=
[
  ['tds_5fdead',['TDS_DEAD',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33af087b64970a1fb35bbcf1bc6ea7a643d',1,'tds.h']]],
  ['tds_5fdone_5fcancelled',['TDS_DONE_CANCELLED',['../a00434.html#aa8d8044be84bcde003f28ec25a77519ca202254cfd6784404cf1aa22bc7147c86',1,'tds.h']]],
  ['tds_5fdone_5fcount',['TDS_DONE_COUNT',['../a00434.html#aa8d8044be84bcde003f28ec25a77519caf17d0c6591e318014c806a10c2f0270b',1,'tds.h']]],
  ['tds_5fdone_5ferror',['TDS_DONE_ERROR',['../a00434.html#aa8d8044be84bcde003f28ec25a77519caa9d79a3b62e3321332223ac3d1a5b18d',1,'tds.h']]],
  ['tds_5fdone_5ffinal',['TDS_DONE_FINAL',['../a00434.html#aa8d8044be84bcde003f28ec25a77519ca7ed9046db24ad78bb94c2b12d6e11f46',1,'tds.h']]],
  ['tds_5fdone_5finxact',['TDS_DONE_INXACT',['../a00434.html#aa8d8044be84bcde003f28ec25a77519cac79a30d1a0bac125e77d87f5d87bc2b2',1,'tds.h']]],
  ['tds_5fdone_5fmore_5fresults',['TDS_DONE_MORE_RESULTS',['../a00434.html#aa8d8044be84bcde003f28ec25a77519ca688b8bf555ce6ae72f3e047177bfc966',1,'tds.h']]],
  ['tds_5fdone_5fproc',['TDS_DONE_PROC',['../a00434.html#aa8d8044be84bcde003f28ec25a77519cae170f368306f421d507c6f08e4d48d9a',1,'tds.h']]],
  ['tds_5fdone_5fsrverror',['TDS_DONE_SRVERROR',['../a00434.html#aa8d8044be84bcde003f28ec25a77519ca7bfe89d6f8fc309eae412ad0a503e34c',1,'tds.h']]],
  ['tds_5fidle',['TDS_IDLE',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33ad1586abc1f75b7f3d640b994afe310e9',1,'tds.h']]],
  ['tds_5fpending',['TDS_PENDING',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33a00f6d5ac5560f2f44661e599241849a8',1,'tds.h']]],
  ['tds_5freading',['TDS_READING',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33a36ddbc8f326d6b297009a8fafd958529',1,'tds.h']]],
  ['tds_5fsending',['TDS_SENDING',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33a2bad5be30bd85edc9495dae3d199d2c1',1,'tds.h']]],
  ['tds_5fwriting',['TDS_WRITING',['../a00434.html#a87cdae58f91ebe9229206bf0628f8e33a4a4fcc1840bee1e09521f08a0184d025',1,'tds.h']]]
];
