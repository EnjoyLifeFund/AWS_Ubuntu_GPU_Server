var searchData=
[
  ['query',['Query',['../a00533.html',1,'']]]
];
