var searchData=
[
  ['how_20to_20add_20a_20new_20type',['How to add a new type',['../a01298.html',1,'']]]
];
