var searchData=
[
  ['dbtds_5funknown',['DBTDS_UNKNOWN',['../a00479.html#a4e19c79341755a7c6666197d381e1ac6',1,'sybdb.h']]],
  ['dbversion_5funknown',['DBVERSION_UNKNOWN',['../a00479.html#adbc038c5d57c0ab4c1c9e081a664dc0f',1,'sybdb.h']]]
];
