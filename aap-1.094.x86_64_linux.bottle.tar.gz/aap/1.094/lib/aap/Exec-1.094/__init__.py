#! /usr/bin/env python
# Main Python code that executes an A-A-P recipe

# Copyright (C) 2002-2003 Stichting NLnet Labs
# Permission to copy and use this file is specified in the file COPYING.
# If this file is missing you can find it here: http://www.a-a-p.org/COPYING


# When executed directly, call the main function.
if __name__ == '__main__':
    import Main
    Main.main()

# vim: set sw=4 et sts=4 tw=79 fo+=l:
