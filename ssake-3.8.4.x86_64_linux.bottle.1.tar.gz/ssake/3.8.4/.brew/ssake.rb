class Ssake < Formula
  homepage "http://www.bcgsc.ca/platform/bioinfo/software/ssake"
  # doi "10.1093/bioinformatics/btl629"
  # tag "bioinformatics"

  url "http://www.bcgsc.ca/platform/bioinfo/software/ssake/releases/3.8.4/ssake_v3-8-4.tar.gz"
  version "3.8.4"
  sha256 "55fad26faa2b33841c58c7e52ed85c98bac2f65ffd48a40d09ba5e274ccb5d87"

  def install
    bin.install "SSAKE"
    doc.install "SSAKE-readme.pdf", "SSAKE-readme.txt"
    prefix.install "test", "tools"
  end

  test do
    system "SSAKE |grep SSAKE"
  end
end
