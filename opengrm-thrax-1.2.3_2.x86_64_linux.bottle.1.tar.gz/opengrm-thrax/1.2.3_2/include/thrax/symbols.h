// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2005-2011 Google, Inc.
// Author: rws@google.com (Richard Sproat)
//
// Builds the symbol tables needed for byte and utf8 if FLAGS_save_symbols is
// set

#ifndef THRAX_SYMBOLS_H_
#define THRAX_SYMBOLS_H_

#include <string>

#include <fst/fstlib.h>

namespace thrax {
namespace function {

// Defined in loader.cc
fst::SymbolTable* GetByteSymbolTable();
fst::SymbolTable* GetUtf8SymbolTable();
void AddToByteSymbolTable(string symbol, int64 label);
void AddToUtf8SymbolTable(string symbol, int64 label);

static const char kByteSymbolTableName[] = "**Byte symbols";
static const char kUtf8SymbolTableName[] = "**UTF8 symbols";

class SymbolTableBuilder {
 public:
  SymbolTableBuilder();
  ~SymbolTableBuilder();
  fst::SymbolTable* GetByteSymbolTable();
  fst::SymbolTable* GetUtf8SymbolTable();
  void AddToByteSymbolTable(string symbol, int64 label);
  void AddToUtf8SymbolTable(string symbol, int64 label);

 private:
  void GenerateByteSymbolTable();
  inline void GenerateUtf8SymbolTable();

  fst::Mutex map_mutex_;
  fst::SymbolTable* byte_symbols_;
  fst::SymbolTable* utf8_symbols_;
  DISALLOW_COPY_AND_ASSIGN(SymbolTableBuilder);
};

}  // namespace function
}  // namespace thrax

#endif  // THRAX_SYMBOLS_H_
