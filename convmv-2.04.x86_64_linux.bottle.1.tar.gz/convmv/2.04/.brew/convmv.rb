class Convmv < Formula
  desc "Filename encoding conversion tool"
  homepage "https://www.j3e.de/linux/convmv/"
  url "https://www.j3e.de/linux/convmv/convmv-2.04.tar.gz"
  sha256 "de1b794cbc73cb9816869b1e3ae358ad9455ced5a4504b1e5cd0084a63b0bd1c"

  def install
    system "make", "install", "PREFIX=#{prefix}"
  end

  test do
    system "#{bin}/convmv", "--list"
  end
end
