# Glossary of Terms

Coming soon: https://discourse.cayley.io/t/glossary-of-terms/180
