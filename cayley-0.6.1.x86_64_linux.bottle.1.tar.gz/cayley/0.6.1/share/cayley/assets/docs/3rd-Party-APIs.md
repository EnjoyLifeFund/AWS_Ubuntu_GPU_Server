Various 3rd party APIs

- **Clojure**: https://github.com/wgb/cayley-clj
- **Javascript/NodeJS**: https://github.com/lnshi/node-cayley, https://github.com/villadora/cayley.js
- **Ruby**: https://github.com/reneklacan/cayley-ruby
- **PHP**: https://github.com/mcuadros/php-cayley
- **Python**: https://github.com/ziyasal/pyley
- **.NET**: https://github.com/ziyasal/Cayley.Net
- **Rust** (in early stage): https://github.com/shamansir/cayley-rust
- **Haskell**: https://github.com/MichelBoucey/cayley-client
