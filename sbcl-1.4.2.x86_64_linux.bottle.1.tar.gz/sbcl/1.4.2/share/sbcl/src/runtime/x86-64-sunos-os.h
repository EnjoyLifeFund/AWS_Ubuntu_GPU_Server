#ifndef _X86_64_SOLARIS_OS_H
#define _X86_64_SOLARIS_OS_H

typedef struct ucontext os_context_t;
typedef long os_context_register_t;

#include "arch-os-generic.inc"

#endif /* _X86_64_SOLARIS_OS_H */
