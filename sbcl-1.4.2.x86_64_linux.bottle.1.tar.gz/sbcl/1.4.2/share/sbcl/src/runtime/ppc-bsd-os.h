#ifndef _PPC_BSD_OS_H
#define _PPC_BSD_OS_H

typedef int os_context_register_t;

#include "arch-os-generic.inc"

#endif /* _PPC_BSD_OS_H */
