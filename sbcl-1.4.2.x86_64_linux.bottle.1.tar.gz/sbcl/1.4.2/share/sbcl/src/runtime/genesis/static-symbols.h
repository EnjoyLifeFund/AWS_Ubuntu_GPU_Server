/*
 * This is a machine-generated file. Please do not edit it by hand.
 * (As of sbcl-0.8.14, it came from WRITE-CONFIG-H in genesis.lisp.)
 *
 * This file contains low-level information about the
 * internals of a particular version and configuration
 * of SBCL. It is used by the C compiler to create a runtime
 * support environment, an executable program in the host
 * operating system's native format, which can then be used to
 * load and run 'core' files, which are basically programs
 * in SBCL's own format.
 */
#ifndef SBCL_GENESIS_STATIC_SYMBOLS
#define SBCL_GENESIS_STATIC_SYMBOLS
#define NIL LISPOBJ(0x20100017)
#define T LISPOBJ(0x2010004F)
#define IMMOBILE_FREELIST LISPOBJ(0x2010007F)
#define FREE_TLS_INDEX LISPOBJ(0x201000AF)
#define MSAN_PARAM_TLS LISPOBJ(0x201000DF)
#define ASSEMBLER_ROUTINES LISPOBJ(0x2010010F)
#define THREAD_INITIAL_BINDINGS LISPOBJ(0x2010013F)
#define FUNCTION_LAYOUT LISPOBJ(0x2010016F)
#define FREE_INTERRUPT_CONTEXT_INDEX (*)
#define FREE_INTERRUPT_CONTEXT_INDEX_tlsindex 0x2108
#define ALLOW_WITH_INTERRUPTS (*)
#define ALLOW_WITH_INTERRUPTS_tlsindex 0x2110
#define INTERRUPTS_ENABLED (*)
#define INTERRUPTS_ENABLED_tlsindex 0x2118
#define ALLOC_SIGNAL (*)
#define ALLOC_SIGNAL_tlsindex 0x2120
#define INTERRUPT_PENDING (*)
#define INTERRUPT_PENDING_tlsindex 0x2128
#define IN_WITHOUT_GCING (*)
#define IN_WITHOUT_GCING_tlsindex 0x2130
#define GC_INHIBIT (*)
#define GC_INHIBIT_tlsindex 0x2138
#define GC_PENDING (*)
#define GC_PENDING_tlsindex 0x2140
#define STOP_FOR_GC_PENDING (*)
#define STOP_FOR_GC_PENDING_tlsindex 0x2148
#define CURRENT_CATCH_BLOCK (*)
#define CURRENT_CATCH_BLOCK_tlsindex 0x48
#define CURRENT_UNWIND_PROTECT_BLOCK (*)
#define CURRENT_UNWIND_PROTECT_BLOCK_tlsindex 0x50
#define SUB_GC_FDEFN LISPOBJ(0x2010019F)
#define POST_GC_FDEFN LISPOBJ(0x201001BF)
#define INTERNAL_ERROR_FDEFN LISPOBJ(0x201001DF)
#define CONTROL_STACK_EXHAUSTED_ERROR_FDEFN LISPOBJ(0x201001FF)
#define BINDING_STACK_EXHAUSTED_ERROR_FDEFN LISPOBJ(0x2010021F)
#define ALIEN_STACK_EXHAUSTED_ERROR_FDEFN LISPOBJ(0x2010023F)
#define HEAP_EXHAUSTED_ERROR_FDEFN LISPOBJ(0x2010025F)
#define UNDEFINED_ALIEN_VARIABLE_ERROR_FDEFN LISPOBJ(0x2010027F)
#define MEMORY_FAULT_ERROR_FDEFN LISPOBJ(0x2010029F)
#define UNHANDLED_TRAP_ERROR_FDEFN LISPOBJ(0x201002BF)
#define HANDLE_BREAKPOINT_FDEFN LISPOBJ(0x201002DF)
#define HANDLE_SINGLE_STEP_TRAP_FDEFN LISPOBJ(0x201002FF)
#define ENTER_ALIEN_CALLBACK_FDEFN LISPOBJ(0x2010031F)
#define ENTER_FOREIGN_CALLBACK_FDEFN LISPOBJ(0x2010033F)
#endif
