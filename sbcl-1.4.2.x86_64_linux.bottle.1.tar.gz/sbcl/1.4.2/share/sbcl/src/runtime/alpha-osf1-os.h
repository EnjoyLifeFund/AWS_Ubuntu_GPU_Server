#ifndef _ALPHA_OSF1_OS_H
#define _ALPHA_OSF1_OS_H

typedef struct ucontext os_context_t;

#include "arch-os-generic.inc"

#endif /* _ALPHA_OSF1_OS_H */
