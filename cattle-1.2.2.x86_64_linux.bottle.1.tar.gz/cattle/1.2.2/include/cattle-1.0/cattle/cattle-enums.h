
/* Generated data (by glib-mkenums) */

#if !defined (__CATTLE_H_INSIDE__) && !defined (CATTLE_COMPILATION)
#error "Only <cattle/cattle.h> can be included directly."
#endif

#ifndef __CATTLE_ENUMS_H__
#define __CATTLE_ENUMS_H__

#include <glib.h>
#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "cattle-configuration.h" */
GType cattle_end_of_input_action_get_type (void) G_GNUC_CONST;
#define CATTLE_TYPE_END_OF_INPUT_ACTION (cattle_end_of_input_action_get_type())

/* enumerations from "cattle-error.h" */
GType cattle_error_get_type (void) G_GNUC_CONST;
#define CATTLE_TYPE_ERROR (cattle_error_get_type())

/* enumerations from "cattle-instruction.h" */
GType cattle_instruction_value_get_type (void) G_GNUC_CONST;
#define CATTLE_TYPE_INSTRUCTION_VALUE (cattle_instruction_value_get_type())

G_END_DECLS

#endif /* __CATTLE_ENUMS_H__ */

/* Generated data ends here */

