class Seqdb < Formula
  desc "High-throughput compression of FASTQ data"
  homepage "https://bitbucket.org/mhowison/seqdb"
  url "https://bitbucket.org/mhowison/seqdb/downloads/seqdb-0.2.1.tar.gz"
  sha256 "44d1ca6a40701de75fb86936346ef843d3180ea8b9d7591739bdafa7415c484b"
  # doi "10.1109/TCBB.2012.160"
  # tag "bioinformatics"

  needs :openmp

  depends_on "hdf5"

  def install
    system "./configure", "--disable-dependency-tracking", "--prefix=#{prefix}"
    system "make", "install"
  end

  test do
    assert_match "Howison", shell_output("#{bin}/seqdb cite 2>&1", 0)
  end
end
