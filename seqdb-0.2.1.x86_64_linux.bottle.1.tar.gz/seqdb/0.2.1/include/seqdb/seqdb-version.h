#ifndef __SEQDB_VERSION_H__
#define __SEQDB_VERSION_H__

#define SEQDB_VERSION 0.2.1

#endif
