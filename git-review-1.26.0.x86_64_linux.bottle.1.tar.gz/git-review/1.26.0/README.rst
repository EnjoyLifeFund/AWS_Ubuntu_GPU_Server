git-review
==========

A git command for submitting branches to Gerrit

git-review is a tool that helps submitting git branches to gerrit for
review.

* Free software: Apache license
* Documentation: http://docs.openstack.org/infra/git-review/
* Source: https://git.openstack.org/cgit/openstack-infra/git-review
* Bugs: https://storyboard.openstack.org/#!/project/719
