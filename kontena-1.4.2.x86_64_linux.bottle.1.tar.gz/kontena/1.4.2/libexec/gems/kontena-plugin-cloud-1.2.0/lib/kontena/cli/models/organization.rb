require_relative 'cloud_api_model'

module Kontena::Cli::Models
  class Organization
    include CloudApiModel

  end
end