# The Celluloid timers gem is beamed directly to you from the minds of...

- Tony Arcieri <bascule@gmail.com>
- Jeremy Hinegardner
- Sean Gregory
- Chuck Remes
- Utenmiki
- Ron Evans
- Larry Lv
- Bruno Enten
- Jesse Cooke
- Nicholas Evans
- Dimitrij Denissenko
- Ryan LeCompte
- Samuel G. D. Williams