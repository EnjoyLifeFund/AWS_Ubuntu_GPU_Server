# frozen_string_literal: true

require "timers/version"

require "timers/group"
require "timers/wait"
