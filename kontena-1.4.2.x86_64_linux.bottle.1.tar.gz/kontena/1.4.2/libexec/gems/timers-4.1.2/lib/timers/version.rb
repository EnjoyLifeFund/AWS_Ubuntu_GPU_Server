# frozen_string_literal: true

module Timers
  VERSION = "4.1.2"
end
