require 'mkmf'
extension_name = 'websocket_mask'
dir_config(extension_name)
create_makefile(extension_name)
