* Andrew Katz <andrew.katz@outright.com>
* Anshul Khandelwal <anshul@anshulkhandelwal.com>
* Ash Wilson <smashwilson@gmail.com>
* Ben Burkert <ben@benburkert.com>
* Benedikt Böhm <bb@xnull.de>
* Bo Jeanes <me@bjeanes.com>
* Brandur <brandur@mutelight.org>
* Brian D. Burns <iosctr@gmail.com>
* Brian Hartsock <brian.hartsock@gmail.com>
* Caio Chassot <dev@caiochassot.com>
* Caius Durling <dev@caius.name>
* Carl Hörberg <carl.hoerberg@gmail.com>
* Carlos Sanchez <csanchez@maestrodev.com>
* Claudio Poli <masterkain@gmail.com>
* Colin Dean <colindean@us.ibm.com>
* Damien Mathieu <damien@heroku.com>
* Dan Hensgen <dan@methodhead.com>
* Dan Peterson <dpiddy@gmail.com>
* Dan Prince <dprince@redhat.com>
* Dane Harrigan <dane.harrigan@gmail.com>
* Dave Myron <therealdave.myron@gmail.com>
* Dave Newton <davelnewton@gmail.com>
* David Biehl <dbiehl@ncmedical.com>
* David Biehl <lazylodr@gmail.com>
* Dimitrij Denissenko <dimitrij@blacksquaremedia.com>
* Dominik Richter <dominik.richter@gmail.com>
* Eugene Howe <eugene@xtreme-computers.net>
* Evan Phoenix <evan@fallingsnow.net>
* Fabian Wiesel <fabian.wiesel@sap.com>
* Federico Ravasio <ravasio.federico@gmail.com>
* Glenn Pratt <glennpratt@gmail.com>
* Graeme Nelson <graeme.nelson@gmail.com>
* Hakan Ensari <hakan.ensari@papercavalier.com>
* Ian Neubert <ian@ianneubert.com>
* Jacob Atzen <jacob@incremental.dk>
* James Watling <watling.james@gmail.com>
* Jeremy Hinegardner <jeremy@copiousfreetime.org>
* John Keiser <jkeiser@opscode.com>
* John Leach <john@brightbox.co.uk>
* Jonas Pfenniger <jonas@pfenniger.name>
* Jonathan Dance <github@wuputah.com>
* Jonathan Dance <jd@wuputah.com>
* Jonathan Roes <jroes@jroes.net>
* Joshua Gross <joshua@surfeasy.com>
* Joshua Mckinney <joshmckin@gmail.com>
* Joshua Napoli <jnapoli@swipely-napoli.home>
* Joshua Napoli <jnapoli@swipely-napoli.local>
* Joshua Smith <kognate@gmail.com>
* Kensuke Nagae <kyanny@gmail.com>
* Konstantin Shabanov <etehtsea@gmail.com>
* Kyle Rames <kyle.rames@rackspace.com>
* Lewis Marshall <lewis@lmars.net>
* Lincoln Stoll <me@lstoll.net>
* Louis Sobel <sobel@mit.edu>
* Mathias Meyer <meyer@paperplanes.de>
* Matt Sanders <matt@modal.org>
* Matt Sanders <matt@polycot.com>
* Matt Snyder <snyder2112@me.com>
* Matt Todd <chiology@gmail.com>
* Max Lincoln <max@devopsy.com>
* Michael Brodhead <mkb@engineyard.com>
* Michael Hale <mike@hales.ws>
* Michael Rowe <mrowe@mojain.com>
* Michael Rykov <mrykov@gmail.com>
* Mike Heffner <mikeh@fesnel.com>
* Myron Marston <myron.marston@gmail.com>
* Nathan Long <nathan.long@tma1.com>
* Nathan Sutton <nate@zencoder.com>
* Nick Osborn <nick.osborn@digital.cabinet-office.gov.uk>
* Nicolas Sanguinetti <contacto@nicolassanguinetti.info>
* Peter Meier <peter.meier@immerda.ch>
* Peter Weldon <peter.weldon@null.net>
* Peter Weldon <peter@lautus.net>
* Ruslan Kyrychuk <ruslan.kyrychuk@gmail.com>
* Ryan Mohr <ryan.mohr@gmail.com>
* Scott Gonyea <me@aitrus.org>
* Scott Gonyea <me@sgonyea.com>
* Sean Cribbs <seancribbs@gmail.com>
* Sergio Rubio <rubiojr@frameos.org>
* Shai Rosenfeld <shaiguitar@gmail.com>
* Swanand Pagnis <swanandp@users.noreply.github.com>
* Terry Howe <terrylhowe@gmail.com>
* Thom Mahoney & Josh Lane <tmahoney@engineyard.com>
* Thom May <thom@digital-science.com>
* Tim Carey-Smith <tim@spork.in>
* Todd Lunter <tlunter@gmail.com>
* Tom Maher <tmaher@heroku.com>
* Tom Maher <tmaher@tursom.org>
* Trym Skaar <trym@tryms.no>
* Tuomas Silen <tuomas.silen@nodeta.fi>
* Viven <vivien.schilis@gmail.com>
* Wesley Beary <geemus+github@gmail.com>
* Wesley Beary <geemus@engineyard.com>
* Wesley Beary <geemus@gmail.com>
* Wesley Beary <wbeary@engineyard.com>
* Wesley Beary <wesley@heroku.com>
* chrisrhoden <carhoden@gmail.com>
* dickeyxxx <jeff@dickeyxxx.com>
* geemus (Wesley Beary) <wbeary@engineyard.com>
* geemus <geemus@gmail.com>
* ggoodale <ggoodale@gmail.com>
* marios <marios@redhat.com>
* mkb <mkb@black-ice.org>
* phiggins <pete@peterhiggins.org>
* rin_ne <rinrin.ne@gmail.com>
* rinrinne <rinrin.ne@gmail.com>
* rkyrychuk <ruslan.kyrychuk@gmail.com>
* sshaw <skye.shaw@gmail.com>
* twrodriguez <tw.rodriguez@gmail.com>
* zimbatm <zimbatm@zimbatm.com>
