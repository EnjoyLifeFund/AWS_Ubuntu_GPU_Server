# encoding: utf-8

require 'tty/color'
require "tty/color/version"
