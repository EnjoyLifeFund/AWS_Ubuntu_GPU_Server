# encoding: utf-8

module TTY
  module Color
    VERSION = "0.4.2"
  end # Color
end # TTY
