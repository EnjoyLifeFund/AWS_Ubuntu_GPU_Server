# encoding: utf-8

require_relative 'tty/prompt'
require_relative 'tty/test_prompt'
