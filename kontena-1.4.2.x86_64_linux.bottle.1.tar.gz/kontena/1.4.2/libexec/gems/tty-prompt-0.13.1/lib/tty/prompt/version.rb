# encoding: utf-8

module TTY
  class Prompt
    VERSION = "0.13.1"
  end # Prompt
end # TTY
