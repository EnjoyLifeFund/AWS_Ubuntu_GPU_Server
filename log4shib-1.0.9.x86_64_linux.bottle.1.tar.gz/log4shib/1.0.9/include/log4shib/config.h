#ifndef _INCLUDE_LOG_SHIB_CONFIG_H
#define _INCLUDE_LOG_SHIB_CONFIG_H 1
 
/* include/log4shib/config.h. Generated automatically at end of configure. */
/* include/config.h.  Generated from config.h.in by configure.  */
/* include/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the <dlfcn.h> header file. */
#ifndef LOG4SHIB_HAVE_DLFCN_H 
#define LOG4SHIB_HAVE_DLFCN_H  1 
#endif

/* Define to 1 if fcntl supports FD_CLOEXEC flag. */
#ifndef LOG4SHIB_HAVE_FD_CLOEXEC 
#define LOG4SHIB_HAVE_FD_CLOEXEC  1 
#endif

/* Define to 1 if you have the `ftime' function. */
#ifndef LOG4SHIB_HAVE_FTIME 
#define LOG4SHIB_HAVE_FTIME  1 
#endif

/* Define to 1 if you have the `gettimeofday' function. */
#ifndef LOG4SHIB_HAVE_GETTIMEOFDAY 
#define LOG4SHIB_HAVE_GETTIMEOFDAY  1 
#endif

/* Define to 1 if you have the `gmtime_r' function. */
#ifndef LOG4SHIB_HAVE_GMTIME_R 
#define LOG4SHIB_HAVE_GMTIME_R  1 
#endif

/* define if the compiler has int64_t */
#ifndef LOG4SHIB_HAVE_INT64_T 
#define LOG4SHIB_HAVE_INT64_T  /**/ 
#endif

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef LOG4SHIB_HAVE_INTTYPES_H 
#define LOG4SHIB_HAVE_INTTYPES_H  1 
#endif

/* Define to 1 if you have the <io.h> header file. */
/* #undef HAVE_IO_H */

/* Define to 1 if you have the `idsa' library (-lidsa). */
/* #undef HAVE_LIBIDSA */

/* Define to 1 if you have the `localtime_r' function. */
#ifndef LOG4SHIB_HAVE_LOCALTIME_R 
#define LOG4SHIB_HAVE_LOCALTIME_R  1 
#endif

/* Define to 1 if you have the <memory.h> header file. */
#ifndef LOG4SHIB_HAVE_MEMORY_H 
#define LOG4SHIB_HAVE_MEMORY_H  1 
#endif

/* define if the compiler implements namespaces */
#ifndef LOG4SHIB_HAVE_NAMESPACES 
#define LOG4SHIB_HAVE_NAMESPACES  /**/ 
#endif

/* Define to 1 if open supports O_CLOEXEC flag. */
#ifndef LOG4SHIB_HAVE_O_CLOEXEC 
#define LOG4SHIB_HAVE_O_CLOEXEC  1 
#endif

/* Define if you have POSIX threads libraries and header files. */
#ifndef LOG4SHIB_HAVE_PTHREAD 
#define LOG4SHIB_HAVE_PTHREAD  1 
#endif

/* Have PTHREAD_PRIO_INHERIT. */
#ifndef LOG4SHIB_HAVE_PTHREAD_PRIO_INHERIT 
#define LOG4SHIB_HAVE_PTHREAD_PRIO_INHERIT  1 
#endif

/* define if the C library has snprintf */
#ifndef LOG4SHIB_HAVE_SNPRINTF 
#define LOG4SHIB_HAVE_SNPRINTF  /**/ 
#endif

/* Define if the SOCK_CLOEXEC flag is supported */
#ifndef LOG4SHIB_HAVE_SOCK_CLOEXEC 
#define LOG4SHIB_HAVE_SOCK_CLOEXEC  1 
#endif

/* define if the compiler has stringstream */
#ifndef LOG4SHIB_HAVE_SSTREAM 
#define LOG4SHIB_HAVE_SSTREAM  /**/ 
#endif

/* define if you have the <stdint.h> header file. */
#ifndef LOG4SHIB_HAVE_STDINT_H 
#define LOG4SHIB_HAVE_STDINT_H  /**/ 
#endif

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef LOG4SHIB_HAVE_STDLIB_H 
#define LOG4SHIB_HAVE_STDLIB_H  1 
#endif

/* Define to 1 if you have the <strings.h> header file. */
#ifndef LOG4SHIB_HAVE_STRINGS_H 
#define LOG4SHIB_HAVE_STRINGS_H  1 
#endif

/* Define to 1 if you have the <string.h> header file. */
#ifndef LOG4SHIB_HAVE_STRING_H 
#define LOG4SHIB_HAVE_STRING_H  1 
#endif

/* Define to 1 if you have the `syslog' function. */
#ifndef LOG4SHIB_HAVE_SYSLOG 
#define LOG4SHIB_HAVE_SYSLOG  1 
#endif

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef LOG4SHIB_HAVE_SYS_STAT_H 
#define LOG4SHIB_HAVE_SYS_STAT_H  1 
#endif

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef LOG4SHIB_HAVE_SYS_TYPES_H 
#define LOG4SHIB_HAVE_SYS_TYPES_H  1 
#endif

/* define if threading is enabled */
#ifndef LOG4SHIB_HAVE_THREADING 
#define LOG4SHIB_HAVE_THREADING  1 
#endif

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef LOG4SHIB_HAVE_UNISTD_H 
#define LOG4SHIB_HAVE_UNISTD_H  1 
#endif

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#ifndef LOG4SHIB_LT_OBJDIR 
#define LOG4SHIB_LT_OBJDIR  ".libs/" 
#endif

/* Name of package */
#ifndef LOG4SHIB_PACKAGE 
#define LOG4SHIB_PACKAGE  "log4shib" 
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef LOG4SHIB_PACKAGE_BUGREPORT 
#define LOG4SHIB_PACKAGE_BUGREPORT  "" 
#endif

/* Define to the full name of this package. */
#ifndef LOG4SHIB_PACKAGE_NAME 
#define LOG4SHIB_PACKAGE_NAME  "log4shib" 
#endif

/* Define to the full name and version of this package. */
#ifndef LOG4SHIB_PACKAGE_STRING 
#define LOG4SHIB_PACKAGE_STRING  "log4shib 1.0.9" 
#endif

/* Define to the one symbol short name of this package. */
#ifndef LOG4SHIB_PACKAGE_TARNAME 
#define LOG4SHIB_PACKAGE_TARNAME  "log4shib" 
#endif

/* Define to the home page for this package. */
#ifndef LOG4SHIB_PACKAGE_URL 
#define LOG4SHIB_PACKAGE_URL  "" 
#endif

/* Define to the version of this package. */
#ifndef LOG4SHIB_PACKAGE_VERSION 
#define LOG4SHIB_PACKAGE_VERSION  "1.0.9" 
#endif

/* Define to necessary symbol if this constant uses a non-standard name on
   your system. */
/* #undef PTHREAD_CREATE_JOINABLE */

/* Define to 1 if you have the ANSI C header files. */
#ifndef LOG4SHIB_STDC_HEADERS 
#define LOG4SHIB_STDC_HEADERS  1 
#endif

/* define if pthread library is available */
#ifndef LOG4SHIB_USE_PTHREADS 
#define LOG4SHIB_USE_PTHREADS  1 
#endif

/* Version number of package */
#ifndef LOG4SHIB_VERSION 
#define LOG4SHIB_VERSION  "1.0.9" 
#endif

/* define for STL if pthread library is used */
#ifndef LOG4SHIB__PTHREADS 
#define LOG4SHIB__PTHREADS  1 
#endif
 
/* once: _INCLUDE_LOG_SHIB_CONFIG_H */
#endif
