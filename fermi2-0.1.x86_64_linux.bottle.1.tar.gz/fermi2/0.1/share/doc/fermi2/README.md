Note: fermi2 is in fact not the successor of fermi. It drops the assembly
component in fermi and focuses on the exploration of FMD-index as a graph. It
relies on fermi or ropebwt2 for index construction.

Fermi2 is fairly incomplete, but some components are usable and to some extend
better than fermi equivalent.
