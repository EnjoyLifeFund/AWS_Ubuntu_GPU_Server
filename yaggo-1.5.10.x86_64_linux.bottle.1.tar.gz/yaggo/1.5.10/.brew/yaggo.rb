class Yaggo < Formula
  desc "Generate command-line parsers for C++"
  homepage "https://github.com/gmarcais/yaggo"
  url "https://github.com/gmarcais/yaggo/archive/v1.5.10.tar.gz"
  sha256 "3a81532d3be8109a0e44949a04ccf74cc1b5c8fee47789a12c8cabc6fa0b1e4f"
  head "https://github.com/gmarcais/yaggo.git"

  depends_on :ruby => ["1.9", :build]

  def install
    system "make", "install", "prefix=#{prefix}"
  end

  test do
    system "#{bin}/yaggo", "--version"
  end
end
