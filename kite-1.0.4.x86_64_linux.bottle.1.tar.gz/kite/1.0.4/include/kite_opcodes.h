#ifndef KITE_VM__KITE_OPCODES_H
#define KITE_VM__KITE_OPCODES_H
/*****************************************************************************
 * Copyright (c) 2007, Mooneer Salem
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Kite Language organization nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ****************************************************************************/

struct kite_object_t;

/*
 * Base VM opcode object
 */
typedef struct kite_opcode_t
{
    unsigned int opcode;
    unsigned int length;
    union
    {
        unsigned int operation; /* arthop */
        struct kite_object_t *obj; /* push */
        int create; /* deref_1 */
        struct kite_opcode_t *jumpto; /* jump_* */
        struct kite_opcode_t *handler; /* exception_hndl */
        int dupe_ref; /* dupe_top */
        int isof; /* objis */
        struct kite_object_t *args; /* funcargs */
    } op_arg;
    char *file;
    int line; /* For alignment purposes */
} kite_opcode_t;

/*
 * VM arithmetic operation
 */
typedef struct kite_opcode_t kite_opcode_arithop;

/*
 * Push object onto execution stack
 */
typedef struct kite_opcode_t kite_opcode_push;

/*
 * Combine two elements (or an element and a list) into a single list
 */
typedef struct kite_opcode_t kite_opcode_list_cons;

/*
 * Create an empty list.
 */
typedef struct kite_opcode_t kite_opcode_list_cons_0;

/*
 * Make list out of a single element
 */
typedef struct kite_opcode_t kite_opcode_list_cons_1;

/*
 * Dereference an object
 */
typedef struct kite_opcode_t kite_opcode_deref_1;

/*
 * Dereference an object (and retrieve property)
 */
typedef struct kite_opcode_t kite_opcode_deref_2;

/*
 * Call method
 */
typedef struct kite_opcode_t kite_opcode_call;

/*
 * Jump if true
 */
typedef struct kite_opcode_t kite_opcode_jump_true;

/*
 * Jump if false
 */
typedef struct kite_opcode_t kite_opcode_jump_false;

/*
 * Jump unconditional
 */
typedef struct kite_opcode_t kite_opcode_jump_unconditional;

/*
 * Handle exception
 */
typedef struct kite_opcode_t kite_opcode_exception_hndl;

/*
 * Handle exception
 */
typedef struct kite_opcode_t kite_opcode_pop_exception_hndl;

/*
 * Duplicate top of stack
 */
typedef struct kite_opcode_t kite_opcode_dupe_top;

/*
 * Create instance of object
 */
typedef struct kite_opcode_t kite_opcode_make;

/*
 * is/isof evaluation
 */
typedef struct kite_opcode_t kite_opcode_objis;

/*
 * Evaluate code
 */
typedef struct kite_opcode_t kite_opcode_eval;

/*
 * No op.
 */
typedef struct kite_opcode_t kite_opcode_nop;

/*
 * Return
 */
typedef struct kite_opcode_t kite_opcode_return;

/*
 * Put variables onto function stack
 */
typedef struct kite_opcode_t kite_opcode_funcargs;

/*
 * Define property/variable.
 */
typedef struct kite_opcode_t kite_opcode_defprop;

/*
 * Get "this".
 */
typedef struct kite_opcode_t kite_opcode_this;

/*
 * Valid opcode numbers
 */
enum kite_opcodes
{
    JUMP_TRUE = 0,
    JUMP_FALSE,
    JUMP_UNCOND,
    CALL,
    DEREF_1,
    DEREF_2,
    DUPE_TOP,
    EXCEPTION_HNDL,
    POP_EXCEPTION_HNDL,
    LIST_CONS,
    LIST_CONS_0,
    LIST_CONS_1,
    PUSH,
    ARITH_OP,
    FUNCARGS,
    MAKE_OBJ,
    EVAL_OBJ,
    IS_ISOF,
    NOP,
    DEFPROP,
    PUSH_THIS,
    RETURN_NOW,
    NUM_OPCODES,
    TEMP_BREAK,
    TEMP_CONTINUE
};

/*
 * Create individual instructions.
 */
kite_opcode_t *kite_compile_arithop(unsigned int);
kite_opcode_t *kite_compile_push(struct kite_object_t *);
kite_opcode_t *kite_compile_list_cons();
kite_opcode_t *kite_compile_list_cons_0();
kite_opcode_t *kite_compile_list_cons_1();
kite_opcode_t *kite_compile_deref_1(int create);
kite_opcode_t *kite_compile_deref_2();
kite_opcode_t *kite_compile_call();
kite_opcode_t *kite_compile_jump_true(kite_opcode_t *);
kite_opcode_t *kite_compile_jump_false(kite_opcode_t *);
kite_opcode_t *kite_compile_jump_uncond(kite_opcode_t *);
kite_opcode_t *kite_compile_exception_hndl(kite_opcode_t *);
kite_opcode_t *kite_compile_pop_exception_hndl();
kite_opcode_t *kite_compile_dupe_top(int dupe_ref);
KITE_EXPORT kite_opcode_t *kite_compile_funcargs(struct kite_object_t *);
kite_opcode_t *kite_compile_make();
kite_opcode_t *kite_compile_eval();
kite_opcode_t *kite_compile_nop();
kite_opcode_t *kite_compile_return();
kite_opcode_t *kite_compile_objis(int isof);
kite_opcode_t *kite_compile_defprop();
kite_opcode_t *kite_compile_this();
kite_opcode_t *kite_compile_ref();

/*
 * Instruction lists
 */
struct kite_thread_t;
#if 0
KITE_EXPORT kite_opcode_t *kite_add_to_instruction_list(kite_opcode_t **, kite_opcode_t *);
void kite_free_instruction_list(struct kite_thread_t *, kite_opcode_t *);
kite_opcode_t *kite_copy_instruction_list(struct kite_thread_t *, kite_opcode_t *);
#else
KITE_EXPORT kite_opcode_t *kite_add_to_instruction_list(struct kite_thread_t *, kite_opcode_t **, kite_opcode_t *);
void kite_free_instruction_list(struct kite_thread_t *, kite_opcode_t *);
kite_opcode_t *kite_copy_instruction_list(struct kite_thread_t *, kite_object_t *, kite_opcode_t *);
void COMPILE_INSTRUCTION2(kite_thread_t *thd, kite_compiler_t *compiler, kite_opcode_t *inst, int lno, void **dest);
#endif /* 0 */

#endif /* KITE_VM__KITE_OPCODES_H */

