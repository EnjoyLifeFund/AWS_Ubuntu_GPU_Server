#ifndef KITE_OBJS__KITEOBJECT_H
#define KITE_OBJS__KITEOBJECT_H
/*****************************************************************************
 * Copyright (c) 2007, Mooneer Salem
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Kite Language organization nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ****************************************************************************/

#include <stdio.h>

#ifdef WIN32
#undef __MINGW32__
#define WIN32_LEAN_AND_MEAN
/*#define _WIN32_WINNT 0x501*/
#include <windows.h>
#ifdef HAVE_GC_GC_H
#define HAVE_GC_H
#endif /* HAVE_GC_GC_H */
#else
#include <pthread.h>
#endif /* WIN32 */

#ifdef CINVOKE_BUILD
#include "config.h"
#endif /* CINVOKE_BUILD */

#ifdef HAVE_GC_H
#define GC_THREADS
#ifdef WIN32
#define WIN32_THREADS
#define GC_NOT_DLL
/*#define GC_WIN32_THREADS*/
#include <gc.h>
#else
#define GC_PTHREADS
#ifndef __APPLE__
void * GC_dlopen(const char *path, int mode);
#else
#define GC_DARWIN_THREADS
#endif /* __APPLE__ */
#include <gc/gc.h>
#endif
#endif /* HAVE_GC_H */

/*
 * FALSE/TRUE definitions (for those platforms that don't already define
 * them).
 */
#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

/* Dynamic library extensions. */
#ifdef WIN32
#define DYLIB_EXTENSION ".dll"
#define KITE_EXPORT __declspec(dllexport)
#else
#ifdef __APPLE__
#define DYLIB_EXTENSION ".dylib"
#else
#define DYLIB_EXTENSION ".so"
#endif
#define KITE_EXPORT
#endif

/*
 * Representation of Kite method written in C
 */
struct kite_object_t;
struct kite_thread_t;
struct kite_opcode_t;

/**
 * Function prototype for all compiled (non-Kite written methods).
 * @param thread The currently running thread object.
 * @param this The current object. This is the class object if called statically.
 * @param args A Kite list containing the method's arguments (0-length if empty).
 */
typedef void (*kite_compiled_func_t)(struct kite_thread_t *thread, 
                                     struct kite_object_t *this, 
                                     struct kite_object_t *args);

/**
 * Representation of Kite method (built-in and user provided)
 * @sa struct kite_opcode_t
 */
typedef struct kite_function_t {
    enum 
    { 
        FUNC_COMPILED /*! C function */, 
        FUNC_BYTECODE /*! Kite-written method */
    } functype /*! The function type (compiled or bytecode) */;
    void *funcptr /*! Pointer to C function or kite_opcode_t representing bytecode. */;
    struct kite_object_t *this /*! The object this method is associated with. \private */;
    int numargs /*! The number of arguments for the given method. */;
    struct kite_object_t *arginfo /*! A Kite list with names and documentation for each argument. */;
    size_t length /*! Length of function, in bytes. */;
} kite_function_t;

/**
 * Kite symbol table object (tree representing properties and methods.)
 * @sa struct kite_object_t
 */
struct kite_symtab_t
{
    char *name /*! Name of the property or method. */;
    char *docstring /*! Documentation describing property 
                        (documentation for methods goes inside the method object.) */;
    int global /*! Whether the property is global across all instances or
                   can have different values per instance. If method, also
                   represents the number of arguments for method overloading. */;
    struct kite_symtab_t *left /*! All properties/methods less than the current one. \private */;
    struct kite_symtab_t *right /*! All properties/methods greater than the current one. \private */;
    struct kite_object_t *value /*! The current value of the given property/method. */;
};
typedef struct kite_symtab_t kite_symtab_t;

#include "kite_vm.h"

enum kite_object_type_t
{ 
    OBJ_INTEGER /*! Integer object. */, 
    OBJ_FLOAT /*! Floating-point object. */,
    OBJ_BOOLEAN /*! Boolean object. */,
    OBJ_NUMBER_OF_BASE_TYPES /*! Number of "basic" types. \private */,
    OBJ_NULL = OBJ_NUMBER_OF_BASE_TYPES /*! The null object. */,
    OBJ_STRING /*! String object. */,
    OBJ_IDENT /*! Identifier object. */, 
    OBJ_LIST /*! List object. */, 
    OBJ_METHOD /*! Method object. */, 
    OBJ_CLASS /*! Class object. */, 
    OBJ_INSTANCE /*! Instance object. */,
    OBJ_NUMBER_OF_TYPES /*! Number of possible internal types. \private */
};

/**
 * Representation of an basic object in the Kite object system. \private
 * @sa struct kite_thread_t
 * @sa struct kite_function_t
 * @sa struct kite_symtab_t
 */
typedef struct kite_basic_object_t {
    enum kite_object_type_t type /*! The object's type. */;
    int shareable /*! Can be shared with other threads. \private */;
    union {
        long intvalue /*! Associated integer value. */;
        double floatvalue /*! Associated floating-point value. */;
    } builtin_data;
} kite_basic_object_t;

/**
 * Representation of an object/class in the Kite object system.
 * @sa struct kite_thread_t
 * @sa struct kite_function_t
 * @sa struct kite_symtab_t
 */
typedef struct kite_object_t {
#ifndef HAVE_GC_H
    unsigned int refcount /*! Current reference count \private */;
    kite_list_t *gc_entry /*! GC entry (not intended to be used by user code) \private */;
#endif /* HAVE_GC_H */
    enum kite_object_type_t type /*! The object's type. */;
    int shareable /*! Can be shared with other threads. \private */;
    union {
        long intvalue /*! Associated integer value. */;
        double floatvalue /*! Associated floating-point value. */;
        struct {
            int length /*! String length. */;
            char *string /*! String value. */;
        } stringvalue;
        struct {
            struct kite_object_t *car /*! Current list element */;
            struct kite_object_t *cdr /*! Next list element */;
            struct kite_object_t *iterator /*! Current iterator position */;
        } listvalue;
        kite_function_t funcvalue /*! Function value. */;
        kite_thread_t *threadvalue /*! Thread value. */;
        FILE *filevalue /*! File value. \private */;
    } builtin_data;
    kite_thread_t *owner_thread /*! Owner thread \private */;
    struct kite_object_t *parent /*! Parent object. \private */;
    struct {
        char *name /*! Name of class. */;
        char *docstring /*! Documentation for given class. */;
        struct kite_object_t *inherit_from /*! Inherited from. */;
        kite_symtab_t *properties /*! Class properties/method. */;
#ifdef WIN32
        HANDLE mtx /*! \private */;
        HMODULE dylib_hndl /*! \private */;
#else
        pthread_mutex_t *mtx /*! \private */;
        void *dylib_hndl /*! \private */;
#endif
    } object_data;
} kite_object_t;

/**
 * Create a new null object.
 * @param thd The associated thread for the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_null(kite_thread_t *thd);

/**
 * Create a new integer object.
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_integer(kite_thread_t *thd, long val);

/**
 * Create a new floating-point object.
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_float(kite_thread_t *thd, double val);

/**
 * Create a new string object.
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_string(kite_thread_t *thd, char *val);

/**
 * Create a new string object (with given length).
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @param length The length of the string.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_string_with_length(kite_thread_t *thd, char *val, int length);

/**
 * Create a new identifier object.
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_ident(kite_thread_t *thd, char *val);

/**
 * Create a new boolean object.
 * @param thd The associated thread for the object.
 * @param val The value to associate with the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_boolean(kite_thread_t *thd, int val);

/**
 * Create a new empty list object.
 * @param thd The associated thread for the object.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_list(kite_thread_t *thd);

/**
 * Create a new method object (based on C-compiled code).
 * @param thd The associated thread for the object.
 * @param func The C function that this method refers to.
 * @param numargs The number of arguments this method should take in Kite code.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_method_compiled(kite_thread_t *thd, kite_compiled_func_t func, int numargs);

/**
 * Create a new method object with documentation strings (based on C-compiled code).
 * @param thd The associated thread for the object.
 * @param func The C function that this method refers to.
 * @param desc The method's description.
 * @param numargs The number of arguments this method should take in Kite code.
 * @param argname (for each argument) The name of the argument.
 * @param argdesc (for each argument) The description of the argument.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_method_compiled_with_docs(
    kite_thread_t *thd, kite_compiled_func_t func, char* desc, int numargs, ...);

/**
 * Create a new method object (based on Kite bytecode).
 * @param thd The associated thread for the object.
 * @param func The C function that this method refers to.
 * @param numargs The number of arguments this method should take in Kite code.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_method_bytecode(kite_thread_t *thd, struct kite_opcode_t *func, int numargs);

/**
 * Create a new method object with documentation strings (based on Kite bytecode).
 * @param thd The associated thread for the object.
 * @param func The bytecode that this method refers to.
 * @param desc The method's description.
 * @param numargs The number of arguments this method should take in Kite code.
 * @param argname (for each argument) The name of the argument.
 * @param argdesc (for each argument) The description of the argument.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_method_bytecode_with_docs(
    kite_thread_t *thd, struct kite_opcode_t *func, char *desc, int numargs, ...);

/**
 * Create a new Kite class.
 * @param thd The associated thread for this object.
 * @param parent The class that this inherits from.
 * @param name The new class' name.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_class(kite_thread_t *thd, kite_object_t *parent, char *name);

/**
 * Create a new Kite instance (without initialization)
 * @param thd The associated thread for this object.
 * @param parent The class that this instance is associated with.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_instance(kite_thread_t *thd, kite_object_t *parent);

/**
 * Create a new Kite instance (with initialization)
 * @param thd The associated thread for this object.
 * @param parent The class that this instance is associated with.
 * @param args A list specifying arguments to pass to the constructor.
 * @return The new object.
 * @note thd->exception will contain an exception object if the constructor
 *       fails.
 * @sa struct kite_thread_t
 */
KITE_EXPORT kite_object_t *kite_new_instance_with_constructor
    (kite_thread_t *thd, kite_object_t *parent, kite_object_t *args);
    
/**
 * Create a new exception object.
 * @param thd The thread to associate the exception with.
 * @param name The fully-qualified name of the exception (e.g. System.exceptions.FileError)
 * @param message The message to associate with the given exception.
 * @return The new object.
 */
KITE_EXPORT kite_object_t *kite_new_exception(kite_thread_t *thd, char *name, char *message);

/**
 * Destroy object.
 * @private
 */
KITE_EXPORT void kite_destruct_object(kite_thread_t *, kite_object_t **, int);

/**
 * Destroy object.
 * @private
 */
KITE_EXPORT void kite_destruct_object_nofree(kite_thread_t *, kite_object_t **, int);

/**
 * Destroy object.
 * @private
 */
KITE_EXPORT void kite_finalize_object(void *, void *);

/**
 * Dereference object.
 * @param obj The object to dereference.
 * @note This has no effect if Kite was compiled with GC support. However,
 *       do not rely on the GC existing in a user's installed version. This
 *       is important to ensure that objects are freed appropriately and
 *       not leaked.
 */
KITE_EXPORT void kite_dereference_object(kite_object_t *obj);

/**
 * Reference object.
 * @param obj The object to dereference.
 * @note This has no effect if Kite was compiled with GC support. However,
 *       do not rely on the GC existing in a user's installed version. This
 *       is important to ensure that objects are freed appropriately and
 *       not leaked.
 * @return The given object.
 */
KITE_EXPORT kite_object_t *kite_reference_object(kite_object_t *obj);

/* 
 * Stuff to allow built-in and loadable extensions to add their own
 * properties and methods, among other things.
 */
 
/**
 * Add property to object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param name The name of the new property.
 * @param global 1 for global property, 0 for non-global.
 * @param doc Description of property (NULL if not given).
 */
KITE_EXPORT void kite_add_property
    (kite_thread_t *thd, kite_object_t *obj, char *name, int global, char *doc);
    
/**
 * Add method to object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param name The name of the new property.
 * @param method The method object to add.
 */
KITE_EXPORT void kite_add_method
    (kite_thread_t *thd, kite_object_t *obj, char *name, kite_object_t *method);

/**
 * Add operator to object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param op The operator to add (from enum kite_operators)
 * @param method The method object to associate with the operator.
 * @sa enum kite_operators
 */
KITE_EXPORT void kite_add_operator
    (kite_thread_t *thd, kite_object_t *obj, int op, kite_object_t *method);

/**
 * Sets the documentation string for a given object.
 * @param obj The object to operate on.
 * @param str The documentation string to set.
 */
KITE_EXPORT void kite_set_docstring(kite_object_t *obj, char *str);

/**
 * Gets the documentation string for a given object.
 * @param obj The object to operate on.
 * @return The object's documentation string (or NULL if not provided).
 * @warning Do not modify the provided string.
 */
KITE_EXPORT char *kite_get_docstring(kite_object_t *obj);

/**
 * Sets the argument information for a given method.
 * @param obj The method to operate on.
 * @param arginfo A list of arguments. Each element is an identifier containing
 *                a name, and the documentation string associated with each identifier
 *                contains the description.
 */
KITE_EXPORT void kite_set_arginfo(kite_object_t *obj, kite_object_t *arginfo);

/**
 * Removes property from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param name The name of the property to remove.
 * @param global 1 for global properties, 0 otherwise.
 */
KITE_EXPORT void kite_remove_property
    (kite_thread_t *thd, kite_object_t *obj, char *name, int global);

/**
 * Removes method from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param name The name of the method to remove.
 * @param numargs The number of arguments of the method to remove.
 */
KITE_EXPORT void kite_remove_method
    (kite_thread_t *thd, kite_object_t *obj, char *name, int numargs);

/**
 * Removes operator from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param op The operator to remove (from kite_operators)
 * @sa enum kite_operators
 */
KITE_EXPORT void kite_remove_operator(kite_thread_t *thd, kite_object_t *obj, int op);

/**
 * Sets property to the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @param name The name of the property to set.
 * @param value The object to set the property to.
 */
KITE_EXPORT void kite_set_property
    (kite_thread_t *thd, kite_object_t *obj, char *name, kite_object_t *value);

/**
 * Determines the existance of a property.
 * @param obj The object to operate on.
 * @param name The name of the property to check.
 * @return TRUE if exists, FALSE otherwise.
 */
KITE_EXPORT int kite_exists_property(kite_object_t *obj, char *name);

/**
 * Determines the existance of a method.
 * @param obj The object to operate on.
 * @param name The name of the method to check.
 * @return TRUE if exists, FALSE otherwise.
 */
KITE_EXPORT int kite_exists_method(kite_object_t *obj, char *name);

/**
 * Determines the existance of an operator.
 * @param obj The object to operate on.
 * @param op The operator to check for (from kite_operators)
 * @return TRUE if exists, FALSE otherwise.
 * @sa enum kite_operators
 */
KITE_EXPORT int kite_exists_operator(kite_object_t *obj, int op);

/**
 * Retrieve the value of a property.
 * @param obj The object to operate on.
 * @param name The name of the property to retrieve.
 * @return The object stored within the property, or NULL if the property 
 *         does not exist.
 */
KITE_EXPORT kite_object_t *kite_get_property(kite_object_t *obj, char *name);

/**
 * Load a Kite module (compiled or bytecode) into memory.
 * @param thd The current thread.
 * @param name The fully-qualified name of the module to load.
 * @return The module itself, or NULL if a problem occurred.
 * @note If a problem occurred, thd->exception will be non-NULL.
 */
KITE_EXPORT kite_object_t *kite_dereference_and_load(kite_thread_t *thd, char *name);

/**
 * Set the dynamic library path.
 * @param path The new dynamic library path (separated by colons).
 */
KITE_EXPORT void kite_set_dylib_path(char *path);

/**
 * Register a loader (for built-in modules).
 * @private
 * @param thd The current thread.
 * @param name The name of the module.
 * @param ptr A pointer to the function that handles module loading.
 */
KITE_EXPORT void kite_loader_register
    (kite_thread_t *thd, char *name, void (*ptr)(kite_thread_t*, kite_object_t*));

/*
 * Stuff to find properties/methods
 */
 
/**
 * Find property for given object and return symbol table object.
 * @param[out] ret The kite_symtab_t pointer to return the result to.
 * @param obj The object to operate on.
 * @param name The name of the property to find.
 * @param num 1 for global properties, 0 otherwise.
 * @sa KITE_FIND_IN_SYMTAB
 * @sa struct kite_symtab_t
 */
#define KITE_FIND_PROPERTY(ret, obj, name, num) \
    KITE_FIND_IN_SYMTAB(ret, obj->object_data.properties, name, num)

/**
 * Find method for given object and return symbol table object.
 * @param[out] ret The kite_symtab_t pointer to return the result to.
 * @param obj The object to operate on.
 * @param name The name of the method to find.
 * @param num The number of arguments of the method.
 * @sa KITE_FIND_IN_SYMTAB
 */
#define KITE_FIND_METHOD(ret, obj, name, num) \
    KITE_FIND_IN_SYMTAB(ret, obj->object_data.properties, name, num)

/**
 * Find property or method for given object and return symbol table object.
 * @param[out] ret The kite_symtab_t pointer to return the result to.
 * @param symtab The symbol table to look in.
 * @param n The property or method to look for.
 * @param num The number of arguments of the method. For properties, 
 *        1 = global and 0 for all others.
 * @sa struct kite_symtab_t
 */
#define KITE_FIND_IN_SYMTAB(ret, symtab, n, num) \
    { \
        ret = symtab; \
        while(ret) { \
            int r = strcmp(n, ret->name); \
            if (!r && ret->global == num) { \
                break; \
            } else if (r < 0 || (!r && ret->global > num)) ret = ret->left; \
            else ret = ret->right; \
        } \
    }

/**
 * Find any property or method for given object and return symbol table object.
 * @param[out] ret The kite_symtab_t pointer to return the result to.
 * @param symtab The symbol table to look in.
 * @param n The property or method to look for.
 * @sa struct kite_symtab_t
 */
#define KITE_FIND_ANY_IN_SYMTAB(ret, symtab, n) \
    { \
        ret = symtab; \
        while(ret) { \
            int r = strcmp(n, ret->name); \
            if (!r) { \
                break; \
            } else if (r < 0) ret = ret->left; \
            else ret = ret->right; \
        } \
    }
    
/*
 * Symbol table manipulation
 */ 

/**
 * Create a new symbol table object.
 * @return Symbol table object.
 */
kite_symtab_t *kite_new_symtab();

/**
 * Insert entry into symbol table.
 * @param thd The current thread.
 * @param symt The symbol table to insert into.
 * @param entry The entry to insert.
 */
KITE_EXPORT void kite_symtab_insert
    (kite_thread_t *thd, kite_symtab_t **symt, kite_symtab_t *entry);

/**
 * Remove entry from symbol table.
 * @param thd The current thread.
 * @param[in,out] symt The symbol table to remove from.
 * @param name The name of the entry to remove.
 * @param num The number of arguments (or global vs non-global property) to remove.
 */
KITE_EXPORT void kite_symtab_remove
    (kite_thread_t *thd, kite_symtab_t **symt, char *name, int num);

/**
 * Copy entire symbol table.
 * @param[out] ret The variable to place the new symbol table.
 * @param symt The symbol table to copy.
 */
KITE_EXPORT void kite_copy_symtab(kite_symtab_t **ret, kite_symtab_t *symt);

/**
 * Destroy symbol table.
 * @param thd The current thread.
 * @param[in,out] symt The symbol table to remove.
 * @param ref If TRUE, dereference objects inside symbol table.
 */
KITE_EXPORT void kite_destruct_symtab(kite_thread_t *thd, kite_symtab_t **symt, int ref);

/**
 * Copy entire symbol table into another possibly existing table, 
 * setting parent as appropriate.
 * @param thd The current thread.
 * @param[in,out] ret The symbol table to copy to (*ret = NULL to make a new table)
 * @param symt The symbol table to copy.
 * @param p The new parent for each object copied from the table.
 */
KITE_EXPORT void kite_copy_symtab_elements
    (kite_thread_t *thd, kite_symtab_t **ret, kite_symtab_t *symt, kite_object_t *p);

/*
 * Canonical object representation
 */
 
/**
 * Find the fully-qualified name of the object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite object with the fully qualified name.
 */
KITE_EXPORT kite_object_t *kite_object_name(kite_thread_t *thd, kite_object_t *obj);

/**
 * Produce Boolean object from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite object with the proper Boolean value.
 * @note Equivalent to executing obj|bool in Kite.
 */
KITE_EXPORT kite_object_t *kite_boolean_object(kite_thread_t *thd, kite_object_t *obj);

/**
 * Produce string object from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite object with the proper string value.
 * @note Equivalent to executing obj|str in Kite.
 */
KITE_EXPORT kite_object_t *kite_string_object(kite_thread_t *thd, kite_object_t *obj);

/**
 * Produce integer object from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite object with the proper integer value.
 * @note Equivalent to executing obj|int in Kite.
 */
KITE_EXPORT kite_object_t *kite_int_object(kite_thread_t *thd, kite_object_t *obj);

/**
 * Produce floating-point object from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite object with the proper floating-point value.
 * @note Equivalent to executing obj|float in Kite.
 */
KITE_EXPORT kite_object_t *kite_float_object(kite_thread_t *thd, kite_object_t *obj);

/**
 * Produce list object from the given object.
 * @param thd The current thread.
 * @param obj The object to operate on.
 * @return A new Kite list with a single element: the given object.
 */
KITE_EXPORT kite_object_t *kite_list_object(kite_thread_t *thd, kite_object_t *obj);

/*
 * List manipulation
 */

/**
 * Find the number of items in a list.
 * @param thd The current thread.
 * @param obj The objet to operate on.
 * @return The number of items in the list.
 */
KITE_EXPORT int kite_list_count(kite_thread_t *thd, kite_object_t *obj);

/**
 * Append an item to the end of a list.
 * @param thd The current thread.
 * @param list The list to operate on.
 * @param obj The object to insert.
 */
KITE_EXPORT void kite_append_list(kite_thread_t *thd, kite_object_t *list, kite_object_t *obj);

/*
 * Defines for module writers
 */
 
/**
 * The name of the method given to the function called by the Kite loader
 * upon loading the module into memory. Not intended for use by user code.
 * @param name The name of the module.
 * @sa KITE_MODULE_INITIALIZER
 */
#define KITE_MODULE_INITIALIZER_NAME(name) \
     name ## _load_module
     
/**
 * Define initializer for a given Kite module. The name should be the name
 * given to the library file during compilation. For example, org.kite.testmodule,
 * located in org/kite/testmodule.so, would result in "testmodule" for name.
 * @param name The name of the module.
 */
#define KITE_MODULE_INITIALIZER(name) \
     void KITE_MODULE_INITIALIZER_NAME(name) (kite_thread_t *, kite_object_t *); \
     void* name ## _load_module__wrap(kite_thread_t *thd) { \
         kite_loader_register(thd, #name, KITE_MODULE_INITIALIZER_NAME(name)); \
         return NULL; \
     } \
     void KITE_MODULE_INITIALIZER_NAME(name) (kite_thread_t *thread, kite_object_t *parent)

/**
 * Define a Kite class method's name and prototype.
 * @param name The C function name to give this method.
 */
#define KITE_CLASS_METHOD(name) \
     void name(kite_thread_t *thd, kite_object_t *this, \
               kite_object_t *args)
               
/**
 * Helper macro to eliminate warnings about "args" not being used.
 */
#define KITE_NO_ARGS (void)args;

/**
 * Helper macro to eliminate warnings about "this" not being used.
 */
#define KITE_THIS_NOT_USED (void)this;

/**
 * Retrieve method argument passed in from code.
 * @param[out] ret The kite_object_t* to place the result in, or NULL if
 *                 argument does not exist.
 * @param n The argument number to retrieve.
 */
#define KITE_GET_METHOD_ARGUMENT(ret, n) KITE_GET_LIST_ELEMENT(ret, args, n)

/**
 * Retrieve an item from a list, given its index.
 * @param[out] ret The kite_object_t* to place the result in, or NULL if
 *                 argument does not exist.
 * @param obj The list to operate on.
 * @param n The list index to retrieve.
 */
#define KITE_GET_LIST_ELEMENT(ret, obj, n) \
    { \
        int cur = n - 1; \
        ret = obj; \
        while(ret && cur > 0) { \
            cur--; \
            ret = ret->builtin_data.listvalue.cdr; \
        } \
        if (ret) ret = ret->builtin_data.listvalue.car; \
    }

/**
 * Replace (or insert) an item in a list, given its index.
 * @param list The list to operate on.
 * @param n The list index to replace/insert to.
 * @param obj The object to replace/insert with.
 */
#define KITE_REPLACE_LIST_ELEMENT(list, n, obj) \
    { \
        int cur = n - 1; \
        kite_object_t *ret = obj; \
        while(ret && cur > 0) { \
            cur--; \
            if (KITE_LIST_CDR(ret) == NULL) { \
                kite_append_list(obj->owner_thread, list, kite_new_null(obj->owner_thread)); \
            } \
            ret = ret->builtin_data.listvalue.cdr; \
        } \
        if (ret) { \
            kite_dereference_object(KITE_LIST_CAR(ret)); \
            KITE_LIST_CAR(ret) = kite_reference_object(obj); \
        } else { \
            kite_append_list(obj->owner_thread, list, obj); \
        } \
    }

/**
 * Remove an item from a list, given its index.
 * @param list The list to operate on.
 * @param n The list index to replace/insert to.
 */
#define KITE_REMOVE_LIST_ELEMENT(list, n) \
    { \
        int cur = n - 1; \
        kite_object_t *ret = obj; \
        while(ret && cur > 0) { \
            cur--; \
            ret = ret->builtin_data.listvalue.cdr; \
        } \
        if (ret) { \
            kite_dereference_object(KITE_LIST_CAR(ret)); \
            if (KITE_LIST_CDR(ret)) { \
                kite_object_t *tmp = KITE_LIST_CDR(ret); \
                KITE_LIST_CAR(ret) = KITE_LIST_CAR(KITE_LIST_CDR(ret)); \
                KITE_LIST_CDR(ret) = KITE_LIST_CDR(KITE_LIST_CDR(ret)); \
                kite_dereference_object(tmp); \
            } else { \
                KITE_LIST_CAR(ret) = NULL; \
            } \
        } \
    }

/**
 * Checks to determine whether an object is of a given type.
 * @param val The Kite object to check.
 * @param t The type to check for.
 * @return TRUE if the type of the given object is equal to t, FALSE otherwise.
 */
#define KITE_IS_TYPE(val, t) ((val)->type == t)

/**
 * Gets the type of the given Kite object.
 * @param val The Kite object to operate on.
 * @return The enum corresponding to the given object's type.
 */
#define KITE_GET_OBJECT_TYPE(val) ((val)->type)

/**
 * Retrieves the parent (inherited from) object. This is usually the class
 * the current instance was created from, or the inherited class if operating
 * on a class object.
 * @param val The Kite object to operate on.
 * @return The parent object.
 */
#define KITE_GET_PARENT_OBJECT(val) ((val)->object_data.inherit_from)

/**
 * Retrieves integer value for a Kite object.
 * @param v The Kite object to retrieve integer from.
 * @warning This is only useful for objects of types OBJ_INTEGER
 *          and OBJ_BOOLEAN. No error checking is performed.
 */
#define KITE_GET_INTEGER(v) (((kite_basic_object_t*)v)->builtin_data.intvalue)

/**
 * Retrieves floating-point value for a Kite object.
 * @param v The Kite object to retrieve number from.
 * @warning This is only useful for objects of type OBJ_FLOAT
 *          No error checking is performed.
 */
#define KITE_GET_FLOAT(v) (((kite_basic_object_t*)v)->builtin_data.floatvalue)

/**
 * Retrieves string value for a Kite object.
 * @param v The Kite object to retrieve string from.
 * @warning This is only useful for objects of type OBJ_STRING and OBJ_IDENT.
 *          No error checking is performed.
 */
#define KITE_GET_STRING_VALUE(v) ((v)->builtin_data.stringvalue.string)

/**
 * Retrieves string length for a Kite object.
 * @param v The Kite object to retrieve string from.
 * @warning This is only useful for objects of type OBJ_STRING and OBJ_IDENT.
 *          No error checking is performed.
 */
#define KITE_GET_STRING_LENGTH(v) ((v)->builtin_data.stringvalue.length)

/**
 * Sets integer value for a Kite object.
 * @param v The Kite object to operate on.
 * @param i The value to assign to the object.
 * @warning This is only useful for objects of type OBJ_INTEGER and OBJ_BOOLEAN.
 *          No error checking is performed.
 */
#define KITE_SET_INTEGER(v, i) KITE_GET_INTEGER(v) = i

/**
 * Sets floating-point value for a Kite object.
 * @param v The Kite object to operate on.
 * @param i The value to assign to the object.
 * @warning This is only useful for objects of type OBJ_FLOAT.
 *          No error checking is performed.
 */
#define KITE_SET_FLOAT(v, i) KITE_GET_FLOAT(v) = i

/**
 * Retrieve the head of a list.
 * @param v The list to operate on.
 * @warning This is only useful for objects of type OBJ_LIST.
 *          No error checking is performed.
 */
#define KITE_LIST_CAR(v) ((v)->builtin_data.listvalue.car)

/**
 * Retrieve the tail of a list.
 * @param v The list to operate on.
 * @warning This is only useful for objects of type OBJ_LIST.
 *          No error checking is performed.
 */
#define KITE_LIST_CDR(v) ((v)->builtin_data.listvalue.cdr)

#endif /* KITE_OBJ__KITEOBJECT_H */
