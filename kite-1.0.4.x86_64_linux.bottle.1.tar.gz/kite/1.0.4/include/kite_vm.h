#ifndef KITE_VM__KITEVM_H
#define KITE_VM__KITEVM_H
/*****************************************************************************
 * Copyright (c) 2007, Mooneer Salem
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Kite Language organization nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

#ifdef WIN32
#undef __MINGW32__
#else
#include <pthread.h>
#ifdef __linux__
#define PTHREAD_MUTEX_RECURSIVE PTHREAD_MUTEX_RECURSIVE_NP
#endif /* __linux__ */
#endif /* WIN32 */

#include <signal.h>
#include <assert.h>

struct kite_object_t;
struct kite_symtab_t;

/*
 * Valid operators
 */
enum kite_operators
{
    OP_ADD = 0,
    OP_SUBTRACT,
    OP_MULTIPLY,
    OP_DIVIDE,
    OP_MODULUS,
    OP_UNARY_PLUS,
    OP_UNARY_MINUS,
    OP_ASSIGNMENT,
    OP_EQUALS,
    OP_NOT_EQUALS,
    OP_LESS_THAN,
    OP_GREATER_THAN,
    OP_LESS_OR_EQUALS,
    OP_GREATER_OR_EQUALS,
    OP_AND,
    OP_OR,
    OP_NOT,
    OP_XOR,
    OP_LEFT_SHIFT,
    OP_RIGHT_SHIFT,
    OP_MAP,
    OP_REDUCE,
    OP_ARRAY_DEREF,
    OP_ARRAY_SET,
    OP_METHOD_CALL,
    OP_PROPERTY,
    NUM_OPERATORS
};

/**
 * Valid Kite compiler operations.
 */
enum kite_compiler_operations
{
    COMPILE_BREAK,
    COMPILE_CONTINUE,
    COMPILE_RETURN,
    COMPILE_CREATE_FUNC,
    COMPILE_CREATE_FUNC_BODY,
    COMPILE_CREATE_ANON_FUNC,
    COMPILE_CREATE_ANON_FUNC_BODY,
    COMPILE_CREATE_CLASS,
    COMPILE_CREATE_CLASS_BODY,
    COMPILE_FROM_DEFAULT,
    COMPILE_FROM_GIVEN_CLASS,
    COMPILE_IMMEDIATE_DEREF_1,
    COMPILE_IMMEDIATE_DEREF_2,
    COMPILE_CONSTRUCTOR,
    COMPILE_CONSTRUCTOR_BODY,
    COMPILE_DESTRUCTOR,
    COMPILE_DESTRUCTOR_BODY,
    COMPILE_PROPERTY_CREATE_WITH_DEFAULT_VAL,
    COMPILE_PROPERTY_CREATE_WITH_SPECIFIED_VAL,
    COMPILE_PROPERTY_CREATE_WITH_SPECIFIED_VAL_RHS,
    COMPILE_OPERATOR,
    COMPILE_OPERATOR_BODY,
    COMPILE_ASSIGNMENT_LHS,
    COMPILE_ASSIGNMENT_RHS,
    COMPILE_OR_LHS,
    COMPILE_OR_RHS,
    COMPILE_XOR,
    COMPILE_AND_LHS,
    COMPILE_AND_RHS,
    COMPILE_LEFT_SHIFT,
    COMPILE_RIGHT_SHIFT,
    COMPILE_EQUALS,
    COMPILE_NOT_EQUALS,
    COMPILE_IS,
    COMPILE_ISOF,
    COMPILE_LESS_THAN,
    COMPILE_GREATER_THAN,
    COMPILE_LESS_EQUALS,
    COMPILE_GREATER_EQUALS,
    COMPILE_ADD,
    COMPILE_SUBTRACT,
    COMPILE_MULTIPLY,
    COMPILE_DIVIDE,
    COMPILE_MODULUS,
    COMPILE_UNARY_PLUS,
    COMPILE_UNARY_MINUS,
    COMPILE_NOT,
    COMPILE_MAP,
    COMPILE_REDUCE,
    COMPILE_FUNC_CALL_BEGIN,
    COMPILE_FUNC_CALL_ARGS,
    COMPILE_DEREF_AND_CALL_BEGIN,
    COMPILE_DEREF_AND_CALL_ARGS,
    COMPILE_ARRAY_DEREF,
    COMPILE_DEREF_2,
    COMPILE_DEREF_1,
    COMPILE_EMPTY_PARAM_LIST,
    COMPILE_SINGLE_FUNC_PARAM,
    COMPILE_COMBINE_FUNC_PARAMS,
    COMPILE_CONSTANT_STRING,
    COMPILE_CONSTANT_INTEGER,
    COMPILE_CONSTANT_FLOAT,
    COMPILE_CONSTANT_BOOL,
    COMPILE_CONSTANT_NULL,
    COMPILE_CONSTANT_RANGE,
    COMPILE_CONSTANT_REGEX,
    COMPILE_MAKE,
    COMPILE_ZERO_ELEMENT_LIST,
    COMPILE_ONE_ELEMENT_LIST,
    COMPILE_TWO_ELEMENT_LIST,
    COMPILE_DECIDE_BEGIN,
    COMPILE_DECIDE_END,
    COMPILE_DECIDE_CONDITION_BEGIN,
    COMPILE_DECIDE_CONDITION_END,
    COMPILE_EVAL_BEGIN,
    COMPILE_EVAL_END,
    COMPILE_LOOP_WRAPPER,
    COMPILE_WHILE_BEGIN,
    COMPILE_WHILE_END,
    COMPILE_UNTIL_BEGIN,
    COMPILE_UNTIL_END,
    COMPILE_RUN_BEGIN,
    COMPILE_RUN_END,
    COMPILE_CATCH_BEGIN,
    COMPILE_CATCH_END,
    NUM_COMPILE_FUNCS
};

struct kite_compiler_t;
typedef void *(*kite_compiler_action_t)(struct kite_compiler_t *, int, ...);
#ifndef KITE_COMPILE_DEFINE
extern kite_compiler_action_t kite_compiler_actions[];
#endif /* KITE_COMPILE_DEFINE */

/*
 * Valid operator strings
 */
#ifndef KITE_EXECUTE_C
extern char *OPERATOR_STRINGS[];
extern char *OPERATOR_METHODS[];
#endif /* KITE_EXECUTE_C */
#define OP_TO_STRING(x) (OPERATOR_STRINGS[(x)])
#define OP_TO_METHOD(x) (OPERATOR_METHODS[(x)])

/*
 * Stack representation
 */
struct kite_stack_entry_t;
typedef struct kite_stack_t /*! Stack object. */
{
    size_t allocated /*! Number of bytes allocated. */;
    size_t used /*! Number of bytes used. */;
    int length /*! Number of entries on the stack. */;
    struct kite_stack_entry_t *stack /*! List of entries on the stack. */;
} kite_stack_t;

typedef struct kite_stack_entry_t /*! Stack entry object. */
{
    int reference /*! 1 if reference (kite_symtab_t, etc) */;
	void *obj /*! Object pointed to on stack. */;
} kite_stack_entry_t;
    
/*
 * Entry on function call stack.
 */
typedef struct kite_funccall_info_t /*! Function call information. */
{
    char *file /*! File containing function call. */;
    int line /*! Line containing function call. */;
    int sys_or_user /*! System or user code */;
    struct kite_symtab_t *locals /*! List of local objects. */;
    struct kite_object_t *this /*! The current object. */;
    char *last_deref /*! The name of the last object dereferenced. */;
    struct kite_symtab_t *last_deref_obj /*! The object that's been dereferenced. */;
    struct kite_object_t *last_deref_ident;
} kite_funccall_info_t;
    
/*
 * Kite thread object. This object represents a single thread in the Kite
 * threading system (and its current state)
 */
typedef struct kite_thread_t
{
    struct kite_thread_t **entry /*! \private */;
    struct kite_vm_t *vm /*! Virtual machine associated with this thread. */;
    kite_stack_t *running_stack /*! \private */;
    kite_stack_t *func_stack /*! \private */;
    struct kite_symtab_t *cached_idents;
    struct kite_object_t *exception /*! Exception that's currently been thrown, if any. */;
    void *start /*! \private */;
#ifdef WIN32
    HANDLE thread /*! \private */;
#else
    pthread_t thread /*! \private */;
#endif /* WIN32 */
} kite_thread_t /*! Thread object representing a Kite thread. */;

/*
 * Kite list object. 
 */
typedef struct kite_list_t /*! Linked list object. */
{
    void *obj /*! Object at current position. */;
    struct kite_list_t *prev /*! Previous object in list. */;
    struct kite_list_t *next /*! Next object in list. */;
} kite_list_t;

/*
 * Kite VM object. This object is how other developers will access
 * Kite internals.
 */
typedef struct kite_vm_t
{
	struct kite_object_t *root_package /*! \private */;
	struct kite_object_t *true_cached /*! \private */;
	struct kite_object_t *false_cached /*! \private */;
	struct kite_object_t *null_cached /*! \private */;
	struct kite_object_t *int_cached /*! \private */;
    struct kite_symtab_t *loader_refs /*! \private */;
    struct kite_object_t *instruction_tracer;
    int numthreads /*! Number of threads created. */;
    kite_thread_t **thread_list /*! \private */;
#ifndef HAVE_GC_H
    kite_list_t *gc_begin /*! \private */, *gc_end /*! \private */; /* garbage collector queue */
#endif /* HAVE_GC_H */
#ifdef WIN32
    HANDLE gc_mtx /*! \private */;
    HANDLE compile_mtx /*! \private */;
#else
    pthread_mutex_t gc_mtx /*! \private */;
    pthread_mutex_t compile_mtx /*! \private */;
#endif /* WIN32 */
#ifdef HAVE_GC_H
    GC_warn_proc old_proc /*! \private */;
#endif /* HAVE_GC_H */
    char **args /*! \private */;
    struct kite_opcode_t *text_segment /*! \private */;
    size_t cur_text_segment /*! \private */;
    size_t text_segment_length /*! \private */;
} kite_vm_t /*! Virtual machine instance object. */;

/*
 * Kite compiler state object
 */
typedef struct kite_compiler_t /*! Compiler state object. */
{
    kite_thread_t *thd /*! Current thread. */;
    char *file /*! Current file. */;
    int verMajor /*! Minimum major version. */;
    int verMinor /*! Minimum minor version. */;
    int verPatch /*! Minimum patch version. */;
    int currentLine /*! Current line number. */;
    int currentCol /*! Current column number. */;
    kite_stack_t *obj_created /*! Currently created object. */;
    kite_stack_t *decide_exits /*! \private */; /* to fix ticket #17 and short-circuiting */
    kite_stack_t *decide_exit_locs /*! \private */;
    kite_stack_t *decide_begins /*! \private */;
    kite_stack_t *func_skip_locs /*! \private */;
    char *curStr /*! Current string being read. */;
} kite_compiler_t;

/*
 * VM handling functions
 */

/**
 * Initialize Kite.
 * @warning This is mandatory before using kite_new_vm() in order to initialize the garbage collector!
 */
KITE_EXPORT void kite_app_init();
 
/**
 * Create a new VM instance.
 * @param args The command line arguments passed into the program.
 * @return A new VM instance.
 */
KITE_EXPORT kite_vm_t *kite_new_vm(char **args);

/**
 * Destroy VM instance.
 * @param[in,out] vm The virtual machine to destroy.
 */
KITE_EXPORT void kite_free_vm(kite_vm_t **vm);

/*
 * Thread handling functions
 */
 
/**
 * Create a new thread without starting it.
 * @param vm The virtual machine to create the thread on.
 * @return A new thread object.
 */
KITE_EXPORT kite_thread_t *kite_new_thread_without_start(kite_vm_t *vm);

/**
 * Create a new bytecode thread (and start it).
 * @param vm Virtual machine to create thread on.
 * @param ptr Pointer to bytecode to start.
 * @return A new thread object.
 */
KITE_EXPORT kite_thread_t *kite_new_thread_bytecode(kite_vm_t *vm, void *ptr);

/**
 * Create a new compiled thread (and start it).
 * @param vm Virtual machine to create thread on.
 * @param ptr Pointer to function to start.
 * @return A new thread object.
 */
KITE_EXPORT kite_thread_t *kite_new_thread_compiled(kite_vm_t *vm, void *ptr);

/**
 * Return first thread in application.
 * @param vm The VM object to operate on.
 */
#define kite_vm_creator_thread(vm) ((vm)->thread_list[0])

/**
 * Start preexisting thread with bytecode.
 * @param thd The thread to start.
 * @param ptr Pointer to bytecode to run.
 */
KITE_EXPORT void kite_start_bytecode(kite_thread_t *thd, void *ptr);

/**
 * Start preexisting thread with compiled C function.
 * @param thd The thread to start.
 * @param ptr Pointer to C function to run.
 */
KITE_EXPORT void kite_start_compiled(kite_thread_t *thd, void *ptr);

/**
 * Wait for thread to terminate.
 * @param vm The VM to operate on.
 * @param thd The thread to wait for.
 */
KITE_EXPORT void kite_join_thread(kite_vm_t *vm, kite_thread_t *thd);

/**
 * Force thread to terminate.
 * @param vm The VM to operate on.
 * @param thd The thread to wait for.
 */
KITE_EXPORT void kite_exit_thread(kite_vm_t *vm, kite_thread_t *thd);

/*
 * Stack handling functions
 */

/**
 * Push item onto the stack.
 * @param[in,out] stack The stack to push onto.
 * @param ref If 1, the object is not a kite_object_t.
 * @param obj The object to push.
 */
KITE_EXPORT void kite_push_stack(kite_stack_t **stack, int ref, void *obj);

/**
 * Destroy stack.
 * @param[in,out] stack The stack to destroy.
 */
KITE_EXPORT void kite_destroy_stack(kite_stack_t **stack);

/**
 * Pop item off of the stack.
 * @param[in,out] stack The stack to operate on.
 * @return The item at the top of the stack.
 */
KITE_EXPORT void *kite_pop_stack(kite_stack_t **stack);

#ifndef WIN32
/*#define INLINE_STACK*/
#endif
#ifndef INLINE_STACK

/**
 * Return the item at the top of the stack without popping it.
 * @param stack The stack to operate on.
 * @return The item at the top of the stack.
 */
KITE_EXPORT void *kite_top_stack(kite_stack_t *stack);

#else
#define kite_top_stack(st) \
    ((!st || st->length == 0) ? \
        NULL : \
        (((&st->stack[st->length - 1])->reference) ? \
            ((kite_symtab_t*)(&st->stack[st->length - 1])->obj)->value : \
            (&st->stack[st->length - 1])->obj))
#endif /* INLINE_STACK */

/*
 * List handling functions
 */

/**
 * Remove item from a linked list.
 * @param[in,out] begin The beginning of the list.
 * @param[in,out] end The end of the list.
 * @param item The item to remove.
 */
KITE_EXPORT void kite_list_remove(kite_list_t **begin, kite_list_t **end, kite_list_t *item);

/**
 * Add item to the end of a linked list.
 * @param[in,out] begin The beginning of the list.
 * @param[in,out] end The end of the list.
 * @param item The item to add.
 */
KITE_EXPORT void kite_list_add_end(kite_list_t **begin, kite_list_t **end, kite_list_t *item);

/**
 * Add item to the beginning of a linked list.
 * @param[in,out] begin The beginning of the list.
 * @param[in,out] end The end of the list.
 * @param item The item to add.
 */
KITE_EXPORT void kite_list_add_begin(kite_list_t **begin, kite_list_t **end, kite_list_t *item);

/* 
 * Script operation functions
 */
#ifndef WIN32

/**
 * @private
 */
void *kite_vm_execute(void *);

#else

/**
 * @private
 */
KITE_EXPORT DWORD WINAPI kite_vm_execute(LPVOID);

#endif /* WIN32 */

/**
 * @private
 */
KITE_EXPORT void kite_vm_execute_user_method(kite_thread_t *, void *);

/**
 * @private
 */
KITE_EXPORT void kite_vm_execute_exception(kite_thread_t *, int);

/**
 * Call method on given object.
 * @param thd The current thread.
 * @param this The object to operate on.
 * @param name The name of the method to call.
 * @param args A list containing the method arguments to pass in.
 * @param err If 1, throw an exception if the method does not exist.
 * @note Method will push its return value to the top of the running stack.
 */
KITE_EXPORT void kite_vm_call_method(kite_thread_t *thd, struct kite_object_t *this, 
                         char *name, struct kite_object_t *args, int err);

/**
 * Call passed in method on given object.
 * @param thd The current thread.
 * @param this The object to operate on.
 * @param method The method to run.
 * @param args A list containing the method arguments to pass in.
 * @note Method will push its return value to the top of the running stack.
 */
KITE_EXPORT void kite_vm_call_object(kite_thread_t *thd, struct kite_object_t *this, 
                         struct kite_object_t *method, struct kite_object_t *args);

/**
 * Call constructor on given object.
 * @param thd The current thread.
 * @param this The object to operate on.
 * @param args A list containing the method arguments to pass in.
 */
KITE_EXPORT void kite_vm_call_constructor(kite_thread_t *thd, struct kite_object_t *this, 
                              struct kite_object_t *args);

/**
 * Call operator on given object.
 * @param thd The current thread.
 * @param this The object to operate on.
 * @param op The operator to call (see enum kite_operators).
 * @param args A list containing the method arguments to pass in.
 * @param err If 1, throw an exception if the operator does not exist.
 * @note Method will push its return value to the top of the running stack.
 */
KITE_EXPORT int kite_vm_call_operator(kite_thread_t *thd, struct kite_object_t *this, 
                          int op, struct kite_object_t *args, int err);

/**
 * Push item onto running stack.
 * @param thd The current thread.
 * @param obj The object to push.
 */
#define kite_vm_push(thd, obj) \
    kite_push_stack(&(thd)->running_stack, FALSE, kite_reference_object(obj))
    
/**
 * Pop item from running stack.
 * @param thd The current thread.
 * @return The item popped from the running stack.
 */
#define kite_vm_pop(thd) (struct kite_object_t*)kite_pop_stack(&(thd)->running_stack)

/**
 * Push item onto running stack and return from method.
 * @param thd The current thread.
 * @param obj The object to push.
 */
#define kite_vm_return(thd, obj) \
	{ \
        kite_object_t *tmp = (obj); \
		kite_vm_push((thd), tmp); \
        kite_dereference_object(tmp); \
		return; \
	}

/*! \private */
#define STACK_MAX 1024

#ifndef HAVE_GC_H 
/**
 * @private
 */
#define PUSH_FUNC_STACK(t) \
     fc_entry = malloc(sizeof(kite_funccall_info_t)); \
     oldentry = ((kite_funccall_info_t*)kite_top_stack(thd->func_stack)); \
     old_sys = oldentry ? oldentry->sys_or_user : 0; \
     fc_entry->this = t; \
     fc_entry->locals = NULL; \
     fc_entry->file = ins->file; \
     fc_entry->line = ins->line; \
     fc_entry->last_deref = NULL; \
     fc_entry->last_deref_obj = NULL; \
     fc_entry->sys_or_user = 0; \
     kite_push_stack(&thd->func_stack, FALSE, fc_entry); \
     if (thd->func_stack->length >= STACK_MAX && !old_sys) { \
         kite_object_t *exc; \
         fc_entry->sys_or_user = 1; \
         exc = kite_new_exception(thd, "System.exceptions.StackOverflow", \
                                  "The function call stack has overflowed."); \
         kite_vm_call_method(thd, exc, "throw", kite_new_list(thd), TRUE); \
         fc_entry->sys_or_user = 0; \
         return; \
     }

/**
 * @private
 */
#define PUSH_FUNC_STACK_WITH_RET_VALUE(t, nxt) \
     fc_entry = malloc(sizeof(kite_funccall_info_t)); \
     oldentry = ((kite_funccall_info_t*)kite_top_stack(thd->func_stack)); \
     old_sys = oldentry ? oldentry->sys_or_user : 0; \
     fc_entry->this = t; \
     fc_entry->locals = NULL; \
     fc_entry->file = ins->file; \
     fc_entry->line = ins->line; \
     fc_entry->last_deref = NULL; \
     fc_entry->last_deref_obj = NULL; \
     fc_entry->sys_or_user = 0; \
     kite_push_stack(&thd->func_stack, FALSE, fc_entry); \
     if (thd->func_stack->length >= STACK_MAX && !old_sys) { \
         kite_object_t *exc; \
         fc_entry->sys_or_user = 1; \
         exc = kite_new_exception(thd, "System.exceptions.StackOverflow", \
                                  "The function call stack has overflowed."); \
         kite_vm_call_method(thd, exc, "throw", kite_new_list(thd), TRUE); \
         fc_entry->sys_or_user = 0; \
         return nxt; \
     }

/**
 * @private
 */
#define POP_FUNC_STACK \
    kite_pop_stack(&thd->func_stack); \
    if (fc_entry->locals) kite_destruct_symtab(thd, &fc_entry->locals, TRUE); \
    free(fc_entry);

#else

/**
 * @private
 */
#define PUSH_FUNC_STACK(t) \
     fc_entry = (kite_funccall_info_t*)GC_malloc(sizeof(kite_funccall_info_t)); \
     oldentry = ((kite_funccall_info_t*)kite_top_stack(thd->func_stack)); \
     old_sys = oldentry ? oldentry->sys_or_user : 0; \
     fc_entry->this = t; \
     fc_entry->locals = NULL; \
     fc_entry->file = ins->file; \
     fc_entry->line = ins->line; \
     fc_entry->last_deref = NULL; \
     fc_entry->last_deref_obj = NULL; \
     fc_entry->sys_or_user = 0; \
     kite_push_stack(&thd->func_stack, FALSE, fc_entry); \
     if (thd->func_stack->length >= STACK_MAX && !old_sys) { \
         kite_object_t *exc; \
         fc_entry->sys_or_user = 1; \
         exc = kite_new_exception(thd, "System.exceptions.StackOverflow", \
                                  "The function call stack has overflowed."); \
         kite_vm_call_method(thd, exc, "throw", kite_new_list(thd), TRUE); \
         fc_entry->sys_or_user = 0; \
         return; \
     }

/**
 * @private
 */
#define PUSH_FUNC_STACK_WITH_RET_VALUE(t, nxt) \
     fc_entry = (kite_funccall_info_t*)GC_malloc(sizeof(kite_funccall_info_t)); \
     oldentry = ((kite_funccall_info_t*)kite_top_stack(thd->func_stack)); \
     old_sys = oldentry ? oldentry->sys_or_user : 0; \
     fc_entry->this = t; \
     fc_entry->locals = NULL; \
     fc_entry->file = ins->file; \
     fc_entry->line = ins->line; \
     fc_entry->last_deref = NULL; \
     fc_entry->last_deref_obj = NULL; \
     fc_entry->sys_or_user = 0; \
     kite_push_stack(&thd->func_stack, FALSE, fc_entry); \
     if (thd->func_stack->length >= STACK_MAX && !old_sys) { \
         kite_object_t *exc; \
         fc_entry->sys_or_user = 1; \
         exc = kite_new_exception(thd, "System.exceptions.StackOverflow", \
                                  "The function call stack has overflowed."); \
         kite_vm_call_method(thd, exc, "throw", kite_new_list(thd), TRUE); \
         fc_entry->sys_or_user = 0; \
         return nxt; \
     }

/**
 * @private
 */
#define POP_FUNC_STACK \
    kite_pop_stack(&thd->func_stack); \
    if (fc_entry->locals) kite_destruct_symtab(thd, &fc_entry->locals, TRUE);

#endif /* HAVE_GC_H */

/*
 * Compiler functions
 */
 
/**
 * Compile Kite code from a file.
 * @param thd The current thread.
 * @param file The path to the file to compile.
 * @return The object that has been compiled.
 * @note thd->exception will be non-NULL if there was a problem during compile.
 */
KITE_EXPORT struct kite_object_t *kite_vm_compile_from_file(kite_thread_t *thd, char *file);

/**
 * Compile Kite code from an already open file.
 * @param thd The current thread.
 * @param fp The file to compile.
 * @param file The file name to associate with the object.
 * @param created_obj The pre-created object to use.
 * @return The object that has been compiled.
 * @note thd->exception will be non-NULL if there was a problem during compile.
 */
KITE_EXPORT struct kite_object_t *kite_vm_compile_from_fp
    (kite_thread_t *thd, FILE *fp, char *file, struct kite_object_t *created_obj);

/**
 * Compile Kite code from a string.
 * @param thd The current thread.
 * @param code The code to compile.
 * @param ln The starting line number.
 * @return The object that has been compiled.
 * @note thd->exception will be non-NULL if there was a problem during compile.
 */
KITE_EXPORT struct kite_object_t *kite_vm_compile_from_string(kite_thread_t *thd, char *code, int ln);

/**
 * Compile Kite code from a string using pre-made object.
 * @param thd The current thread.
 * @param code The code to compile.
 * @param ln The starting line number.
 * @param obj The object that has been pre-made.
 * @return The object that has been compiled.
 * @note thd->exception will be non-NULL if there was a problem during compile.
 */
KITE_EXPORT struct kite_object_t *kite_vm_compile_from_string_without_obj(kite_thread_t *thd, char *code, int ln, struct kite_object_t *obj);

/**
 * Compile Kite code from a file using pre-created object.
 * @param thd The current thread.
 * @param file The file to compile.
 * @param created_obj The pre-created object to use.
 * @return The object that has been compiled.
 * @note thd->exception will be non-NULL if there was a problem during compile.
 */
KITE_EXPORT struct kite_object_t *kite_vm_compile_from_file_without_create(
    kite_thread_t *thd, char *file, struct kite_object_t *created_obj);

/*
 * Signal handling.
 */
#ifndef WIN32
#undef NSIG

/**
 * Number of possible signals.
 */
#define NSIG 65

#endif /* WIN32 */

/**
 * @private
 */
KITE_EXPORT extern struct kite_object_t *kite_signal_handlers[NSIG + 1];

/**
 * @private
 */
void kite_handle_signal(int);

/*
 * To facilitate module loading
 */
#ifndef KITE_MODULE_INITIALIZER_C
/**
 * @private
 */
extern void kite_module_initialize_now(kite_thread_t*);
#endif /* KITE_MODULE_INITIALIZER_C */

#ifdef INLINE_STACK
inline void *kite_pop_stack(kite_stack_t **st)
{
    kite_stack_t *entry;
    void *ret;

    assert(st != NULL && (*st)->length > 0);
    entry = *st;

    ret = kite_top_stack(entry);
    entry->length--;

    return ret;
}

inline void kite_push_stack(kite_stack_t **st, int ref, void *obj)
{
    assert(st != NULL && obj != NULL);

    kite_stack_t *cur = *st;
    if (cur == NULL)
    {
#ifndef HAVE_GC_H
        cur = malloc(sizeof(kite_stack_t));
#else
        cur = GC_malloc(sizeof(kite_stack_t));
#endif /* HAVE_GC_H */
        assert(cur != NULL);
        cur->length = 0;
        cur->allocated = sizeof(kite_stack_entry_t);
#ifndef HAVE_GC_H
        cur->stack = malloc(cur->allocated);
#else
        cur->stack = GC_malloc(cur->allocated);
#endif /* HAVE_GC_H */
        *st = cur;
    }

    if (((cur->length + 1) * sizeof(kite_stack_entry_t)) > cur->allocated)
    {
        int newsize = cur->allocated << 1;
#ifndef HAVE_GC_H
        cur->stack = realloc(cur->stack, newsize);
#else
        cur->stack = GC_realloc(cur->stack, newsize);
#endif /* HAVE_GC_H */
        assert(cur->stack != NULL);
        cur->allocated = newsize;
    }

    kite_stack_entry_t *entry = &cur->stack[++cur->length - 1];
    entry->obj = obj;
    entry->reference = ref;
}
#endif

#endif /* KITE_VM__KITEVM_H */
