##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

import "__internal._regex";
import "__internal._regex_match";

/[Regular expression matching on text.]/

property internal_regex_obj;
property case_insensitive
    /[Is match case-insensitive?]/;

construct(
    regex /[Regular expression to use.]/
) /[Construct new regular expression object.]/
[
    this.internal_regex_obj = make __internal._regex(regex);
];

construct(
    regex /[Regular expression to use.]/,
    c_insensitive /[Case insensitivity on/off]/
) /[Construct new regular expression object.]/
[
    this.internal_regex_obj = make __internal._regex(regex);
    this.case_insensitive = c_insensitive;
];

method match(
    str /[String to search.]/
) /[Match regular expression on text.]/
[
    this|match(str, 0);
];

method match(
    str /[String to search.]/,
    start /[Starting location to search.]/
) /[Match regular expression on text.]/
[
    property ret;
    
    this.internal_regex_obj|set_insensitive(this.case_insensitive);
    ret = this.internal_regex_obj|match(str, start);
    decide 
    [
        (ret is System.null) [ ret; ],
        true [ (make System.regex.match_result(ret)); ]
    ];
];

method replace(
    str /[String to manipulate.]/,
    replace_with /[String to replace with.]/
) /[Replaces string matched by regular expression with another.]/
[
    this|replace(str, replace_with, 65535);
];

method replace(
    str /[String to manipulate.]/,
    replace_with /[String to replace with.]/,
    max /[Maximum times to replace.]/
) /[Replaces string matched by regular expression with another.]/
[
    property start;
    property thematch;
    property ret;
    property i;
    property j;
    property prop;
    property last_empty;
    
    start = 0;
    j = 0;
    ret = "";
    last_empty = false;
    
    thematch = this|match(str, start);
    while(not (thematch is System.null) and j < max)
    [
        ret = ret + str|substring(start, thematch.match_begin - start);
        decide
        [
            (replace_with is System.method) [ 
                ret = ret + replace_with(thematch.captures);
            ],
            true [
                prop = "" + replace_with;
                i = thematch.captures|count - 1;
                while(i >= 0)
                [
                    prop = (make System.regex("\\\\" + i|str))|replace(prop, thematch.captures[i]);
                    i = i - 1;
                ];
                ret = ret + prop;
            ]
        ];
        
        j = j + 1;
        decide
        [
            (thematch.match_length > 0) [ 
                start = thematch.match_begin + thematch.match_length;
                last_empty = false; 
            ],
            true [
                decide
                [
                    (thematch.match_begin == 0 and thematch.match_length == 0)
                    [
                        ret = ret + str|substring(0, 1);
                    ]
                ];
                start = thematch.match_begin + 1;
                last_empty = true;
            ]
        ];
        thematch = this|match(str, start);
    ];

    ret = ret + str|substring(start);
    ret;
];

method split(
    str /[String to split.]/
) /[Splits a string based on regular expression.]/
[
    this|split(str, 65535);
];

method split(
    str /[String to split.]/,
    max /[Maximum results to return.]/
) /[Splits a string based on regular expression.]/
[
    property start;
    property thematch;
    property ret;
    property i;
    property j;
    
    start = 0;
    j = 0;
    ret = [];
    
    thematch = this|match(str, start);
    while(not (thematch is System.null) and j < max)
    [
        ret << str|substring(start, thematch.match_begin - start);
        decide
        [
            (thematch.captures|count > 1) [
                i = 1;
                while(i < thematch.captures|count)
                [
                    ret << thematch.captures[i];
                    i = i + 1;
                ];
            ]
        ];
        
        j = j + 1;
        start = thematch.match_begin + thematch.match_length;
        thematch = this|match(str, start);
    ];
    
    ret << str|substring(start);
    ret;
];

class match_result /[Regular expression result object.]/
[
    property match_begin /[Position of match.]/,
    property match_length /[Length of match.]/,
    property captures /[Captured subexpressions.]/,
    
    construct(
        arg /[internal regex match object]/) 
    /[Not directly callable.]/
    [
        property i;
        
        this.match_begin = arg|get_match_begin;
        this.match_length = arg|get_group(0)|length;
        
        i = 0;
        this.captures = [];
        while (i < arg|get_num_groups)
        [
            this.captures << arg|get_group(i);
            i = i + 1;
        ];
    ]
];
