##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Objects representing various abstract data structures.]/

class _TreeNode 
    /[Tree node object (not intended for public use)]/
[
    property left /[Nodes lower than current.]/,
    property right /[Nodes greater than current.]/,
    property key /[Node's key.]/,
    property item /[Node's value.]/,
    property parent /[Node's parent.]/,

    construct (
        k /[Node's key.]/, 
        v /[Node's value.]/,
        p /[Node's parent.]/
    ) /[Class constructor.]/ 
    [
        this.key = k;
        this.item = v;
        this.left = null;
        this.right = null;
        this.parent = p;
    ],

    method set(
        k /[Key to set.]/,
        v /[Value to set key to.]/
    ) /[Set key to specified value.]/ [
        decide [
            (k == this.key) [
                this.item = v;
            ],
            (k < this.key and this.left is System.null) [
                this.left = make System.collections._TreeNode(k, v, this);
            ],
            (k > this.key and this.right is System.null) [
                this.right = make System.collections._TreeNode(k, v, this);
            ],
            (k < this.key) [ this.left|set(k, v); ],
            (k > this.key) [ this.right|set(k, v); ]
        ];
    ],

    method find_leftmost() 
        /[Find leftmost node in tree.]/
    [
        property tmp;
        tmp = this;
        while (not (tmp.left is System.null)) [
            tmp = tmp.left;
        ];
        tmp;
    ],

    method find_rightmost() 
        /[Find rightmost node in tree.]/
    [
        property tmp;
        tmp = this;
        while (not (tmp.right is System.null)) [
            tmp = tmp.right;
        ];
        tmp;
    ],

    method remove(
        k /[Key to remove.]/
    ) /[Remove given key from tree.]/
    [
        property tmp;
        decide [
            (not (this.left is System.null) and this.left.key == k) [
                decide [ 
                    (not (this.left.right is System.null)) [ 
                        tmp = this.left.right|find_leftmost;
                        tmp.left = this.left.left;
                        tmp.right = this.left.right;
                        this.left = tmp;
                    ],
                    (true) [
                        this.left = this.left.left;
                    ]
                ];
            ],
            (not (this.right is System.null) and this.right.key == k) [
                decide [ 
                    (not (this.right.left is System.null)) [ 
                        tmp = this.right.left|find_rightmost;
                        tmp.left = this.right.left;
                        tmp.right = this.right.right;
                        this.right = tmp;
                    ],
                    (true) [
                        this.right = this.right.right;
                    ]
                ];
            ],
            (not (this.left is System.null) and k < this.key) [
                this.left|remove(k);
            ],
            (not (this.right is System.null) and k > this.key) [
                this.right|remove(k);
            ]
        ];
        true;
    ],

    method get(
        k /[Key to grab value of.]/
    ) /[Grab value of specified node.]/
    [
        decide [
            (k == this.key) [
                this.item;
            ],
            (k < this.key and this.left is System.null) [
                this.left = make System.collections._TreeNode(k, null, this);
                this.left.item;
            ],
            (k > this.key and this.right is System.null) [
                this.right = make System.collections._TreeNode(k, null, this);
                this.right.item;
            ],
            (k < this.key) [ this.left|get(k); ],
            (k > this.key) [ this.right|get(k); ]
        ];
    ],

    method count() 
        /[Return number of nodes in the tree.]/
    [
        property x;

        x = 1;
        decide [ (not (this.left is System.null)) [ x = x + this.left|count; ] ];
        decide [ (not (this.right is System.null)) [ x = x + this.right|count; ] ];
        x;
    ]
];

class binary_tree 
    /[Binary tree object.]/
[
    property root_node /[Root node of tree (do not touch!)]/,
    property iterator /[Current node in iterator.]/,

    method count() 
        /[Counts the number of nodes in the tree.]/
    [
        decide [
            (this.root_node is System.null) [ 0; ],
            (true) [ this.root_node|count; ]
        ];
    ],

    method set(
        key /[Key to set.]/,
        value /[Value to set key to.]/
    ) /[Set specified key to specified value.]/
    [
        decide [
            (this.root_node is System.null) [ 
                this.root_node = 
                    make System.collections._TreeNode(key, value, null); 
            ],
            true [
                this.root_node|set(key, value);
            ]
        ];
    ],

    method remove(
        key /[Key to remove.]/
    ) /[Removed specified node from tree.]/ 
    [
        decide [
            (this.root_node is System.null) [ true; ],
            (this.root_node.key == key) [ this.root_node = null; ],
            (true) [ this.root_node|remove(key); ]
        ];
        true;
    ],

    operator array(
        key /[Key to retrieve.]/
    ) /[Retrieve specified key from tree.]/
    [
        decide [
            (this.root_node is System.null) [ 
                this.root_node = make System.collections._TreeNode(key, null, null);
                this.root_node.item;
            ],
            (true) [ this.root_node|get(key); ]
        ];
    ],

    operator array_set(
        key /[Key to set.]/,
        value /[Value to set.]/
    ) /[Set key/value in tree.]/
    [
        decide [
            (this.root_node is System.null) [ 
                this.root_node = make System.collections._TreeNode(key, value, null);
            ],
            (true) [ this.root_node|set(key, value); ]
        ];
    ],
    
    method reset() 
        /[Reset iterator to beginning.]/
    [
        decide [
            (this.root_node is System.null) [ null; ],
            true [ 
                this.iterator = this.root_node|find_leftmost;
                this.iterator;
            ]
        ];
    ],

    method cur() 
        /[Return current item pointed to by iterator.]/
    [
        decide [
            (this.iterator is System.null) [ this|reset(); ]
        ];
        this.iterator;
    ],

    method next() 
        /[Move iterator to next item in tree.]/
    [
        decide [
            (this.iterator is System.null) [ false; ],
            true [
                decide [
                    (this.iterator.right is System.null) [
                        property tmp;
                        tmp = this.iterator.parent;
                        while (not (tmp is System.null) and (not (tmp.right is System.null)) and tmp.right.key == this.iterator.key) [
                            this.iterator = tmp;
                            tmp = tmp.parent;
                        ];
                        this.iterator = tmp;
                    ],
                    true [
                        this.iterator = this.iterator.right|find_leftmost;
                    ]
                ];
                (not (this.iterator is System.null));
            ]
        ];
    ]
];

class stack 
    /[Stack object.]/
[
    property list /[List of items in the stack.]/,

    construct() 
        /[Class constructor.]/
    [
        this.list = [];
    ],

    method count() 
        /[Return number of items on the stack.]/
    [
        this.list|count;
    ],

    method push(
        v /[Item to push onto stack.]/
    ) /[Push item onto stack.]/
    [
        this.list|prepend(v);
        true;
    ],

    method pop()
        /[Pop item from stack.]/
    [
        property tmp;
        tmp = this.list|head;
        this.list|removeAt(0);
        tmp;
    ],

    method top() 
        /[Return topmost item on stack.]/
    [
        this.list|head;
    ]
];

class queue 
    /[Queue object.]/
[
    property list /[List of items in the queue.]/,

    construct() 
        /[Class constructor.]/
    [
        this.list = [];
    ],

    method count() 
        /[Number of items in the queue.]/
    [
        this.list|count;
    ],

    method enqueue(
        v /[Item to place in queue.]/ 
    )   /[Place item in queue.]/
    [
        this.list|append(v);
        true;
    ],

    method dequeue() 
        /[Remove next item from queue.]/
    [
        property tmp;
        tmp = this.list|head;
        this.list|removeAt(0);
        tmp;
    ]
];
