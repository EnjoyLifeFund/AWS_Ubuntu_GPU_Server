##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

import "__internal._exception";

/[Package containing built-in Kite exceptions.]/

class exception from __internal._exception
    /[Base exception class.]/
[
    property msg /[Message associated with exception.]/,
    property trace /[Exception's stack trace.]/,

    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ],

    method throw()
        /[Throws exception.]/
    [
        base|throw;
    ],

    method str()
        /[Returns string representation of exception.]/
    [
        base|str;
    ]
];

class StackOverflow from exception
    /[Stack overflow exception.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class AccessDenied from exception
    /[Access denied to object.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class ArrayBounds from exception
    /[Array index exceeds bounds exception.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class DivideByZero from exception
    /[Division by zero occurred exception.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class DnsError from exception
    /[Error while resolving name exception.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class FileError from exception
    /[Exception occurred during file access.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class InterfaceError from exception
    /[Error encountered while interfacing with foreign code.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];


class InvalidArgument from exception
    /[An invalid argument was passed to a method.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class NoIteratorSupported from exception
    /[Iterator methods attempted on an object that doesn't support them.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class NotImplemented from exception
    /[Exception while accessing an unimplemented feature.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class ObjectNotFound from exception
    /[Specified object could not be found.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class PackageNotFound from exception
    /[The specified package could not be found.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class SocketError from exception
    /[Exception while accessing socket.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class SyntaxError from exception
    /[Error in syntax discovered while parsing.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class TypeMismatch from exception
    /[Object passed not of the expected type.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class OperatorNotDefined from exception
    /[Operator not defined for the given object.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class SystemCallFailure
    /[Failure while calling system call.]/
[
    construct()
        /[Class constructor.]/
    [
        base|__construct__(this|get_perror());
    ]
];
