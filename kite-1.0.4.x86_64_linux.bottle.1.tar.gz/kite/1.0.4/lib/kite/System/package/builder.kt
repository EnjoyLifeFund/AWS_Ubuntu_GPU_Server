##############################################################################
# Copyright (c) 2009, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Module to build Kite packages.]/

version "1.0.2";

import "System.doc";
import "System.collections.binary_tree";
import "System.compile_options";
import "System.os";
import "System.vm.thread";
import "System.regex";

property options;

class builder_options
    /[Class specifying module information for building.]/
[
    property libraries_built
        /[Kite modules to build.]/,
    property library_files
        /[Files for each Kite library.]/,
    property file_cflags
        /[Compiler flags for a file.]/,
    property library_ldflags
        /[Linker flags for a library.]/,
    property custom_pre_build_rules
        /[Custom build rules (pre-build).]/,
    property custom_post_build_rules
        /[Custom build rules (post-build).]/,
    property custom_pre_install_rules
        /[Custom install rules (pre-install).]/,
    property custom_post_install_rules
        /[Custom install rules (post-install).]/,
    property custom_pre_clean_rules
        /[Custom install rules (pre-clean).]/,
    property custom_post_clean_rules
        /[Custom install rules (post-clean).]/,
    property module_depends
        /[Modules that libraries depend on.]/,
    property doc_classes
        /[Classes to generate kdoc documentation for.]/,
    property package_name
        /[Name of the package being distributed.]/,
    property package_version
        /[Version of the package being distributed.]/,
        
    construct()
        /[Class constructor.]/
    [
        this.libraries_built = [];
        this.library_files = make System.collections.binary_tree();
        this.file_cflags = make System.collections.binary_tree();
        this.library_ldflags = make System.collections.binary_tree();
        this.module_depends = make System.collections.binary_tree();
        this.doc_classes = make System.collections.binary_tree();
        this.custom_pre_build_rules = [];
        this.custom_post_build_rules = [];
        this.custom_pre_install_rules = [];
        this.custom_post_install_rules = [];
        this.custom_pre_clean_rules = [];
        this.custom_post_clean_rules = [];
        
    ]
];

method process_builder_build_library_files(
    options /[builder_options object specifying build options.]/, 
    lib /[Library being built.]/,
    lib_file /[Library file being built.]/
)
[
    property cflags;
    decide [
        (options.file_cflags[lib_file] is System.null) [ cflags = ""; ],
        true [ cflags = options.file_cflags[lib_file]; ]
    ];
    
    decide [
        (not ((make System.regex("\\.kt$"))|match(lib_file) is System.null))
        [
            # Simple Kite file. Copy to dist folder.
            property last_segment_file;
            property last_segment;
            last_segment_file = (make System.regex("([^/]+)\\.kt$")|match(lib_file)).captures[1];
            last_segment = lib|split(".");
            decide 
            [
                (last_segment_file == last_segment[last_segment|count - 1])
                [
                    this|run_command_with_echo("cp -f %s dist/%s"|format([
                        lib_file, 
                        last_segment<|(
                            method(p,c) [
                                decide [
                                    (p is System.null) [ p = c; ],
                                    true [ p = p + "/" + c; ]
                                ];
                                p;
                            ]
                        ) + ".kt"]));
                ],
                true
                [
                    this|run_command_with_echo("cp -f %s dist/%s"|format([lib_file, (make System.regex("\\."))|replace(lib,"/")]));
                ]
            ];
            null;
            return;
        ],
        (not ((make System.regex("\\.c(pp|c)$"))|match(lib_file) is System.null))
        [
            # C++ file.
            this|run_command_with_echo("if [ \! \( -e %s \) -o \( %s -nt %s \) ]; then %s %s -c %s -o %s; fi"|format([
                (make System.regex("\\..+?$"))|replace(lib_file, ".o"),
                lib_file,
                (make System.regex("\\..+?$"))|replace(lib_file, ".o"),
                System.compile_options.build_cplusplus,
                System.compile_options.build_cxxflags,
                lib_file,
                (make System.regex("\\..+?$"))|replace(lib_file, ".o")]));
        ],
        true [
            # C file.
            this|run_command_with_echo("if [ \! \( -e %s \) -o \( %s -nt %s \) ]; then %s %s -c %s -o %s; fi"|format([
                (make System.regex("\\..+?$"))|replace(lib_file, ".o"),
                lib_file,
                (make System.regex("\\..+?$"))|replace(lib_file, ".o"),
                System.compile_options.build_cc,
                cflags,
                lib_file,
                (make System.regex("\\..+?$"))|replace(lib_file, ".o")]));
        ]
    ];
    (make System.regex("\\..+?$"))|replace(lib_file, ".o");
];

method process_builder_custom_rules(
    options /[builder_options object specifying build options.]/,
    custom_rules /[list containing custom rules.]/
) /[Process custom rules.]/
[
    custom_rules|reset;
    while(not (custom_rules|cur is System.null))
    [
        property tmp;
        tmp = custom_rules|cur;
        decide [
            (tmp(options) == false) 
            [
                "Stopping due to build error."|print;
                (make System.exceptions.exception("Build error."))|throw;
            ]
        ];
        custom_rules|next;
    ];
];

method process_builder_build_library(
    options /[builder_options object specifying build options.]/,
    lib /[Library to build.]/
) /[Build given library.]/
[
    # Build distribution folders.
    sp = lib|split(".");
    sp|reset;
    res = "";
    while (sp|cur)
    [
        res = res + sp|cur + "/";
        this|run_command_with_echo("if [ \! -e \"dist/%s\" ]; then mkdir dist/%s; fi"|format([res, res]));
        sp|next;
    ];
    
    # Build each file in the library.
    property compile_outputs;
    property output;
    compile_outputs = "";
    options.library_files[lib]|reset;
    while(options.library_files[lib]|cur)
    [
        output = this|process_builder_build_library_files(options, lib, options.library_files[lib]|cur);
        decide [
            (not (output is System.null) and output != "") [ compile_outputs = compile_outputs + output + " "; ]
        ];
        options.library_files[lib]|next;
    ];
    
    # Link library.
    property ldflags;
    decide [
        (options.library_ldflags[lib] is System.null) [ ldflags = ""; ],
        true [ ldflags = options.library_ldflags[lib]; ]
    ];
    decide [
        (compile_outputs != "") [
            this|run_command_with_echo("%s %s %s %s -o dist/%s %s"|format([
                System.compile_options.build_cc,
                System.compile_options.build_ldflags,
                System.compile_options.build_dylib_flags,
                ldflags,
                ((make System.regex("\\."))|replace(lib, "/") + System.compile_options.build_dylib_extension),
                compile_outputs
            ]));
        ]
    ];
];

method run_command_with_echo(
    command /[Command to run.]/
) /[Execute command, outputting what we're running before we do.]/
[
    command|print;
    decide [
        (System.os|system(command) != 0) [
            "Stopping due to build error."|print;
            (make System.exceptions.exception("Build error."))|throw;
        ]
    ];
];

method process_builder_build(
    options /[builder_options object specifying build options.]/
) /[Begin build.]/
[
    this|process_builder_custom_rules(options, options.custom_pre_build_rules);
    
    # Check module dependencies
    options.libraries_built|reset;
    while(options.libraries_built|cur)
    [
        decide [
            (not (options.module_depends[options.libraries_built|cur] is System.null)) 
            [
                property tmp;
                tmp = options.module_depends[options.libraries_built|cur];
                tmp|reset;
                while(tmp|cur)
                [
                    run [
                        eval "import \"%s\";"|format([tmp|cur]);
                    ] catch [
                        "Could not load %s, a needed dependency."|format([tmp|cur])|print;
                        "Please (re)install and try again."|print;
                        __exc|throw;
                    ];
                    tmp|next;
                ];
            ]
        ];
        options.libraries_built|next;
    ];
    
    this|run_command_with_echo("rm -rf dist/");
    this|run_command_with_echo("mkdir dist/");
    
    options.libraries_built|reset;
    while(options.libraries_built|cur)
    [
        this|process_builder_build_library(options, options.libraries_built|cur);
        options.libraries_built|next;
    ];
    
    this|process_builder_custom_rules(options, options.custom_post_build_rules);
    true;
];

method process_builder_install(
    options /[builder_options object specifying build options.]/
) /[Install package.]/
[
    this|process_builder_custom_rules(options, options.custom_pre_install_rules);
    decide [
        (System.os|envGet("KPKG_DESTDIR") != "") [
            this|run_command_with_echo("cp -fR dist/* %s"|format([System.os|envGet("KPKG_DESTDIR")]));
        ],
        true [
            this|run_command_with_echo("cp -fR dist/* %s"|format([System.compile_options.build_install_dir]));
        ]
    ];
    this|process_builder_custom_rules(options, options.custom_post_install_rules);
    true;
];

method process_builder_clean(
    options /[builder_options object specifying build options.]/
) /[Clean package.]/
[
    this|process_builder_custom_rules(options, options.custom_pre_clean_rules);
    this|run_command_with_echo("rm -rf dist/");
    this|run_command_with_echo("rm -rf *.o");
    this|process_builder_custom_rules(options, options.custom_post_clean_rules);
    true;
];

method process_builder_docs(
  options /[ builder_options object specifying build options. ]/
) /[ Build package docs. ]/
[
    this|run_command_with_echo("rm -rf docs/");
    this|run_command_with_echo("mkdir docs/");
    self = this; /[ Scoping issue ]/
    
    out = make System.doc.outputters.html_outputter();
    
    options.libraries_built|reset;
    while(options.libraries_built|cur)
    [
      key = options.libraries_built|cur;
      list = options.doc_classes[key];
      
      eval "import \""+key+"\";";
      list|reset;
      while(list|cur)
      [
          eval "import \""+list|cur+"\";";
          doc = System.doc|generate_doc(eval list|cur+";");
          doc|output(out);
          self|run_command_with_echo("mv "+list|cur+".html"+" docs/");
          list|next;
      ];  
      options.libraries_built|next;
    ];
];

method process_builder(
    options /[builder_options object specifying build options.]/
) /[Process command line arguments and begin build/install.]/
[
    os_args = System.os.args;

    decide 
    [
        (os_args|count == 0 or ((make System.regex("kpkg\\.kt"))|match(os_args[0]) is System.null))
        [
            # Load only, do not execute.
            true;
            return;
        ],
        (os_args|count > 1 and os_args[1] == "build")
        [
            this|process_builder_build(options);
        ],
        (os_args|count > 1 and os_args[1] == "clean")
        [
            this|process_builder_clean(options);
        ],
        (os_args|count > 1 and os_args[1] == "install")
        [
            this|process_builder_install(options);
        ],
        (os_args|count > 1 and os_args[1] == "doc")
        [
            this|process_builder_docs(options);
        ],
        true
        [
            "Invalid command.

Usage: %s [build|install|clean]
Available options:
    build: Build source files into Kite package.
    install: Install Kite package into Kite tree.
    clean: Clean sources.
    docs: Build documentation.
"|format([os_args[0]])|print;
            System.vm.thread|exit;
        ]
    ];
    "Build complete."|print;
    true;
];