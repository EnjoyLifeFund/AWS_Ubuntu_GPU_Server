##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

import "System.collections";
import "System.file";
import "System.vm.thread";
import "interface.text.readline";

/[The Kite debugger.]/

class line_info
[
    property line_contents,
    property breakpoint,
    property temporary,
    
    construct(line)
    [
        this.breakpoint = false;
        this.temporary = false;
        this.line_contents = line;
    ]
];

property code_cache;
property first_break;
property last_file;
property last_line;
property last_command;

construct()
    /[Class constructor]/
[
    this.code_cache = make System.collections.binary_tree();
    this.first_break = true;
    this.last_file = "";
    this.last_line = "";
    this.last_command = "";
    this|share;
];

method read_file(file)
[
    property fp;
    property tmp_cache;
    property tmpline;

    fp = make System.file(file, "r");
    tmp_cache = [];

    tmpline = fp|readline;
    while(not (tmpline is System.null))
    [
        property tmpobj;
        tmpobj = make System.vm.debugger.line_info(tmpline);
        tmp_cache << tmpobj;
    
        tmpline = fp|readline;
    ];
    fp|close;

    this.code_cache|set(file, tmp_cache);
];

method grab_code_line(file, line)
[
    property ret;
    ret = this.code_cache[file];
    decide [
        (ret is System.null) [
            this|read_file(file);
            ret = this.code_cache[file];
            decide [
                (line > ret|count) [ null; ],
                true [ ret[line - 1]; ]
            ];
        ],
        true [
            decide [
                (line > ret|count) [ null; ],
                true [ ret[line - 1]; ]
            ];
        ]
    ];
];

method stepper(
    opc /[Current opcode]/,
    file /[Current file]/,
    line /[Current line]/
) /[Main debugger loop. Executed on every VM instruction.]/
[
    decide [
        (line > 0) [
            # Begin critical section
            this|lock;

            # Grab line of code from code cache.
            property code_line;
            code_line = this|grab_code_line(file, line);

            decide [
                (code_line is System.null) [ 
                    # ignore 
                ],
                (code_line.breakpoint or this.first_break) [
                    # Encountered breakpoint.
                    this|prompt_action(file, line, code_line);
                ],
                true [ 
                    this.last_file = file;
                    this.last_line = line;
                    true;
                ]
            ];

            # End critical section
            this|unlock;
        ],
        true [ true; ]
    ];
];

method split_file_line(str)
[
    str|split(":", 2);
];

method clear_bp(file, line, code_line, args)
[
    property clear_code_line;
    property clear_code_lines;
    clear_code_lines = this|split_file_line(args[1]);
    clear_code_line = this|grab_code_line(clear_code_lines[0], clear_code_lines[1]|int);
    clear_code_line.breakpoint = false;
    clear_code_line.temporary = false;
    "Breakpoint cleared at %s"|format([args[1]]);
    this|prompt_action(file, line, code_line);
];

method set_bp(file, line, code_line, args)
[
    property clear_code_line;
    property clear_code_lines;
    clear_code_lines = this|split_file_line(args[1]);
    clear_code_line = this|grab_code_line(clear_code_lines[0], clear_code_lines[1]|int);
    clear_code_line.breakpoint = true;
    clear_code_line.temporary = false;
    "Breakpoint set at %s"|format([args[1]]);
    this|prompt_action(file, line, code_line);
];

method move_next(file, line, code_line, args)
[
    property tmp;
    tmp = this|grab_code_line(file, line + 1);
    decide [
        (tmp is System.null) [
            this.first_break = true;
        ],
        true [
            tmp.breakpoint = true;
            tmp.temporary = true;
        ]
    ];
];

method decide_action(file, line, code_line)
[
    args = this.last_command|split(" ", 2);
    decide [
        (args[0] == "eval") [
            run [
                (eval args[1])|print;
            ]
            catch
            [
                "%s: %s"|format([__exc|type, __exc.msg])|print;
            ];
            this|prompt_action(file, line, code_line);
        ],
        (args[0]|substring(0, 2) == "ev") [
            run [
                (eval args[1])|print;
            ]
            catch
            [
                "%s: %s"|format([__exc|type, __exc.msg])|print;
            ];
            this|prompt_action(file, line, code_line);
        ],
        (args[0] == "exit") [
            System.vm.thread|exit;
        ],
        (args[0]|substring(0, 2) == "ex") [
            System.vm.thread|exit;
        ],
        (args[0] == "clear") [
            this|clear_bp(file, line, code_line, args);
        ],
        (args[0]|substring(0, 2) == "cl") [
            this|clear_bp(file, line, code_line, args);
        ],
        (args[0] == "break") [
            this|set_bp(file, line, code_line, args);
        ],
        (args[0]|substring(0, 1) == "b") [
            this|set_bp(file, line, code_line, args);
        ],
        (args[0] == "step") [
            this.first_break = true;
        ],
        (args[0]|substring(0, 1) == "s") [
            this.first_break = true;
        ],
        (args[0] == "next") [
            this|move_next(file, line, code_line, args);
        ],
        (args[0]|substring(0, 1) == "n") [
            this|move_next(file, line, code_line, args);
        ],
        (args[0] == "cont") [
            true;
        ],
        (args[0]|substring(0, 2) == "co") [
            true;
        ],
        true [
            "Invalid command."|print;
            this|prompt_action(file, line, code_line);
        ]
    ];
];

method prompt_action(file, line, code_line)
[
    decide [
        (this.last_file == file and this.last_line == line) [ true; ],
        true [
            this.first_break = false;

            System.file.stdout|write("%s[%d]: %s"|format([file, line, code_line.line_contents]));
            #System.file.stdout|write("> ");
            
            property inp;
            property args;
            #inp = System.file.stdin|readline;
            inp = interface.text.readline|readline("> ");
            
            decide [ (inp is System.null) [ inp = "exit"; ] ];
            inp = inp|substring(0, inp|length - 1);
            decide [
                (inp == "") [ this|decide_action(file, line, code_line); ],
                true [
                    interface.text.readline|add_history(inp);
                    this.last_command = inp;
                    this|decide_action(file, line, code_line);
                ]
            ];
            
            this.last_file = file;
            this.last_line = line;
            
            decide [
                (code_line.temporary) [
                    code_line.temporary = false;
                    code_line.breakpoint = false;
                ]
            ];

        ]
    ];
];
