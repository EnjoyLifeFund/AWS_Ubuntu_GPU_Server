##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Kite<->C language library interface, based on the C/Invoke library at
http://www.nongnu.org/cinvoke/.

Platforms supported: x86 (32 and 64-bit), SPARC, PPC (OS X only), Windows.
(Use on unsupported platforms will result in an exception being thrown.)]/

import "__internal._cinvoke_library";
import "__internal._cinvoke_function";
import "__internal._cinvoke_context";
import "__internal._cinvoke_structure";
import "__internal._cinvoke_callback";

class function_prototype
    /[C Function prototype.]/
[
    property func_instance /[CInvokeFunction instance.]/,
    property entrypoint /[Function entry point.]/,
    property ret_type /[Return parameter type.]/,
    property param_types /[Parameter types.]/,
    property param_types_string /[Parameter type string.]/
];

class param_types
    /[Valid C<->Kite data types.]/
[
    global property char,
    global property int,
    global property short,
    global property long,
    global property longlong,
    global property float,
    global property double,
    global property pointer,
    global property int16,
    global property int32,
    global property int64,
    global property void,
    global property string,
    global property type_characters,
    global property type_classes,

    this.char = 0,
    this.short = 1,
    this.int = 2,
    this.long = 3,
    this.longlong = 4,
    this.float = 5,
    this.double = 6,
    this.pointer = 7,
    this.string = 8,
    this.int16 = 9,
    this.int32 = 10,
    this.int64 = 11,
    this.void = 12,
    
    this.type_characters = ["c", "s", "i", "l", "e", "f", "d", "p", "t", "2", "4", "8", ""],
    this.type_classes = [
        System.integer,
        System.integer,
        System.integer,
        System.integer,
        System.integer,
        System.float,
        System.float,
        System.integer,
        System.string,
        System.integer,
        System.integer,
        System.integer,
        null
    ]
];

class c_callback
    /[Represents a callback function.]/
[
    property _ctx /[Internal use only.]/,
    property _cbk /[Internal use only.]/,
    property _func /[Internal use only.]/,
    
    construct(
        ctx /[Library object callback will be used in.]/,
        retType /[Callback's return type.]/,
        paramTypes /[Callback's parameters.]/,
        mthd /[Method to use.]/,
        userData /[Additional user data.]/
    )   /[Class constructor.]/
    [
        property fx;
        
        fx = ctx|_make_prototype(retType, paramTypes);
        
        this._ctx = ctx;
        this._func = make __internal._cinvoke_function(ctx._ctx, fx.ret_type, fx.param_types_string);
        this._cbk = 
            make __internal._cinvoke_callback(
                ctx._ctx, 
                this._func, 
                userData, 
                fx.ret_type, 
                fx.param_types_string, 
                mthd
            );
    ],
    
    destruct
        /[Class destructor.]/
    [
        this._cbk|destruct;
        this._func|destruct;
    ],
    
    method pointer()
        /[Return pointer for use in function.]/
    [
        this._cbk|get_entrypoint;
    ]
];

class c_struct_instance
    /[Represents an instance of a C structure.]/
[
    property _struct /[Internal use only.]/,
    property _instance /[Internal use only.]/,
    property _destruct /[Internal use only.]/,
    
    construct(
        struct /[Structure to create instance of.]/
    )   /[Class constructor.]/
    [
        this._struct = struct;
        this._instance = struct._struct|new_instance;
        this._destruct = true;
    ],
    
    construct(
        struct /[Structure to use.]/,
        inst /[Instance to use.]/
    )   /[Internal use only.]/
    [
        this._struct = struct;
        this._instance = inst;
        this._destruct = false;
    ],
    
    destruct
        /[Class destructor.]/
    [
        decide
        [
            (this._destruct == true) 
            [
                this._struct|destroy_instance(this._instance); 
            ]
        ];
    ],
    
    operator call(
        name /[Name of method]/,
        args /[Method arguments]/
    )   /[Get or set structure value.]/
    [
        property m_info;
        property i;
        property tmp;
        
        i = 0;
        while(i < this._struct._members|count)
        [
            tmp = this._struct._members[i];
            decide
            [
                (tmp[0] == name) [ m_info = tmp; ]
            ];
            i = i + 1;
        ];
        
        decide
        [
            (m_info is System.null) 
            [
                (make System.exceptions.ObjectNotFound("Could not find member " + name + " in struct."))|throw;
            ]
        ];
        
        decide
        [
            (args|count == 0 and m_info[1] is System.integer)
            [
                tmp = this._struct._struct|get_instance_value(
                    this._instance, 
                    name, 
                    interface.language.c.param_types.type_characters[
                        m_info[1]
                    ]
                );
            ],
            (args|count == 0)
            [
                tmp = this._struct._struct|get_instance_value(
                    this._instance, 
                    name, 
                    "r"
                );
                tmp = make interface.language.c.c_struct_instance(m_info[1], tmp);
            ],
            (args|count == 1 and m_info[1] is System.integer)
            [
                this._struct._struct|set_instance_value(
                    this._instance, 
                    name,
                    args[0],
                    interface.language.c.param_types.type_characters[
                        m_info[1]
                    ]
                );
            ],
            (args|count == 1)
            [
                tmp = args[0];
                this._struct._struct|set_instance_value(
                    this._instance, 
                    name,
                    tmp._instance,
                    "r"
                );
                tmp = null;
            ],
            true
            [
                (make System.exceptions.ObjectNotFound(
                    "Could not find method " + name + " with " + args|count + " arguments."
                ))|throw;
            ]
        ];
        
        tmp;
    ],
    
    method pointer()
        /[Return pointer value usable in functions.]/
    [
        this._instance;
    ]
];

class c_struct
    /[Represents a C structure definition.]/
[
    property _library /[interface.language.c instance.]/,
    property _struct /[Internal use only.]/,
    property _members /[Internal use only.]/,
    
    construct(
        library /[C library that structure will be used in.]/,
        members /[List of members. Each member is a list of [name, type].]/
    )   /[Class constructor.]/
    [
        property i;
        
        this._library = library;
        this._members = members;
        this._struct = make __internal._cinvoke_structure(library._ctx);
        library|_check_error_status;
        
        i = 0;
        
        while(i < members|count)
        [
            property m_def;
            property m_name;
            property m_type;
            
            m_def = members[i];
            m_name = m_def[0];
            m_type = m_def[1];
            
            decide
            [
                (m_type is System.integer) [ this._struct|add_value(m_name, m_type); ],
                true [ this._struct|add_struct(m_name, m_type); ]
            ];
            library|_check_error_status;
            
            i = i + 1;
        ];
        
        this._struct|finish;
        library|_check_error_status;
    ],
    
    destruct
        /[Class destructor.]/
    [
        this._struct|destruct;
    ],
    
    method size()
        /[Gets size of struct.]/
    [
        this._struct|size;
    ],
    
    method make_instance()
        /[Create new instance of structure.]/
    [
        (make interface.language.c.c_struct_instance(this));
    ]
];

property _ctx /[Internal use only.]/;
property _library /[Internal use only.]/;
property _valid_functions /[Internal use only.]/;

construct(
    lib /[Path to library on your system.]/
)   /[Load a new library into memory.]/
[
    this._ctx = make __internal._cinvoke_context();
    this._library = make __internal._cinvoke_library(this._ctx, lib);
    this|_check_error_status;
    
    this._valid_functions = make System.collections.binary_tree();
];

destruct
    /[Class destructor.]/
[
    property cur;
    
    cur = this._valid_functions|cur;
    while ((not (cur is System.null)) or this._valid_functions|next) [
        cur = this._valid_functions|cur;
        cur.item.func_instance|destroy;
        cur = null;
    ];
    
    this._library|destruct;
    this._ctx|destruct;
];

method _check_error_status()
    /[Check the error status and throw exception if needed (internal use)]/
[
    decide
    [
        (this._ctx|get_error is System.null) [ false; ],
        true [ (make System.exceptions.InterfaceError(this._ctx|get_error))|throw; ]
    ];
];

method _make_prototype(
    ret_type /[Function's return type.]/, 
    parameter_types /[Function's parameters.]/
)   /[Internal use only.]/
[
    property fx;
    property i;

    fx = make interface.language.c.function_prototype();
    fx.ret_type = interface.language.c.param_types.type_characters[ret_type];
    fx.param_types = [];
    fx.param_types_string = "";
    
    i = 0;
    while(i < parameter_types|count)
    [
        fx.param_types|append(interface.language.c.param_types.type_classes[parameter_types[i]]);
        fx.param_types_string = 
            fx.param_types_string + 
            interface.language.c.param_types.type_characters[parameter_types[i]];
        i = i + 1;
    ];
    
    fx;
];

method add_method(
    name /[Function name.]/,
    ret_type /[Function return type.]/,
    parameter_types /[List of parameter types.]/
)   /[Load method from library and make callable.]/
[
    property fx;
    
    fx = this|_make_prototype(ret_type, parameter_types);

    fx.entrypoint = this._library|get_entrypoint(name);
    this|_check_error_status;
    fx.func_instance = make __internal._cinvoke_function(this._ctx, fx.ret_type, fx.param_types_string);
    this|_check_error_status;
    
    this._valid_functions|set(name, fx);
];

operator call(
    name /[Method name.]/,
    params /[Method parameters.]/
)   /[Invoke given function.]/
[
    property fx;
    fx = this._valid_functions[name];
    
    decide
    [
        (fx is System.null) [ (make System.exceptions.ObjectNotFound("Could not find function " + name))|throw; ]
    ];
    
    property tmp;
    tmp = 0;
    while(tmp < params|count)
    [
        property param;
        property ptype;
        param = params[tmp];
        ptype = fx.param_types[tmp];
        
        decide
        [
            (not (param is ptype)) 
            [
                (make System.exceptions.InvalidArgument(
                    "Argument %d must be %s"|format([tmp + 1, ptype|type])
                ))|throw;
            ]
        ];
        
        tmp = tmp + 1;
    ];
    
    fx.func_instance|invoke(fx.entrypoint, params);
];
