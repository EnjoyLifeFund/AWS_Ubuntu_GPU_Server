##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Base64 encoding and decoding.]/

property _base64_characters;

_base64_characters = 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

method encode(
    str /[The string to encode.]/
) /[Encode a string as Base64.]/
[
    property current_block;
    property i;
    property k;
    property char_at;
    property ret;
    
    ret = "";
    i = 0;
    current_block = 0;
    while(i < str|length)
    [
        char_at = str|charAt(i);
        k = i % 3;
        decide
        [
            (k >= 1)
            [
                current_block = current_block << 8;
            ]
        ];
        current_block = current_block + char_at|asc;
        
        decide
        [
            (k == 2)
            [
                ret = ret + 
                    interface.text.base64._base64_characters|charAt((current_block >> 18) and 63);
                ret = ret + 
                    interface.text.base64._base64_characters|charAt((current_block >> 12) and 63);
                ret = ret + 
                    interface.text.base64._base64_characters|charAt((current_block >> 6) and 63);
                ret = ret + 
                    interface.text.base64._base64_characters|charAt(current_block and 63);
                current_block = 0;
                
                decide [ ((ret|length % 64) == 0) [ ret = ret + "\n"; ] ];
            ]
        ];
        
        i = i + 1;
    ];

    # Pad with extra bytes
    decide
    [
        ((i % 3) == 2)
        [
            current_block = current_block << 8;
        ],
        ((i % 3) == 1)
        [
            current_block = current_block << 16;
        ],
        ((i % 3) == 0)
        [
            ret;
            return;
        ]
    ];

    ret = ret + 
        interface.text.base64._base64_characters|charAt((current_block >> 18) and 63);
    ret = ret + 
        interface.text.base64._base64_characters|charAt((current_block >> 12) and 63);
    decide
    [
        (((current_block >> 6) and 63) == 0) [ ret = ret + "="; ],
        true
        [ 
            ret = ret + 
                interface.text.base64._base64_characters|charAt((current_block >> 6) and 63);
        ]
    ];
    decide
    [
        ((current_block and 63) == 0) [ ret = ret + "="; ],
        true
        [ 
            ret = ret + 
                interface.text.base64._base64_characters|charAt(current_block and 63);
        ]
    ];
    
    ret;
];

method decode(
    str /[String to decode.]/
) /[Decode Base64-encoded string.]/
[
    property decoded_chars;
    property i;
    property ret;
    property ch;
    
    i = 0;
    decoded_chars = 0;
    ret = "";
    while(i < str|length)
    [
        ch = str|charAt(i);
        decide [ ((ch == "\n") or (ch == "\r")) [ i = i + 1; continue; ] ];
        decoded_chars = decoded_chars << 6;
        decide
        [
            (ch != "=")
            [
                decoded_chars = decoded_chars + _find_index(str|charAt(i));
            ]
        ];
        
        decide
        [
            ((i % 4) == 3)
            [
                ret = ret + System.string|chr(decoded_chars >> 16);
                ret = ret + System.string|chr(decoded_chars >> 8);
                ret = ret + System.string|chr(decoded_chars);
                decoded_chars = 0;
            ]
        ];
        
        i = i + 1;
    ];
    
    ret;
];

method _find_index(
    char /[Character to find index of.]/
) /[Find index of Base64-encoded character.]/
[
    property i;
    i = 0;
    while(i < interface.text.base64._base64_characters|length)
    [
        decide
        [
            (char == interface.text.base64._base64_characters|charAt(i))
            [
                i;
                return;
            ]
        ];
        i = i + 1;
    ];
    0;
];
