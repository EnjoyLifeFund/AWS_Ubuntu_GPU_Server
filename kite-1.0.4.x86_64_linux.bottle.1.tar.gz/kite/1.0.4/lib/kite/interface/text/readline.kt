##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Kite interface to GNU readline.]/

import "System.os";

global property _rl;
global property _rl_name;

decide [
    (System.os.dylib_extension == ".dll") [ _rl_name = "readline.dll"; ],
    (System.os.dylib_extension == ".dylib") [ 
        _rl_name = "/usr/lib/libreadline.dylib";
    ],
    true [ _rl_name = "libreadline.so.5"; ]
];

run 
[
    _rl = make interface.language.c(_rl_name);
    _rl|add_method(
        "readline",
        interface.language.c.param_types.string,
        [interface.language.c.param_types.string]
    );
    _rl|add_method(
        "add_history",
        interface.language.c.param_types.void,
        [interface.language.c.param_types.string]
    );
]
catch
[
    # Readline does not exist on this system.
    _rl = null;
];

method readline(
    prompt /[The prompt to emit to the user.]/
) /[Ask for a line of user input, including command history.]/
[
    decide 
    [
        (this._rl is System.null) [ 
            System.file.stdout|write(prompt);
            System.file.stdin|readline(); 
        ],
        true [
            property ret;
            ret = this._rl|readline(prompt);
            decide [ (not (ret is System.null)) [ ret = ret + "\n"; ] ];
            ret;
        ]
    ];
];

method add_history(
    text /[Command to add to history.]/
) /[Add command to command history.]/
[
    decide 
    [
        (this._rl is System.null) [ 
            false;
        ],
        true [
            this._rl|add_history(text);
            true;
        ]
    ];
];
