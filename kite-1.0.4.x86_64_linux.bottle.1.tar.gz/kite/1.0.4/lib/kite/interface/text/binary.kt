##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Convert Kite built-ins to binary and vice versa.]/

global property BIG_ENDIAN /[Big endian byte order.]/;
global property LITTLE_ENDIAN /[Little endian byte order.]/;

this.BIG_ENDIAN = 1;
this.LITTLE_ENDIAN = 2;

property _direction /[What byte ordering are we using?]/;

construct(
    direction /[The byte order to use.]/
)   /[Construct object.]/
[
    this._direction = direction;
];

method to_int8(
    number /[Number to convert.]/
) /[Convert integer to single-byte character.]/
[
    this|integer_to_bytes(number, 1, true);
];

method to_uint8(
    number /[Number to convert.]/
) /[Convert integer to single-byte character.]/
[
    this|integer_to_bytes(number, 1, false);
];

method to_int16(
    number /[Number to convert.]/
) /[Convert integer to two-byte character sequence.]/
[
    this|integer_to_bytes(number, 2, true);
];

method to_uint16(
    number /[Number to convert.]/
) /[Convert integer to two-byte character sequence.]/
[
    this|integer_to_bytes(number, 2, false);
];

method to_int32(
    number /[Number to convert.]/
) /[Convert integer to four-byte character sequence.]/
[
    this|integer_to_bytes(number, 4, true);
];

method to_uint32(
    number /[Number to convert.]/
) /[Convert integer to four-byte character sequence.]/
[
    this|integer_to_bytes(number, 4, false);
];

method integer_to_bytes(
    number /[Number to convert.]/,
    bytes /[Length of number.]/,
    signed /[Signed or unsigned?]/
) /[Convert integer to byte array.]/
[
    property result;
    property i;
    property tmp;
    
    # Convert to unsigned first.
    decide [
        ((not signed) and number < 0) [ number = -number; ]
    ];
    
    # Produce big-endian version of number.
    result = "";
    i = 0;
    while (i < bytes)
    [
        result = result + System.string|chr(number and 255);
        number = number >> 8;
        i = i + 1;
    ];
    
    # Swap to little-endian as appropriate.
    decide [
        (this._direction == interface.text.binary.LITTLE_ENDIAN)
        [
            tmp = "";
            i = 0;
            while (i < bytes)
            [
                tmp = tmp + result[bytes - 1 - i];
                i = i + 1;
            ];
            
            result = tmp;
        ]
    ];
    
    # Return result.
    result;
];

method from_int8(
    str /[String to convert back to integer.]/
) /[Convert binary to 8-bit integer.]/
[
    this|bytes_to_integer(str, 1, true);
];

method from_uint8(
    str /[String to convert back to integer.]/
) /[Convert binary to 8-bit unsigned integer.]/
[
    this|bytes_to_integer(str, 1, false);
];

method from_int16(
    str /[String to convert back to integer.]/
) /[Convert binary to 16-bit integer.]/
[
    this|bytes_to_integer(str, 2, true);
];

method from_uint16(
    str /[String to convert back to integer.]/
) /[Convert binary to 16-bit unsigned integer.]/
[
    this|bytes_to_integer(str, 2, false);
];

method from_int32(
    str /[String to convert back to integer.]/
) /[Convert binary to 32-bit integer.]/
[
    this|bytes_to_integer(str, 4, true);
];

method from_uint32(
    str /[String to convert back to integer.]/
) /[Convert binary to 32-bit unsigned integer.]/
[
    this|bytes_to_integer(str, 4, false);
];

method bytes_to_integer(
    number /[String to convert.]/,
    bytes /[Length of number.]/,
    signed /[Signed or unsigned?]/
) /[Convert integer to byte array.]/
[
    property result;
    property i;
    property tmp;
    
    # Convert to proper endian first.
    decide
    [
        (this._direction == interface.text.binary.BIG_ENDIAN)
        [
            tmp = "";
            i = bytes - 1;
            while(i >= 0)
            [
                tmp = tmp + number[i];
                i = i - 1;
            ];
        ],
        true
        [
            tmp = number;
        ]
    ];
    
    # Convert.
    result = 0;
    i = 0;
    while(i < bytes)
    [
        result = result << 8;
        result = result + tmp[i]|asc;
        i = i + 1;
    ];
    
    # Ignore sign; Kite does not have an unsigned type.
    result;
];
