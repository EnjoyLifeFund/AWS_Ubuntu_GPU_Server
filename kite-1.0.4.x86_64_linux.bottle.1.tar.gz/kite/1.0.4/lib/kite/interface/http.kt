##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[HTTP request handling methods and classes.]/

import "System.exceptions";
import "System.collections";
import "System.regex";
import "System.network.socket";

class request_parser
    /[HTTP request parser base class.]/
[
    construct()
        /[Class constructor.]/
    [
    ],

    method parse()
        /[Parse HTTP request passed in by the interface.]/
    [
        (make System.exceptions.NotImplemented("Not implemented."))|throw;
    ]
];

class request
    /[HTTP request object.]/
[
    property request_method
        /[HTTP method used.]/,

    property path_info
        /[Path appended to the end of the request.]/,

    property query_string
        /[Query string used.]/,

    property headers
        /[HTTP headers dictionary.]/,

    property response
        /[HTTP response.]/,

    property parameters
        /[Query string/POST keys and values.]/,

    property content_length
        /[Length of content (for POST).]/,

    property content
        /[Content (for POST).]/,

    construct()
        /[Class constructor.]/
    [
        this.headers = make System.collections.binary_tree();
        this.parameters = make System.collections.binary_tree();
        this.response = make interface.http.response();
    ],

    method parse_params()
        /[Parse HTTP request parameters.]/
    [
        decide 
        [
            (not (this.query_string is System.null))
            [
                this|parse_params_helper(this.query_string);
            ]
        ];
        decide 
        [
            (not (this.content is System.null))
            [
                this|parse_params_helper(this.content);
            ]
        ];
    ],

    method parse_replace(caps)
    [
        "%c"|format(
            [System.integer|parse(caps[1], 16)]);
    ],

    method parse_params_helper(
        str /[Query string.]/
    ) /[Helper method (do not call directly!)]/
    [
        property params;
        property i;

        params = str|split("&");
        i = 0;
        while (params[0] != "" and i < params|count)
        [
            property p_nv;
            property p_name;
            property p_value;
            property decode_rgx;
            property space_rgx;

            p_nv = params[i];
            p_nv = p_nv|split("=", 2);
            p_name = p_nv[0];
            p_value = "";
            decide [ (p_nv|count == 2) [ p_value = p_nv[1]; ] ];

            decode_rgx = make System.regex("%(\\d\\d)");
            space_rgx = make System.regex("\\+");
            p_name = space_rgx|replace(p_name, " ");
            p_name = decode_rgx|replace(p_name, this.parse_replace);
            p_value = space_rgx|replace(p_value, " ");
            p_value = decode_rgx|replace(p_value, this.parse_replace);

            decide
            [
                (this.parameters[p_name] is System.null)
                [
                    this.parameters|set(p_name, [p_value]);
                ],
                true
                [
                    property p_ary;
                    p_ary = this.parameters[p_name];
                    p_ary|append(p_value);
                ]
            ];

            i = i + 1;
        ];
    ],

    method emit_response(resp)
        /[Emits HTTP response.]/
    [
        (make System.exceptions.NotImplemented("Not implemented."))|throw;
    ]
];

class response
    /[HTTP response object.]/
[
    property status_code
        /[Status code to return.]/,

    property headers
        /[Additional HTTP headers to return.]/,

    property location
        /[Location, for redirects.]/,

    property content
        /[Output of response.]/,

    property content_type
        /[Type of content.]/,

    construct()
        /[Class constructor.]/
    [
        this.status_code = 200;
        this.headers = make System.collections.binary_tree();
        this.location = null;
        this.content = "";
        this.content_type = "text/html";
    ],

    method emit()
        /[Write response as string.]/
    [
        property ret;
        property iter;

        this.headers|set("Content-Type", this.content_type);
        decide
        [
            (not (this.location is System.null))
            [
                this.status_code = 302;
                this.headers|set("Location", this.location);
            ]
        ];
        this.headers|set("Content-Length", this.content|length);

        ret = "HTTP/1.0 %d OK\n"|format([this.status_code]);
        this.headers|reset;
        iter = this.headers|cur;
        while (not (iter is System.null) or this.headers|next)
        [
            iter = this.headers|cur;
            ret = ret + "%s: %s\n"|format([iter.key|str, iter.item|str]);
            iter = null;
        ];

        ret = ret + "\n";
        ret = ret + this.content;
        ret;
    ],

    method write(text)
        /[Write text to output.]/
    [
        this.content = this.content + text;
    ]
];

method process_request(
    req_parser /[Request handler object.]/,
    req_method /[Method to process request.]/
) /[Processes an HTTP request.]/
[
    property req;

    req = req_parser|parse;
    decide [
        (not (req is System.null))
        [
            req|emit_response(req_method(req_parser, req));
        ]
    ];
];

method dictionary_to_query_string(
    params  /[Query parameters.]/
) /[Dictionary->query string]/
[
    property ret;
    property cur;
    property rgx;
    property mth;
    
    ret = "";
    rgx = make System.regex("([^A-Za-z0-9_-])");
    mth = method(cap) [ 
        property x;
        property y;
        x = cap[1]|asc;
        y = "0123456789ABCDEF";
        
        ("%" + y[x / 16] + y[x % 16]);
    ];
    
    params|reset;
    cur = params|cur;
    while ((not (cur is System.null)) or params|next) [
        cur = params|cur;
        ret = ret + rgx|replace(cur.key, mth) + "=" + rgx|replace(cur.item, mth);
        cur = null;
    ];
    
    ret;
];

method get(
    request_method /[GET or POST]/,
    host /[Hostname to retrieve]/,
    port /[Port to use for connection]/,
    path /[Path to retrieve]/,
    options /[Request options.]/
) /[Retrieves a resource from an HTTP server.

options can be null or a System.collections.binary_tree that has one or more of
the following fields:

auth_type: Authentication type (only Basic is supported at the moment)
auth_username: Username for HTTP authentication
auth_password: Password for HTTP authentication
parameters: a binary_tree with keys/values to send
headers: additional HTTP headers to send

Returns an interface.http.response object with the request's response,
or throws an exception if the server cannot be reached.
]/
[
    property content;
    property sock;

    decide
    [
        (options is System.null)
        [
            options = make System.collections.binary_tree();
        ]
    ];

    decide 
    [ 
        (options["headers"] is System.null) 
        [
            options|set("headers", make System.collections.binary_tree());
        ]
    ];

    decide
    [
        (not (options["auth_type"] is System.null) and options["auth_type"] == "Basic")
        [
            options["headers"]|set(
                "Authorize", 
                "Basic " + 
                interface.text.base64|encode(
                    options["auth_username"] + ":" + options["auth_password"]
                )
            );
        ]
    ];

    options["headers"]|set("Host", host);
    content = "";
    
    decide
    [
        (not (options["parameters"] is System.null))
        [
            content = dictionary_to_query_string(options["parameters"]);
        ]
    ];

    decide
    [
        (request_method == "POST")
        [
            options["headers"]|set("Content-Length", content|length);
            options["headers"]|set("Content-Type", "application/x-www-form-urlencoded");
        ],
        (request_method == "GET" and not ((make System.regex("\\?"))|match(path) is System.null))
        [
            path = path + "&" + content;
            content = "";
        ],
        true
        [
            path = path + "?" + content;
            content = "";
        ]
    ];
    
    sock = make System.network.socket(System.network.socket.AF_INET,
                       System.network.socket.SOCK_STREAM,
                       0);
    sock|connect(host, port);
    sock|write(request_method + " " + path + " HTTP/1.0\r\n");
    property i;
    property j;
    property ret;
    options["headers"]|reset;
    i = options["headers"]|cur;

    while (not (i is System.null) or options["headers"]|next) [
        i = options["headers"]|cur;
        sock|write(i.key + ": " + i.item + "\r\n");
        i = null;
    ];
    
    sock|write("\r\n" + content + "\r\n");

    i = sock|readline;
    i = (make System.regex("HTTP/(1\\.\\d) (\\d\\d\\d)"))|match(i);
    ret = make interface.http.response();
    ret.status_code = i.captures[2];
    i = sock|readline;
    j = (make System.regex("(.*): ([^\r\n]*)\r?\n"))|match(i);
    while(not (j is System.null))
    [
        ret.headers|set(j.captures[1], j.captures[2]);
        i = sock|readline;
        j = (make System.regex("(.*): ([^\r\n]*)\r?\n"))|match(i);
    ];

    len = ret.headers["Content-Length"]|int;
    decide [
        (len > 0) [
            ret.content = sock|read(len);
        ],
        true [
            i = sock|read(512);
            while(not (i is System.null)) [
                ret.content = ret.content + i;
                i = sock|read(512);
            ];
        ]
    ];
    sock|close;

    ret.content_type = ret.headers["Content-Type"];
    ret.location = ret.headers["Location"];
    ret;
];
