##############################################################################
# Copyright (c) 2008, Mooneer Salem
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[Common Gateway Interface (CGI) request handler.]/

import "System.os";
import "System.file";

from interface.http.request_parser;

property already_parsed
    /[Has the request been read yet?]/;;

construct()
    /[Class constructor.]/
[
    base|__construct__;
    this.already_parsed = false;
];

method parse()
    /[Parse CGI request.]/
[
    decide
    [
        (this.already_parsed) [ null; ],
        true [ this|parse_helper; ]
    ];
];

method parse_helper()
    /[Force parsing, regardless of status (internal use only!)]/
[
    this.already_parsed = true;

    property ret;
    ret = make interface.http.cgi.cgi_request();

    ret.request_method = System.os|envGet("REQUEST_METHOD");
    ret.path_info = System.os|envGet("PATH_INFO");
    ret.query_string = System.os|envGet("QUERY_STRING");

    decide
    [
        (ret.request_method == "POST")
        [
            ret.content_length = System.os|envGet("CONTENT_LENGTH");
            this|read_content(ret);
        ]
    ];

    ret|parse_params;
    ret;
];

method read_content(
    obj /[Request object to use.]/
) /[Read content from standard input (for POST)]/
[
    ret.content = System.file.stdin|read(ret.content_length);
];

class cgi_request from interface.http.request
    /[CGI request object.]/
[
    construct()
        /[Class constructor.]/
    [
        base|__construct__;
    ],

    method emit_response(resp)
        /[Emit response.]/
    [
        resp|emit|print;
    ]
];
