##############################################################################
#
# Copyright (c) 2009, Michael J. Edgar. Dartmouth College, Class of 2010
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[ SMTP methods and classes.

 Typical usage:
 
 import "interface.pop3";
 pop = interface.pop3|connect("your.smtp.server",110);
 pop|authorize("username","password");
 ("You have "+pop|messagecount|str+" messages!")|print;
 pop|getmessage(1)|print;
 pop|close;

]/

import "System.exceptions";
import "System.collections";
import "System.regex";
import "System.network.socket";
import "System.digest";

class POPException from System.exceptions.exception
    /[The SMTP server is busy right now.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class POPUnknownError from System.exceptions.exception
    /[The SMTP server is busy right now.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];


class response [
  property status_code,
  property text,
  construct() [
    status_code = System.null;
    text = System.null;
  ],
  method find_code() [
    i = (make System.regex("([\\+\\-])(.*?)\n"))|match(text);
    this.status_code = i.captures[1];
    this|check_code;
  ],
  method check_code() [
    result = true;
    decide [
      (this.status_code == "+") [ result = true; ],
      (this.status_code == "-") [ result = false; make POPException(this.text)|throw; ],
      true                      [ result = true; ]
    ];
    result;
  ]
  
];

class pop3_connection [
  property socket,
  property apop_available,
  property apop_timestamp,
  construct(host,port) [
    sock = make System.network.socket(System.network.socket.AF_INET,
                       System.network.socket.SOCK_STREAM,
                       0);
    sock|connect(host, port);
    this.socket = sock;
    connstring = this.socket|readline;
    apop_checker = make System.regex("<.+>")|match(connstring);
    decide
    [
      (apop_checker is System.null)
        [ this.apop_available = false; ],
      true
        [ this.apop_available = true; this.apop_timestamp = apop_checker.captures[1];  ]
    ];
  ],
  method getresponse() [
    ret = make interface.pop3.response();
    i = socket|read(512);
    ret.text = i;
    ret.text|print;
    ret|find_code;
    ret|check_code;
    ret;
  ],
  method send(command) [
    this.socket|write(command+"\r\n");
    command|print;
    resp = this|getresponse();
    resp;
  ],
  method write(command)
  [
    this.socket|write(command+"\r\n");
    command|print;
  ],
  method stat() [
    result = this|send("STAT");
    count = make System.regex("\\+OK ([\\d]+) ([\\d]+)")|match(result.text).captures[1]|int;
    count;
  ],
  method retr(number) [
    this|write("RETR "+number|str);
    ret = make interface.pop3.response();
    sizeline = socket|readline;
    result = ""; i="";
    while (not (i is System.null)) [
      result = result + i;
      i = socket|read(10,100);
    ];
    /[result = this.socket|read(1023);]/
    ret.text = result;
    ret;
  ],
  
  method authorize(user,pass) [
    decide
    [
      (this.apop_available)
      [
        outputpass = digest|md5(apop_timestamp + pass);
        this|send("APOP " + user + " " + outputpass);
      ],
      true
      [
        this|send("USER " + user);
        this|send("PASS " + pass);
      ]
    ];
  ],
  
  method close() [
    this|write("QUIT");
    socket|close;
  ]
  
];

property conn /[ The SMTP connection that we work with, which handles all the socket logic. ]/ ;

method connect(host /[ The host you wish to connect to, e.g. smtp.gmail.com. ]/,
               port /[ The port the server is running on. Most servers use 110. ]/) 
/[ Connects to an smtp server at the given host and port, and identifies with the domain given
   by +helo+.
   
   host: the POP3 server to connect to.
   port: the port the server is running on.
   
   Typical Usage:
   
   pop = interface.pop3|connect("your.smtp.server",110);
   pop|authorize("username","password");
   ("You have "+pop|messagecount|str+" messages!")|print;
   pop|getmessage(1)|print;
   pop|close;
   
]/                        
[
  this.conn = make pop3_connection(host,port);
  this;
];

method messagecount() 
/[ Returns the number of messages on the server. ]/
[
   this.conn|stat;
];
method getmessage(id /[ The ID number of the message. Can be between 1-messagecount. ]/)
/[ Returns the message at index +id+. ]/
[
  this.conn|retr(id).text;
];

method authorize(username /[ The POP3 username for authentication ]/,
                 password /[ The POP3 password for authentication ]/)
/[ Authenticates you to the POP server.
   Supports basic POP3 authentication and APOP authentication. If the
   server supports APOP, it is used - otherwise, normal authentication is
   performed. ]/                 
[
  this.conn|authorize(username,password);
];


method close() 
/[ Closes the connection with the POP server, which also includes sending "QUIT". ]/
[
  this.conn|close;
];