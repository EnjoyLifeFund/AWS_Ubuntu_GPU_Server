##############################################################################
#
# Copyright (c) 2009, Michael J. Edgar. Dartmouth College, Class of 2010
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Kite Language organization nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY MOONEER SALEM ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL MOONEER SALEM BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
##############################################################################

/[ SMTP methods and classes.

 Typical usage:
 
 smtp = interface.smtp|connect('smtp.gmail.com',1234,'google.com');
 smtp|setheader("From","Michael Edgar <mje@michaeledgar.com>");
 smtp|setheader("Subject", "Free BMW");
 smtp|sendemail("My first email!.","from@from.com",["recipient@recipient.com","otherguy@recipient.com"]);
 smtp|close;

]/

import "System.exceptions";
import "System.collections";
import "System.regex";
import "System.network.socket";
class SMTPServerBusyException from System.exceptions.exception
    /[The SMTP server is busy right now.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];
class SMTPSyntaxErrorException from System.exceptions.exception
    /[The input command was invalid.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];
class SMTPFatalErrorException from System.exceptions.exception
    /[Something has gone terribly, terribly wrong.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];
class SMTPUnknownException from System.exceptions.exception
    /[Unsure what this error code, or, I just don't care.]/
[
    construct(
        msg /[Message to associate with given exception.]/
    ) /[Class constructor]/
    [
        base|__construct__(msg);
    ]
];

class response [
  property status_code,
  property text,
  construct() [
    status_code = System.null;
    text = System.null;
  ],
  method find_code() [
    i = (make System.regex("(\\d\\d\\d) (.*?)\n"))|match(text);
    this.status_code = i.captures[1];
  ],
  method check_code() [
    result = true;
    decide [
      (not (make System.regex("\\A2")|match(this.status_code) is System.null)) [ result = true; ],
      (not (make System.regex("\\A3")|match(this.status_code) is System.null)) [ result = true; ],
      (not (make System.regex("\\A4")|match(this.status_code) is System.null)) [ result = false; make System.exceptions.SMTPServerBusyException()|throw; ],
      (not (make System.regex("\\A50")|match(this.status_code) is System.null)) [ result = false; make System.exceptions.SMTPSyntaxErrorException()|throw; ],
      (not (make System.regex("\\A55")|match(this.status_code) is System.null)) [ result = false; make System.exceptions.SMTPFatalErrorException()|throw; ],
      true [ result = false; make System.exceptions.SMTPUnknownException()|throw; ]
    
    ];
    result;
  ]
  
];

class smtp_connection [
  property socket,
  
  construct(host,port) [
    sock = make System.network.socket(System.network.socket.AF_INET,
                       System.network.socket.SOCK_STREAM,
                       0);
    sock|connect(host, port);
    this.socket = sock;
    
  ],
  method getresponse() [
    ret = make interface.smtp.response();
    i = socket|read(512);
    ret.text = i;
    ret|find_code;
    ret;
  ],
  method send(command) [
    this.socket|write(command+"\r\n");
    resp = this|getresponse();
    resp;
  ],
  method write(command)
  [
    this.socket|write(command+"\r\n");
  ],
  method sayhelo(domain) [
    this|send("HELO "+ domain);
    /[ Check for Errors ]/
  ],
  method sendemail(message, emailfrom, recipients, headers) [
    this|send("MAIL From: " + emailfrom);
    /[ Check for Errors ]/
    globalresult = recipients|head|str;
    reciplist = (recipients|tail <| method(result,next) [ decide [(not (result is System.null)) [ globalresult = globalresult + "," + next|str; ]];]);
    
    this|send("RCPT To: " + globalresult);
    this|send("DATA");
    
    
    i = headers|cur;
    while (not (i is System.null) or headers|next) [
        i = headers|cur;
        this|write(i.key + ": " + i.item);
        i = null;
    ];
    this|write(message);
    this|send("."); 
  ],
  method close() [
    this|write("QUIT");
    socket|close;
  ]
  
];

property conn /[ The SMTP connection that we work with, which handles all the socket logic. ]/ ;
property headers /[ The Headers to send in the message. You should handle these with setheader(). ]/ ;

method connect(host /[ The host you wish to connect to, e.g. smtp.gmail.com. ]/,
               port /[ The port the server is running on. Most servers use 25. ]/,
               helo /[ The "domain" you will serve with the "HELO" command - you'll need to use
                        this with almost all SMTP servers, or you will be blocked.]/) 
/[ Connects to an smtp server at the given host and port, and identifies with the domain given
   by +helo+.
   
   host: the SMTP server to connect to.
   port: the port the server is running on.
   helo: the domain you serve to the HELO command - needed by 90% of the servers out there,
         or you will be blocked as a spambot.

   
]/                        
[
  this.conn = make smtp_connection(host,port);
  this.conn|sayhelo(helo);
  this.headers = make System.collections.binary_tree();
  this;
];

method setheader(key /[ The key of the header, e.g. "From" or "Subject"]/,
                 value /[ The value of the header, e.g. "Cool party tomorrow" as a subject]/) 
/[ Sets a mail header for the message you will send.
   
   key: Header key, e.g. "From" in "From: mje@michaeledgar.com"
   value: Header value, e.g. "mje@michaeledgar.com" in "From: mje@michaeledgar.com"

]/
[
  this.headers|set(key,value);
];

method sendemail(message /[the raw message to send. Could be HTML or plaintext.]/,
                 emailfrom /[the specified sender of the email.]/,
                 recipients /[the people you will send the email to, in any data type supporting iterators.]/) 
/[ Sends the specified SMTP message, from the sepcified person, to the list of recipients.
   
   message: the raw message to send. Could be HTML or plaintext.
   emailfrom: the specified sender of the email.
   recipients: the people you will send the email to, in any data type supporting iterators.
   
]/
[
  this.conn|sendemail(message,emailfrom,recipients,this.headers);
];
method close() 
/[ Closes the connection with the SMTP server, which also includes sending "QUIT". ]/
[
  this.conn|close;
];