Features

	* fResync should have an option to check the entire file for errors
	  instead of checking only the extremes.


Known bugs

	* fResync isn't 100% effective yet. CRC verification and
	  "bit reservoir" handling is lacking. Will be fixed in future
	  release of fIcy.

	* fResync will deliberately remove any form of ID3v1 or v2 tag if
	  run on a "sane" file.

	* There's no HDD fIcy can't fill.

