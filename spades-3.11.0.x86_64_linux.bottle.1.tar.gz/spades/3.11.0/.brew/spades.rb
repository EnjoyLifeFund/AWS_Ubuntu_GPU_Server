class Spades < Formula
  desc "SPAdes: de novo genome assembly"
  homepage "http://bioinf.spbau.ru/spades/"
  url "http://cab.spbu.ru/files/release3.11.0/SPAdes-3.11.0.tar.gz"
  sha256 "308aa3e6c5fb00221a311a8d32c5e8030990356ae03002351eac10abb66bad1f"
  # doi "10.1089/cmb.2012.0021"
  # tag "bioinformatics"

  depends_on "cmake" => :build
  depends_on :python unless OS.mac?

  needs :openmp

  fails_with :gcc => "4.7" do
    cause "Compiling SPAdes requires GCC >= 4.7 for OpenMP 3.1 support"
  end

  def install
    # Fix error: 'uint' does not name a type
    inreplace "src/projects/ionhammer/config_struct.hpp", "uint", "unsigned"

    mkdir "src/build" do
      system "cmake", "..", *std_cmake_args
      system "make", "install"
    end
  end

  test do
    system "#{bin}/spades.py", "--test"
  end
end
