class Fqzcomp < Formula
  homepage "https://sourceforge.net/projects/fqzcomp/"
  # doi '10.1371/journal.pone.0059190'
  # tag 'bioinformatics'
  url "https://downloads.sourceforge.net/project/fqzcomp/fqzcomp-4.6.tar.gz"
  sha256 "ff98f5a5e2c0351cdeacbd236aa25c7771ec8a4f547416c22a1b5c74a1875620"

  def install
    system "make"
    bin.install "fqz_comp"
    doc.install "README"
  end

  test do
    system "#{bin}/fqz_comp -h"
  end
end
