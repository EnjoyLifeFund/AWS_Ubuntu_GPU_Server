/* picdis.h  - constants and includes	*/
/* version 0.1				*/
/* (c) I.King 1994			*/

#include <stdio.h>
#include <ctype.h>

/*
#define PIC12	0
#define PIC14	1


#define LOWERCASE	0
#define UPPERCASE	1
*/

#define MAXPICSIZE 0x10000
#define CONFIGURATION_WORD 0x2007

/* ... The End ... */
