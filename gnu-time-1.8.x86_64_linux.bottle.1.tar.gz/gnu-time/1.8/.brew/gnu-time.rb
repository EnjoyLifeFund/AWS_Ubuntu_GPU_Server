class GnuTime < Formula
  desc "GNU implementation of time utility"
  homepage "https://www.gnu.org/software/time/"
  url "https://ftp.gnu.org/gnu/time/time-1.8.tar.gz"
  mirror "https://ftpmirror.gnu.org/time/time-1.8.tar.gz"
  sha256 "8a2f540155961a35ba9b84aec5e77e3ae36c74cecb4484db455960601b7a2e1b"

  option "with-default-names", "Do not prepend 'g' to the binary"

  def install
    args = [
      "--prefix=#{prefix}",
      "--mandir=#{man}",
      "--info=#{info}",
    ]

    args << "--program-prefix=g" if build.without? "default-names"

    system "./configure", *args
    system "make", "install"

    bin.install_symlink "time" => "gtime" if build.with?("default-names") && !OS.mac?
  end

  test do
    if OS.mac?
      system bin/"gtime", "ruby", "--version"
    else
      system bin/"gtime", bin/"gtime", "--version"
    end
  end
end
