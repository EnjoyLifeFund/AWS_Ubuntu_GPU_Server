/*
Copyright (c) 2015 Microsoft Corporation. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Robert Y. Lewis, Leonardo de Moura
*/
#pragma once
namespace lean {
void initialize_norm_num_tactic();
void finalize_norm_num_tactic();
}
