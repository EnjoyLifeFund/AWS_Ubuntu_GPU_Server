/*
Copyright (c) 2014 Microsoft Corporation. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

Author: Leonardo de Moura
*/
#pragma once

#define LEAN_XSTR(x) #x
#define LEAN_STR(x) LEAN_XSTR(x)
