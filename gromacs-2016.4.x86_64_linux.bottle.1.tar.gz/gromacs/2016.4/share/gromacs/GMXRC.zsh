# zsh configuration file for Gromacs
# only kept for backwards compatibility
source @@HOMEBREW_PREFIX@@/Cellar/gromacs/2016.4/bin/GMXRC.bash
