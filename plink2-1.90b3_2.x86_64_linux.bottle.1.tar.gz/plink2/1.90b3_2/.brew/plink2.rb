class Plink2 < Formula
  desc "Analyze genotype and phenotype data"
  homepage "https://www.cog-genomics.org/plink2"
  url "https://github.com/chrchang/plink-ng/archive/v1.90b3.tar.gz"
  version "1.90b3"
  # doi "10.1186/s13742-015-0047-8"
  # tag "bioinformatics"
  sha256 "2f4afc193c288b13af4410e4587358ee0a6f76ed7c98dd77ca1317aac28adf0d"
  revision 2
  head "https://github.com/chrchang/plink-ng"

  depends_on :fortran
  depends_on "zlib"
  if OS.mac?
    depends_on "openblas" => :optional
  else
    depends_on "openblas" => :recommended
  end

  def install
    mv "Makefile.std", "Makefile"
    ln_s Formula["zlib"].opt_include, "zlib-1.2.8"
    cflags = "-Wall -O2 -flax-vector-conversions"
    cflags += " -I#{Formula["openblas"].opt_include}" if build.with? "openblas"
    args = ["CFLAGS=#{cflags}", "ZLIB=-L#{Formula["zlib"].opt_lib} -lz"]
    args << "BLASFLAGS=-L#{Formula["openblas"].opt_lib} -lopenblas" if build.with? "openblas"
    system "make", "plink", *args
    bin.install "plink" => "plink2"
  end

  test do
    system "#{bin}/plink2", "--dummy", "513", "1423", "0.02", "--out", "dummy_cc1"
    assert File.exist?("dummy_cc1.bed")
  end
end
