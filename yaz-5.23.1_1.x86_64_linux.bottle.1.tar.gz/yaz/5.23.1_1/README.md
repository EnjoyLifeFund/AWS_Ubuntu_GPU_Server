## YAZ toolkit

Copyright (C) 1995-2017 Index Data.
See the file LICENSE for details.

The primary output of the source here is the
[YAZ](http://www.indexdata.com/yaz) library, which contains support
functions for implementing the server or client role of Z39.50 and SRU.

For more information about YAZ refer to the documentation in sub
directory `doc` or 
[online](http://www.indexdata.com/yaz/doc).

To get more information or assistance, send mail to yaz-help@indexdata.dk.
Even better, sign on to the
[YAZ mailing list](http://lists.indexdata.dk/cgi-bin/mailman/listinfo/yazlist)

