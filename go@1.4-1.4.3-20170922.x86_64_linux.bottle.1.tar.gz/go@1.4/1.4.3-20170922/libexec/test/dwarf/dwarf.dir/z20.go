
//line x20.go:4
package main
func F20() {}
