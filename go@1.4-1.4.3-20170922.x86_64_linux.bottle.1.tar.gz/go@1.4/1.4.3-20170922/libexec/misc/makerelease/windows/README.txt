
Windows build dependencies

- Mercurial (hg): http://mercurial.selenic.com/
- MinGW: http://www.mingw.org/
- Windows Installer XML (WiX) toolset: http://wix.sourceforge.net/

Packaging

The dependencies must be in/added to the system's search PATH. 

Run bindist as normal, eg:
	bindist windows-386

TODO

- Documentation server shortcut checkbox option

Misc

WiX box sizes:
 - banner size: 493x58
 - left side of dialog: 164x312
 - full dialog size: 493x312

