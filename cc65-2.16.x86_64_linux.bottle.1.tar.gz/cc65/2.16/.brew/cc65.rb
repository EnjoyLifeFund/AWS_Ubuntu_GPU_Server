class Cc65 < Formula
  desc "6502 C compiler"
  homepage "https://cc65.github.io/cc65/"
  url "https://github.com/cc65/cc65/archive/V2.16.tar.gz"
  sha256 "fdbbf1efbf2324658a5774fdceef4a1b202322a04f895688d95694843df76792"

  head "https://github.com/cc65/cc65.git"

  conflicts_with "grc", :because => "both install `grc` binaries"

  def install
    ENV.deparallelize

    make_vars = ["prefix=#{prefix}", "libdir=#{share}"]

    system "make", *make_vars
    system "make", "install", *make_vars
  end

  def caveats
    <<~EOS
      Library files have been installed to:
        #{pkgshare}
    EOS
  end

  test do
    (testpath/"foo.c").write "int main (void) { return 0; }"

    system bin/"cl65", "foo.c" # compile and link
    assert_predicate testpath/"foo", :exist? # binary
  end
end
