// MissingGlyphExample.cpp

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <LASi.h>

using namespace LASi;
using namespace std;

int main(const int argc, char* const argv[]) 
{
  ofstream strm;

  try {
    PostscriptDocument doc;
    int i, lineSpacing = 25, x=10, y=800;
    int nstrings = 12;
    const char * strings[12] = {
      "Display glyphs that are often missing on most systems to verify that",
      "libLASi does the right thing in these cases (displays an empty box).",
      "",
      "Unicode U+0802: ࠂ",
      "Unicode U+088A: ࢪ",
      "Unicode U+2AF4: ⫴", 
      "Unicode U+2AF5: ⫵", 
      "Unicode U+2AF6: ⫶", 
      "Unicode U+2AF7: ⫷", 
      "Unicode U+2AF8: ⫸", 
      "Unicode U+1010A: 𐄊",
      "Unicode U+1F70A: 🜊",
    };

    //
    // Set font to generic "serif":
    //
    doc.osBody() << setFont("Arial") << setFontSize(18) << endl;
    doc.osBody() << x << " " << y << " moveto" << endl;
    for(i=0;i<nstrings; i++)
    {
      doc.osBody() << show(strings[i]);
      y -= lineSpacing;
      doc.osBody() << x << " " << y << " moveto" << endl;
    }

    //
    // Postscript showpage:
    //
    doc.osBody() << "showpage" << endl;
    
    if (argc == 1) {
      doc.write(cout);
    }
    else {
      strm.open(argv[1]);
      doc.write(strm);
      strm.close();
    }
    
  } catch (runtime_error& e) {
  
    cerr << e.what() << endl;
    return 1;
    
  }

  return 0;
  
}

