# bamkit
Tools for common BAM file manipulations
