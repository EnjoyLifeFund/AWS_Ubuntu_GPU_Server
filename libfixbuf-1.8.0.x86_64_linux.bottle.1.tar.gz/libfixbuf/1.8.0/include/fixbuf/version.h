/* version.h
 *
 * This is a generated file.  Please modify 'configure.ac'
 */

#ifndef __FB_VERSION_H__
#define __FB_VERSION_H__

#define FIXBUF_VERSION_MAJOR 1
#define FIXBUF_VERSION_MINOR 8
#define FIXBUF_VERSION_RELEASE 0
#define FIXBUF_VERSION_BUILD 0

#endif /* __FB_VERSION_H__ */
