require 'spec_helper'

describe Celluloid::IO::Mailbox do
  it_behaves_like "a Celluloid Mailbox"
end
