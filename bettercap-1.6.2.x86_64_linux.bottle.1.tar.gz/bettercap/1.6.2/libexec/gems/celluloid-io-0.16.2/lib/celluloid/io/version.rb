module Celluloid
  module IO
    VERSION = "0.16.2"
  end
end
