require 'spec_helper'

describe Celluloid::Mailbox do
  it_behaves_like "a Celluloid Mailbox"
end
