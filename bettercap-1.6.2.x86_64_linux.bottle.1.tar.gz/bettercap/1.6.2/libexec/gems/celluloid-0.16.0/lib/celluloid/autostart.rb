require 'celluloid'

Celluloid.start
