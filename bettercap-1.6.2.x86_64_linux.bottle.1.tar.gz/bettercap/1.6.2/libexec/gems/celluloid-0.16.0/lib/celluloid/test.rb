$CELLULOID_TEST = true

require 'celluloid'
