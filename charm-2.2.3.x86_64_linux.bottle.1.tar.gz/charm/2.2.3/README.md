# charmstore-client

The charmstore-client repository holds client-side code for interacting
with the Juju charm store.

To install:

```
go get github.com/juju/charmstore-client
cd $GOPATH/src/github.com/juju/charmstore-client
make deps install
```

You'll then be able to run `$GOPATH/bin/charm`.

