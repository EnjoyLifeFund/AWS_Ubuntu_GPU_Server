class Bam < Formula
  desc "Build system that uses Lua to describe the build process"
  homepage "https://matricks.github.io/bam/"
  url "https://github.com/matricks/bam/archive/v0.5.0.tar.gz"
  sha256 "16c0bccb6c5dee62f4381acaa004dd4f7bc9a32c10d0f2a40d83ea7e2ae25998"
  head "https://github.com/matricks/bam.git"

  # Fixes "[string "src/tools.lua"]:165: no driver set"; patch is from upstream
  patch do
    url "https://github.com/matricks/bam/commit/27b28f09.patch?full_index=1"
    sha256 "9dabe77480156b49dda02378a936597e5f6b1aefaae2d88f2887c6161675d5ee"
  end

  def install
    system "./make_unix.sh"
    bin.install "bam"
  end

  test do
    (testpath/"hello.c").write <<~EOS
      #include <stdio.h>
      int main() {
        printf("hello\\n");
        return 0;
      }
    EOS

    (testpath/"bam.lua").write <<~EOS
      settings = NewSettings()
      objs = Compile(settings, Collect("*.c"))
      exe = Link(settings, "hello", objs)
    EOS

    system bin/"bam", "-v"
    assert_equal "hello", shell_output("./hello").chomp
  end
end
