class Scarpa < Formula
  homepage "http://compbio.cs.toronto.edu/hapsembler/scarpa.html"
  # doi "10.1093/bioinformatics/bts716"
  # tag "bioinformatics"

  url "http://compbio.cs.toronto.edu/hapsembler/scarpa-0.241.tar.gz"
  sha256 "a5e71d63b8c828d4bd0ee081d1c5250ce25ffa52b4b2a8759d2a75ce2863d558"

  depends_on "lp_solve"

  def install
    rm Dir["liblpsolve55.*"]
    inreplace "makefile", "liblpsolve55.a", "-llpsolve55"
    system "make"
    bin.install "bin/scarpa"
    doc.install "SCARPA.README"
  end

  test do
    system "#{bin}/scarpa", "--version"
  end
end
