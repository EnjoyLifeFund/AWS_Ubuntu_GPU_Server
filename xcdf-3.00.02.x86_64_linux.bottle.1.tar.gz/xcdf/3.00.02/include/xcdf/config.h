/*!
 * @file config.h
 * @brief Build-time constants.
 * @author Segev BenZvi
 * @date 25 Oct 2013
 * @version $Id$
 */

#ifndef XCDF_CONFIG_H_INCLUDED
#define XCDF_CONFIG_H_INCLUDED

#ifndef XCDF_MAJOR_VERSION
#define XCDF_MAJOR_VERSION 3
#endif

#ifndef XCDF_MINOR_VERSION
#define XCDF_MINOR_VERSION 0
#endif

#ifndef XCDF_PATCH_VERSION
#define XCDF_PATCH_VERSION 1
#endif

#endif // XCDF_CONFIG_H_INCLUDED
