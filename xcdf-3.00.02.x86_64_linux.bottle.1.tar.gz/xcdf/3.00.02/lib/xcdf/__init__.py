# Python wrapper to XCDF bindings in pyxcdf library.
# $Id: __init__.py.in 15395 2013-05-31 22:45:48Z sybenzvi $

__version__ = "3.0.1"

from pyxcdf import XCDFFile
from Histogram import Histogram as Histogram

