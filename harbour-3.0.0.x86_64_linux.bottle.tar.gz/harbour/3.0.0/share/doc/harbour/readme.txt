/*
 * $Id: readme.txt 14669 2010-06-03 08:43:47Z vszakats $
 */

                             Welcome to Harbour
                             ==================

Harbour is a free software compiler for the xBase superset language often
referred to as Clipper (the language that is implemented by the compiler
CA-Cl*pper). The goal of the Harbour project is to produce a cross platform
CA-Cl*pper compatible compiler.

The Harbour web site is at <URL:http://harbour-project.org/>. If you
have any problems with this copy of Harbour please visit our web site and
ensure that you are using the latest release.

If you have any questions about Harbour please be sure to read the FAQ
<URL:http://harbour-project.org/faq/>. Also, please be sure to read the
documentation that comes with Harbour, you should find it in the same
directory in which you found this file.

If you are reading this file as part of a source distribution of harbour you
probably want to start by reading dirstruc.txt because this is your map to
the harbour source directories.
