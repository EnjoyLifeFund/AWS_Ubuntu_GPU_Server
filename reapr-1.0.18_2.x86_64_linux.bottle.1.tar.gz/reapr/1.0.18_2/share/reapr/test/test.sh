#!/usr/bin/env bash
set -e

echo "
test smaltmap

"
reapr smaltmap -u 5 assembly.fa reads_longinsert_1.fastq reads_longinsert_2.fastq out.smaltmap.bam
echo "
smaltmap OK
______________________________________________________________________________

test perfectmap

"

reapr perfectmap assembly.fa reads_shortinsert_1.fastq reads_shortinsert_2.fastq 165 out.perfectmap
echo "
perfectmap OK
______________________________________________________________________________

test pipeline

"

reapr pipeline assembly.fa mapped_reads.bam out.pipeline perfect
echo "
pipeline OK
______________________________________________________________________________

All looked OK so cleaning files...
"

rm -fr out.*

echo "
All done!
"

