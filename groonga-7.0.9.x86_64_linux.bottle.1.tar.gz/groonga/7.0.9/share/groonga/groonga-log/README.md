# README

[![Build Status](https://travis-ci.org/groonga/groonga-log.png?branch=master)](https://travis-ci.org/groonga/groonga-log)

## Name

groonga-log

## Description

Groonga-log is a collection of library and tools to
process [Groonga](http://groonga.org/)'s log.

Groonga's log is logged when `--log-path` option is specified. You can
write a program to process Groonga log by using groonga-log as a
library.

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'groonga-log'
```

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install groonga-log

## Usage

TODO: Write usage instructions here

## Dependencies

TODO:

## License

LGPLv2.1 or later. See doc/text/lgpl-2.1.txt for details.
