class RnaStar < Formula
  desc "RNA-seq aligner"
  homepage "https://github.com/alexdobin/STAR"
  # doi "10.1093/bioinformatics/bts635"
  # tag "bioinformatics"

  url "https://github.com/alexdobin/STAR/archive/2.5.3a.tar.gz"
  version "2.5.3a"
  sha256 "2a258e77cda103aa293e528f8597f25dc760cba188d0a7bc7c9452f4698e7c04"
  head "https://github.com/alexdobin/STAR.git"

  # Fix error: 'omp.h' file not found
  needs :openmp

  needs :cxx11

  def install
    ENV.cxx11
    cd "source" do
      progs = %w[STAR STARlong]
      targets = OS.mac? ? %w[STARforMacStatic STARlongForMacStatic] : progs
      system "make", *targets
      bin.install progs
    end
    pkgshare.install "extras"
    doc.install (buildpath/"doc").children
    mv "RELEASEnotes.md", "NOTES.md"
  end

  test do
    system "#{bin}/STAR", "--version"
    system "#{bin}/STARlong", "--version"
  end
end
