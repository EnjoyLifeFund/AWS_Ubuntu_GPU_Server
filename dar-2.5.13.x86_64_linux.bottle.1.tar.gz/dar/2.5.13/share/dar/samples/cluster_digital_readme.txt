What follows is an extract from several email exchange with Roi Rodriguez.
Denis.

----
"[the] remote copy feature needs to use a ssh authentication method which
doesn't prompt for a password (in order to make it non-interactive, so you
can run it from cron. It's no needed if someone plan to run it by hand, of
course). I've added this comment at the beginning of the script."
----