class Archivemount < Formula
  desc "File system for accessing archives using libarchive"
  homepage "http://www.cybernoia.de/software/archivemount.html"
  url "http://www.cybernoia.de/software/archivemount/archivemount-0.8.7.tar.gz"
  sha256 "47045ca8d4d62fbe0b4248574c65cf90a6d29b488d166aec8c365b6aafe131b6"
  head "http://cybernoia.de/software/archivemount/git"

  depends_on "pkg-config" => :build
  depends_on "libarchive"
  depends_on :osxfuse

  def install
    system "./configure", "--disable-debug",
                          "--disable-dependency-tracking",
                          "--disable-silent-rules",
                          "--prefix=#{prefix}"

    system "make", "install"
  end

  test do
    system bin/"archivemount", "--version"
  end
end
