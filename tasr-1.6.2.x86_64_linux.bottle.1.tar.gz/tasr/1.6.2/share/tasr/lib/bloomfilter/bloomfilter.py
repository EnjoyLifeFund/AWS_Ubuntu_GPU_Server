import bloomfilter_ext
a= bloomfilter_ext.BloomFilter(1000, 5, 4);
print a;

print "Works!"


