#ifndef _APNGASM_VERSION_H_
#define _APNGASM_VERSION_H_

namespace apngasm {
  static const char* APNGASM_VERSION = "3.1.6";
} // namespace apngasm

#endif  // _APNGASM_VERSION_H_
