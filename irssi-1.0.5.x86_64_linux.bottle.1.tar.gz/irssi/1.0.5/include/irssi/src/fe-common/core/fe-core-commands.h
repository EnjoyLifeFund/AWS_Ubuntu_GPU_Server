#ifndef __FE_CORE_COMMANDS_H
#define __FE_CORE_COMMANDS_H

extern int command_hide_output;

void fe_core_commands_init(void);
void fe_core_commands_deinit(void);

#endif
