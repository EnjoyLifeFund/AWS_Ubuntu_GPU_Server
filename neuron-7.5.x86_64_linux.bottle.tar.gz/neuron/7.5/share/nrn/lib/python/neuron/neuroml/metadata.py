def notes(self, node):
  pass

def properties(self, node):
 pass

def property(self, node):
  pass

def tag(self, node):
  pass

def value(self, node):
  pass

