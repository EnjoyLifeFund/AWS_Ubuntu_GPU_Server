#ifndef nrnapi_h
#define nrnapi_h

#define NRNAPI 2

#endif

