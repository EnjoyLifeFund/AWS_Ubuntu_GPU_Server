#
# Settings that specify the version of BroControl
#

VERSION = "1.7"
BROBASE = "@@HOMEBREW_PREFIX@@/Cellar/bro/2.5.2"
CFGFILE = "@@HOMEBREW_PREFIX@@/etc/broctl.cfg"
BROSCRIPTDIR = "@@HOMEBREW_PREFIX@@/Cellar/bro/2.5.2/share/bro"
