(* tag::snippet[] *)
let s = SS.empty;;
(* end::snippet[] *)
