module Asciidoctor
  VERSION = '1.5.6.1'
end
