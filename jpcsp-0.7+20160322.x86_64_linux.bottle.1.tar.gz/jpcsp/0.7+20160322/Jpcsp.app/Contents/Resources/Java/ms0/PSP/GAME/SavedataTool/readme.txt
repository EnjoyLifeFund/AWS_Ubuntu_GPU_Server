see savedatatool.c
