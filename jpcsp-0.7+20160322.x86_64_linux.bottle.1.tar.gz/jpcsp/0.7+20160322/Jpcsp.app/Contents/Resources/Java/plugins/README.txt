           &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
     &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   &&&&&&&&&*********&&&*********&&&********&&&&*******&&&*********&&&&&&&&&
 &&&&&&&&&&&&&&&&****&&&***&&&&**&&&***&&&&&&&&***&&&&&&&&***&&&&**&&&&&&&&&&&
&&&&&&&&&&&&&&&&&****&&&***&&&&**&&&***&&&&&&&&***&&&&&&&&***&&&&**&&&&&&&&&&&&
&&&&&&&&&&&&&&&&&****&&&*********&&&***&&&&&&&&&*****&&&&&*********&&&&&&&&&&&&
&&&&&&&&&&&&&&&&&****&&&***&&&&&&&&&***&&&&&&&&&&&&***&&&&***&&&&&&&&&&&&&&&&&&
 &&&&&&&&&&&&&&&&****&&&***&&&&&&&&&***&&&&&&&&&&&&***&&&&***&&&&&&&&&&&&&&&&
  &&&&&&&&&&&*******&&&&***&&&&&&&&&********&&&******&&&&&***&&&&&&&&&&&&&&&
    &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
           &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

*******************************************************************************					
[JPCSP PLUGINS]:

This folder contains 3rd party plugins coded for JPCSP.

Instructions:
- Open the folder corresponding to your PC's architecture
  (e.g.: plugins/windows-amd64).
- Copy the .dll file to JPCSP's lib/[YOUR PC'S ARCHITECTURE] folder 
  (e.g.: lib/windows-amd64).
- Start JPCSP and if the plugin is detected, it's option will be activated 
  under the "Plugins" menu.

Plugins:
- XBRZ4JPCSP:
	A xBRZ texture filter plugin by shenweip based on PPSSPP and HqMAME 
        (https://github.com/shenweip/XBRZ4JPCSP).
*******************************************************************************	

If you wish to add your plugin to JPCSP, please contact us at 
http://www.emunewz.net/forum/index.php or https://code.google.com/p/jpcsp/