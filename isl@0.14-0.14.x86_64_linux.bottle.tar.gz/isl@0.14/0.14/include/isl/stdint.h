#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.14"
/* generated using gnu compiler gcc-4.8 (Ubuntu 4.8.4-2ubuntu1~14.04.3) 4.8.4 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
