function EmptyModule() {
    'use asm';
    return {};
}
