int foo() {
  return 43;
}
