int foo() {
  return 42;
}

void bar();

int main() {
  foo();
  bar();
}
