class Afra < Formula
  desc "Alignmen-free support values"
  homepage "https://github.com/EvolBioInf/afra"
  # tag "bioinformatics"

  url "https://github.com/EvolBioInf/afra/releases/download/v2.1/afra-v2.1.tar.gz"
  sha256 "e4042de524bc6a979a56fb6f7dba4e163e97ba1047854a385ddebc3ea090d2d3"
  head "https://github.com/EvolBioInf/afra.git"

  needs :openmp

  depends_on "autoconf" => :build
  depends_on "automake" => :build

  def install
    system "./configure",
      "--disable-dependency-tracking",
      "--prefix=#{prefix}"
    system "make", "install"
  end

  test do
    assert_match "quartet", shell_output("#{bin}/afra --help 2>&1", 0)
  end
end
