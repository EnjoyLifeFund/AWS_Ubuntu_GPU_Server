class Minia < Formula
  desc "Short-read assembler of a Bloom filter de Bruijn graph"
  homepage "http://minia.genouest.org/"
  # doi "10.1186/1748-7188-8-22"
  # tag "bioinformatics"

  url "https://github.com/GATB/minia/releases/download/v2.0.7/minia-v2.0.7-Source.tar.gz"
  sha256 "76d96dc14b8c4c01e081da6359c3a8236edafc5ef93b288eaf25f324de65f3ce"

  depends_on "cmake" => :build
  depends_on "imagemagick" => :build if build.with? "tex"
  depends_on :tex => [:build, :optional]

  def install
    mkdir "build" do
      args = std_cmake_args
      # Fix error: 'hdf5/hdf5.h' file not found
      args.delete "-DCMAKE_BUILD_TYPE=Release"
      args << "-DSKIP_DOC=1" if build.without? "docs"
      system "cmake", "..", *args
      system "make"
      system "make", "install"
      # Resolve conflict with hdf5: https://github.com/GATB/minia/issues/5
      mv bin/"h5dump", bin/"minia-h5dump"
    end
  end

  test do
    assert_match "options", shell_output("#{bin}/minia")
  end
end
