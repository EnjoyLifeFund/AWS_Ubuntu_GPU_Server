class Grabix < Formula
  desc "Tool for random access into BGZF files"
  homepage "https://github.com/arq5x/grabix"
  # tag "bioinformatics"
  url "https://github.com/arq5x/grabix/archive/0.1.6.tar.gz"
  sha256 "a1c92311501f583ad1912b6e0394f95d06b8e3aafe1db6a7ba517d5aed161043"
  head "https://github.com/arq5x/grabix.git"

  def install
    system "make"
    bin.install "grabix"
    doc.install "README.md"
    pkgshare.install "simrep.chr1.bed"
  end

  test do
    assert_equal `#{bin}/grabix check #{pkgshare}/simrep.chr1.bed`.chomp, "no"
  end
end
