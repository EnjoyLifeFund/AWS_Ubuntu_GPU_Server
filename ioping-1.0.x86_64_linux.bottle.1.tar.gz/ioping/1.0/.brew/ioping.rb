class Ioping < Formula
  desc "Tool to monitor I/O latency in real time"
  homepage "https://github.com/koct9i/ioping"
  url "https://github.com/koct9i/ioping/archive/v1.0.tar.gz"
  sha256 "db999abb0f9de00bce800267965cdd9b826ebce6052e905b12d9f40076157088"

  head "https://github.com/koct9i/ioping.git"

  def install
    system "make"
    system "make", "install", "PREFIX=#{prefix}"
  end

  test do
    system "#{bin}/ioping", "-c", "1", testpath
  end
end
